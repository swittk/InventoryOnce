/** Exact clean-hub source commit used by every dependency-closure equation. */
export const CATALOG_READ_CLEAN_HUB_COMMIT =
  "2eea09471b3bf8fcb61f38256e1c6a362149dad4";

/** Official 535-callable compiler surface retained by clean hub e46b42b. */
export const CATALOG_READ_OFFICIAL_SURFACE_DIGEST =
  "6a3bdd7dd66a3e352c1dca251d654406a5b25bef3c502c5392785384be5b93c1";

/** Universal receiver/input domain for the six pure frozen-snapshot reads. */
export const CATALOG_READ_DEPENDENCY_CLOSURE_DOMAIN =
  "ALL_VALIDATED_NATIVE_CATALOGS_AND_COHERENT_FROZEN_PUBLISHED_SNAPSHOTS_AT_2EEA094_V1";

/** Independently stated laws that determine every newly proved helper result. */
export const CATALOG_READ_FAMILY_LAWS = Object.freeze([
  Object.freeze({
    lawId: "deterministic-position-selection-v1",
    sourceFiles: Object.freeze(["src/projection.ts"]),
    equation:
      "Positions(selector) is the canonical-identity-ordered sequence of exactly those projection rows reached by the narrowest available item/revision/location index and satisfying the normalized selector; every dangling index reference throws.",
  }),
  Object.freeze({
    lawId: "exact-stock-summary-v1",
    sourceFiles: Object.freeze(["src/read-model.ts", "src/measurement-schema.ts"]),
    equation:
      "StockSummary groups Positions(selector) by exact item revision, includes the requested/active zero row, adds exact measurement vectors for signed, physical, deficit, optional-identity, and qualified-dimension buckets, and orders every observable sequence by its immutable identity.",
  }),
  Object.freeze({
    lawId: "simultaneous-availability-v1",
    sourceFiles: Object.freeze(["src/availability.ts", "src/deficits.ts"]),
    equation:
      "Availability at canonical time t is physical stock minus the once-per-location-pool recorded deficit and all active competing claims, clamped at zero per exact axis, together with the feasibility status of the same complete reservation graph.",
  }),
  Object.freeze({
    lawId: "bounded-exact-allocation-v1",
    sourceFiles: Object.freeze(["src/allocation.ts", "src/picking.ts"]),
    equation:
      "Allocation validates time/item/selector/amount, excludes disallowed expiry and claims, pays each selected deficit pool once, searches the complete bounded increment state space before deterministic FIFO/FEFO fallback, and returns exact lines, shortfalls, deficits, and explanation flags without changing the snapshot.",
  }),
  Object.freeze({
    lawId: "exact-packaging-list-v1",
    sourceFiles: Object.freeze(["src/events.ts"]),
    equation:
      "Every observed authority time must be a non-empty canonical ISO instant; invalid or non-canonical spellings throw before read semantics can depend on them.",
  }),
  Object.freeze({
    lawId: "exact-collection-rollup-v1",
    sourceFiles: Object.freeze(["src/collections.ts"]),
    equation:
      "CollectionSummary resolves the exact retained definition, summarizes every exact member under one normalized scope, and emits only declared scalar rollups using exact reference conversion and stable member/contribution ordering.",
  }),
  Object.freeze({
    lawId: "simultaneous-reservation-feasibility-v1",
    sourceFiles: Object.freeze(["src/reservations.ts"]),
    equation:
      "Reservation feasibility groups active claims by exact competing axis, applies shared deficit burden, exhaustively assigns bounded indivisible groups, then computes maximum continuous bigint flow; feasible means and only means total fulfillable minor units equal total requested minor units.",
  }),
  Object.freeze({
    lawId: "immutable-catalog-extension-v1",
    sourceFiles: Object.freeze(["src/catalog.ts"]),
    equation:
      "Catalog extension unions each revision family by exact revision id, accepts an existing id only when its independently certified digest is equal, overlays only supplied active pointers, revalidates the whole catalog, and preserves object identity exactly when the resulting digest is unchanged.",
  }),
]);

/** Separate non-executed equation sources used for genuinely new helper algorithms. */
export const CATALOG_READ_EXPECTED_LAW_FILES = Object.freeze([
  "allocation",
  "availability",
  "collections",
  "deficits",
  "events",
  "measurement-schema",
  "picking",
  "projection",
  "read-model",
  "reservations",
].map((family) =>
  `experiments/tla-conformance/authority-r5/catalog-read-laws/${family}.expected.ts.txt`,
));

/** Exact prior certificate identities reused as dependencies rather than copied proof trees. */
export const CATALOG_READ_REUSED_CERTIFICATES = Object.freeze([
  Object.freeze({
    family: "quantity-measurement",
    proofKind: "inventoryonce-quantity-measurement-complete-source-equations-v1",
    artifactSha256:
      "f5b31c828b402fa98d0787a5b1e02a23290e86bdaad81f2ffed9f775358e284c",
    certificateId:
      "VALUE_CERTIFICATE_FAMILY:sha256:22f777b6f641ae5af58c1236b6e6e2e9f2257d95551ed957bd59447662d4c310",
  }),
  Object.freeze({
    family: "identity-selector",
    proofKind: "independent-identity-values-closed-equations-v1",
    artifactSha256:
      "d5e629e6f18e8357b7042529cb946852d14d19c3757cfc43779ee37306219c8f",
    certificateId: "inventoryonce.identity-values.closed-source-equations.v1",
  }),
  Object.freeze({
    family: "catalog-snapshot",
    proofKind: "independent-catalog-snapshot-closed-equations-v1",
    artifactSha256:
      "110326f4da80463c077efeb9a23d69e048005dc6c185e7ca4ef9ce0332848d9c",
    certificateId: "official-clean-hub-2f39cfe/catalog-family.json",
  }),
  Object.freeze({
    family: "catalog-published-direct-source",
    proofKind: "complete-source-equations-v1",
    artifactSha256:
      "e767440999da004ef44d685d55c27fa1769d225e0539be990a379c283dfe597a",
    certificateId:
      "SOURCE_EQUATION_FAMILY:sha256:86ca8e3a561802d5f5e17b72ed83263c8b48a40a611ad0755dfda48960df3cfe",
  }),
  Object.freeze({
    family: "catalog-snapshot-alias",
    proofKind: "semantic-contract-source-closed-v1",
    artifactSha256:
      "523fb3bd2e3321a9fafff68fae450d6ee71851b5a853829ecbf14bd4fb15db6d",
    certificateId: "official-clean-hub-2f39cfe/semantic-evidence.json",
  }),
]);

/** Fresh runtime constants and class storage appearing in the helper closure. */
export const CATALOG_READ_EXPECTED_RUNTIME_VALUES = Object.freeze([
  Object.freeze({ key: "src/allocation.ts#const:MAXIMUM_EXACT_ALLOCATION_DEPTH", law: Object.freeze(["integer", "5000"]) }),
  Object.freeze({ key: "src/allocation.ts#const:MAXIMUM_EXACT_ALLOCATION_STATES", law: Object.freeze(["integer", "100000"]) }),
  Object.freeze({ key: "src/allocation.ts#enum:InventoryAllocationMethod", law: Object.freeze(["enum", Object.freeze([Object.freeze(["Fifo", "fifo"]), Object.freeze(["Fefo", "fefo"])])]) }),
  Object.freeze({ key: "src/reservations.ts#const:MAXIMUM_RESERVATION_FEASIBILITY_EDGES", law: Object.freeze(["integer", "8192"]) }),
  Object.freeze({ key: "src/reservations.ts#const:MAXIMUM_RESERVATION_FEASIBILITY_POSITIONS", law: Object.freeze(["integer", "512"]) }),
  Object.freeze({ key: "src/reservations.ts#const:MAXIMUM_RESERVATION_FEASIBILITY_RESERVATIONS", law: Object.freeze(["integer", "128"]) }),
  Object.freeze({ key: "src/reservations.ts#const:MAXIMUM_RESERVATION_FEASIBILITY_STATES", law: Object.freeze(["integer", "100000"]) }),
  Object.freeze({ key: "src/reservations.ts#enum:InventoryReservationFeasibilityStatus", law: Object.freeze(["enum", Object.freeze([Object.freeze(["Feasible", "feasible"]), Object.freeze(["Shortage", "shortage"])])]) }),
  Object.freeze({ key: "src/reservations.ts#enum:InventoryReservationStatus", law: Object.freeze(["enum", Object.freeze([Object.freeze(["Active", "active"]), Object.freeze(["Released", "released"]), Object.freeze(["Consumed", "consumed"]), Object.freeze(["Expired", "expired"])])]) }),
  Object.freeze({ key: "src/reservations.ts#field:BigIntFlowNetwork.adjacency", law: Object.freeze(["fresh-map"]) }),
  Object.freeze({ key: "src/reservations.ts#field:BigIntFlowNetwork.residual", law: Object.freeze(["fresh-map"]) }),
]);

/** Pure helper exports whose implementations are already roots of the six snapshot proofs. */
export const CATALOG_READ_HELPER_ALIAS_BINDINGS = Object.freeze([
  Object.freeze({ surfaceKey: "export:.#summarizeInventoryAvailability::call[0]", equationKey: "src/availability.ts#summarizeInventoryAvailability" }),
  Object.freeze({ surfaceKey: "export:./kernel#summarizeInventoryAvailability::call[0]", equationKey: "src/availability.ts#summarizeInventoryAvailability" }),
  Object.freeze({ surfaceKey: "export:.#listInventoryPackagingRevisions::call[0]", equationKey: "src/read-model.ts#listInventoryPackagingRevisions" }),
  Object.freeze({ surfaceKey: "export:./kernel#listInventoryPackagingRevisions::call[0]", equationKey: "src/read-model.ts#listInventoryPackagingRevisions" }),
  Object.freeze({ surfaceKey: "export:.#inventoryAmountForPrimaryAllocation::call[0]", equationKey: "src/picking.ts#inventoryAmountForPrimaryAllocation" }),
  Object.freeze({ surfaceKey: "export:./kernel#inventoryAmountForPrimaryAllocation::call[0]", equationKey: "src/picking.ts#inventoryAmountForPrimaryAllocation" }),
  Object.freeze({ surfaceKey: "export:.#planInventoryAllocation::call[0]", equationKey: "src/picking.ts#planInventoryAllocation" }),
  Object.freeze({ surfaceKey: "export:./kernel#planInventoryAllocation::call[0]", equationKey: "src/picking.ts#planInventoryAllocation" }),
  Object.freeze({ surfaceKey: "export:.#summarizeInventoryStock::call[0]", equationKey: "src/read-model.ts#summarizeInventoryStock" }),
  Object.freeze({ surfaceKey: "export:./kernel#summarizeInventoryStock::call[0]", equationKey: "src/read-model.ts#summarizeInventoryStock" }),
  Object.freeze({ surfaceKey: "export:./kernel#allocateInventory::call[0]", equationKey: "src/allocation.ts#allocateInventory" }),
  Object.freeze({ surfaceKey: "export:./kernel#compareInventoryAllocationCandidates::call[0]", equationKey: "src/allocation.ts#compareInventoryAllocationCandidates" }),
  Object.freeze({ surfaceKey: "export:./kernel#findInventoryPositions::call[0]", equationKey: "src/projection.ts#findInventoryPositions" }),
  Object.freeze({ surfaceKey: "export:./kernel#summarizeInventoryCollection::call[0]", equationKey: "src/collections.ts#summarizeInventoryCollection" }),
]);

/** Pure catalog construction aliases inherited from the earlier direct source family. */
export const CATALOG_READ_CONSTRUCTION_ALIAS_BINDINGS = Object.freeze([
  "export:.#InventoryCatalog.define::call[0]",
  "export:./kernel#InventoryCatalog.define::call[0]",
  "export:.#defineInventoryCatalog::call[0]",
  "export:./kernel#defineInventoryCatalog::call[0]",
  "export:.#emptyInventoryCatalogSnapshot::call[0]",
  "export:./kernel#emptyInventoryCatalogSnapshot::call[0]",
  "export:.#inventoryCatalogFromSnapshot::call[0]",
  "export:./kernel#inventoryCatalogFromSnapshot::call[0]",
  "export:.#assertInventoryCatalogRetainsSnapshot::call[0]",
  "export:./kernel#assertInventoryCatalogRetainsSnapshot::call[0]",
  "export:./storage#inventoryCatalogSnapshotDigest::call[0]",
]);

/** New immutable-extension aliases proved by the catalog-extension source law. */
export const CATALOG_READ_EXTENSION_ALIAS_BINDINGS = Object.freeze([
  "export:.#extendInventoryCatalog::call[0]",
  "export:./kernel#extendInventoryCatalog::call[0]",
]);

/** Already-V snapshot aliases strengthened by this complete semantic closure. */
export const CATALOG_READ_STRENGTHENED_ALIAS_BINDINGS = Object.freeze([
  "export:.#inventoryCatalogSnapshot::call[0]",
  "export:./kernel#inventoryCatalogSnapshot::call[0]",
]);

/** Build one independently reviewed snapshot/helper return equation. */
function snapshotRead(
  surfaceKey,
  methodName,
  helperSourceFile,
  helperName,
  facadeEquation,
  helperEquation,
) {
  return Object.freeze({
    surfaceKey,
    methodName,
    helperSourceFile,
    helperName,
    facadeEquation,
    helperEquation,
  });
}

/** Complete equations for the six snapshot reads blocked only by helper closure. */
export const CATALOG_READ_SNAPSHOT_CONTRACTS = Object.freeze([
  snapshotRead(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.positions::call[0]",
    "positions",
    "src/projection.ts",
    "findInventoryPositions",
    "result = findInventoryPositions(frozenWorld.projection, selector)",
    "Normalize the selector; enumerate only its exact projection-index candidates; reject a dangling index row; retain precisely the position keys matching every normalized constraint; order by canonical stock-position identity; return the corresponding frozen position rows.",
  ),
  snapshotRead(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.summary::call[0]",
    "summary",
    "src/read-model.ts",
    "summarizeInventoryStock",
    "result = summarizeInventoryStock({ catalog: frozenCatalog, projection: frozenWorld.projection, selector })",
    "Normalize the selector and select matching positions; group by exact item revision; retain requested revisions and the active zero-stock revision; reject a revision owned by another item; for each ordered revision return exact total, positive physical, signed deficit, positions, every optional identity bucket, and every qualified-dimension bucket, with exact measurement addition and deterministic ordering.",
  ),
  snapshotRead(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.availability::call[0]",
    "availability",
    "src/availability.ts",
    "summarizeInventoryAvailability",
    "result = summarizeInventoryAvailability({ catalog: frozenCatalog, projection: frozenWorld.projection, reservations: frozenWorld.reservations, selector, at: suppliedAt ?? frozenDefaultAt })",
    "Normalize the selector; group selected positions by exact revision; retain requested and active zero-stock revisions; select reservations active at the canonical authority time; for each ordered revision compute exact physical, claim, recorded-deficit, and non-negative available vectors over the selected pools; return those summaries plus the exact simultaneous reservation-feasibility result for the same frozen projection, claim book, catalog, and time.",
  ),
  snapshotRead(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.planAllocation::call[0]",
    "planAllocation",
    "src/picking.ts",
    "planInventoryAllocation",
    "result = planInventoryAllocation({ catalog: frozenCatalog, world: frozenWorld, selector: input.selector, amount: input.amount, method: input.method, at: input.at ?? frozenDefaultAt, and each supplied optional policy field })",
    "Validate both authority times; freeze the exact item revision, selector, request measurements, and positive primary quantity; form the whole selected location deficit pool; derive reservation-, expiry-, package-, serial-, and measured-increment-aware candidates; pay recorded deficit once per pool; perform exact bounded allocation before FIFO/FEFO fallback; reject missing reviewed candidates; return exact lines, requested values, shortfall and optional shortfall amount, deficit fields, and every policy explanation flag without mutating the frozen world.",
  ),
  snapshotRead(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.packagingRevisions::call[0]",
    "packagingRevisions",
    "src/read-model.ts",
    "listInventoryPackagingRevisions",
    "result = listInventoryPackagingRevisions({ catalog: frozenCatalog, ...input })",
    "Retain precisely the immutable packaging revisions whose stable item identity matches and whose exact item revision matches when supplied; sort by stable item, package unit, and exact packaging-revision identity; return the retained revision objects without collapsing equal human labels.",
  ),
  snapshotRead(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.collectionSummary::call[0]",
    "collectionSummary",
    "src/collections.ts",
    "summarizeInventoryCollection",
    "result = summarizeInventoryCollection({ catalog: frozenCatalog, projection: frozenWorld.projection, collectionRevisionId: input.collectionRevisionId, scope: input.scope when supplied })",
    "Normalize and copy the shared stock scope; resolve the exact retained collection revision and exact member revisions; summarize each member over the same frozen projection; sort members by immutable revision identity; compute only explicitly declared compatible scalar rollups with exact quantity conversion and stable contribution ordering; return definition, normalized scope, members, and rollups.",
  ),
]);

/** One honest family blocker for the three reads that must acquire storage state. */
export const CATALOG_READ_STORAGE_ACQUISITION_BLOCKER = Object.freeze({
  gapId: "CATALOG_READ_STORAGE_ACQUISITION_EXTERNAL_BOUNDARY",
  affectedSurfaceKeys: Object.freeze([
    "type:src/facade.ts#InventoryOnceCatalogApi.activeItem::call[0]",
    "type:src/facade.ts#InventoryOnceCatalogApi.itemRevision::call[0]",
    "type:src/facade.ts#InventoryOnceCatalogApi.itemRevisionsForItem::call[0]",
  ]),
  provenLocalEquation:
    "Each facade read resolves its owning internals, awaits exactly one InventoryDurableStorage.readWorld call, chooses the configured catalog only for revision zero and otherwise reconstructs the exact published catalog, then applies the already-closed InventoryCatalog lookup/filter equation.",
  missingFact:
    "InventoryDurableStorage.readWorld is an application-supplied asynchronous port. The package defines its result contract but no universal implementation, failure behavior, or state-acquisition function over all adapters, so this family cannot derive one strict-V return for every valid receiver.",
  disposition: "TRUE_EXTERNAL_STORAGE_BOUNDARY_NO_STRICT_V_CREDIT",
});
