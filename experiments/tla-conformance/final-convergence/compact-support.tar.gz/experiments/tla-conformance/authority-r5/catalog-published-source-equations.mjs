#!/usr/bin/env node
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  canonicalJson,
  compareCodeUnits,
  discoverCompilerSurface,
  loadCompilerContext,
  normalizeRelativePath,
  spanOf,
  ts,
} from "../surface-bindings/lib/compiler-surface.mjs";
import {
  CATALOG_PUBLICATION_STATEFUL_BLOCKER,
  CATALOG_PUBLISHED_SOURCE_CONTRACTS,
  CATALOG_PUBLISHED_SOURCE_DOMAIN,
  CATALOG_PUBLISHED_SUPPORTING_CONTRACTS,
  CATALOG_SNAPSHOT_SOURCE_CONTRACTS,
  PUBLISHED_READ_STATEFUL_BINDING_BLOCKER,
} from "./catalog-published-source-contracts.mjs";

/** Directory containing the authority-publication source-equation family. */
const FAMILY_DIRECTORY = path.dirname(fileURLToPath(import.meta.url));

/** Repository root resolved without trusting the invoking shell directory. */
const REPOSITORY_ROOT = path.resolve(FAMILY_DIRECTORY, "../../..");

/** Persisted independently inspectable source-equation certificate. */
const CERTIFICATE_PATH = path.join(
  FAMILY_DIRECTORY,
  "catalog-published-source-equations.json",
);

/** Earlier fixture certificate retained only as a bounded regression control. */
const BOUNDED_FIXTURE_CERTIFICATE_PATH = path.join(
  FAMILY_DIRECTORY,
  "catalog-published-value-certificate.json",
);

/** Exact old fixture domain that this source proof must not silently widen. */
const BOUNDED_FIXTURE_DOMAIN =
  "RICH_SCALAR_CATALOG_AND_ONE_RECEIPT_SNAPSHOT_V1";

/** Frozen byte identity of the historical bounded fixture after archival from the final tree. */
const BOUNDED_FIXTURE_SHA256 =
  "c0860eda3406691b84924d56c7cea1b0625a55cd75ba594ce79f2480608a1869";

/** Frozen content address of the historical bounded fixture after archival from the final tree. */
const BOUNDED_FIXTURE_CERTIFICATE_ID =
  "VALUE_CERTIFICATE_FAMILY:sha256:b22005aec0d6a076d71d3686773b0366e4560bba04af3b728a25f7e5cd49942e";

/** Stable family identity for the universal source-equation certificate. */
const SOURCE_FAMILY_ID =
  "inventoryonce.catalog-published.source-equations.v1";

/** Return a lowercase SHA-256 digest for supplied bytes or text. */
function sha256(value) {
  return createHash("sha256").update(value).digest("hex");
}

/** Require an exact object field set at one evidence boundary. */
function requireExactKeys(value, expected, label) {
  assert.equal(
    value !== null && typeof value === "object" && !Array.isArray(value),
    true,
    `${label} must be an object.`,
  );
  assert.deepEqual(
    Object.keys(value).sort(compareCodeUnits),
    [...expected].sort(compareCodeUnits),
    `${label} fields changed.`,
  );
}

/** Return one method declaration by exact class and method identity. */
export function findClassMethod(source, className, methodName) {
  const matchingClasses = source.statements.filter(
    (statement) =>
      ts.isClassDeclaration(statement) && statement.name?.text === className,
  );
  assert.equal(
    matchingClasses.length,
    1,
    `Expected one class '${className}' in ${source.fileName}.`,
  );
  const methods = matchingClasses[0].members.filter(
    (declaration) =>
      ts.isMethodDeclaration(declaration) &&
      ts.isIdentifier(declaration.name) &&
      declaration.name.text === methodName &&
      declaration.body !== undefined,
  );
  assert.equal(
    methods.length,
    1,
    `Expected one concrete method '${className}.${methodName}'.`,
  );
  return methods[0];
}

/** Return one ordinary function declaration by exact source identity. */
export function findFunction(source, functionName) {
  const functions = source.statements.filter(
    (statement) =>
      ts.isFunctionDeclaration(statement) &&
      statement.name?.text === functionName &&
      statement.body !== undefined,
  );
  assert.equal(
    functions.length,
    1,
    `Expected one concrete function '${functionName}' in ${source.fileName}.`,
  );
  return functions[0];
}

/** Return a stable operator name for one TypeScript binary token. */
function binaryOperator(token) {
  return ts.tokenToString(token.kind) ?? ts.SyntaxKind[token.kind];
}

/** Normalize one callable into a closed, name-insensitive runtime source term. */
export function normalizeCallable(declaration) {
  assert.notEqual(declaration.body, undefined, "Callable needs one concrete body.");
  const environment = new Map();
  const counters = { local: 0, lambda: 0 };

  /** Bind one source identifier to a stable positional identity. */
  function bind(name, identity) {
    assert.equal(ts.isIdentifier(name), true, "Only simple source bindings are admitted.");
    environment.set(name.text, identity);
  }

  for (const [index, parameter] of declaration.parameters.entries()) {
    bind(parameter.name, `parameter:${index}`);
  }

  /** Normalize one property name without executing computed source. */
  function propertyName(name) {
    if (ts.isIdentifier(name) || ts.isStringLiteral(name) || ts.isNumericLiteral(name)) {
      return name.text;
    }
    throw new Error(`Unsupported computed property '${name.getText()}'.`);
  }

  /** Normalize one runtime expression in the deliberately finite equation grammar. */
  function expression(node, scopedEnvironment = environment) {
    if (ts.isParenthesizedExpression(node)) return expression(node.expression, scopedEnvironment);
    if (ts.isAsExpression(node) || ts.isTypeAssertionExpression(node) || ts.isNonNullExpression(node)) {
      return expression(node.expression, scopedEnvironment);
    }
    if (node.kind === ts.SyntaxKind.ThisKeyword) return ["this"];
    if (ts.isIdentifier(node)) {
      return ["reference", scopedEnvironment.get(node.text) ?? `source:${node.text}`];
    }
    if (ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) {
      return ["string", node.text];
    }
    if (ts.isNumericLiteral(node)) return ["number", node.text];
    if (node.kind === ts.SyntaxKind.TrueKeyword) return ["boolean", true];
    if (node.kind === ts.SyntaxKind.FalseKeyword) return ["boolean", false];
    if (node.kind === ts.SyntaxKind.NullKeyword) return ["null"];
    if (ts.isPropertyAccessExpression(node)) {
      return [
        "property",
        expression(node.expression, scopedEnvironment),
        node.name.text,
        node.questionDotToken === undefined ? "required" : "optional",
      ];
    }
    if (ts.isElementAccessExpression(node)) {
      assert.notEqual(node.argumentExpression, undefined);
      return [
        "element",
        expression(node.expression, scopedEnvironment),
        expression(node.argumentExpression, scopedEnvironment),
        node.questionDotToken === undefined ? "required" : "optional",
      ];
    }
    if (ts.isCallExpression(node)) {
      return [
        "call",
        expression(node.expression, scopedEnvironment),
        node.arguments.map((argument) => expression(argument, scopedEnvironment)),
        node.questionDotToken === undefined ? "required" : "optional",
      ];
    }
    if (ts.isNewExpression(node)) {
      return [
        "new",
        expression(node.expression, scopedEnvironment),
        (node.arguments ?? []).map((argument) => expression(argument, scopedEnvironment)),
      ];
    }
    if (ts.isAwaitExpression(node)) return ["await", expression(node.expression, scopedEnvironment)];
    if (ts.isBinaryExpression(node)) {
      return [
        "binary",
        binaryOperator(node.operatorToken),
        expression(node.left, scopedEnvironment),
        expression(node.right, scopedEnvironment),
      ];
    }
    if (ts.isConditionalExpression(node)) {
      return [
        "conditional",
        expression(node.condition, scopedEnvironment),
        expression(node.whenTrue, scopedEnvironment),
        expression(node.whenFalse, scopedEnvironment),
      ];
    }
    if (ts.isPrefixUnaryExpression(node)) {
      return [
        "prefix",
        ts.tokenToString(node.operator) ?? ts.SyntaxKind[node.operator],
        expression(node.operand, scopedEnvironment),
      ];
    }
    if (ts.isVoidExpression(node)) return ["void", expression(node.expression, scopedEnvironment)];
    if (ts.isSpreadElement(node)) return ["spread", expression(node.expression, scopedEnvironment)];
    if (ts.isArrayLiteralExpression(node)) {
      return [
        "array",
        node.elements.map((element) =>
          ts.isOmittedExpression(element)
            ? ["omitted"]
            : expression(element, scopedEnvironment),
        ),
      ];
    }
    if (ts.isObjectLiteralExpression(node)) {
      return [
        "record",
        node.properties.map((property) => {
          if (ts.isPropertyAssignment(property)) {
            return [
              "field",
              propertyName(property.name),
              expression(property.initializer, scopedEnvironment),
            ];
          }
          if (ts.isShorthandPropertyAssignment(property)) {
            return [
              "field",
              property.name.text,
              expression(property.name, scopedEnvironment),
            ];
          }
          if (ts.isSpreadAssignment(property)) {
            return ["spread", expression(property.expression, scopedEnvironment)];
          }
          throw new Error(`Unsupported object member '${property.getText()}'.`);
        }),
      ];
    }
    if (ts.isArrowFunction(node)) {
      const childEnvironment = new Map(scopedEnvironment);
      const lambdaId = counters.lambda;
      counters.lambda += 1;
      for (const [index, parameter] of node.parameters.entries()) {
        assert.equal(ts.isIdentifier(parameter.name), true, "Lambda parameters must be simple.");
        childEnvironment.set(parameter.name.text, `lambda:${lambdaId}:${index}`);
      }
      return [
        "lambda",
        node.parameters.length,
        ts.isBlock(node.body)
          ? statement(node.body, childEnvironment)
          : expression(node.body, childEnvironment),
      ];
    }
    if (ts.isTemplateExpression(node)) {
      return [
        "template",
        node.head.text,
        node.templateSpans.map((span) => [
          expression(span.expression, scopedEnvironment),
          span.literal.text,
        ]),
      ];
    }
    throw new Error(
      `Unsupported source-equation expression '${ts.SyntaxKind[node.kind]}': ${node.getText()}`,
    );
  }

  /** Normalize one control-flow branch while ignoring semantically inert braces. */
  function branch(node, scopedEnvironment) {
    if (!ts.isBlock(node)) return statement(node, scopedEnvironment);
    const normalized = statements(node.statements, new Map(scopedEnvironment));
    return normalized.length === 1 ? normalized[0] : ["sequence", normalized];
  }

  /** Normalize a sequence while assigning deterministic local slots. */
  function statements(sourceStatements, scopedEnvironment) {
    const result = [];
    for (const sourceStatement of sourceStatements) {
      result.push(statement(sourceStatement, scopedEnvironment));
    }
    return result;
  }

  /** Normalize one runtime statement and every complete branch below it. */
  function statement(node, scopedEnvironment = environment) {
    if (ts.isBlock(node)) {
      return ["sequence", statements(node.statements, new Map(scopedEnvironment))];
    }
    if (ts.isVariableStatement(node)) {
      assert.equal(node.declarationList.declarations.length, 1, "One local per declaration is required.");
      const declaration = node.declarationList.declarations[0];
      assert.equal(ts.isIdentifier(declaration.name), true, "Locals must use simple identifiers.");
      const initializer =
        declaration.initializer === undefined
          ? ["undefined"]
          : expression(declaration.initializer, scopedEnvironment);
      const identity = `local:${counters.local}`;
      counters.local += 1;
      scopedEnvironment.set(declaration.name.text, identity);
      return ["bind", identity, initializer];
    }
    if (ts.isIfStatement(node)) {
      return [
        "if",
        expression(node.expression, scopedEnvironment),
        branch(node.thenStatement, new Map(scopedEnvironment)),
        node.elseStatement === undefined
          ? ["no-else"]
          : branch(node.elseStatement, new Map(scopedEnvironment)),
      ];
    }
    if (ts.isReturnStatement(node)) {
      return [
        "return",
        node.expression === undefined
          ? ["undefined"]
          : expression(node.expression, scopedEnvironment),
      ];
    }
    if (ts.isThrowStatement(node)) return ["throw", expression(node.expression, scopedEnvironment)];
    if (ts.isExpressionStatement(node)) {
      return ["expression", expression(node.expression, scopedEnvironment)];
    }
    if (ts.isForOfStatement(node)) {
      assert.equal(
        ts.isVariableDeclarationList(node.initializer),
        true,
        "For-of source equations require one declared iterator.",
      );
      assert.equal(node.initializer.declarations.length, 1);
      const iterator = node.initializer.declarations[0];
      assert.equal(ts.isIdentifier(iterator.name), true);
      const iterable = expression(node.expression, scopedEnvironment);
      const childEnvironment = new Map(scopedEnvironment);
      const identity = `local:${counters.local}`;
      counters.local += 1;
      childEnvironment.set(iterator.name.text, identity);
      return [
        "for-of",
        identity,
        iterable,
        branch(node.statement, childEnvironment),
      ];
    }
    if (ts.isContinueStatement(node)) return ["continue"];
    throw new Error(
      `Unsupported source-equation statement '${ts.SyntaxKind[node.kind]}': ${node.getText()}`,
    );
  }

  const parameters = declaration.parameters.map((parameter) => ({
    optional: parameter.questionToken !== undefined,
    rest: parameter.dotDotDotToken !== undefined,
    default:
      parameter.initializer === undefined
        ? null
        : expression(parameter.initializer, environment),
  }));
  return {
    async:
      declaration.modifiers?.some(
        (modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword,
      ) ?? false,
    parameters,
    body: ["sequence", statements(declaration.body.statements, environment)],
  };
}

/** Escape fixed text for a source template literal used in an independent law. */
function templateText(value) {
  return value.replaceAll("\\", "\\\\").replaceAll("`", "\\`");
}

/** Build the expected method source for one reviewed reusable law. */
function expectedMethodSource(contract) {
  const law = contract.law;
  switch (law.kind) {
    case "required-map-lookup": {
      const error =
        "`" +
        templateText(law.errorPrefix) +
        "${p0}" +
        templateText(law.errorSuffix) +
        "`";
      return `class Expected { sample(p0) {
        const found = this.${law.mapField}.get(p0);
        if (found === undefined) throw new Error(${error});
        return found;
      } }`;
    }
    case "retained-item-filter":
      return `class Expected { sample(p0) {
        const result = this.itemRevisions.filter((item) => item.itemId === p0);
        return Object.freeze(result);
      } }`;
    case "measurement-axis-lookup":
      return `class Expected { sample(p0, p1) {
        if (p0.primaryAxis.axisId === p1) return p0.primaryAxis;
        for (const axis of p0.independentAxes) {
          if (axis.axisId === p1) return axis;
        }
        throw new Error(\`Item revision '${"${p0.revisionId}"}' has no measurement axis '${"${p1}"}'.\`);
      } }`;
    case "retained-transformation-item-filter":
      return `class Expected { sample(p0) {
        const result = this.transformationRevisions.filter(
          (definition) => [...definition.inputs, ...definition.outputs].some(
            (line) => this.itemRevision(line.itemRevisionId).itemId === p0
          )
        );
        return Object.freeze(result);
      } }`;
    case "active-transformation-revision-filter":
      return `class Expected { sample(p0) {
        const result = [];
        for (const definition of this.activeTransformationById.values()) {
          if (definition.${law.side}.some((line) => line.itemRevisionId === p0)) result.push(definition);
        }
        result.sort(compareTransformationRevision);
        return Object.freeze(result);
      } }`;
    case "between-transformation-filter":
      return `class Expected { sample(p0, p1) {
        return Object.freeze(
          this.transformationsFromRevision(p0).filter(
            (definition) => definition.outputs.some(
              (line) => line.itemRevisionId === p1
            )
          )
        );
      } }`;
    case "published-catalog-delegate":
      return `class Expected { async sample(p0) {
        const internals = requireInventoryOnceInternals(this.owner);
        const world = await internals.storage.readWorld();
        return inventoryCatalogForPublishedWorld(world, internals.catalog).${law.targetMethod}(p0);
      } }`;
    case "direct-return": {
      const parameters = Array.from({ length: law.parameterCount }, (_, index) => {
        const defaultExpression = law.defaults[index];
        const optional = law.optionalParameters.includes(index) ? "?" : "";
        return defaultExpression === undefined || defaultExpression === null
          ? `p${index}${optional}`
          : `p${index} = ${defaultExpression}`;
      });
      return `class Expected { sample(${parameters.join(", ")}) { return ${law.expression}; } }`;
    }
    case "projection-values-sort":
      return `class Expected { sample() {
        const result = Object.values(${law.expression});
        result.sort(${law.comparator});
        return result;
      } }`;
    case "snapshot-composition-filter":
      return `class Expected { sample(p0) {
        const result = [];
        for (const composition of this.catalog.compositionRevisions) {
          const packaging = this.catalog.packagingRevision(composition.sourcePackagingRevisionId);
          if (packaging.itemId === p0) result.push(composition);
        }
        result.sort(compareInventoryCompositionRevision);
        return result;
      } }`;
    default:
      throw new Error(`Unknown source-equation law '${law.kind}'.`);
  }
}

/** Build the expected helper source for one reviewed supporting law. */
function expectedSupportingSource(contract) {
  switch (contract.law.kind) {
    case "published-catalog-selection":
      return `function expected(p0, p1) {
        return p0.revision === 0 ? p1 : inventoryCatalogFromSnapshot(p0.catalog);
      }`;
    case "projected-lot-index":
      return `function expected(p0, p1?: string) {
        const identities = p1 === undefined ? Object.keys(p0.lots) : inventorySparseRecordValue(p0.lotIdentitiesByItemId, p1) ?? [];
        const result = [];
        for (const identity of identities) {
          const projected = p0.lots[identity];
          if (projected === undefined) {
            throw new Error(\`Inventory lot index references missing lot '${"${identity}"}'.\`);
          }
          if (p1 !== undefined && projected.definition.itemId !== p1) {
            throw new Error(\`Inventory lot index '${"${p1}"}' contains foreign lot '${"${identity}"}'.\`);
          }
          result.push(projected);
        }
        result.sort(compareProjectedLotDefinition);
        return result;
      }`;
    default:
      throw new Error(`Unknown supporting source-equation law '${contract.law.kind}'.`);
  }
}

/** Build the complete empty catalog input and snapshot record source. */
function emptyCatalogRecordSource(includeDigest) {
  const emptyIndex = includeDigest ? "createInventorySparseRecord()" : "{}";
  return `{
    ${includeDigest ? "digest: inventoryCatalogDigest(input)," : ""}
    itemRevisions: [],
    activeItemRevisionIds: ${emptyIndex},
    packagingRevisions: [],
    compositionRevisions: [],
    activeCompositionRevisionIds: ${emptyIndex},
    transformationRevisions: [],
    activeTransformationRevisionIds: ${emptyIndex},
    collectionRevisions: [],
    activeCollectionRevisionIds: ${emptyIndex},
    fungibilityRevisions: [],
    activeFungibilityRevisionIds: ${emptyIndex},
  }`;
}

/** Build one retained-revision digest loop for the independent snapshot law. */
function retainedRevisionLoop({
  retainedName,
  collection,
  lookup,
  identity,
  digest,
  errorPrefix,
}) {
  return `for (const ${retainedName} of retainedCatalog.${collection}) {
    const supplied = p0.${lookup}(${retainedName}.${identity});
    if (${digest}(supplied) !== ${digest}(${retainedName})) {
      throw new Error(\`${errorPrefix}'${"${" + retainedName + "." + identity + "}"}' changed after it entered durable truth.\`);
    }
  }`;
}

/** Build the expected callable source for one pure catalog snapshot/integrity law. */
function expectedCatalogSnapshotSource(contract) {
  switch (contract.law.kind) {
    case "catalog-static-define":
      return "class Expected { static sample(p0) { return new InventoryCatalog(createInventoryCatalogParts(p0)); } }";
    case "catalog-define-delegate":
      return "function expected(p0) { return InventoryCatalog.define(p0); }";
    case "empty-catalog-snapshot":
      return `function expected() {
        const input = ${emptyCatalogRecordSource(false)};
        return ${emptyCatalogRecordSource(true)};
      }`;
    case "catalog-from-snapshot":
      return `function expected(p0) {
        const catalog = defineInventoryCatalog(p0);
        if (catalog.digest !== p0.digest) {
          throw new Error("Durable inventory catalogue snapshot digest does not match its definitions.");
        }
        return catalog;
      }`;
    case "retained-catalog-digest-equality": {
      const loops = [
        {
          retainedName: "retainedItem",
          collection: "itemRevisions",
          lookup: "itemRevision",
          identity: "revisionId",
          digest: "inventoryItemRevisionDigest",
          errorPrefix: "Inventory item revision ",
        },
        {
          retainedName: "retainedPackaging",
          collection: "packagingRevisions",
          lookup: "packagingRevision",
          identity: "revisionId",
          digest: "inventoryPackagingRevisionDigest",
          errorPrefix: "Inventory packaging revision ",
        },
        {
          retainedName: "retainedComposition",
          collection: "compositionRevisions",
          lookup: "compositionRevision",
          identity: "revisionId",
          digest: "inventoryCompositionRevisionDigest",
          errorPrefix: "Inventory composition revision ",
        },
        {
          retainedName: "retainedTransformation",
          collection: "transformationRevisions",
          lookup: "transformationRevision",
          identity: "revisionId",
          digest: "inventoryTransformationRevisionDigest",
          errorPrefix: "Inventory transformation revision ",
        },
        {
          retainedName: "retainedCollection",
          collection: "collectionRevisions",
          lookup: "collectionRevision",
          identity: "revisionId",
          digest: "inventoryCollectionRevisionDigest",
          errorPrefix: "Inventory collection revision ",
        },
        {
          retainedName: "retainedPool",
          collection: "fungibilityRevisions",
          lookup: "fungibilityRevision",
          identity: "revisionId",
          digest: "inventoryFungibilityRevisionDigest",
          errorPrefix: "Inventory fungibility revision ",
        },
      ].map(retainedRevisionLoop);
      return `function expected(p0, p1) {
        const retainedCatalog = inventoryCatalogFromSnapshot(p1);
        ${loops.join("\n")}
      }`;
    }
    case "catalog-snapshot-digest":
      return "function expected(p0) { return inventoryCatalogFromSnapshot(p0).digest; }";
    default:
      throw new Error(`Unknown catalog snapshot source-equation law '${contract.law.kind}'.`);
  }
}

/** Parse one independent expected method and return its normalized term. */
export function expectedMethodTerm(contract) {
  const source = ts.createSourceFile(
    `expected-${contract.methodName}.ts`,
    expectedMethodSource(contract),
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TS,
  );
  return normalizeCallable(findClassMethod(source, "Expected", "sample"));
}

/** Parse one independent expected helper and return its normalized term. */
export function expectedSupportingTerm(contract) {
  const source = ts.createSourceFile(
    `expected-${contract.functionName}.ts`,
    expectedSupportingSource(contract),
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TS,
  );
  return normalizeCallable(findFunction(source, "expected"));
}

/** Parse one independent catalog snapshot/integrity law into its normalized term. */
function expectedCatalogSnapshotTerm(contract) {
  const source = ts.createSourceFile(
    `expected-${contract.declarationName}.ts`,
    expectedCatalogSnapshotSource(contract),
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TS,
  );
  const declaration =
    contract.declarationKind === "method"
      ? findClassMethod(source, "Expected", "sample")
      : findFunction(source, "expected");
  return normalizeCallable(declaration);
}

/** Load one production source, honoring an in-memory mutation only in tests. */
function loadSource(sourceFile, sourceOverrides) {
  const absolute = path.join(REPOSITORY_ROOT, sourceFile);
  const text = sourceOverrides.get(sourceFile) ?? fs.readFileSync(absolute, "utf8");
  return ts.createSourceFile(
    absolute,
    text,
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TS,
  );
}

/** Prove all 33 source equations and both complete supporting helper branches. */
export function verifyCatalogPublishedSourceContracts(sourceOverrides = new Map()) {
  const sourceCache = new Map();
  const source = (sourceFile) => {
    if (!sourceCache.has(sourceFile)) {
      sourceCache.set(sourceFile, loadSource(sourceFile, sourceOverrides));
    }
    return sourceCache.get(sourceFile);
  };
  const equations = CATALOG_PUBLISHED_SOURCE_CONTRACTS.map((contract) => {
    const declaration = findClassMethod(
      source(contract.sourceFile),
      contract.className,
      contract.methodName,
    );
    const actualTerm = normalizeCallable(declaration);
    const expectedTerm = expectedMethodTerm(contract);
    assert.deepEqual(
      actualTerm,
      expectedTerm,
      `${contract.surfaceKey} does not implement '${contract.equation}'.`,
    );
    return { contract, declaration, term: actualTerm };
  });
  const supportingEquations = CATALOG_PUBLISHED_SUPPORTING_CONTRACTS.map(
    (contract) => {
      const declaration = findFunction(
        source(contract.sourceFile),
        contract.functionName,
      );
      const actualTerm = normalizeCallable(declaration);
      const expectedTerm = expectedSupportingTerm(contract);
      assert.deepEqual(
        actualTerm,
        expectedTerm,
        `${contract.functionName} does not implement '${contract.equation}'.`,
      );
      return { contract, declaration, term: actualTerm };
    },
  );
  const catalogSnapshotEquations = CATALOG_SNAPSHOT_SOURCE_CONTRACTS.map(
    (contract) => {
      const declaration =
        contract.declarationKind === "method"
          ? findClassMethod(
              source(contract.sourceFile),
              contract.className,
              contract.declarationName,
            )
          : findFunction(source(contract.sourceFile), contract.declarationName);
      const actualTerm = normalizeCallable(declaration);
      const expectedTerm = expectedCatalogSnapshotTerm(contract);
      assert.deepEqual(
        actualTerm,
        expectedTerm,
        `${contract.declarationName} does not implement '${contract.equation}'.`,
      );
      return { contract, declaration, term: actualTerm };
    },
  );
  assert.equal(equations.length, 33);
  assert.equal(new Set(equations.map(({ contract }) => contract.surfaceKey)).size, 33);
  assert.equal(catalogSnapshotEquations.length, 6);
  assert.equal(
    catalogSnapshotEquations.reduce(
      (total, { contract }) => total + contract.surfaceKeys.length,
      0,
    ),
    11,
  );
  return { equations, supportingEquations, catalogSnapshotEquations };
}

/** Return whether one declaration is a concrete package-source callable. */
function isConcretePackageCallable(context, declaration) {
  if (
    declaration === undefined ||
    declaration.body === undefined ||
    (!ts.isFunctionDeclaration(declaration) && !ts.isMethodDeclaration(declaration))
  ) {
    return false;
  }
  return normalizeRelativePath(
    context.repositoryRoot,
    declaration.getSourceFile().fileName,
  ).startsWith("src/");
}

/** Collect exact direct source/helper declarations used by one checked body. */
function directSourceDependencies(context, declaration) {
  const dependencies = new Map();
  const ownStart = declaration.getStart(declaration.getSourceFile());
  const ownKey = `${declaration.getSourceFile().fileName}:${ownStart}`;

  /** Add one resolved callable dependency when it belongs to production source. */
  function addDependency(candidate) {
    if (!isConcretePackageCallable(context, candidate)) return;
    const key = `${candidate.getSourceFile().fileName}:${candidate.getStart(candidate.getSourceFile())}`;
    if (key === ownKey || dependencies.has(key)) return;
    const span = spanOf(context, candidate);
    dependencies.set(key, {
      declarationKind: ts.isMethodDeclaration(candidate) ? "method" : "function",
      name:
        candidate.name !== undefined && ts.isIdentifier(candidate.name)
          ? candidate.name.text
          : "anonymous",
      sourceFile: span.file,
      sourceAstSha256: span.astHash,
    });
  }

  /** Resolve calls and callable values such as sort comparators through TypeScript. */
  function visit(node) {
    if (ts.isCallExpression(node)) {
      addDependency(context.checker.getResolvedSignature(node)?.declaration);
    } else if (ts.isIdentifier(node)) {
      const symbol = context.checker.getSymbolAtLocation(node);
      for (const candidate of symbol?.declarations ?? []) addDependency(candidate);
    }
    ts.forEachChild(node, visit);
  }
  visit(declaration.body);
  return [...dependencies.values()].sort((left, right) =>
    compareCodeUnits(
      `${left.sourceFile}:${left.name}:${left.sourceAstSha256}`,
      `${right.sourceFile}:${right.name}:${right.sourceAstSha256}`,
    ),
  );
}

/** Retain semantic declaration identity without whole-file hashes or movable offsets. */
function semanticDeclarationIdentity(context, declaration) {
  const span = spanOf(context, declaration);
  return { sourceFile: span.file, sourceAstSha256: span.astHash };
}

/** Resolve the current compiler-owned declaration matching one checked contract. */
function compilerDeclaration(context, contract, kind) {
  const absolute = path.join(REPOSITORY_ROOT, contract.sourceFile);
  const source = context.program.getSourceFile(absolute);
  assert.notEqual(source, undefined, `Compiler omitted ${contract.sourceFile}.`);
  return kind === "method"
    ? findClassMethod(source, contract.className, contract.methodName)
    : findFunction(source, contract.functionName);
}

/** Build one source equation with exact source and helper dependency evidence. */
function equationEvidence(context, verified) {
  const declaration = compilerDeclaration(context, verified.contract, "method");
  return {
    producerMethod: `${verified.contract.className}.${verified.contract.methodName}`,
    sourceFile: verified.contract.sourceFile,
    className: verified.contract.className,
    methodName: verified.contract.methodName,
    equation: verified.contract.equation,
    law: verified.contract.law,
    completeBranchesChecked: true,
    allValidatedInputs: true,
    sampledInputs: 0,
    normalizedTerm: verified.term,
    normalizedTermSha256: sha256(canonicalJson(verified.term)),
    declaration: semanticDeclarationIdentity(context, declaration),
    directSourceDependencies: directSourceDependencies(context, declaration),
  };
}

/** Build one checked supporting helper equation and its source dependencies. */
function supportingEquationEvidence(context, verified) {
  const declaration = compilerDeclaration(context, verified.contract, "function");
  return {
    sourceFile: verified.contract.sourceFile,
    functionName: verified.contract.functionName,
    equation: verified.contract.equation,
    law: verified.contract.law,
    completeBranchesChecked: true,
    normalizedTerm: verified.term,
    normalizedTermSha256: sha256(canonicalJson(verified.term)),
    declaration: semanticDeclarationIdentity(context, declaration),
    directSourceDependencies: directSourceDependencies(context, declaration),
  };
}

/** Build one pure catalog snapshot/integrity equation and all compiler aliases it supports. */
function catalogSnapshotEquationEvidence(context, verified) {
  const source = context.program.getSourceFile(
    path.join(REPOSITORY_ROOT, verified.contract.sourceFile),
  );
  assert.notEqual(source, undefined, `Compiler omitted ${verified.contract.sourceFile}.`);
  const declaration =
    verified.contract.declarationKind === "method"
      ? findClassMethod(
          source,
          verified.contract.className,
          verified.contract.declarationName,
        )
      : findFunction(source, verified.contract.declarationName);
  return {
    sourceFile: verified.contract.sourceFile,
    declarationKind: verified.contract.declarationKind,
    declarationName: verified.contract.declarationName,
    equation: verified.contract.equation,
    law: verified.contract.law,
    completeBranchesChecked: true,
    allValidatedInputs: true,
    sampledInputs: 0,
    normalizedTerm: verified.term,
    normalizedTermSha256: sha256(canonicalJson(verified.term)),
    declaration: semanticDeclarationIdentity(context, declaration),
    directSourceDependencies: directSourceDependencies(context, declaration),
  };
}

/** Read and validate the earlier bounded fixture certificate without widening it. */
function boundedFixtureControl() {
  let fixtureSha256 = BOUNDED_FIXTURE_SHA256;
  let certificateId = BOUNDED_FIXTURE_CERTIFICATE_ID;
  if (fs.existsSync(BOUNDED_FIXTURE_CERTIFICATE_PATH)) {
    const bytes = fs.readFileSync(BOUNDED_FIXTURE_CERTIFICATE_PATH);
    const document = JSON.parse(bytes.toString("utf8"));
    assert.equal(document.semanticCore.equationDomain, BOUNDED_FIXTURE_DOMAIN);
    assert.equal(document.semanticCore.proofCounts.producerEquations, 33);
    assert.equal(document.reviewEnvelope.globalBinderCreditGranted, false);
    fixtureSha256 = sha256(bytes);
    certificateId = document.contentAddress.certificateId;
    assert.equal(fixtureSha256, BOUNDED_FIXTURE_SHA256);
    assert.equal(certificateId, BOUNDED_FIXTURE_CERTIFICATE_ID);
  }
  return {
    file: normalizeRelativePath(REPOSITORY_ROOT, BOUNDED_FIXTURE_CERTIFICATE_PATH),
    sha256: fixtureSha256,
    certificateId,
    domain: BOUNDED_FIXTURE_DOMAIN,
    equationCount: 33,
    role: "BOUNDED_RUNTIME_REGRESSION_ONLY",
    universalCreditGranted: false,
  };
}

/** Build current compiler binding candidates outside the semantic content address. */
function compilerBindingEnvelope() {
  const surface = discoverCompilerSurface(REPOSITORY_ROOT);
  const callableByKey = new Map(
    surface.callables.map((callable) => [callable.key, callable]),
  );
  const requested = [
    ...CATALOG_PUBLISHED_SOURCE_CONTRACTS.map((contract) => ({
      surfaceKey: contract.surfaceKey,
      producerEquation: `${contract.className}.${contract.methodName}`,
    })),
    ...CATALOG_SNAPSHOT_SOURCE_CONTRACTS.flatMap((contract) =>
      contract.surfaceKeys.map((surfaceKey) => ({
        surfaceKey,
        producerEquation:
          contract.declarationKind === "method"
            ? `${contract.className}.${contract.declarationName}`
            : contract.declarationName,
      })),
    ),
  ];
  assert.equal(requested.length, 44);
  assert.equal(new Set(requested.map(({ surfaceKey }) => surfaceKey)).size, 44);
  return requested.map(({ surfaceKey, producerEquation }) => {
    const callable = callableByKey.get(surfaceKey);
    assert.notEqual(callable, undefined, `Compiler surface omitted '${surfaceKey}'.`);
    return {
      surfaceKey,
      producerEquation,
      proposedRelation: "COMPILER_BINDING_TO_COMPLETE_SOURCE_EQUATION",
      callableIdentity: callable,
      creditGrantedByLane: false,
    };
  });
}

/** Build the semantic source-equation core independently of binder metadata. */
export function buildCatalogPublishedSourceEquationSemanticCore() {
  const context = loadCompilerContext(REPOSITORY_ROOT);
  const verified = verifyCatalogPublishedSourceContracts();
  const sourceEquations = verified.equations.map((equation) =>
    equationEvidence(context, equation),
  );
  const supportingEquations = verified.supportingEquations.map((equation) =>
    supportingEquationEvidence(context, equation),
  );
  const catalogSnapshotEquations = verified.catalogSnapshotEquations.map(
    (equation) => catalogSnapshotEquationEvidence(context, equation),
  );
  const lawCounts = {};
  for (const equation of sourceEquations) {
    lawCounts[equation.law.kind] = (lawCounts[equation.law.kind] ?? 0) + 1;
  }
  return {
    schemaVersion: 1,
    familyId: SOURCE_FAMILY_ID,
    familyVersion: 1,
    domain: CATALOG_PUBLISHED_SOURCE_DOMAIN,
    claim:
      "Every named read implements its independently declared complete source equation for all validated catalogs or all states of one already-frozen published snapshot.",
    proofCounts: {
      sourceEquations: sourceEquations.length,
      catalogLookupEquations: 17,
      publishedCatalogDelegationEquations: 3,
      frozenSnapshotEquations: 13,
      supportingHelperEquations: supportingEquations.length,
      catalogSnapshotImplementationEquations: catalogSnapshotEquations.length,
      catalogSnapshotCompilerBindings: CATALOG_SNAPSHOT_SOURCE_CONTRACTS.reduce(
        (total, contract) => total + contract.surfaceKeys.length,
        0,
      ),
      sampledInputs: 0,
    },
    lawCounts,
    sourceEquations,
    supportingEquations,
    catalogSnapshotEquations,
    statefulFamilyBlocker: CATALOG_PUBLICATION_STATEFUL_BLOCKER,
  };
}

/** Build review metadata that preserves old fixture and authority-action boundaries. */
function buildReviewEnvelope() {
  const contractPath = path.join(
    FAMILY_DIRECTORY,
    "catalog-published-source-contracts.mjs",
  );
  const verifierPath = fileURLToPath(import.meta.url);
  return {
    status: "SOURCE_EQUATION_FAMILY_COMPLETE_AWAITING_SHARED_BINDER_REVIEW",
    independentContract: {
      file: normalizeRelativePath(REPOSITORY_ROOT, contractPath),
      sha256: sha256(fs.readFileSync(contractPath)),
    },
    verifier: {
      file: normalizeRelativePath(REPOSITORY_ROOT, verifierPath),
      sha256: sha256(fs.readFileSync(verifierPath)),
      engine: "COMPLETE_SOURCE_CONTROL_FLOW_EQUATION_V1",
    },
    compilerBindings: compilerBindingEnvelope(),
    statefulReadBindingBlocker: PUBLISHED_READ_STATEFUL_BINDING_BLOCKER,
    boundedFixtureControl: boundedFixtureControl(),
    applicability: {
      binderOwner: "hub-global-binder",
      sharedGateReplacedOrBypassed: false,
      sourceEquationIsNotOriginalModelAdmission: true,
      helperDelegationRequiresExactDependencyIdentity: true,
      permitsAdditionalWrapperSemantics: false,
    },
    authorityActionFamilyUsed: false,
    authorityFixtureScenariosPromotedToFormalCredit: 0,
    globalBinderCreditGranted: false,
  };
}

/** Build a content-addressed source-equation certificate document. */
export function buildCatalogPublishedSourceEquationDocument() {
  const semanticCore = buildCatalogPublishedSourceEquationSemanticCore();
  const contentSha256 = sha256(canonicalJson(semanticCore));
  return {
    certificateKind: "INVENTORYONCE_SOURCE_EQUATION_FAMILY",
    semanticCore,
    contentAddress: {
      algorithm: "sha256",
      contentSha256,
      certificateId: `SOURCE_EQUATION_FAMILY:sha256:${contentSha256}`,
    },
    reviewEnvelope: buildReviewEnvelope(),
  };
}

/** Verify one document by rebuilding every source equation and dependency. */
export function verifyCatalogPublishedSourceEquationDocument(document) {
  requireExactKeys(
    document,
    ["certificateKind", "semanticCore", "contentAddress", "reviewEnvelope"],
    "Source-equation certificate",
  );
  const expected = buildCatalogPublishedSourceEquationDocument();
  assert.deepEqual(
    document,
    expected,
    "Source-equation certificate differs from current independent contracts or source truth.",
  );
  return {
    certificateId: document.contentAddress.certificateId,
    sourceEquations: document.semanticCore.proofCounts.sourceEquations,
    supportingHelperEquations:
      document.semanticCore.proofCounts.supportingHelperEquations,
    catalogSnapshotImplementationEquations:
      document.semanticCore.proofCounts.catalogSnapshotImplementationEquations,
    catalogSnapshotCompilerBindings:
      document.semanticCore.proofCounts.catalogSnapshotCompilerBindings,
    compilerBindingCandidates: document.reviewEnvelope.compilerBindings.length,
    sampledInputs: document.semanticCore.proofCounts.sampledInputs,
    statefulReadBindingBlocker:
      document.reviewEnvelope.statefulReadBindingBlocker.family,
    statefulBlocker: document.semanticCore.statefulFamilyBlocker.gapId,
    globalBinderCreditGranted: document.reviewEnvelope.globalBinderCreditGranted,
  };
}

/** Persist and immediately verify the canonical source-equation family. */
export function writeCatalogPublishedSourceEquationDocument() {
  const document = buildCatalogPublishedSourceEquationDocument();
  fs.writeFileSync(CERTIFICATE_PATH, `${JSON.stringify(document, null, 2)}\n`);
  return verifyCatalogPublishedSourceEquationDocument(document);
}

/** Verify the persisted source-equation family without using fixture outputs. */
export function verifyPersistedCatalogPublishedSourceEquationDocument() {
  return verifyCatalogPublishedSourceEquationDocument(
    JSON.parse(fs.readFileSync(CERTIFICATE_PATH, "utf8")),
  );
}

/** Run deterministic write or verification mode for lane and hub review. */
function runCommandLine() {
  const mode = process.argv[2] ?? "--verify";
  if (mode !== "--write" && mode !== "--verify") {
    throw new Error(`Unknown source-equation mode '${mode}'.`);
  }
  const summary =
    mode === "--write"
      ? writeCatalogPublishedSourceEquationDocument()
      : verifyPersistedCatalogPublishedSourceEquationDocument();
  process.stdout.write(`${JSON.stringify(summary, null, 2)}\n`);
}

if (
  process.argv[1] !== undefined &&
  path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  runCommandLine();
}
