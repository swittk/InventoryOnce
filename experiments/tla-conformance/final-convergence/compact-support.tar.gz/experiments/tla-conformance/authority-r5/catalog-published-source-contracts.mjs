/** Explicit domain in which source equations quantify over every valid input. */
export const CATALOG_PUBLISHED_SOURCE_DOMAIN =
  "ALL_VALIDATED_CATALOGS_AND_FROZEN_PUBLISHED_SNAPSHOTS_V1";

/** Build one immutable source-equation member declaration. */
function member(surfaceKey, sourceFile, className, methodName, equation, law) {
  return Object.freeze({
    surfaceKey,
    sourceFile,
    className,
    methodName,
    equation,
    law: Object.freeze(law),
  });
}

/** Build one required-map-lookup equation with its complete missing-key branch. */
function requiredLookup(surfaceKey, methodName, mapField, errorPrefix, errorSuffix) {
  return member(
    surfaceKey,
    "src/catalog.ts",
    "InventoryCatalog",
    methodName,
    `result = ${mapField}[key] when present; otherwise throw the declared key-specific error`,
    {
      kind: "required-map-lookup",
      mapField,
      errorPrefix,
      errorSuffix,
    },
  );
}

/** Build one published-catalog facade delegation equation. */
function publishedCatalogDelegate(surfaceKey, methodName) {
  return member(
    surfaceKey,
    "src/facade.ts",
    "InventoryOnceCatalogImplementation",
    methodName,
    `result = catalogFor(storage.readWorld(), configuredCatalog).${methodName}(argument)`,
    { kind: "published-catalog-delegate", targetMethod: methodName },
  );
}

/** Build one direct frozen-snapshot return equation. */
function snapshotReturn(
  surfaceKey,
  methodName,
  parameterCount,
  expression,
  defaults = [],
  optionalParameters = [],
) {
  return member(
    surfaceKey,
    "src/facade.ts",
    "InventoryOnceReadSnapshotImplementation",
    methodName,
    `result = ${expression}`,
    {
      kind: "direct-return",
      parameterCount,
      defaults: Object.freeze(defaults),
      optionalParameters: Object.freeze(optionalParameters),
      expression,
    },
  );
}

/** Independently reviewed equations for the complete 33-member read family. */
export const CATALOG_PUBLISHED_SOURCE_CONTRACTS = Object.freeze([
  requiredLookup(
    "type:src/catalog.ts#InventoryCatalog.activeItem::call[0]",
    "activeItem",
    "activeItemById",
    "Unknown active inventory item '",
    "'.",
  ),
  requiredLookup(
    "type:src/catalog.ts#InventoryCatalog.itemRevision::call[0]",
    "itemRevision",
    "itemByRevisionId",
    "Unknown inventory item revision '",
    "'.",
  ),
  member(
    "type:src/catalog.ts#InventoryCatalog.itemRevisionsForItem::call[0]",
    "src/catalog.ts",
    "InventoryCatalog",
    "itemRevisionsForItem",
    "result = freeze(itemRevisions filtered by exact stable itemId)",
    { kind: "retained-item-filter" },
  ),
  member(
    "type:src/catalog.ts#InventoryCatalog.measurementAxis::call[0]",
    "src/catalog.ts",
    "InventoryCatalog",
    "measurementAxis",
    "result = primary axis when ids match, else first matching independent axis, else throw",
    { kind: "measurement-axis-lookup" },
  ),
  requiredLookup(
    "type:src/catalog.ts#InventoryCatalog.packagingRevision::call[0]",
    "packagingRevision",
    "packagingByRevisionId",
    "Unknown inventory packaging revision '",
    "'.",
  ),
  requiredLookup(
    "type:src/catalog.ts#InventoryCatalog.activeComposition::call[0]",
    "activeComposition",
    "activeCompositionById",
    "Unknown active inventory composition '",
    "'.",
  ),
  requiredLookup(
    "type:src/catalog.ts#InventoryCatalog.compositionRevision::call[0]",
    "compositionRevision",
    "compositionByRevisionId",
    "Unknown inventory composition revision '",
    "'.",
  ),
  requiredLookup(
    "type:src/catalog.ts#InventoryCatalog.compositionForSourcePackagingRevision::call[0]",
    "compositionForSourcePackagingRevision",
    "compositionBySourcePackagingRevisionId",
    "Inventory packaging revision '",
    "' has no heterogeneous composition.",
  ),
  requiredLookup(
    "type:src/catalog.ts#InventoryCatalog.activeTransformation::call[0]",
    "activeTransformation",
    "activeTransformationById",
    "Unknown active inventory transformation '",
    "'.",
  ),
  requiredLookup(
    "type:src/catalog.ts#InventoryCatalog.transformationRevision::call[0]",
    "transformationRevision",
    "transformationByRevisionId",
    "Unknown inventory transformation revision '",
    "'.",
  ),
  member(
    "type:src/catalog.ts#InventoryCatalog.transformationsForItem::call[0]",
    "src/catalog.ts",
    "InventoryCatalog",
    "transformationsForItem",
    "result = freeze(all retained transformations with any input/output revision owned by itemId)",
    { kind: "retained-transformation-item-filter" },
  ),
  member(
    "type:src/catalog.ts#InventoryCatalog.transformationsFromRevision::call[0]",
    "src/catalog.ts",
    "InventoryCatalog",
    "transformationsFromRevision",
    "result = freeze(sorted active transformations with an input matching the exact revision)",
    { kind: "active-transformation-revision-filter", side: "inputs" },
  ),
  member(
    "type:src/catalog.ts#InventoryCatalog.transformationsToRevision::call[0]",
    "src/catalog.ts",
    "InventoryCatalog",
    "transformationsToRevision",
    "result = freeze(sorted active transformations with an output matching the exact revision)",
    { kind: "active-transformation-revision-filter", side: "outputs" },
  ),
  member(
    "type:src/catalog.ts#InventoryCatalog.transformationsBetweenRevisions::call[0]",
    "src/catalog.ts",
    "InventoryCatalog",
    "transformationsBetweenRevisions",
    "result = freeze(transformationsFromRevision(from) filtered by an exact matching output revision)",
    { kind: "between-transformation-filter" },
  ),
  requiredLookup(
    "type:src/catalog.ts#InventoryCatalog.activeCollection::call[0]",
    "activeCollection",
    "activeCollectionById",
    "Unknown active inventory collection '",
    "'.",
  ),
  requiredLookup(
    "type:src/catalog.ts#InventoryCatalog.collectionRevision::call[0]",
    "collectionRevision",
    "collectionByRevisionId",
    "Unknown inventory collection revision '",
    "'.",
  ),
  requiredLookup(
    "type:src/catalog.ts#InventoryCatalog.collectionItemRevisionIds::call[0]",
    "collectionItemRevisionIds",
    "collectionItemRevisionIdsByRevisionId",
    "Unknown inventory collection revision '",
    "'.",
  ),
  publishedCatalogDelegate(
    "type:src/facade.ts#InventoryOnceCatalogApi.activeItem::call[0]",
    "activeItem",
  ),
  publishedCatalogDelegate(
    "type:src/facade.ts#InventoryOnceCatalogApi.itemRevision::call[0]",
    "itemRevision",
  ),
  publishedCatalogDelegate(
    "type:src/facade.ts#InventoryOnceCatalogApi.itemRevisionsForItem::call[0]",
    "itemRevisionsForItem",
  ),
  snapshotReturn(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.positions::call[0]",
    "positions",
    1,
    "findInventoryPositions(this.world.projection, p0)",
  ),
  snapshotReturn(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.summary::call[0]",
    "summary",
    1,
    "summarizeInventoryStock({ catalog: this.catalog, projection: this.world.projection, selector: p0 })",
  ),
  snapshotReturn(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.availability::call[0]",
    "availability",
    2,
    "summarizeInventoryAvailability({ catalog: this.catalog, projection: this.world.projection, reservations: this.world.reservations, selector: p0, at: p1 })",
    [null, "this.defaultAt"],
  ),
  snapshotReturn(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.planAllocation::call[0]",
    "planAllocation",
    1,
    "planInventoryAllocation({ catalog: this.catalog, world: this.world, selector: p0.selector, amount: p0.amount, method: p0.method, at: p0.at ?? this.defaultAt, ...(p0.reservationAt === undefined ? {} : { reservationAt: p0.reservationAt }), ...(p0.itemRevisionId === undefined ? {} : { itemRevisionId: p0.itemRevisionId }), ...(p0.allowExpiredLots === undefined ? {} : { allowExpiredLots: p0.allowExpiredLots }), ...(p0.reservationId === undefined ? {} : { reservationId: p0.reservationId }), ...(p0.allowAllocatedStock === undefined ? {} : { allowAllocatedStock: p0.allowAllocatedStock }) })",
  ),
  snapshotReturn(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.packagingRevisions::call[0]",
    "packagingRevisions",
    1,
    "listInventoryPackagingRevisions({ catalog: this.catalog, ...p0 })",
  ),
  snapshotReturn(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.container::call[0]",
    "container",
    1,
    "this.world.projection.containers[inventoryContainerIdentity(p0)]",
  ),
  member(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.containers::call[0]",
    "src/facade.ts",
    "InventoryOnceReadSnapshotImplementation",
    "containers",
    "result = Object.values(frozen projection containers) sorted by exact container identity",
    {
      kind: "projection-values-sort",
      expression: "this.world.projection.containers",
      comparator: "compareProjectedContainerDefinition",
    },
  ),
  snapshotReturn(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.lot::call[0]",
    "lot",
    2,
    "this.world.projection.lots[inventoryLotIdentity(p0, p1)]",
  ),
  snapshotReturn(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.lots::call[0]",
    "lots",
    1,
    "inventoryProjectedLots(this.world.projection, p0)",
    [],
    [0],
  ),
  member(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.compositionRevisionsForItem::call[0]",
    "src/facade.ts",
    "InventoryOnceReadSnapshotImplementation",
    "compositionRevisionsForItem",
    "result = exact catalog compositions whose source package belongs to itemId, sorted by revision identity",
    { kind: "snapshot-composition-filter" },
  ),
  snapshotReturn(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.collectionSummary::call[0]",
    "collectionSummary",
    1,
    "summarizeInventoryCollection({ catalog: this.catalog, projection: this.world.projection, collectionRevisionId: p0.collectionRevisionId, ...(p0.scope === undefined ? {} : { scope: p0.scope }) })",
  ),
  snapshotReturn(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.event::call[0]",
    "event",
    1,
    "inventorySparseRecordValue(this.world.projection.events, p0)",
  ),
  snapshotReturn(
    "type:src/facade.ts#InventoryOnceReadSnapshotApi.count::call[0]",
    "count",
    1,
    "inventorySparseRecordValue(this.world.counts.counts, p0)",
  ),
]);

/** Independently reviewed non-public helper equations needed by facade reads. */
export const CATALOG_PUBLISHED_SUPPORTING_CONTRACTS = Object.freeze([
  Object.freeze({
    sourceFile: "src/facade.ts",
    functionName: "inventoryCatalogForPublishedWorld",
    equation:
      "result = configured catalog exactly at revision zero; otherwise reconstruct the exact published catalog snapshot",
    law: Object.freeze({ kind: "published-catalog-selection" }),
  }),
  Object.freeze({
    sourceFile: "src/facade.ts",
    functionName: "inventoryProjectedLots",
    equation:
      "result = all lot identities or the exact item index, rejecting missing/foreign index rows, sorted by item-scoped identity",
    law: Object.freeze({ kind: "projected-lot-index" }),
  }),
]);

/** Build one independently reviewed pure catalog snapshot/integrity equation. */
function catalogSnapshotMember(
  sourceFile,
  declarationKind,
  declarationName,
  surfaceKeys,
  equation,
  law,
  className,
) {
  return Object.freeze({
    sourceFile,
    declarationKind,
    declarationName,
    surfaceKeys: Object.freeze(surfaceKeys),
    equation,
    law: Object.freeze(law),
    ...(className === undefined ? {} : { className }),
  });
}

/** Independent supported family for pure catalog construction and snapshot integrity. */
export const CATALOG_SNAPSHOT_SOURCE_CONTRACTS = Object.freeze([
  catalogSnapshotMember(
    "src/catalog.ts",
    "method",
    "define",
    [
      "export:.#InventoryCatalog.define::call[0]",
      "export:./kernel#InventoryCatalog.define::call[0]",
    ],
    "result = new InventoryCatalog(createInventoryCatalogParts(input))",
    { kind: "catalog-static-define" },
    "InventoryCatalog",
  ),
  catalogSnapshotMember(
    "src/catalog.ts",
    "function",
    "defineInventoryCatalog",
    [
      "export:.#defineInventoryCatalog::call[0]",
      "export:./kernel#defineInventoryCatalog::call[0]",
    ],
    "result = InventoryCatalog.define(input)",
    { kind: "catalog-define-delegate" },
  ),
  catalogSnapshotMember(
    "src/catalog.ts",
    "function",
    "emptyInventoryCatalogSnapshot",
    [
      "export:.#emptyInventoryCatalogSnapshot::call[0]",
      "export:./kernel#emptyInventoryCatalogSnapshot::call[0]",
    ],
    "result = the complete empty retained snapshot with digest computed from the same empty definition input",
    { kind: "empty-catalog-snapshot" },
  ),
  catalogSnapshotMember(
    "src/catalog.ts",
    "function",
    "inventoryCatalogFromSnapshot",
    [
      "export:.#inventoryCatalogFromSnapshot::call[0]",
      "export:./kernel#inventoryCatalogFromSnapshot::call[0]",
    ],
    "result = normalized snapshot catalog only when its recomputed digest equals the retained digest; otherwise throw",
    { kind: "catalog-from-snapshot" },
  ),
  catalogSnapshotMember(
    "src/catalog.ts",
    "function",
    "assertInventoryCatalogRetainsSnapshot",
    [
      "export:.#assertInventoryCatalogRetainsSnapshot::call[0]",
      "export:./kernel#assertInventoryCatalogRetainsSnapshot::call[0]",
    ],
    "for every retained item, package, composition, transformation, collection, and fungibility revision, require an equal digest at the same exact revision identity",
    { kind: "retained-catalog-digest-equality" },
  ),
  catalogSnapshotMember(
    "src/integrity.ts",
    "function",
    "inventoryCatalogSnapshotDigest",
    ["export:./storage#inventoryCatalogSnapshotDigest::call[0]"],
    "result = inventoryCatalogFromSnapshot(snapshot).digest",
    { kind: "catalog-snapshot-digest" },
  ),
]);

/** Storage-backed reads that still require a causal published-world binding at the hub. */
export const PUBLISHED_READ_STATEFUL_BINDING_BLOCKER = Object.freeze({
  family: "PUBLISHED_WORLD_STORAGE_ACQUISITION",
  reason:
    "Source equations prove exact delegation after readWorld, but this lane does not substitute them for checkpoint-derived storage causality.",
  surfaceKeys: Object.freeze([
    "export:.#readPublishedInventoryCatalog::call[0]",
    "export:.#readPublishedInventorySnapshot::call[0]",
    "type:src/facade.ts#InventoryOnceCatalogApi.activeItem::call[0]",
    "type:src/facade.ts#InventoryOnceCatalogApi.itemRevision::call[0]",
    "type:src/facade.ts#InventoryOnceCatalogApi.itemRevisionsForItem::call[0]",
  ]),
  checkpointCausalityProvedHere: false,
  localAdmissionCreditGranted: false,
});

/** Existing stateful publication mismatch kept outside read-equation admission. */
export const CATALOG_PUBLICATION_STATEFUL_BLOCKER = Object.freeze({
  gapId: "CATALOG_PUBLICATION_REDUNDANT_SWITCH_ACTIVE_GAP",
  family: "STATEFUL_CATALOG_PUBLICATION_COMMANDS",
  reason:
    "Original CatalogPublication permits redundant SwitchActive occurrences that the native publication command rejects or stutters.",
  originalMismatchOccurrences: 1080,
  sourceEquationCreditGranted: false,
});
