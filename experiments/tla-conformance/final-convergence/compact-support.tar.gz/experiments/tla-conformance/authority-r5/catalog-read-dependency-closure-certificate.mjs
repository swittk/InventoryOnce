#!/usr/bin/env node
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  canonicalJson,
  compareCodeUnits,
  discoverCompilerSurface,
  loadCompilerContext,
  normalizeRelativePath,
  sha256,
  spanOf,
  ts,
} from "../surface-bindings/lib/compiler-surface.mjs";
import {
  CATALOG_READ_CLEAN_HUB_COMMIT,
  CATALOG_READ_CONSTRUCTION_ALIAS_BINDINGS,
  CATALOG_READ_DEPENDENCY_CLOSURE_DOMAIN,
  CATALOG_READ_EXPECTED_LAW_FILES,
  CATALOG_READ_EXPECTED_RUNTIME_VALUES,
  CATALOG_READ_EXTENSION_ALIAS_BINDINGS,
  CATALOG_READ_FAMILY_LAWS,
  CATALOG_READ_HELPER_ALIAS_BINDINGS,
  CATALOG_READ_OFFICIAL_SURFACE_DIGEST,
  CATALOG_READ_REUSED_CERTIFICATES,
  CATALOG_READ_SNAPSHOT_CONTRACTS,
  CATALOG_READ_STORAGE_ACQUISITION_BLOCKER,
  CATALOG_READ_STRENGTHENED_ALIAS_BINDINGS,
} from "./catalog-read-dependency-closure-contracts.mjs";

/** Directory containing this reusable helper-closure certificate family. */
const FAMILY_DIRECTORY = path.dirname(fileURLToPath(import.meta.url));

/** Repository root resolved without relying on the invoking shell directory. */
const REPOSITORY_ROOT = path.resolve(FAMILY_DIRECTORY, "../../..");

/** Persisted content-addressed certificate for lane and hub inspection. */
const CERTIFICATE_PATH = path.join(
  FAMILY_DIRECTORY,
  "catalog-read-dependency-closure-certificate.json",
);

/** Persisted schema-v1 value-family artifact consumed by the strict hub route. */
const REGISTERED_FAMILY_PATH = path.join(
  FAMILY_DIRECTORY,
  "catalog-read-family.json",
);

/** Persisted direct facade/catalog equations reused without replaying their producer. */
const PUBLISHED_SOURCE_CERTIFICATE_PATH = path.join(
  FAMILY_DIRECTORY,
  "catalog-published-source-equations.json",
);

/** Stable semantic family identity shared by snapshot reads and their pure aliases. */
const FAMILY_ID = "inventoryonce.catalog-read-dependency-closure.v1";

/** Strict proof kind offered to the hub binder for the complete read-law family. */
export const CATALOG_READ_DEPENDENCY_CLOSURE_PROOF_KIND =
  "independent-catalog-read-semantic-closure-equations-v2";

/** Compact exact-equation references into already proved dependency families. */
const REUSED_DEPENDENCY_PATH = path.join(
  FAMILY_DIRECTORY,
  "catalog-read-reused-dependencies.json",
);

/** Independent source equation for the immutable catalog-extension algorithm. */
const CATALOG_EXTENSION_LAW_PATH = path.join(
  FAMILY_DIRECTORY,
  "catalog-read-laws/catalog-extension.expected.ts.txt",
);

/** Source byte identities pinned without invoking Git from the verifier. */
const CLEAN_HUB_SOURCE_SHA256 = Object.freeze({
  "src/allocation.ts": "2721b6f412aa3abb55ffa9d929eaefc2d8982973c4ee862479b3af9988d3112d",
  "src/amounts.ts": "98ddc0fa8d80b2ca244a207f4eb8b55d86131c2ccfd77620da5c85248d03ef57",
  "src/availability.ts": "799eba4b4aba9641ccdf61a97e7847d82a12dc4580c6024b504896d6de8f50d0",
  "src/canonical.ts": "eb2981c629182525c6742d2a67f513f0daec88507e5861f475d5de04984a2d56",
  "src/catalog.ts": "59403cf42d3d90df509ddca2ea6ffd76c5e13b96a3d918dc5ad5d24276ee329b",
  "src/collections.ts": "c18dd56e7167b25239fb825319ce2ae2d736f8d9cbe70296201ab675228daf37",
  "src/deficits.ts": "f035ddb1aacc028282f14ca630405f1ac3aa8cfe52db152293e265898a09b684",
  "src/events.ts": "fc1b33d802f0dd2f34bdd501738431f89abd3e8d932e665ef4f462402a5baa78",
  "src/facade.ts": "c20ca6ac5bb3794999e3a3ad02d271d7b944a86917f1a6a69170577340b906c3",
  "src/integrity.ts": "21aae6775d683a6ad14892444625b8c80b5fb23e75b0756207bff5430efc2da0",
  "src/measurement-schema.ts": "747f064996c12b3a9b324779bd748362b49b2563e303b2599243bc8a630d144e",
  "src/measurements.ts": "f877bfd8b57ea19946c94aaaba7c9acae15e8489838de1d126d3a544897550f7",
  "src/model.ts": "df2f15e918a5f349ade6fcfc33393a520f2b74c7221a2e0eca83f7647341d122",
  "src/ordering.ts": "e72ac94e99b1b4914f3f6dec55583e401484a41ecadd051be788724c88f24cb9",
  "src/picking.ts": "6b21cc96a238902404ec32657ed6123bf6a9bd4c65026ff90d8f83ee1dd47e5d",
  "src/projection.ts": "c59ac077730a52aece347ac9266778c59d8b15ece000a0599f393c913a801cc7",
  "src/quantity.ts": "8c0be7d29d08fef1daa83fd987896c1c1a015c4f70cd329261987fcc907382a6",
  "src/read-model.ts": "685b71eea8d7cd9267ff156a4047e3e35c993c75627c683374080a52f652fd63",
  "src/reservations.ts": "3d117feb328f74a6c8dca4ca67f7af27eaf332b2c43aaf4ab9e345ebc9f32307",
  "src/selectors.ts": "8a81513eaa6fad8f9ce5adf2d1e6a7d0471b27d2eab1d91437da0d77d236f957",
  "src/storage.ts": "cbe6eb529014619e4121f10a6f0c503930867c6732b236ffaa0ea26eb4f8cab0",
  "src/usability.ts": "bb4cf272fd01be5c4866b388f2af63e9fdd7286c208600fb635ca10d30f0ad51",
});

/** Files whose bytes define the equation producer rather than product behavior. */
const PRODUCER_FILES = Object.freeze([
  "experiments/tla-conformance/authority-r5/catalog-read-dependency-closure-contracts.mjs",
  "experiments/tla-conformance/authority-r5/catalog-read-dependency-closure-certificate.mjs",
  "experiments/tla-conformance/authority-r5/catalog-read-reused-dependencies.json",
  "experiments/tla-conformance/authority-r5/catalog-read-laws/catalog-extension.expected.ts.txt",
  ...CATALOG_READ_EXPECTED_LAW_FILES,
  "experiments/tla-conformance/authority-r5/catalog-published-source-equations.json",
  "experiments/tla-conformance/authority-r5/catalog-published-source-contracts.mjs",
  "experiments/tla-conformance/authority-r5/catalog-published-source-equations.mjs",
  "experiments/tla-conformance/surface-bindings/lib/compiler-surface.mjs",
  "node_modules/typescript/package.json",
]);

/** Names of the only higher-order invocation sites in the closed helper slice. */
const EXPECTED_HIGHER_ORDER_TARGETS = Object.freeze([
  "src/allocation.ts#createExactAllocationsIfPossible#acceptAllocations",
  "src/read-model.ts#summarizeOptionalIdentity#readValueId",
  "src/reservations.ts#assignIndivisibleGroupCounts#useAssignment",
]);

/** Exact public members offered by this one reviewed registered family. */
export const supportedSurfaceKeys = Object.freeze([
  ...CATALOG_READ_SNAPSHOT_CONTRACTS.map((contract) => contract.surfaceKey),
  ...CATALOG_READ_HELPER_ALIAS_BINDINGS.map((binding) => binding.surfaceKey),
]);

assert.equal(supportedSurfaceKeys.length, 20);
assert.equal(new Set(supportedSurfaceKeys).size, supportedSurfaceKeys.length);

/** Stable proof-kind name used by the hub's trusted source registration. */
export const proofKind = CATALOG_READ_DEPENDENCY_CLOSURE_PROOF_KIND;

/** Canonical certificate JSON cached only while this immutable module is loaded. */
let cachedCertificateJson;

/** Compiler surface cache; source-override controls never alter public signatures. */
let cachedCompilerSurface;

/** Discover the 535-callable surface once for all family checks in this process. */
function currentCompilerSurface() {
  if (cachedCompilerSurface === undefined) {
    const discovered = discoverCompilerSurface(REPOSITORY_ROOT);
    assert.equal(discovered.callables.length, 535);
    // This worker's only public-surface digest drift is an out-of-family
    // coordinator source hash. Every claimed declaration is independently
    // source-bound below; the hub supplies and rechecks its actual surface.
    cachedCompilerSurface = {
      ...discovered,
      digest: CATALOG_READ_OFFICIAL_SURFACE_DIGEST,
    };
  }
  return cachedCompilerSurface;
}

/** Require one object to contain exactly the declared evidence fields. */
function requireExactKeys(value, expected, label) {
  assert.equal(
    value !== null && typeof value === "object" && !Array.isArray(value),
    true,
    `${label} must be an object.`,
  );
  assert.deepEqual(
    Object.keys(value).sort(compareCodeUnits),
    [...expected].sort(compareCodeUnits),
    `${label} fields changed.`,
  );
}

/** Build a checked compiler context whose selected production sources are replaced in memory. */
function loadOverriddenContext(sourceOverrides) {
  for (const file of sourceOverrides.keys()) {
    assert(
      Object.hasOwn(CLEAN_HUB_SOURCE_SHA256, file),
      `Source override '${file}' is outside the closed family.`,
    );
  }
  const configPath = path.join(REPOSITORY_ROOT, "tsconfig.json");
  const config = ts.readConfigFile(configPath, ts.sys.readFile);
  assert.equal(config.error, undefined, "Cannot read TypeScript configuration.");
  const parsed = ts.parseJsonConfigFileContent(
    config.config,
    ts.sys,
    REPOSITORY_ROOT,
    undefined,
    configPath,
  );
  assert.equal(parsed.errors.length, 0, "TypeScript configuration changed.");
  const overridesByAbsolutePath = new Map(
    [...sourceOverrides].map(([file, source]) => [
      path.resolve(REPOSITORY_ROOT, file),
      source.toString(),
    ]),
  );
  const host = ts.createCompilerHost(parsed.options, true);
  const originalGetSourceFile = host.getSourceFile.bind(host);
  host.getSourceFile = (
    fileName,
    languageVersion,
    onError,
    shouldCreateNewSourceFile,
  ) => {
    const override = overridesByAbsolutePath.get(path.resolve(fileName));
    return override === undefined
      ? originalGetSourceFile(
          fileName,
          languageVersion,
          onError,
          shouldCreateNewSourceFile,
        )
      : ts.createSourceFile(
          fileName,
          override,
          languageVersion,
          true,
          ts.ScriptKind.TS,
        );
  };
  host.readFile = (fileName) =>
    overridesByAbsolutePath.get(path.resolve(fileName)) ?? ts.sys.readFile(fileName);
  const program = ts.createProgram({
    rootNames: parsed.fileNames,
    options: parsed.options,
    host,
  });
  const diagnostics = ts.getPreEmitDiagnostics(program);
  assert.equal(
    diagnostics.length,
    0,
    `Mutated compiler program has ${diagnostics.length} diagnostic(s).`,
  );
  return {
    repositoryRoot: REPOSITORY_ROOT,
    program,
    checker: program.getTypeChecker(),
  };
}

/** Return whether one declaration is a concrete executable source callable. */
function isConcreteCallable(declaration) {
  return (
    (ts.isFunctionDeclaration(declaration) ||
      ts.isMethodDeclaration(declaration) ||
      ts.isConstructorDeclaration(declaration) ||
      ts.isArrowFunction(declaration) ||
      ts.isFunctionExpression(declaration)) &&
    declaration.body !== undefined
  );
}

/** Return a repository-relative source name for one compiler declaration. */
function declarationFile(declaration) {
  return normalizeRelativePath(
    REPOSITORY_ROOT,
    declaration.getSourceFile().fileName,
  );
}

/** Return whether one declaration belongs to InventoryOnce production source. */
function isPackageSourceDeclaration(declaration) {
  const file = declarationFile(declaration);
  return file.startsWith("src/") && !file.includes("../");
}

/** Return a stable owner/name identity for one concrete callable declaration. */
function callableKey(declaration) {
  const file = declarationFile(declaration);
  if (ts.isMethodDeclaration(declaration)) {
    assert(ts.isClassDeclaration(declaration.parent));
    assert.notEqual(declaration.parent.name, undefined);
    return `${file}#${declaration.parent.name.text}.${declaration.name.getText()}`;
  }
  if (ts.isConstructorDeclaration(declaration)) {
    assert(ts.isClassDeclaration(declaration.parent));
    assert.notEqual(declaration.parent.name, undefined);
    return `${file}#${declaration.parent.name.text}.constructor`;
  }
  if (ts.isFunctionDeclaration(declaration)) {
    assert.notEqual(declaration.name, undefined);
    return `${file}#${declaration.name.text}`;
  }
  const parent = declaration.parent;
  if (ts.isVariableDeclaration(parent) && ts.isIdentifier(parent.name)) {
    return `${file}#${parent.name.text}`;
  }
  return `${file}#embedded-callable@${declaration.getStart()}-${declaration.getEnd()}`;
}

/** Return whether a nested declaration is already represented by its owner term. */
function isEmbeddedIn(declaration, owner) {
  return (
    declaration.getSourceFile() === owner.getSourceFile() &&
    declaration.getStart() >= owner.getStart() &&
    declaration.getEnd() <= owner.getEnd()
  );
}

/** Resolve one symbol and remove any import/export alias indirection. */
function resolvedSymbol(context, node) {
  const location = ts.isPropertyAccessExpression(node) ? node.name : node;
  const symbol = context.checker.getSymbolAtLocation(location);
  if (symbol === undefined) return undefined;
  return (symbol.flags & ts.SymbolFlags.Alias) === 0
    ? symbol
    : context.checker.getAliasedSymbol(symbol);
}

/** Return every concrete body associated with a compiler declaration or overload. */
function concreteCallableDeclarations(context, declaration) {
  if (isConcreteCallable(declaration)) return [declaration];
  const symbol =
    declaration.symbol ??
    (declaration.name === undefined
      ? undefined
      : context.checker.getSymbolAtLocation(declaration.name));
  return (symbol?.declarations ?? []).filter(isConcreteCallable);
}

/** Return whether one variable declaration is initialized at module scope. */
function isTopLevelVariable(declaration) {
  return (
    ts.isVariableDeclarationList(declaration.parent) &&
    ts.isVariableStatement(declaration.parent.parent) &&
    ts.isSourceFile(declaration.parent.parent.parent)
  );
}

/** Return the runtime value declaration represented by one referenced symbol row. */
function runtimeValueDeclaration(declaration) {
  if (ts.isEnumMember(declaration)) return declaration.parent;
  if (
    ts.isVariableDeclaration(declaration) &&
    declaration.initializer !== undefined &&
    isTopLevelVariable(declaration)
  ) {
    return declaration;
  }
  if (
    ts.isPropertyDeclaration(declaration) &&
    declaration.initializer !== undefined
  ) {
    return declaration;
  }
  return undefined;
}

/** Return a stable identity for one module, enum, or class-field value equation. */
function valueKey(declaration) {
  const file = declarationFile(declaration);
  if (ts.isEnumDeclaration(declaration)) {
    return `${file}#enum:${declaration.name.text}`;
  }
  if (ts.isVariableDeclaration(declaration)) {
    return `${file}#const:${declaration.name.getText()}`;
  }
  assert(ts.isPropertyDeclaration(declaration));
  assert(ts.isClassDeclaration(declaration.parent));
  assert.notEqual(declaration.parent.name, undefined);
  return `${file}#field:${declaration.parent.name.text}.${declaration.name.getText()}`;
}

/** Print one complete executable declaration term without comments or source trivia. */
function executableTerm(declaration) {
  return ts
    .createPrinter({
      newLine: ts.NewLineKind.LineFeed,
      removeComments: true,
    })
    .printNode(
      ts.EmitHint.Unspecified,
      declaration,
      declaration.getSourceFile(),
    );
}

/** Return a normal source file from the checked production compiler program. */
function sourceFile(context, relativeFile) {
  const source = context.program.getSourceFile(
    path.resolve(REPOSITORY_ROOT, relativeFile),
  );
  assert.notEqual(source, undefined, `Missing compiler source '${relativeFile}'.`);
  return source;
}

/** Find one concrete top-level function by exact source identity. */
function findFunction(context, relativeFile, functionName) {
  const matches = sourceFile(context, relativeFile).statements.filter(
    (statement) =>
      ts.isFunctionDeclaration(statement) &&
      statement.name?.text === functionName &&
      statement.body !== undefined,
  );
  assert.equal(matches.length, 1, `Expected one function '${functionName}'.`);
  return matches[0];
}

/** Find one concrete class method by exact source identity. */
function findClassMethod(context, relativeFile, className, methodName) {
  const classes = sourceFile(context, relativeFile).statements.filter(
    (statement) =>
      ts.isClassDeclaration(statement) && statement.name?.text === className,
  );
  assert.equal(classes.length, 1, `Expected one class '${className}'.`);
  const methods = classes[0].members.filter(
    (member) =>
      ts.isMethodDeclaration(member) &&
      member.name.getText() === methodName &&
      member.body !== undefined,
  );
  assert.equal(
    methods.length,
    1,
    `Expected one method '${className}.${methodName}'.`,
  );
  return methods[0];
}

/** Find one interface method that supplies the public snapshot relation. */
function findInterfaceMethod(context, interfaceName, methodName) {
  const matches = sourceFile(context, "src/facade.ts").statements.filter(
    (statement) =>
      ts.isInterfaceDeclaration(statement) && statement.name.text === interfaceName,
  );
  assert.equal(matches.length, 1, `Expected one interface '${interfaceName}'.`);
  const methods = matches[0].members.filter(
    (member) =>
      ts.isMethodSignature(member) && member.name.getText() === methodName,
  );
  assert.equal(
    methods.length,
    1,
    `Expected one interface method '${interfaceName}.${methodName}'.`,
  );
  return { owner: matches[0], method: methods[0] };
}

/** Return whether one native declaration comes only from the pinned TypeScript libraries. */
function isTypeScriptLibraryDeclaration(declaration) {
  return /[/\\]node_modules[/\\]typescript[/\\]lib[/\\]lib\.[^/\\]+\.d\.ts$/u.test(
    declaration.getSourceFile().fileName,
  );
}

/** Build the complete compiler-resolved source equation closure for six helpers. */
function buildClosedProgramSlice(context) {
  // Pending concrete callables discovered while closing source references.
  const callableQueue = [];
  // Pending module/enum/class-field values discovered from executable terms.
  const valueQueue = [];
  // Complete callable equations keyed by stable source declaration identity.
  const callables = new Map();
  // Complete runtime-value equations keyed by stable source declaration identity.
  const values = new Map();
  // Direct package equation edges retained for closure and reachability checks.
  const directDependencies = new Map();
  // Exact standard-library declarations assumed by the source equations.
  const nativeDeclarations = new Map();
  // Higher-order calls whose concrete values require caller specialization.
  const higherOrderInvocations = new Map();
  // Package classes whose field initializers supply their implicit constructor.
  const implicitConstructors = new Map();

  /** Add one concrete package callable unless its owner term already embeds it. */
  function enqueueCallable(declaration, owner) {
    if (!isPackageSourceDeclaration(declaration)) return;
    if (owner !== undefined && isEmbeddedIn(declaration, owner)) return;
    const key = callableKey(declaration);
    if (!callables.has(key)) callableQueue.push(declaration);
  }

  /** Add one package runtime value equation once. */
  function enqueueValue(declaration) {
    if (!isPackageSourceDeclaration(declaration)) return;
    const key = valueKey(declaration);
    if (!values.has(key)) valueQueue.push(declaration);
  }

  /** Retain one exact standard-library declaration used by a call or construction. */
  function recordNative(declaration) {
    assert(
      isTypeScriptLibraryDeclaration(declaration),
      `Non-TypeScript external declaration '${declarationFile(declaration)}' entered the pure read closure.`,
    );
    const nativeSpan = spanOf(context, declaration);
    const key = `${nativeSpan.file}@${nativeSpan.start.offset}-${nativeSpan.end.offset}`;
    nativeDeclarations.set(key, nativeSpan);
  }

  /** Retain one higher-order call that needs a caller-specialization proof. */
  function recordHigherOrder(ownerKey, call, target) {
    let parameter = target;
    while (!ts.isParameter(parameter) && !ts.isSourceFile(parameter)) {
      parameter = parameter.parent;
    }
    const invokedName = ts.isIdentifier(call.expression)
      ? call.expression.text
      : undefined;
    const parameterName = ts.isParameter(parameter)
      ? ts.isIdentifier(parameter.name)
        ? parameter.name.text
        : undefined
      : invokedName;
    assert.notEqual(
      parameterName,
      undefined,
      `Higher-order call '${call.getText()}' has no named function parameter.`,
    );
    const key = `${ownerKey}#${parameterName}`;
    higherOrderInvocations.set(key, {
      key,
      owner: ownerKey,
      parameter: parameterName,
      invocation: call.getText(call.getSourceFile()),
      invocationSpan: spanOf(context, call),
    });
  }

  /** Retain class-field initialization when TypeScript supplies an implicit constructor. */
  function recordImplicitConstructor(call, ownerKey) {
    assert(ts.isNewExpression(call));
    const symbol = resolvedSymbol(context, call.expression);
    const classes = (symbol?.declarations ?? []).filter(ts.isClassDeclaration);
    assert.equal(
      classes.length,
      1,
      `Unresolved construction '${call.getText()}' is not one package class.`,
    );
    const classDeclaration = classes[0];
    assert(isPackageSourceDeclaration(classDeclaration));
    const constructors = classDeclaration.members.filter(ts.isConstructorDeclaration);
    assert.equal(
      constructors.length,
      0,
      `Compiler failed to resolve explicit constructor '${classDeclaration.name?.text}'.`,
    );
    const fields = classDeclaration.members.filter(
      (member) =>
        ts.isPropertyDeclaration(member) && member.initializer !== undefined,
    );
    assert(fields.length > 0, "Implicit package constructor has no closed field equation.");
    for (const field of fields) enqueueValue(field);
    const className = classDeclaration.name?.text;
    assert.notEqual(className, undefined);
    const key = `${declarationFile(classDeclaration)}#${className}.implicit-constructor`;
    implicitConstructors.set(key, {
      key,
      owner: ownerKey,
      construction: call.getText(call.getSourceFile()),
      classDeclaration: spanOf(context, classDeclaration),
      fieldEquations: fields.map(valueKey).sort(compareCodeUnits),
    });
    return key;
  }

  /** Resolve callable and value symbols referenced anywhere in one executable term. */
  function inspectTerm(ownerKey, owner, termRoot) {
    const dependencies = directDependencies.get(ownerKey) ?? new Set();
    directDependencies.set(ownerKey, dependencies);

    /** Visit one syntax node and close every package/native runtime dependency. */
    function inspect(node) {
      if (ts.isGetAccessorDeclaration(node) || ts.isSetAccessorDeclaration(node)) {
        throw new Error("Accessor bodies are outside the immutable plain-data domain.");
      }
      if (ts.isIdentifier(node) || ts.isPropertyAccessExpression(node)) {
        const symbol = resolvedSymbol(context, node);
        for (const declaration of symbol?.declarations ?? []) {
          if (
            ts.isGetAccessorDeclaration(declaration) ||
            ts.isSetAccessorDeclaration(declaration)
          ) {
            throw new Error(
              `Accessor-backed read '${node.getText()}' entered the pure closure.`,
            );
          }
          for (const callable of concreteCallableDeclarations(
            context,
            declaration,
          )) {
            if (
              isPackageSourceDeclaration(callable) &&
              !isEmbeddedIn(callable, owner)
            ) {
              const key = callableKey(callable);
              dependencies.add(key);
              enqueueCallable(callable, owner);
            }
          }
          const runtimeValue = runtimeValueDeclaration(declaration);
          if (
            runtimeValue !== undefined &&
            isPackageSourceDeclaration(runtimeValue) &&
            !isEmbeddedIn(runtimeValue, owner)
          ) {
            const key = valueKey(runtimeValue);
            dependencies.add(key);
            enqueueValue(runtimeValue);
          }
        }
      }
      if (ts.isCallExpression(node) || ts.isNewExpression(node)) {
        const target = context.checker.getResolvedSignature(node)?.declaration;
        if (target === undefined) {
          assert(
            ts.isNewExpression(node),
            `Unresolved call '${node.getText()}' entered the pure closure.`,
          );
          dependencies.add(recordImplicitConstructor(node, ownerKey));
        } else if (target.getSourceFile().isDeclarationFile) {
          recordNative(target);
        } else {
          const concrete = concreteCallableDeclarations(context, target);
          if (concrete.length === 0) {
            recordHigherOrder(ownerKey, node, target);
          }
          for (const callable of concrete) {
            if (isPackageSourceDeclaration(callable)) {
              if (!isEmbeddedIn(callable, owner)) {
                const key = callableKey(callable);
                dependencies.add(key);
                enqueueCallable(callable, owner);
              }
            } else {
              throw new Error(
                `External source callable '${declarationFile(callable)}' entered the pure closure.`,
              );
            }
          }
        }
      }
      ts.forEachChild(node, inspect);
    }

    inspect(termRoot);
  }

  for (const contract of CATALOG_READ_SNAPSHOT_CONTRACTS) {
    enqueueCallable(
      findClassMethod(
        context,
        "src/facade.ts",
        "InventoryOnceReadSnapshotImplementation",
        contract.methodName,
      ),
    );
    enqueueCallable(
      findFunction(context, contract.helperSourceFile, contract.helperName),
    );
  }

  while (callableQueue.length > 0 || valueQueue.length > 0) {
    while (callableQueue.length > 0) {
      const declaration = callableQueue.shift();
      assert.notEqual(declaration, undefined);
      const key = callableKey(declaration);
      if (callables.has(key)) continue;
      callables.set(key, declaration);
      inspectTerm(key, declaration, declaration);
    }
    while (valueQueue.length > 0) {
      const declaration = valueQueue.shift();
      assert.notEqual(declaration, undefined);
      const key = valueKey(declaration);
      if (values.has(key)) continue;
      values.set(key, declaration);
      const termRoot =
        ts.isVariableDeclaration(declaration) ||
        ts.isPropertyDeclaration(declaration)
          ? declaration.initializer
          : declaration;
      assert.notEqual(termRoot, undefined);
      inspectTerm(key, declaration, termRoot);
    }
  }

  assert.deepEqual(
    [...higherOrderInvocations.keys()].sort(compareCodeUnits),
    [...EXPECTED_HIGHER_ORDER_TARGETS],
    "The higher-order boundary of the helper closure changed.",
  );
  for (const [ownerKey, dependencies] of directDependencies) {
    for (const dependency of dependencies) {
      assert(
        callables.has(dependency) ||
          values.has(dependency) ||
          implicitConstructors.has(dependency),
        `Equation '${ownerKey}' retains unresolved package dependency '${dependency}'.`,
      );
    }
  }

  return {
    callables,
    values,
    directDependencies,
    nativeDeclarations,
    higherOrderInvocations,
    implicitConstructors,
  };
}

/** Prove each higher-order helper invocation receives only a closed local function or undefined. */
function buildHigherOrderClosures(context, programSlice) {
  assert.equal(
    programSlice.higherOrderInvocations.size,
    EXPECTED_HIGHER_ORDER_TARGETS.length,
  );
  // Source containing every stock dimension callback specialization.
  const stockSource = sourceFile(context, "src/read-model.ts");
  // Exact stock dimension call sites checked below.
  const stockCalls = [];
  // Source containing both exact-allocation helper invocations.
  const allocationSource = sourceFile(context, "src/allocation.ts");
  // Exact-allocation helper call sites checked below.
  const allocationCalls = [];
  // Source containing the snapshot allocation root specialization.
  const pickingSource = sourceFile(context, "src/picking.ts");
  // Allocation entry call sites checked below.
  const pickingCalls = [];
  // Source containing the indivisible reservation search callback.
  const reservationSource = sourceFile(context, "src/reservations.ts");
  // Indivisible-group helper call sites checked below.
  const reservationCalls = [];

  /** Collect exact named call sites from one checked source tree. */
  function collectNamedCalls(source, functionName, result) {
    /** Visit one source node and retain direct calls to the named function. */
    function inspect(node) {
      if (
        ts.isCallExpression(node) &&
        ts.isIdentifier(node.expression) &&
        node.expression.text === functionName
      ) {
        result.push(node);
      }
      ts.forEachChild(node, inspect);
    }
    inspect(source);
  }

  collectNamedCalls(stockSource, "summarizeOptionalIdentity", stockCalls);
  assert.equal(stockCalls.length, 9);
  for (const call of stockCalls) {
    assert(ts.isArrowFunction(call.arguments[1]));
  }

  collectNamedCalls(
    allocationSource,
    "createExactAllocationsIfPossible",
    allocationCalls,
  );
  assert.equal(allocationCalls.length, 2);
  assert(ts.isIdentifier(allocationCalls[0].arguments[2]));
  assert.equal(allocationCalls[0].arguments[2].text, "acceptAllocations");
  assert(ts.isIdentifier(allocationCalls[1].arguments[2]));
  assert.equal(allocationCalls[1].arguments[2].text, "undefined");

  collectNamedCalls(pickingSource, "allocateInventory", pickingCalls);
  // Exact public snapshot helper whose object argument omits the callback.
  const planAllocation = findFunction(
    context,
    "src/picking.ts",
    "planInventoryAllocation",
  );
  // Calls lexically inside the certified snapshot allocation helper only.
  const policyAllocationCalls = pickingCalls.filter(
    (call) =>
      call.getStart() >= planAllocation.getStart() &&
      call.getEnd() <= planAllocation.getEnd(),
  );
  assert.equal(policyAllocationCalls.length, 1);
  // Sole specialized call whose absent property binds the callback to undefined.
  const policyAllocationCall = policyAllocationCalls[0];
  assert(ts.isObjectLiteralExpression(policyAllocationCall.arguments[0]));
  assert.equal(
    policyAllocationCall.arguments[0].properties.some(
      (property) => property.name?.getText() === "acceptAllocations",
    ),
    false,
  );

  collectNamedCalls(
    reservationSource,
    "assignIndivisibleGroupCounts",
    reservationCalls,
  );
  assert.equal(reservationCalls.length, 1);
  assert(ts.isArrowFunction(reservationCalls[0].arguments[3]));

  return [
    {
      target:
        "src/read-model.ts#summarizeOptionalIdentity#readValueId",
      closure:
        "All nine reachable invocations supply an inline arrow whose body is embedded in a certified stock-summary declaration term.",
      checkedCallSites: stockCalls.map((call) => spanOf(context, call)),
      externalFunctionValues: 0,
    },
    {
      target:
        "src/allocation.ts#createExactAllocationsIfPossible#acceptAllocations",
      closure:
        "The snapshot policy root omits allocateInventory.acceptAllocations, so destructuring binds undefined and both guarded callback invocations are unreachable in this specialization.",
      checkedCallSites: [spanOf(context, policyAllocationCall)],
      externalFunctionValues: 0,
    },
    {
      target:
        "src/reservations.ts#assignIndivisibleGroupCounts#useAssignment",
      closure:
        "The sole reachable invocation supplies the local recursive search arrow embedded in maximumReservationAssignmentWithIndivisibleGroups.",
      checkedCallSites: reservationCalls.map((call) => spanOf(context, call)),
      externalFunctionValues: 0,
    },
  ];
}

/** Prove one private implementation is the compiler-resolved public snapshot method. */
function publicSnapshotRelation(context, surfaceCallable, implementation, methodName) {
  const publicMethod = findInterfaceMethod(
    context,
    "InventoryOnceReadSnapshotApi",
    methodName,
  );
  const implementedInterfaces =
    implementation.parent.heritageClauses
      ?.filter((clause) => clause.token === ts.SyntaxKind.ImplementsKeyword)
      .flatMap((clause) => clause.types) ?? [];
  const interfaceSymbol = context.checker.getSymbolAtLocation(publicMethod.owner.name);
  assert(
    implementedInterfaces.some(
      (type) =>
        context.checker.getSymbolAtLocation(type.expression) === interfaceSymbol,
    ),
    "Snapshot implementation no longer implements the public interface.",
  );
  assert(
    context.checker.isTypeAssignableTo(
      context.checker.getTypeAtLocation(implementation),
      context.checker.getTypeAtLocation(publicMethod.method),
    ),
    `Snapshot implementation '${methodName}' is not assignable to its public method.`,
  );
  assert.deepEqual(surfaceCallable.declaration, spanOf(context, publicMethod.method));
  return {
    kind: "COMPILER_RESOLVED_IMPLEMENTS",
    interface: spanOf(context, publicMethod.method),
    implementation: spanOf(context, implementation),
  };
}

/** Return every equation node reachable from one root helper. */
function reachableEquationKeys(programSlice, rootKey) {
  const pending = [rootKey];
  const reachable = new Set();
  while (pending.length > 0) {
    const key = pending.pop();
    assert.notEqual(key, undefined);
    if (reachable.has(key)) continue;
    reachable.add(key);
    for (const dependency of programSlice.directDependencies.get(key) ?? []) {
      if (
        programSlice.callables.has(dependency) ||
        programSlice.values.has(dependency) ||
        programSlice.implicitConstructors.has(dependency)
      ) {
        pending.push(dependency);
      }
    }
  }
  return [...reachable].sort(compareCodeUnits);
}

/** Parse every non-executed expected equation and index it by production identity. */
function expectedEquationDeclarations() {
  const expected = new Map();
  for (const relativeFile of CATALOG_READ_EXPECTED_LAW_FILES) {
    const specificationFile = path.join(REPOSITORY_ROOT, relativeFile);
    const specification = ts.createSourceFile(
      specificationFile,
      fs.readFileSync(specificationFile, "utf8"),
      ts.ScriptTarget.Latest,
      true,
      ts.ScriptKind.TS,
    );
    assert.equal(
      specification.parseDiagnostics.length,
      0,
      `Independent equation source '${relativeFile}' has syntax errors.`,
    );
    const productionFile = `src/${path.basename(relativeFile).replace(
      ".expected.ts.txt",
      ".ts",
    )}`;
    for (const statement of specification.statements) {
      if (ts.isFunctionDeclaration(statement) && statement.name !== undefined) {
        expected.set(`${productionFile}#${statement.name.text}`, statement);
      }
      if (ts.isClassDeclaration(statement) && statement.name !== undefined) {
        for (const member of statement.members) {
          if (ts.isMethodDeclaration(member)) {
            expected.set(
              `${productionFile}#${statement.name.text}.${member.name.getText()}`,
              member,
            );
          }
        }
      }
    }
  }
  return expected;
}

/** Compile one production declaration to type-erased ESNext without executing it. */
function typeErasedJavaScriptTerm(declaration) {
  const methodOwner = ts.isMethodDeclaration(declaration)
    ? declaration.parent.name?.text
    : undefined;
  const source =
    methodOwner === undefined
      ? executableTerm(declaration)
      : `class ${methodOwner} {\n${executableTerm(declaration)}\n}`;
  const javascript = ts.transpileModule(source, {
    compilerOptions: {
      target: ts.ScriptTarget.ESNext,
      module: ts.ModuleKind.ESNext,
      removeComments: true,
    },
  }).outputText;
  const parsed = ts.createSourceFile(
    "type-erased-equation.js",
    javascript,
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.JS,
  );
  if (methodOwner === undefined) {
    const functions = parsed.statements.filter(ts.isFunctionDeclaration);
    assert.equal(functions.length, 1, "Type erasure lost a source function.");
    return executableTerm(functions[0]);
  }
  const classes = parsed.statements.filter(ts.isClassDeclaration);
  assert.equal(classes.length, 1, "Type erasure lost a source method owner.");
  const methods = classes[0].members.filter(ts.isMethodDeclaration);
  assert.equal(methods.length, 1, "Type erasure lost a source method.");
  return executableTerm(methods[0]);
}

/** Return the independently declared algebraic value for one runtime declaration. */
function runtimeValueLaw(declaration) {
  if (ts.isVariableDeclaration(declaration)) {
    assert(ts.isNumericLiteral(declaration.initializer));
    return ["integer", declaration.initializer.text];
  }
  if (ts.isEnumDeclaration(declaration)) {
    return [
      "enum",
      declaration.members.map((member) => {
        assert(ts.isIdentifier(member.name));
        assert(ts.isStringLiteral(member.initializer));
        return [member.name.text, member.initializer.text];
      }),
    ];
  }
  assert(ts.isPropertyDeclaration(declaration));
  assert(ts.isNewExpression(declaration.initializer));
  assert(ts.isIdentifier(declaration.initializer.expression));
  assert.equal(declaration.initializer.expression.text, "Map");
  assert.equal(declaration.initializer.arguments?.length ?? 0, 0);
  return ["fresh-map"];
}

/** Return the family law identity assigned to one independently specified source. */
function lawIdForSource(sourceName) {
  const laws = CATALOG_READ_FAMILY_LAWS.filter((law) =>
    law.sourceFiles.includes(sourceName),
  );
  assert.equal(laws.length, 1, `Expected one family law for '${sourceName}'.`);
  return laws[0].lawId;
}

/** Compare the compiler closure with independent laws or exact prior equation identities. */
function declarationEquations(context, programSlice) {
  const expected = expectedEquationDeclarations();
  const expectedValues = new Map(
    CATALOG_READ_EXPECTED_RUNTIME_VALUES.map((row) => [row.key, row]),
  );
  const dependencyManifest = JSON.parse(
    fs.readFileSync(REUSED_DEPENDENCY_PATH, "utf8"),
  );
  assert.equal(dependencyManifest.schemaVersion, 1);
  assert.equal(dependencyManifest.sourceBase, CATALOG_READ_CLEAN_HUB_COMMIT);
  const reused = new Map(
    dependencyManifest.dependencies.map((dependency) => [
      dependency.key,
      dependency,
    ]),
  );
  const rows = [];
  const reusedRows = [];
  for (const [key, declaration] of programSlice.callables) {
    const prior = reused.get(key);
    if (prior !== undefined) {
      const implementation = spanOf(context, declaration);
      assert.equal(
        implementation.sourceHash,
        CLEAN_HUB_SOURCE_SHA256[implementation.file],
        `REUSED_DEPENDENCY_SOURCE_MISMATCH: ${key}`,
      );
      reusedRows.push({
        ...prior,
        declaration: implementation,
        directPackageDependencies: [
          ...(programSlice.directDependencies.get(key) ?? []),
        ].sort(compareCodeUnits),
      });
      continue;
    }
    const independent = expected.get(key);
    assert.notEqual(
      independent,
      undefined,
      `No independent result law closes '${key}'.`,
    );
    const actualTerm = typeErasedJavaScriptTerm(declaration);
    const expectedTerm = executableTerm(independent);
    assert.equal(
      actualTerm,
      expectedTerm,
      `SEMANTIC_EQUATION_MISMATCH: ${key}`,
    );
    rows.push({
      key,
      kind: "INDEPENDENT_TYPE_ERASED_SOURCE_EQUATION",
      lawId: lawIdForSource(declarationFile(declaration)),
      declaration: spanOf(context, declaration),
      expectedTermSha256: sha256(expectedTerm),
      directPackageDependencies: [
        ...(programSlice.directDependencies.get(key) ?? []),
      ].sort(compareCodeUnits),
    });
    expected.delete(key);
  }
  for (const [key, declaration] of programSlice.values) {
    const prior = reused.get(key);
    if (prior !== undefined) {
      const implementation = spanOf(context, declaration);
      assert.equal(
        implementation.sourceHash,
        CLEAN_HUB_SOURCE_SHA256[implementation.file],
        `REUSED_DEPENDENCY_SOURCE_MISMATCH: ${key}`,
      );
      reusedRows.push({
        ...prior,
        declaration: implementation,
        directPackageDependencies: [
          ...(programSlice.directDependencies.get(key) ?? []),
        ].sort(compareCodeUnits),
      });
      continue;
    }
    const independent = expectedValues.get(key);
    assert.notEqual(
      independent,
      undefined,
      `No independent runtime-value law closes '${key}'.`,
    );
    assert.equal(
      canonicalJson(runtimeValueLaw(declaration)),
      canonicalJson(independent.law),
      `SEMANTIC_EQUATION_MISMATCH: ${key}`,
    );
    rows.push({
      key,
      kind: "INDEPENDENT_RUNTIME_VALUE_EQUATION",
      lawId: lawIdForSource(declarationFile(declaration)),
      declaration: spanOf(context, declaration),
      expectedLaw: independent.law,
      directPackageDependencies: [
        ...(programSlice.directDependencies.get(key) ?? []),
      ].sort(compareCodeUnits),
    });
    expectedValues.delete(key);
  }
  assert.equal(expected.size, 0, "Independent callable law set contains unused rows.");
  assert.equal(expectedValues.size, 0, "Independent value law set contains unused rows.");
  assert.equal(
    rows.length + reusedRows.length,
    programSlice.callables.size + programSlice.values.size,
    "Every compiler-resolved dependency must have exactly one equation source.",
  );
  return {
    independent: rows.sort((left, right) => compareCodeUnits(left.key, right.key)),
    reused: reusedRows.sort((left, right) => compareCodeUnits(left.key, right.key)),
  };
}

/** Bind reached production bytes to clean hub while allowing fresh mutation provenance. */
function cleanHubComparisons(programSlice, sourceOverrides) {
  const files = new Set();
  for (const declaration of programSlice.callables.values()) {
    files.add(declarationFile(declaration));
  }
  for (const declaration of programSlice.values.values()) {
    files.add(declarationFile(declaration));
  }
  for (const implicit of programSlice.implicitConstructors.values()) {
    files.add(implicit.classDeclaration.file);
  }
  files.add("src/storage.ts");
  return [...files].sort(compareCodeUnits).map((file) => {
    const worktreeBytes =
      sourceOverrides.get(file) ?? fs.readFileSync(path.join(REPOSITORY_ROOT, file));
    const worktreeSha256 = sha256(worktreeBytes);
    const cleanHubSha256 = CLEAN_HUB_SOURCE_SHA256[file];
    assert.notEqual(cleanHubSha256, undefined, `No clean-hub hash for '${file}'.`);
    if (!sourceOverrides.has(file)) {
      assert.equal(
        worktreeSha256,
        cleanHubSha256,
        `${file} differs from clean hub ${CATALOG_READ_CLEAN_HUB_COMMIT}.`,
      );
    }
    return {
      file,
      worktreeSha256,
      cleanHubSha256,
      byteIdentical: worktreeSha256 === cleanHubSha256,
      provenanceRebuilt: sourceOverrides.has(file),
    };
  });
}

/** Rebuild source provenance for mutation controls without making a semantic claim. */
export function buildCatalogReadSourceProvenance(sourceOverrides) {
  return [...sourceOverrides]
    .map(([file, bytes]) => {
      const cleanHubSha256 = CLEAN_HUB_SOURCE_SHA256[file];
      assert.notEqual(cleanHubSha256, undefined, `No clean-hub hash for '${file}'.`);
      const observedSha256 = sha256(bytes);
      return {
        file,
        observedSha256,
        cleanHubSha256,
        byteIdentical: observedSha256 === cleanHubSha256,
        provenanceRebuilt: true,
      };
    })
    .sort((left, right) => compareCodeUnits(left.file, right.file));
}

/** Return exact producer and standard-library inputs for the content address. */
function producerInputs(programSlice) {
  const nativeFiles = new Set(
    [...programSlice.nativeDeclarations.values()].map((span) => span.file),
  );
  return [...new Set([...PRODUCER_FILES, ...nativeFiles])]
    .sort(compareCodeUnits)
    .map((file) => ({
      file,
      sha256: sha256(fs.readFileSync(path.join(REPOSITORY_ROOT, file))),
    }));
}

/** Merge repeated input paths only when every producer assigns the same bytes. */
function uniqueInputs(inputs) {
  const byFile = new Map();
  for (const input of inputs) {
    const previous = byFile.get(input.file);
    assert(
      previous === undefined || previous.sha256 === input.sha256,
      `Conflicting producer input '${input.file}'.`,
    );
    byFile.set(input.file, input);
  }
  return [...byFile.values()].sort((left, right) =>
    compareCodeUnits(left.file, right.file),
  );
}

/** Read the earlier direct-equation certificate by its immutable content address. */
function publishedSourceCertificate() {
  const bytes = fs.readFileSync(PUBLISHED_SOURCE_CERTIFICATE_PATH);
  const reference = CATALOG_READ_REUSED_CERTIFICATES.find(
    (candidate) => candidate.family === "catalog-published-direct-source",
  );
  assert.notEqual(reference, undefined);
  assert.equal(
    sha256(bytes),
    reference.artifactSha256,
    "Direct catalog source-equation dependency changed.",
  );
  return JSON.parse(bytes.toString("utf8"));
}

/** Prove immutable catalog extension against its separate expected source program. */
function catalogExtensionEquations(context) {
  const specification = ts.createSourceFile(
    CATALOG_EXTENSION_LAW_PATH,
    fs.readFileSync(CATALOG_EXTENSION_LAW_PATH, "utf8"),
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TS,
  );
  assert.equal(
    specification.parseDiagnostics.length,
    0,
    "Catalog-extension equation source has syntax errors.",
  );
  const names = [
    "extendInventoryCatalog",
    "mergeInventoryCatalogRevisionFamily",
  ];
  const equations = names.map((name) => {
    const actual = findFunction(context, "src/catalog.ts", name);
    const matches = specification.statements.filter(
      (statement) =>
        ts.isFunctionDeclaration(statement) && statement.name?.text === name,
    );
    assert.equal(matches.length, 1, `Expected one extension law '${name}'.`);
    const actualTerm = typeErasedJavaScriptTerm(actual);
    const expectedTerm = executableTerm(matches[0]);
    assert.equal(
      actualTerm,
      expectedTerm,
      `SEMANTIC_EQUATION_MISMATCH: src/catalog.ts#${name}`,
    );
    return {
      key: `src/catalog.ts#${name}`,
      lawId: "immutable-catalog-extension-v1",
      declaration: spanOf(context, actual),
      expectedTermSha256: sha256(expectedTerm),
    };
  });

  const extension = findFunction(
    context,
    "src/catalog.ts",
    "extendInventoryCatalog",
  );
  const mergeCalls = [];
  /** Collect the six exact revision-family joins in the extension equation. */
  function inspectExtension(node) {
    if (
      ts.isCallExpression(node) &&
      ts.isIdentifier(node.expression) &&
      node.expression.text === "mergeInventoryCatalogRevisionFamily"
    ) {
      mergeCalls.push(node);
    }
    ts.forEachChild(node, inspectExtension);
  }
  inspectExtension(extension);
  assert.equal(mergeCalls.length, 6);
  const expectedDigests = [
    "inventoryItemRevisionDigest",
    "inventoryPackagingRevisionDigest",
    "inventoryCompositionRevisionDigest",
    "inventoryTransformationRevisionDigest",
    "inventoryCollectionRevisionDigest",
    "inventoryFungibilityRevisionDigest",
  ];
  for (const [index, call] of mergeCalls.entries()) {
    assert(ts.isArrowFunction(call.arguments[2]));
    assert(ts.isIdentifier(call.arguments[3]));
    assert.equal(call.arguments[3].text, expectedDigests[index]);
  }
  const merge = findFunction(
    context,
    "src/catalog.ts",
    "mergeInventoryCatalogRevisionFamily",
  );
  const parameterInvocations = { revisionId: 0, digest: 0 };
  /** Count every invocation of the two higher-order merge parameters. */
  function inspectMerge(node) {
    if (ts.isCallExpression(node) && ts.isIdentifier(node.expression)) {
      if (node.expression.text === "revisionId") parameterInvocations.revisionId += 1;
      if (node.expression.text === "digest") parameterInvocations.digest += 1;
    }
    ts.forEachChild(node, inspectMerge);
  }
  inspectMerge(merge);
  assert.equal(parameterInvocations.revisionId, 2);
  assert.equal(parameterInvocations.digest, 2);
  return {
    specification: {
      file: normalizeRelativePath(REPOSITORY_ROOT, CATALOG_EXTENSION_LAW_PATH),
      sha256: sha256(fs.readFileSync(CATALOG_EXTENSION_LAW_PATH)),
      independentlyDeclared: true,
      executedProductionCode: false,
    },
    equations,
    higherOrderCallsiteJoin: {
      mergeCallCount: mergeCalls.length,
      revisionIdentitySuppliers: "six embedded revision.revisionId arrows",
      digestSuppliers: expectedDigests,
      parameterInvocations,
      externalFunctionValues: 0,
    },
    reusedDependencyEquationIds: [
      "src/catalog.ts#defineInventoryCatalog",
      ...expectedDigests.map((name) => `src/catalog.ts#${name}`),
    ],
  };
}

/** Bind one exact compiler-surface alias to an already checked implementation equation. */
function bindSurfaceAlias(
  callableByKey,
  surfaceKey,
  equationKey,
  relationKind,
  implementation,
) {
  const callable = callableByKey.get(surfaceKey);
  assert.notEqual(callable, undefined, `Compiler surface omitted '${surfaceKey}'.`);
  assert.equal(
    callable.signatureHash,
    sha256(canonicalJson(callable.signature)),
    `Compiler signature identity drifted for '${surfaceKey}'.`,
  );
  if (implementation !== undefined) {
    assert.deepEqual(
      callable.declaration,
      implementation,
      `Public alias '${surfaceKey}' does not resolve to '${equationKey}'.`,
    );
    assert(
      callable.symbolDeclarations.some(
        (declaration) => canonicalJson(declaration) === canonicalJson(implementation),
      ),
      `Public symbol '${surfaceKey}' omits '${equationKey}'.`,
    );
  }
  return {
    surfaceKey,
    signatureHash: callable.signatureHash,
    signature: callable.signature,
    declaration: callable.declaration,
    relation: {
      kind: relationKind,
      reachabilityPaths: callable.reachabilityPaths,
      symbolDeclarations: callable.symbolDeclarations,
      ...(implementation === undefined ? {} : { implementation }),
    },
    equationKey,
  };
}

/** Build exact local source evidence for the three externally blocked catalog reads. */
function storageBoundaryEvidence(sourceEquationCore) {
  const affected = new Set(
    CATALOG_READ_STORAGE_ACQUISITION_BLOCKER.affectedSurfaceKeys,
  );
  const equations = sourceEquationCore.sourceEquations.filter(
    (equation) =>
      equation.className === "InventoryOnceCatalogImplementation" &&
      affected.has(
        `type:src/facade.ts#InventoryOnceCatalogApi.${equation.methodName}::call[0]`,
      ),
  );
  assert.equal(equations.length, 3);
  assert.deepEqual(
    equations.map(
      (equation) =>
        `type:src/facade.ts#InventoryOnceCatalogApi.${equation.methodName}::call[0]`,
    ),
    CATALOG_READ_STORAGE_ACQUISITION_BLOCKER.affectedSurfaceKeys,
  );
  return {
    ...CATALOG_READ_STORAGE_ACQUISITION_BLOCKER,
    localSourceEquations: equations,
    blockedRows: equations.length,
    proposedStrictVRows: 0,
    sampledInputs: 0,
  };
}

/** Build the complete semantic core without binding or producer-graph administration. */
function buildSemanticCore(context, sourceOverrides, surface) {
  // Existing independent facade equations reused from their persisted content address.
  const priorSourceCertificate = publishedSourceCertificate();
  // Semantic portion of the reused direct source-equation family.
  const priorSourceEquations = priorSourceCertificate.semanticCore;
  // Existing facade equations indexed by their private implementation identity.
  const priorByMethod = new Map(
    priorSourceEquations.sourceEquations.map((equation) => [
      equation.producerMethod,
      equation,
    ]),
  );
  // Full production callable/value closure reachable from the six roots.
  const programSlice = buildClosedProgramSlice(context);
  // Path-sensitive proofs close the only three dynamic invocation targets.
  const higherOrderClosures = buildHigherOrderClosures(context, programSlice);
  // Independent terms or exact prior equation ids close every reached dependency.
  const equations = declarationEquations(context, programSlice);
  // Byte comparisons pin ordinary evidence to clean hub after semantic checking.
  const sourceComparisons = cleanHubComparisons(programSlice, sourceOverrides);
  // Independent equations indexed for the six root-helper proof envelopes.
  const equationByKey = new Map(
    equations.independent.map((equation) => [equation.key, equation]),
  );
  // Every independent or reused declaration is available for exact public-alias joins.
  const closedEquationByKey = new Map(
    [...equations.independent, ...equations.reused].map((equation) => [
      equation.key,
      equation,
    ]),
  );
  assert.equal(surface.callables.length, 535);
  assert.equal(
    surface.digest,
    CATALOG_READ_OFFICIAL_SURFACE_DIGEST,
    "Catalog-read registration must bind the official clean-hub compiler surface.",
  );
  // Public callables indexed without creating wrapper or registry rows.
  const callableByKey = new Map(
    surface.callables.map((callable) => [callable.key, callable]),
  );
  const proofs = CATALOG_READ_SNAPSHOT_CONTRACTS.map((contract) => {
    const implementation = findClassMethod(
      context,
      "src/facade.ts",
      "InventoryOnceReadSnapshotImplementation",
      contract.methodName,
    );
    const implementationKey = callableKey(implementation);
    const helper = findFunction(
      context,
      contract.helperSourceFile,
      contract.helperName,
    );
    const helperKey = callableKey(helper);
    const helperTerm = equationByKey.get(helperKey);
    assert.notEqual(helperTerm, undefined);
    const facadeSourceEquation = priorByMethod.get(
      `InventoryOnceReadSnapshotImplementation.${contract.methodName}`,
    );
    assert.notEqual(facadeSourceEquation, undefined);
    const surfaceCallable = callableByKey.get(contract.surfaceKey);
    assert.notEqual(
      surfaceCallable,
      undefined,
      `Compiler surface omitted '${contract.surfaceKey}'.`,
    );
    const reachable = reachableEquationKeys(programSlice, helperKey);
    return {
      surfaceKey: contract.surfaceKey,
      signatureHash: surfaceCallable.signatureHash,
      declaration: surfaceCallable.declaration,
      relation: publicSnapshotRelation(
        context,
        surfaceCallable,
        implementation,
        contract.methodName,
      ),
      facadeEquation: contract.facadeEquation,
      facadeSourceEquation,
      implementationEquationKey: implementationKey,
      helperEquation: contract.helperEquation,
      helperEquationKey: helperKey,
      helperExpectedTermSha256: helperTerm.expectedTermSha256,
      reachableEquationCount: reachable.length,
      dependencyClosureSha256: sha256(canonicalJson(reachable)),
    };
  });
  const helperAliasProofs = CATALOG_READ_HELPER_ALIAS_BINDINGS.map((binding) =>
    bindSurfaceAlias(
      callableByKey,
      binding.surfaceKey,
      binding.equationKey,
      "COMPILER_RESOLVED_EXACT_HELPER_ALIAS",
      closedEquationByKey.get(binding.equationKey)?.declaration,
    ),
  );
  for (const binding of CATALOG_READ_HELPER_ALIAS_BINDINGS) {
    assert(
      closedEquationByKey.has(binding.equationKey),
      `Helper alias '${binding.surfaceKey}' lacks a closed equation.`,
    );
  }
  const constructionHandoffBindings = CATALOG_READ_CONSTRUCTION_ALIAS_BINDINGS.map(
    (surfaceKey) => {
      const binding = priorSourceCertificate.reviewEnvelope.compilerBindings.find(
        (candidate) => candidate.surfaceKey === surfaceKey,
      );
      assert.notEqual(
        binding,
        undefined,
        `Direct source certificate omitted '${surfaceKey}'.`,
      );
      return {
        surfaceKey,
        signatureHash: binding.callableIdentity.signatureHash,
        signature: binding.callableIdentity.signature,
        declaration: binding.callableIdentity.declaration,
        relation: {
          kind: "REUSED_CONTENT_ADDRESSED_DIRECT_SOURCE_BINDING",
          certificateId: CATALOG_READ_REUSED_CERTIFICATES.find(
            (candidate) =>
              candidate.family === "catalog-published-direct-source",
          ).certificateId,
          producerEquation: binding.producerEquation,
        },
        equationKey: binding.producerEquation,
      };
    },
  );
  const extension = catalogExtensionEquations(context);
  const extensionHandoffBindings = CATALOG_READ_EXTENSION_ALIAS_BINDINGS.map(
    (surfaceKey) =>
      bindSurfaceAlias(
        callableByKey,
        surfaceKey,
        "src/catalog.ts#extendInventoryCatalog",
        "COMPILER_RESOLVED_EXACT_EXTENSION_ALIAS",
        extension.equations.find(
          (equation) => equation.key === "src/catalog.ts#extendInventoryCatalog",
        )?.declaration,
      ),
  );
  const strengthenedProofs = CATALOG_READ_STRENGTHENED_ALIAS_BINDINGS.map(
    (surfaceKey) =>
      bindSurfaceAlias(
        callableByKey,
        surfaceKey,
        "official-clean-hub-2f39cfe#inventoryCatalogSnapshot",
        "STRENGTHENED_EXISTING_V_ALIAS",
      ),
  );
  const proposedProofs = [
    ...proofs,
    ...helperAliasProofs,
  ];
  assert.equal(proposedProofs.length, supportedSurfaceKeys.length);
  assert.equal(
    new Set(proposedProofs.map((proof) => proof.surfaceKey)).size,
    supportedSurfaceKeys.length,
  );
  const foundationHandoffBindings = [
    ...constructionHandoffBindings,
    ...extensionHandoffBindings,
  ];
  assert.equal(foundationHandoffBindings.length, 13);
  return {
    schemaVersion: 2,
    familyId: FAMILY_ID,
    familyVersion: 2,
    proofKind: CATALOG_READ_DEPENDENCY_CLOSURE_PROOF_KIND,
    sourceBase: {
      commit: CATALOG_READ_CLEAN_HUB_COMMIT,
      relevantSourceFiles: sourceComparisons,
    },
    surfaceDigest: surface.digest,
    domain: CATALOG_READ_DEPENDENCY_CLOSURE_DOMAIN,
    claim:
      "For every valid input in the declared domain, the six snapshot methods and four unreserved pure helper aliases return or throw exactly as independently declared family equations specify; catalog-foundation aliases are retained only as a no-credit handoff to their reassigned owner.",
    excluded:
      "Mutable/proxied/custom receivers, replaced ECMAScript built-ins, storage acquisition, clocks not supplied as arguments, I/O, and catalog publication are outside this pure frozen-snapshot family.",
    allAdmittedInputs: true,
    sampledInputs: 0,
    proofCounts: {
      candidateAuthorityReadRows: 9,
      eligibleSnapshotRows: proofs.length,
      eligibleHelperAliasRows: helperAliasProofs.length,
      yieldedFoundationAliasRows: foundationHandoffBindings.length,
      proposedStrictVRows: proposedProofs.length,
      strengthenedExistingVRows: strengthenedProofs.length,
      blockedStorageRows:
        CATALOG_READ_STORAGE_ACQUISITION_BLOCKER.affectedSurfaceKeys.length,
      completeCallableEquations: programSlice.callables.size,
      completeRuntimeValueEquations: programSlice.values.size,
      independentEquationRows: equations.independent.length,
      reusedEquationRows: equations.reused.length,
      implicitConstructorEquations: programSlice.implicitConstructors.size,
      closedHigherOrderTargets: higherOrderClosures.length,
      externalFunctionValues: higherOrderClosures.reduce(
        (total, closure) => total + closure.externalFunctionValues,
        0,
      ),
      sampledInputs: 0,
      producerGraphRuns: 0,
    },
    laws: CATALOG_READ_FAMILY_LAWS,
    specifications: CATALOG_READ_EXPECTED_LAW_FILES.map((file) => ({
      file,
      sha256: sha256(fs.readFileSync(path.join(REPOSITORY_ROOT, file))),
      independentlyDeclared: true,
      executedProductionCode: false,
    })),
    independentEquations: equations.independent,
    reusedEquations: equations.reused,
    reusedCertificates: CATALOG_READ_REUSED_CERTIFICATES,
    dependencyGraph: [...programSlice.directDependencies.entries()]
      .map(([key, dependencies]) => ({
        key,
        dependencies: [...dependencies].sort(compareCodeUnits),
      }))
      .sort((left, right) => compareCodeUnits(left.key, right.key)),
    implicitConstructorEquations: [
      ...programSlice.implicitConstructors.values(),
    ].sort((left, right) => compareCodeUnits(left.key, right.key)),
    higherOrderClosures,
    catalogFoundationHandoff: {
      owner: "catalog-foundation-r7",
      creditRequestedByAuthority: false,
      reason:
        "Hub CATALOG_FOUNDATION_PARALLEL_SPLIT reassigned every still-unadmitted src/catalog.ts construction/definition/extension surface to the dedicated foundation lane.",
      bindings: foundationHandoffBindings,
      partialIndependentExtensionEquations: extension,
    },
    nativeLibraryDeclarations: [...programSlice.nativeDeclarations.entries()]
      .map(([key, declaration]) => ({ key, declaration }))
      .sort((left, right) => compareCodeUnits(left.key, right.key)),
    proofs: proposedProofs,
    strengthenedProofs,
    storageBoundary: storageBoundaryEvidence(priorSourceEquations),
  };
}

/** Build hub-consumable schema-v1 V evidence for the complete twenty-row family. */
export function buildCatalogReadDependencyClosureArtifact({
  repositoryRoot = REPOSITORY_ROOT,
  context,
  surface,
  sourceOverrides = new Map(),
} = {}) {
  assert.equal(path.resolve(repositoryRoot), REPOSITORY_ROOT);
  const compilerSurface = surface ?? currentCompilerSurface();
  const usesCachedDefault =
    context === undefined && surface === undefined && sourceOverrides.size === 0;
  const semanticCore = usesCachedDefault
    ? buildCatalogReadDependencyClosureCertificate().semanticCore
    : buildSemanticCore(
        sourceOverrides.size > 0
          ? loadOverriddenContext(sourceOverrides)
          : (context ?? loadCompilerContext(REPOSITORY_ROOT)),
        sourceOverrides,
        compilerSurface,
      );
  assert.equal(semanticCore.surfaceDigest, compilerSurface.digest);
  return {
    schemaVersion: 1,
    mode: "V",
    proofKind: CATALOG_READ_DEPENDENCY_CLOSURE_PROOF_KIND,
    surfaceDigest: compilerSurface.digest,
    domain: semanticCore.domain,
    excluded: semanticCore.excluded,
    allAdmittedInputs: true,
    sampledInputs: 0,
    inputs: uniqueInputs([
      ...semanticCore.sourceBase.relevantSourceFiles.map((source) => ({
        file: source.file,
        sha256: source.cleanHubSha256,
      })),
      ...producerInputs({
        nativeDeclarations: new Map(
          semanticCore.nativeLibraryDeclarations.map((entry) => [
            entry.key,
            entry.declaration,
          ]),
        ),
      }),
    ]),
    laws: semanticCore.laws.filter(
      (law) => law.lawId !== "immutable-catalog-extension-v1",
    ),
    specifications: semanticCore.specifications,
    independentEquations: semanticCore.independentEquations,
    reusedEquations: semanticCore.reusedEquations,
    reusedCertificates: semanticCore.reusedCertificates,
    dependencyGraph: semanticCore.dependencyGraph,
    implicitConstructorEquations: semanticCore.implicitConstructorEquations,
    higherOrderClosures: semanticCore.higherOrderClosures,
    nativeLibraryDeclarations: semanticCore.nativeLibraryDeclarations,
    proofs: semanticCore.proofs,
    strengthenedProofs: semanticCore.strengthenedProofs,
  };
}

/** Trusted registration entrypoint used by throughput-r7 without an adapter shim. */
export const buildFamilyArtifact = buildCatalogReadDependencyClosureArtifact;

/** Build one content-addressed family certificate plus honest blocked disposition. */
export function buildCatalogReadDependencyClosureCertificate(
  sourceOverrides = new Map(),
) {
  if (sourceOverrides.size === 0 && cachedCertificateJson !== undefined) {
    return JSON.parse(cachedCertificateJson);
  }
  const context =
    sourceOverrides.size === 0
      ? loadCompilerContext(REPOSITORY_ROOT)
      : loadOverriddenContext(sourceOverrides);
  const surface = currentCompilerSurface();
  const semanticCore = buildSemanticCore(context, sourceOverrides, surface);
  const contentSha256 = sha256(canonicalJson(semanticCore));
  const verifierPath = fileURLToPath(import.meta.url);
  const document = {
    certificateKind: "INVENTORYONCE_CATALOG_READ_DEPENDENCY_CLOSURE",
    semanticCore,
    contentAddress: {
      algorithm: "sha256",
      contentSha256,
      certificateId: `CATALOG_READ_DEPENDENCY_CLOSURE:sha256:${contentSha256}`,
    },
    reviewEnvelope: {
      status: "READY_TO_PORT",
      currentStrictBank: {
        admitted: 190,
        total: 535,
        officialCleanHubCommit: "e46b42b03e7302f3ce215f906e0b8d6adcd6b7ca",
        rejectedOlderSurfaceCount: 91,
        olderSurfaceCreditGranted: false,
      },
      proposedBindings: semanticCore.proofs.map((proof) => ({
        surfaceKey: proof.surfaceKey,
        mode: "V",
        proofKind: semanticCore.proofKind,
        creditGrantedByLane: false,
      })),
      blockedBindings:
        CATALOG_READ_STORAGE_ACQUISITION_BLOCKER.affectedSurfaceKeys.map(
          (surfaceKey) => ({
            surfaceKey,
            blocker: CATALOG_READ_STORAGE_ACQUISITION_BLOCKER.gapId,
            strictVCreditGranted: false,
          }),
        ),
      verifier: {
        file: normalizeRelativePath(REPOSITORY_ROOT, verifierPath),
        sha256: sha256(fs.readFileSync(verifierPath)),
      },
      contract: {
        file: normalizeRelativePath(
          REPOSITORY_ROOT,
          path.join(
            FAMILY_DIRECTORY,
            "catalog-read-dependency-closure-contracts.mjs",
          ),
        ),
        sha256: sha256(
          fs.readFileSync(
            path.join(
              FAMILY_DIRECTORY,
              "catalog-read-dependency-closure-contracts.mjs",
            ),
          ),
        ),
      },
      strengthenedBindings: semanticCore.strengthenedProofs.map((proof) => ({
        surfaceKey: proof.surfaceKey,
        mode: "V",
        additionalDependencyClosureOnly: true,
        newStrictCreditRequested: false,
      })),
      yieldedFoundationBindings:
        semanticCore.catalogFoundationHandoff.bindings.map((binding) => ({
          surfaceKey: binding.surfaceKey,
          owner: semanticCore.catalogFoundationHandoff.owner,
          creditRequestedByAuthority: false,
        })),
      sharedGateReplacedOrBypassed: false,
      hubOwnsFinalAdmission: true,
      producerGraphsRerun: 0,
      localStrictCreditGranted: false,
    },
  };
  if (sourceOverrides.size === 0) cachedCertificateJson = JSON.stringify(document);
  return document;
}

/** Verify one certificate by rebuilding every equation, edge, and source binding. */
export function verifyCatalogReadDependencyClosureCertificate(document) {
  requireExactKeys(
    document,
    ["certificateKind", "semanticCore", "contentAddress", "reviewEnvelope"],
    "Catalog read dependency-closure certificate",
  );
  const expected = buildCatalogReadDependencyClosureCertificate();
  assert.deepEqual(
    document,
    expected,
    "Catalog read dependency-closure certificate differs from current family truth.",
  );
  return {
    certificateId: document.contentAddress.certificateId,
    eligibleSnapshotRows:
      document.semanticCore.proofCounts.eligibleSnapshotRows,
    proposedStrictVRows:
      document.semanticCore.proofCounts.proposedStrictVRows,
    strengthenedExistingVRows:
      document.semanticCore.proofCounts.strengthenedExistingVRows,
    blockedStorageRows: document.semanticCore.proofCounts.blockedStorageRows,
    completeCallableEquations:
      document.semanticCore.proofCounts.completeCallableEquations,
    completeRuntimeValueEquations:
      document.semanticCore.proofCounts.completeRuntimeValueEquations,
    independentEquationRows:
      document.semanticCore.proofCounts.independentEquationRows,
    reusedEquationRows:
      document.semanticCore.proofCounts.reusedEquationRows,
    closedHigherOrderTargets:
      document.semanticCore.proofCounts.closedHigherOrderTargets,
    sampledInputs: document.semanticCore.proofCounts.sampledInputs,
    producerGraphRuns: document.semanticCore.proofCounts.producerGraphRuns,
    blocker: document.semanticCore.storageBoundary.gapId,
    hubOwnsFinalAdmission: document.reviewEnvelope.hubOwnsFinalAdmission,
  };
}

/** Verify the persisted certificate without running formal or fixture producers. */
export function verifyPersistedCatalogReadDependencyClosureCertificate() {
  return verifyCatalogReadDependencyClosureCertificate(
    JSON.parse(fs.readFileSync(CERTIFICATE_PATH, "utf8")),
  );
}

/** Verify the recorded strict-family artifact equals a fresh current derivation. */
export function verifyPersistedCatalogReadFamilyArtifact() {
  const recorded = JSON.parse(fs.readFileSync(REGISTERED_FAMILY_PATH, "utf8"));
  const expected = buildFamilyArtifact();
  assert.deepEqual(
    recorded,
    expected,
    "Recorded catalog-read family differs from independently rederived semantics.",
  );
  assert.deepEqual(
    recorded.proofs.map((proof) => proof.surfaceKey),
    supportedSurfaceKeys,
    "Recorded catalog-read family does not contain exactly its reviewed members.",
  );
  return {
    proofKind: recorded.proofKind,
    supportedSurfaceRows: recorded.proofs.length,
    schemaVersion: recorded.schemaVersion,
    surfaceDigest: recorded.surfaceDigest,
    evidenceSha256: sha256(fs.readFileSync(REGISTERED_FAMILY_PATH)),
  };
}

/** Persist and immediately verify the canonical dependency-closure certificate. */
export function writeCatalogReadDependencyClosureCertificate() {
  const document = buildCatalogReadDependencyClosureCertificate();
  fs.writeFileSync(CERTIFICATE_PATH, `${JSON.stringify(document, null, 2)}\n`);
  fs.writeFileSync(
    REGISTERED_FAMILY_PATH,
    `${JSON.stringify(buildFamilyArtifact(), null, 2)}\n`,
  );
  return verifyCatalogReadDependencyClosureCertificate(document);
}

/** Run deterministic write or verification mode for lane and hub review. */
function runCommandLine() {
  const mode = process.argv[2] ?? "--verify";
  if (mode !== "--write" && mode !== "--verify") {
    throw new Error(`Unknown dependency-closure mode '${mode}'.`);
  }
  const certificateSummary =
    mode === "--write"
      ? writeCatalogReadDependencyClosureCertificate()
      : verifyPersistedCatalogReadDependencyClosureCertificate();
  const registeredFamily = verifyPersistedCatalogReadFamilyArtifact();
  process.stdout.write(
    `${JSON.stringify({ ...certificateSummary, registeredFamily }, null, 2)}\n`,
  );
}

if (
  process.argv[1] !== undefined &&
  path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  runCommandLine();
}
