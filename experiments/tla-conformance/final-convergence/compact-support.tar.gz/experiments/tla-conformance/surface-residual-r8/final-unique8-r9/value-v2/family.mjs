import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { canonicalJson, discoverCompilerSurface, sha256, ts } from "../../../surface-bindings/lib/compiler-surface.mjs";
import { loadEvidenceCompilerContext } from "../../../surface-bindings/lib/binding-checker.mjs";
import { buildFamilyArtifact as buildTransferCorrectionValues, normalizeTransferCorrectionCallable } from "../../../transfer-surface-r6/source-equations-r7/family.mjs";
import { buildIndependentV9Artifact } from "../../../migration-helper-causal-r7/independent-v9-laws.mjs";

export const proofKind = "surface-residual-final-projection-values-v2-v1";
export const supportedSurfaceKeys = Object.freeze([
  "export:./kernel#projectInventoryEvents::call[0]",
  "export:./storage#inventoryProjectionDigest::call[0]",
]);
const EXPECTED = "experiments/tla-conformance/surface-residual-r8/final-unique8-r9/value-v2/equations.expected.ts.txt";

function parse(file,text){const sf=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);assert.equal(sf.parseDiagnostics.length,0,`Cannot parse ${file}`);return sf;}
function findFunction(sf,name){const rows=sf.statements.filter((row)=>ts.isFunctionDeclaration(row)&&row.name?.text===name&&row.body!==undefined);assert.equal(rows.length,1,`Expected one function ${name}`);return rows[0];}
function input(root,file){return{file,sha256:sha256(fs.readFileSync(path.resolve(root,file)))};}
function mergeInputs(rows){const by=new Map();for(const row of rows){const prior=by.get(row.file);if(prior!==undefined)assert.equal(prior.sha256,row.sha256,`Conflicting input ${row.file}`);by.set(row.file,row);}return[...by.values()].sort((a,b)=>a.file.localeCompare(b.file));}
function localDigestEquations(root,overrides=new Map()){
  const actualText=overrides.get("src/integrity.ts")??fs.readFileSync(path.resolve(root,"src/integrity.ts"),"utf8");
  const expectedText=fs.readFileSync(path.resolve(root,EXPECTED),"utf8");
  const actual=parse("src/integrity.ts",actualText), expected=parse(EXPECTED,expectedText);
  const result=[];
  for(const name of ["inventoryProjectionDigest","sortedRecordRows"]){
    const a=normalizeTransferCorrectionCallable(findFunction(actual,name));
    const e=normalizeTransferCorrectionCallable(findFunction(expected,name));
    assert.deepEqual(a,e,`Complete expected projection-digest equation drifted: ${name}`);
    result.push({id:`src/integrity.ts#${name}`,equationSha256:sha256(canonicalJson(e)),term:e,completeExpectedTerm:true});
  }
  return result;
}
function equation(artifact,id){const rows=artifact.semanticCore.equations.filter((row)=>row.id===id);assert.equal(rows.length,1,`Transfer family missing ${id}`);return rows[0];}
function localLaw(artifact,id){const rows=artifact.localLaws.filter((row)=>row.id===id);assert.equal(rows.length,1,`Migration helper family missing ${id}`);assert.equal(rows[0].gaps.length,0,`${id} still has gaps`);return rows[0];}

export function buildFamilyArtifact({repositoryRoot=process.cwd(),context=loadEvidenceCompilerContext(repositoryRoot,[]),surface=discoverCompilerSurface(repositoryRoot),sourceOverrides=new Map()}={}){
  const root=repositoryRoot;
  assert.equal(surface.callables.length,535);
  const transfer=buildTransferCorrectionValues({repositoryRoot:root,context,surface,sourceOverrides});
  assert.equal(transfer.proofKind,"inventoryonce-transfer-correction-complete-source-equations-v2");
  assert.equal(transfer.allAdmittedInputs,true); assert.equal(transfer.sampledInputs,0);
  const project=equation(transfer,"src/projection.ts#projectInventoryEvents");
  assert.equal(project.strengtheningOnly,false);
  const digestEquations=localDigestEquations(root,sourceOverrides);
  if(sourceOverrides.size>0)return{mutationControlAccepted:false,project,digestEquations};
  const migration=buildIndependentV9Artifact({repositoryRoot:root,context,surface});
  assert.equal(migration.allAdmittedInputs,true); assert.equal(migration.sampledInputs,0);
  const shaLaw=localLaw(migration,"src/digest.ts#inventorySha256"), rotateLaw=localLaw(migration,"src/digest.ts#rotateRight");
  const live=new Map(surface.callables.map((row)=>[row.key,row]));
  const projectCallable=live.get(supportedSurfaceKeys[0]), digestCallable=live.get(supportedSurfaceKeys[1]);
  assert(projectCallable!==undefined&&digestCallable!==undefined);
  assert.deepEqual(project.declaration,projectCallable.declaration,"projectInventoryEvents compiler declaration drifted from complete equation");
  const digestPublic=digestEquations.find((row)=>row.id==="src/integrity.ts#inventoryProjectionDigest");
  const sortedRows=digestEquations.find((row)=>row.id==="src/integrity.ts#sortedRecordRows");
  assert(digestPublic!==undefined&&sortedRows!==undefined);
  const inputs=mergeInputs([
    input(root,"experiments/tla-conformance/surface-residual-r8/final-unique8-r9/value-v2/family.mjs"),
    input(root,EXPECTED),input(root,"src/integrity.ts"),input(root,"src/projection.ts"),input(root,"src/digest.ts"),input(root,"node_modules/typescript/package.json"),
    ...(transfer.inputs??[]),...(migration.inputs??[]),
  ]);
  return {schemaVersion:1,proofKind,surfaceDigest:surface.digest,domain:"Two universal deterministic value surfaces. projectInventoryEvents reuses the independently specified complete Transfer/Correction replay equation over every internally valid retained history; inventoryProjectionDigest independently specifies every projection-root field and stable key ordering while reusing the complete independently specified SHA-256/rotate laws. No fixtures, callbacks, storage I/O, constructors, native replay, graph replay, or reverse replay.",allAdmittedInputs:true,sampledInputs:0,inputs,proofs:[
    {surfaceKey:supportedSurfaceKeys[0],signatureHash:projectCallable.signatureHash,declaration:projectCallable.declaration,semantics:{completeExpectedTerm:{id:project.id,lawId:project.lawId,equationSha256:project.equationSha256,declaration:project.declaration},sourceFamily:{proofKind:transfer.proofKind,domain:transfer.domain},strengtheningOnly:project.strengtheningOnly}},
    {surfaceKey:supportedSurfaceKeys[1],signatureHash:digestCallable.signatureHash,declaration:digestCallable.declaration,semantics:{completeExpectedTerm:digestPublic,privateEquations:[sortedRows],shaDependency:{id:shaLaw.id,completeExpectedTerm:shaLaw.completeExpectedTerm,dependencies:shaLaw.dependencies},rotateDependency:{id:rotateLaw.id,completeExpectedTerm:rotateLaw.completeExpectedTerm},shaSupportingValues:migration.supportingValues}},
  ]};
}
