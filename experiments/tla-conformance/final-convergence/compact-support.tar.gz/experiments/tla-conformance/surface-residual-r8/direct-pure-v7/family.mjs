import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { canonicalJson, discoverCompilerSurface, sha256, ts } from "../../surface-bindings/lib/compiler-surface.mjs";
import { loadEvidenceCompilerContext } from "../../surface-bindings/lib/binding-checker.mjs";
import { buildFamilyArtifact as buildIdentityValues } from "../../identity-values-r7/family.mjs";
import { buildCatalogFamilyArtifact } from "../../value-contracts/catalog-family.mjs";

export const proofKind = "surface-residual-direct-pure-complete-values-v7-v1";
export const supportedSurfaceKeys = Object.freeze([
  "export:.#defineInventoryAmountLineGroup::call[0]",
  "export:.#combineInventoryAmountLineGroups::call[0]",
  "export:.#defineInventoryPolicyBatchRequestGroup::call[0]",
  "export:.#combineInventoryPolicyBatchRequestGroups::call[0]",
  "export:./kernel#abandonInventoryCount::call[0]",
  "export:./kernel#inventoryCompositionOpenIntentFingerprint::call[0]",
  "export:./kernel#inventoryEventsInRecordSequence::call[0]",
]);

const EXPECTED="experiments/tla-conformance/surface-residual-r8/direct-pure-v7/equations.expected.ts.txt";
const PUBLIC=Object.freeze([
  {surfaceKey:supportedSurfaceKeys[0],file:"src/facade.ts",actual:"defineInventoryAmountLineGroup",expected:"expectedDefineInventoryAmountLineGroup"},
  {surfaceKey:supportedSurfaceKeys[1],file:"src/facade.ts",actual:"combineInventoryAmountLineGroups",expected:"expectedCombineInventoryAmountLineGroups"},
  {surfaceKey:supportedSurfaceKeys[2],file:"src/facade.ts",actual:"defineInventoryPolicyBatchRequestGroup",expected:"expectedDefineInventoryPolicyBatchRequestGroup"},
  {surfaceKey:supportedSurfaceKeys[3],file:"src/facade.ts",actual:"combineInventoryPolicyBatchRequestGroups",expected:"expectedCombineInventoryPolicyBatchRequestGroups"},
  {surfaceKey:supportedSurfaceKeys[4],file:"src/counts.ts",actual:"abandonInventoryCount",expected:"expectedAbandonInventoryCount"},
  {surfaceKey:supportedSurfaceKeys[5],file:"src/composition.ts",actual:"inventoryCompositionOpenIntentFingerprint",expected:"expectedInventoryCompositionOpenIntentFingerprint"},
  {surfaceKey:supportedSurfaceKeys[6],file:"src/projection.ts",actual:"inventoryEventsInRecordSequence",expected:"expectedInventoryEventsInRecordSequence"},
]);
const PRIVATE=Object.freeze([
  {file:"src/events.ts",actual:"assertCanonicalInventoryTime",expected:"expectedAssertCanonicalInventoryTime"},
  {file:"src/counts.ts",actual:"findCountOperationReplay",expected:"expectedFindCountOperationReplay"},
  {file:"src/counts.ts",actual:"replaceCountWithOperation",expected:"expectedReplaceCountWithOperation"},
  {file:"src/composition.ts",actual:"compositionQualifiedDimensionFingerprint",expected:"expectedCompositionQualifiedDimensionFingerprint"},
  {file:"src/composition.ts",actual:"compareCompositionQualifiedDimensionFingerprint",expected:"expectedCompareCompositionQualifiedDimensionFingerprint"},
  {file:"src/ordering.ts",actual:"compareInventoryIdentityText",expected:"expectedCompareInventoryIdentityText"},
  {file:"src/projection.ts",actual:"compareCommittedEventSequence",expected:"expectedCompareCommittedEventSequence"},
]);
const IDENTITY_KEYS=Object.freeze([
  "export:./kernel#assertInventoryAmountSum::call[0]",
  "export:./kernel#normalizeInventoryStockSelector::call[0]",
  "export:./kernel#inventoryStockPositionIdentity::call[0]",
  "export:./kernel#inventoryIntentFingerprint::call[0]",
  "export:./kernel#inventoryMetadataFingerprint::call[0]",
  "export:./kernel#inventoryTraceabilityNodeIdentity::call[0]",
]);
const CATALOG_KEYS=Object.freeze([
  "type:src/catalog.ts#InventoryCatalog.itemRevision::call[0]",
  "type:src/catalog.ts#InventoryCatalog.packagingRevision::call[0]",
  "type:src/catalog.ts#InventoryCatalog.compositionForSourcePackagingRevision::call[0]",
]);

function source(root,file,override){const abs=path.resolve(root,file);return ts.createSourceFile(abs,override??fs.readFileSync(abs,"utf8"),ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);}
function expectedSource(root){const file=path.resolve(root,EXPECTED);return ts.createSourceFile(file,fs.readFileSync(file,"utf8"),ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);}
function findFunction(sf,name){const rows=sf.statements.filter((row)=>ts.isFunctionDeclaration(row)&&row.name?.text===name);assert.equal(rows.length,1,`Expected one function ${name}`);assert(rows[0].body!==undefined);return rows[0];}
function runtimeTerm(node,sf){
  let text=node.getText(sf).replace(/^export\s+/u,"");
  const name=node.name?.text;assert(name!==undefined);
    text=text.replace(new RegExp(`^(?:async\\s+)?function\\s+${name}\\b`), (match)=>match.replace(name,"__proof"));
  const emitted=ts.transpileModule(text,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.None,removeComments:true}}).outputText.trim();
  const scanner=ts.createScanner(ts.ScriptTarget.ES2022,true,ts.LanguageVariant.Standard,emitted);
  const tokens=[];for(;;){const kind=scanner.scan();if(kind===ts.SyntaxKind.EndOfFileToken)break;tokens.push([ts.SyntaxKind[kind],scanner.getTokenText()]);}
  return tokens;
}
function prove(actual,expected,label){const a=runtimeTerm(actual,actual.getSourceFile()),e=runtimeTerm(expected,expected.getSourceFile());assert.deepEqual(a,e,`Complete expected source equation drifted: ${label}`);return {label,normalizedTermSha256:sha256(canonicalJson(a)),completeBranchesChecked:true};}
function enumValues(sf,name,wanted){const rows=sf.statements.filter((row)=>ts.isEnumDeclaration(row)&&row.name.text===name);assert.equal(rows.length,1);const result={};for(const member of rows[0].members){const key=member.name.getText(sf);if(!wanted.includes(key))continue;assert(ts.isStringLiteral(member.initializer),`${name}.${key} must stay string-valued`);result[key]=member.initializer.text;}assert.deepEqual(Object.keys(result).sort(),[...wanted].sort());return result;}

/** Re-derive all public equations, private helper equations, and count enum values. */
export function sourceEquationReceipt(root,overrides=new Map()){
  const expected=expectedSource(root), cache=new Map();
  function sf(file){if(!cache.has(file))cache.set(file,source(root,file,overrides.get(file)));return cache.get(file);}
  const publicEquations=PUBLIC.map((row)=>prove(findFunction(sf(row.file),row.actual),findFunction(expected,row.expected),row.actual));
  const privateEquations=PRIVATE.map((row)=>prove(findFunction(sf(row.file),row.actual),findFunction(expected,row.expected),row.actual));
  const counts=sf("src/counts.ts");
  const supportingValues={
    InventoryCountOperationKind:enumValues(counts,"InventoryCountOperationKind",["Abandon"]),
    InventoryCountStatus:enumValues(counts,"InventoryCountStatus",["Completed","Abandoned"]),
  };
  assert.deepEqual(supportingValues,{InventoryCountOperationKind:{Abandon:"abandon"},InventoryCountStatus:{Completed:"completed",Abandoned:"abandoned"}});
  return {publicEquations,privateEquations,supportingValues};
}

/** Re-derive the two existing semantic families used by these direct functions. */
function dependencyReceipt(root,context,surface){
  const families=[
    {name:"identity",artifact:buildIdentityValues({repositoryRoot:root,context,surface}),keys:IDENTITY_KEYS},
    {name:"catalog",artifact:buildCatalogFamilyArtifact({repositoryRoot:root,context,surface}),keys:CATALOG_KEYS},
  ];
  const receipts=[];
  for(const family of families){assert.equal(family.artifact.surfaceDigest,surface.digest);const byKey=new Map(family.artifact.proofs.map((p)=>[p.surfaceKey,p]));for(const surfaceKey of family.keys){const proof=byKey.get(surfaceKey);assert(proof!==undefined,`${family.name} dependency missing ${surfaceKey}`);const callable=surface.callables.find((row)=>row.key===surfaceKey);assert(callable!==undefined);assert.equal(proof.signatureHash,callable.signatureHash);assert.deepEqual(proof.declaration,callable.declaration);receipts.push({family:family.name,proofKind:family.artifact.proofKind,surfaceKey,signatureHash:proof.signatureHash,declaration:proof.declaration});}}
  return {receipts,families};
}
function addInput(root,inputs,file){if(inputs.has(file))return;inputs.set(file,{file,sha256:sha256(fs.readFileSync(path.resolve(root,file)))});}
function semanticInputs(root,dependencies){const inputs=new Map();for(const file of [EXPECTED,"experiments/tla-conformance/surface-residual-r8/direct-pure-v7/family.mjs","src/facade.ts","src/counts.ts","src/events.ts","src/composition.ts","src/ordering.ts","src/projection.ts","node_modules/typescript/package.json"])addInput(root,inputs,file);for(const family of dependencies.families)for(const input of family.artifact.inputs??family.artifact.producers??[])addInput(root,inputs,input.file);return [...inputs.values()].sort((a,b)=>a.file<b.file?-1:a.file>b.file?1:0);}

export function buildFamilyArtifact({repositoryRoot=process.cwd(),context=loadEvidenceCompilerContext(repositoryRoot,[]),surface=discoverCompilerSurface(repositoryRoot),sourceOverrides=new Map()}={}){
  const equations=sourceEquationReceipt(repositoryRoot,sourceOverrides);
  if(sourceOverrides.size>0)return{mutationControlAccepted:false,equations};
  const dependencies=dependencyReceipt(repositoryRoot,context,surface);
  const live=new Map(surface.callables.map((row)=>[row.key,row]));
  const byLabel=new Map(equations.publicEquations.map((row)=>[row.label,row]));
  const proofs=PUBLIC.map((row)=>{const callable=live.get(row.surfaceKey);assert(callable!==undefined);return{surfaceKey:row.surfaceKey,signatureHash:callable.signatureHash,declaration:callable.declaration,semantics:{completeExpectedTerm:byLabel.get(row.actual),privateEquations:equations.privateEquations,supportingValues:equations.supportingValues,dependencyReceipts:dependencies.receipts}};});
  return{schemaVersion:1,proofKind,surfaceDigest:surface.digest,domain:"Seven direct deterministic public functions over plain application inputs: four amount/policy grouping helpers, count abandonment, composition-open retry fingerprinting, and committed-event sequence normalization. Complete public/private source terms, count enum values, and exact Identity/Catalog semantic dependencies are rederived; constructors, application callbacks, event reducers, composition execution, and projection digest are excluded.",allAdmittedInputs:true,sampledInputs:0,inputs:semanticInputs(repositoryRoot,dependencies),proofs};
}
