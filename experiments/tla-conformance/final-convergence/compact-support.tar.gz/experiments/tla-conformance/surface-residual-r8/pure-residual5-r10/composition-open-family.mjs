import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import {canonicalJson,discoverCompilerSurface,sha256,ts} from "../../surface-bindings/lib/compiler-surface.mjs";
import {loadEvidenceCompilerContext} from "../../surface-bindings/lib/binding-checker.mjs";
import {buildIdentityValuesFamilyArtifact} from "../../identity-values-r7/family.mjs";
import {buildQuantityValuesFamilyCertificate} from "../../quantity-values-r7/certificate.mjs";
import {buildCatalogFamilyArtifact} from "../../value-contracts/catalog-family.mjs";
import {buildEventValuesFamilyArtifact} from "../../quantity-values-r7/event-values/certificate.mjs";

export const proofKind="surface-residual-composition-open-complete-value-v1";
export const supportedSurfaceKeys=Object.freeze(["export:./kernel#createInventoryCompositionOpenEvent::call[0]"]);
const EXPECTED="experiments/tla-conformance/surface-residual-r8/pure-residual5-r10/composition-open.expected.ts.txt";
const PUBLIC=Object.freeze({file:"src/composition.ts",actual:"createInventoryCompositionOpenEvent",expected:"expectedCreateInventoryCompositionOpenEvent"});
const PRIVATE=Object.freeze([
 {actual:"createCompositionOutputLine",expected:"expectedCreateCompositionOutputLine"},
 {actual:"compositionOutputAmount",expected:"expectedCompositionOutputAmount"},
 {actual:"compositionOutputPosition",expected:"expectedCompositionOutputPosition"},
 {actual:"compositionOutputLotId",expected:"expectedCompositionOutputLotId"},
 {actual:"compositionOutputLotMetadata",expected:"expectedCompositionOutputLotMetadata"},
 {actual:"currentSourceLot",expected:"expectedCurrentSourceLot"},
 {actual:"compositionTraceabilityNode",expected:"expectedCompositionTraceabilityNode"},
 {actual:"assertKnownCompositionPlacements",expected:"expectedAssertKnownCompositionPlacements"},
 {actual:"assertCompositionPlacementFields",expected:"expectedAssertCompositionPlacementFields"},
 {actual:"compositionEventMetadata",expected:"expectedCompositionEventMetadata"},
 {actual:"compositionOutputEvidence",expected:"expectedCompositionOutputEvidence"},
]);
const DEPENDENCIES=Object.freeze([
 {family:"identity",key:"export:.#inventoryMeasuredAmountFromVector::call[0]"},
 {family:"identity",key:"export:.#packageAmount::call[0]"},
 {family:"identity",key:"export:.#inventoryLotIdentity::call[0]"},
 {family:"identity",key:"export:./kernel#inventoryTraceabilityNodeIdentity::call[0]"},
 {family:"quantity",key:"export:.#inventoryMeasurementsFingerprint::call[0]"},
 {family:"quantity",key:"export:.#multiplyInventoryMeasurementsByWholeNumber::call[0]"},
 {family:"catalog",key:"type:src/catalog.ts#InventoryCatalog.itemRevision::call[0]"},
 {family:"catalog",key:"type:src/catalog.ts#InventoryCatalog.packagingRevision::call[0]"},
 {family:"catalog",key:"type:src/catalog.ts#InventoryCatalog.compositionForSourcePackagingRevision::call[0]"},
 {family:"event",key:"export:./kernel#createInventoryTransformationEvent::call[0]"},
]);
function sf(root,file,override){const abs=path.resolve(root,file);return ts.createSourceFile(abs,override??fs.readFileSync(abs,"utf8"),ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);}
function expectedSource(root){const file=path.resolve(root,EXPECTED);return ts.createSourceFile(file,fs.readFileSync(file,"utf8"),ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);}
function findFunction(source,name){const rows=source.statements.filter((row)=>ts.isFunctionDeclaration(row)&&row.name?.text===name);assert.equal(rows.length,1,`Expected one function ${name}`);assert(rows[0].body!==undefined);return rows[0];}
function runtimeTerm(node,source){let text=node.getText(source).replace(/^export\s+/u,"");const name=node.name?.text;assert(name!==undefined);text=text.replace(new RegExp(`^(?:async\\s+)?function\\s+${name}\\b`),(m)=>m.replace(name,"__proof"));const emitted=ts.transpileModule(text,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.None,removeComments:true}}).outputText.trim();const scanner=ts.createScanner(ts.ScriptTarget.ES2022,true,ts.LanguageVariant.Standard,emitted);const tokens=[];for(;;){const kind=scanner.scan();if(kind===ts.SyntaxKind.EndOfFileToken)break;tokens.push([ts.SyntaxKind[kind],scanner.getTokenText()]);}return tokens;}
function prove(actual,expected,label){const a=runtimeTerm(actual,actual.getSourceFile()),e=runtimeTerm(expected,expected.getSourceFile());assert.deepEqual(a,e,`Complete expected source equation drifted: ${label}`);return{label,normalizedTermSha256:sha256(canonicalJson(a)),completeBranchesChecked:true,allValidatedInputs:true,sampledInputs:0};}
function enumValues(source,name,wanted){const rows=source.statements.filter((row)=>ts.isEnumDeclaration(row)&&row.name.text===name);assert.equal(rows.length,1,`Expected enum ${name}`);const result={};for(const member of rows[0].members){const key=member.name.getText(source);if(!wanted.includes(key))continue;assert(ts.isStringLiteral(member.initializer),`${name}.${key} must stay string-valued`);result[key]=member.initializer.text;}assert.deepEqual(Object.keys(result).sort(),[...wanted].sort());return result;}
export function sourceEquationReceipt(root,overrides=new Map()){
 const actual=sf(root,"src/composition.ts",overrides.get("src/composition.ts")),expected=expectedSource(root);
 const publicEquation=prove(findFunction(actual,PUBLIC.actual),findFunction(expected,PUBLIC.expected),PUBLIC.actual);
 const privateEquations=PRIVATE.map((row)=>prove(findFunction(actual,row.actual),findFunction(expected,row.expected),row.actual));
 const catalog=sf(root,"src/catalog.ts",overrides.get("src/catalog.ts")),model=sf(root,"src/model.ts",overrides.get("src/model.ts"));
 const supportingValues={
  InventoryCompositionOutputAmountKind:enumValues(catalog,"InventoryCompositionOutputAmountKind",["Measured","Package"]),
  InventoryCompositionOutputLotPolicy:enumValues(catalog,"InventoryCompositionOutputLotPolicy",["None","InheritSource","InheritSourceWhenPresent","Explicit"]),
  InventoryTrackingRequirement:enumValues(catalog,"InventoryTrackingRequirement",["Forbidden","Optional","Required"]),
  InventoryTraceabilityNodeKind:enumValues(model,"InventoryTraceabilityNodeKind",["Serial","Container","Lot","External"]),
 };
 assert.deepEqual(supportingValues,{InventoryCompositionOutputAmountKind:{Measured:"measured",Package:"package"},InventoryCompositionOutputLotPolicy:{None:"none",InheritSource:"inherit-source",InheritSourceWhenPresent:"inherit-source-when-present",Explicit:"explicit"},InventoryTrackingRequirement:{Forbidden:"forbidden",Optional:"optional",Required:"required"},InventoryTraceabilityNodeKind:{Serial:"serial",Container:"container",Lot:"lot",External:"external"}});
 return{publicEquation,privateEquations,supportingValues};
}
function familyArtifacts(root,context,surface){return new Map([
 ["identity",buildIdentityValuesFamilyArtifact({repositoryRoot:root,context,surface})],
 ["quantity",buildQuantityValuesFamilyCertificate({repositoryRoot:root,context,surface})],
 ["catalog",buildCatalogFamilyArtifact({repositoryRoot:root,context,surface})],
 ["event",buildEventValuesFamilyArtifact({repositoryRoot:root,context,surface})],
]);}
function dependencyReceipt(root,context,surface){const families=familyArtifacts(root,context,surface),receipts=[];for(const dep of DEPENDENCIES){const artifact=families.get(dep.family);assert(artifact!==undefined);assert.equal(artifact.surfaceDigest,surface.digest);const proof=artifact.proofs.find((p)=>p.surfaceKey===dep.key);assert(proof!==undefined,`${dep.family} missing ${dep.key}`);const callable=surface.callables.find((row)=>row.key===dep.key);assert(callable!==undefined);assert.equal(proof.signatureHash,callable.signatureHash);assert.deepEqual(proof.declaration,callable.declaration);receipts.push({family:dep.family,proofKind:artifact.proofKind,surfaceKey:dep.key,signatureHash:proof.signatureHash,declaration:proof.declaration,semanticIdentity:proof.semantics?.equationSha256??proof.equationId??proof.implementationKey??proof.lawId??null});}return{families,receipts};}
function addInput(root,inputs,file){if(inputs.has(file))return;inputs.set(file,{file,sha256:sha256(fs.readFileSync(path.resolve(root,file)))});}
function semanticInputs(root,deps){const inputs=new Map();for(const file of [EXPECTED,"experiments/tla-conformance/surface-residual-r8/pure-residual5-r10/composition-open-family.mjs","src/composition.ts","src/catalog.ts","src/model.ts","node_modules/typescript/package.json"])addInput(root,inputs,file);for(const artifact of deps.families.values())for(const input of artifact.inputs??artifact.producers??[])addInput(root,inputs,input.file);return[...inputs.values()].sort((a,b)=>a.file<b.file?-1:a.file>b.file?1:0);}
export function buildFamilyArtifact({repositoryRoot=process.cwd(),context=loadEvidenceCompilerContext(repositoryRoot,[]),surface=discoverCompilerSurface(repositoryRoot),sourceOverrides=new Map()}={}){
 const equations=sourceEquationReceipt(repositoryRoot,sourceOverrides);if(sourceOverrides.size>0)return{mutationControlAccepted:false,equations};
 const deps=dependencyReceipt(repositoryRoot,context,surface),callable=surface.callables.find((row)=>row.key===supportedSurfaceKeys[0]);assert(callable!==undefined);
 return{schemaVersion:1,proofKind,surfaceDigest:surface.digest,domain:"Every input admitted by CreateInventoryCompositionOpenEventInput. Complete public control flow and all eleven private helper equations are independently frozen, including package-count rejection, source-package/item consistency, output placement validation, lot inheritance/explicit-lot rules, genealogy ambiguity, amount scaling, output placement and audit metadata. Exact external Catalog, Identity, Quantity and TransformationEvent semantics are rederived from their already-certified families; no sampled fixtures or bounded composition oracle are used.",allAdmittedInputs:true,sampledInputs:0,producerGraphRuns:0,producerReplayRuns:0,inputs:semanticInputs(repositoryRoot,deps),proofs:[{surfaceKey:supportedSurfaceKeys[0],signatureHash:callable.signatureHash,declaration:callable.declaration,semantics:{completeExpectedTerm:equations.publicEquation,privateEquations:equations.privateEquations,supportingValues:equations.supportingValues,dependencyReceipts:deps.receipts,languagePrimitives:["Number.isSafeInteger","Object.keys","Object.entries","Set","encodeURIComponent"]}}]};
}
