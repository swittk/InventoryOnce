import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { compareCodeUnits, sha256, ts } from "../surface-bindings/lib/compiler-surface.mjs";
import { strictDependencySemanticReceipt } from "../throughput-r7/strict-dependency-semantic-receipt.mjs";

export const proofKind = "inventoryonce-reservation-feasibility-guard-value-v1";
export const supportedSurfaceKeys = Object.freeze(["export:./kernel#assertInventoryReservationsFeasible::call[0]"]);
const expectedFile=fileURLToPath(new URL("./equations.expected.ts.txt",import.meta.url));
const dependencyKey="export:./kernel#inspectInventoryReservationFeasibility::call[0]";
const inputFiles=Object.freeze([
  "src/reservations.ts",
  "experiments/tla-conformance/boundary-adjudication-r18/equations.expected.ts.txt",
  "experiments/tla-conformance/boundary-adjudication-r18/family.mjs",
  "experiments/tla-conformance/throughput-r7/registered-value-family.mjs",
  "experiments/tla-conformance/throughput-r7/strict-dependency-receipt.mjs",
  "experiments/tla-conformance/throughput-r7/strict-dependency-semantic-receipt.mjs",
]);
const printer=ts.createPrinter({removeComments:true,newLine:ts.NewLineKind.LineFeed});
function parse(file,text){return ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS)}
function inputText(root,overrides,file){return overrides.get(file)??fs.readFileSync(path.resolve(root,file),"utf8")}
function source(root,context,overrides,file){if(overrides.has(file))return parse(file,inputText(root,overrides,file));const s=context.program.getSourceFile(path.resolve(root,file));assert(s,`Compiler omitted '${file}'.`);return s}
function fn(s,name){const xs=s.statements.filter(x=>ts.isFunctionDeclaration(x)&&x.name?.text===name&&x.body);assert.equal(xs.length,1,`Expected one function '${name}'.`);return xs[0]}
function rendered(node,s){return printer.printNode(ts.EmitHint.Unspecified,node,s).replaceAll(/\r\n/gu,"\n").trim()}
function equation(id,actual,actualSource,expected,expectedSource){const a=rendered(actual,actualSource),e=rendered(expected,expectedSource);assert.equal(a,e,`Independent complete source equation changed for '${id}'.`);return {id,equationSha256:sha256(e),canonicalSource:e}}
function dependency(root,surface){return strictDependencySemanticReceipt({repositoryRoot:root,surface,requirements:[{surfaceKey:dependencyKey,mode:"B"}],label:"reservation feasibility guard dependency"})}
export function buildFamilyArtifact({repositoryRoot,context,surface,sourceOverrides=new Map()}){
  const expected=parse(expectedFile,fs.readFileSync(expectedFile,"utf8"));
  const reservations=source(repositoryRoot,context,sourceOverrides,"src/reservations.ts");
  const eq=equation("src/reservations.ts#assertInventoryReservationsFeasible",fn(reservations,"assertInventoryReservationsFeasible"),reservations,fn(expected,"assertInventoryReservationsFeasible"),expected);
  const callable=new Map(surface.callables.map(x=>[x.key,x])).get(supportedSurfaceKeys[0]);assert(callable,"Compiler omitted reservation feasibility guard.");
  const inputs=[...new Set(inputFiles)].sort(compareCodeUnits).map(file=>({file,sha256:sha256(inputText(repositoryRoot,sourceOverrides,file))}));
  return {schemaVersion:1,mode:"V",proofKind,sourceBase:"82d95e976919966154ee163976d0c93defdb3a10",surfaceDigest:surface.digest,allAdmittedInputs:true,sampledInputs:0,domain:{observableContract:"all reports produced by the already-strict ReservationSafety feasibility projection; exact feasible void return and deterministic sorted shortage error for every non-feasible report"},strictDependencies:dependency(repositoryRoot,surface),equations:[eq],inputs,proofs:[{surfaceKey:supportedSurfaceKeys[0],signatureHash:callable.signatureHash,declaration:callable.declaration,equationId:eq.id}]};
}
