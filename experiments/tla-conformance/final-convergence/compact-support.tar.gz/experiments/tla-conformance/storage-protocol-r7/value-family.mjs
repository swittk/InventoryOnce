import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  canonicalJson,
  compareCodeUnits,
  sha256,
  spanOf,
  ts,
} from "../surface-bindings/lib/compiler-surface.mjs";
import { normalizeQuantityValueCallable } from "../quantity-values-r7/certificate.mjs";

/** Exact current-source value-family discriminator proposed for hub registration. */
export const proofKind = "storage-protocol-construction-and-plan-closed-equations-v1";

/** Exact public value surfaces owned by this family. */
export const supportedSurfaceKeys = Object.freeze([
  "export:./storage#InMemoryInventoryDurableStorage::construct[0]",
  "export:./storage#InventoryApplyingOperationConflictError::construct[0]",
  "export:./storage#InventoryWorldRevisionConflictError::construct[0]",
  "export:./storage#createInMemoryInventoryDurableStorage::call[0]",
  "export:./storage#inventoryDurablePlanDigest::call[0]",
  "export:./storage#materializeInventoryDurableOperationWorld::call[0]",
  "export:./storage#validateInventoryDurableOperationBeginInput::call[0]",
]);

/** Production and independent-equation callables compared by normalized semantics. */
const equations = Object.freeze([
  ["src/storage.ts", "InventoryWorldRevisionConflictError.constructor"],
  ["src/storage.ts", "InventoryApplyingOperationConflictError.constructor"],
  ["src/storage.ts", "InMemoryInventoryDurableStorage.constructor"],
  ["src/storage.ts", "createInMemoryInventoryDurableStorage"],
  ["src/integrity.ts", "inventoryDurablePlanDigest"],
  ["src/storage.ts", "validateInventoryDurableOperationBeginInput"],
  ["src/storage.ts", "materializeInventoryDurableOperationWorld"],
  ["src/world.ts", "emptyInventoryWorldState"],
  ["src/storage.ts", "validateBeginInventoryOperation"],
  ["src/storage.ts", "validateInventoryDurablePlanAgainstBase"],
  ["src/storage.ts", "inventoryWorldContentRootsEqual"],
  ["src/storage.ts", "validatePublishedInventoryWorld"],
]);

/** Current hub certificates reused as exact semantic dependencies, never rerun here. */
const reusedCertificates = Object.freeze([
  { family: "inventoryonce-quantity-measurement-complete-source-equations-v1", certificateId: "sha256:9550e29f9da15f3c3e901c747ee4335f6ce00b055aaf4bf8386fd3dcef011eb2", artifactSha256: "e07ec5ed44b8fdb160b5b2a0969c276e12725d800ed0acd7da40a2244abfed0e" },
  { family: "independent-identity-values-closed-equations-v1", certificateId: "sha256:70cf9a5160149abb2eaaae541f129c0a661bd3315636a1cb96420fd88cd5fa63", artifactSha256: "c250ec4434674f76ae50993e1b228bb7ced4e884787ac604c573967b46f215e6" },
  { family: "independent-catalog-foundation-closed-equations-v1", certificateId: "sha256:f595bf4214015e0597d3c67cc9689e1f65b9ab65cc6c64c41158f7281ec6a442", artifactSha256: "3b87ba5c2fc4ff4ea6388b2a488c8ce679d8a4afbee159800153b4b0b50f9bce" },
  { family: "inventoryonce-event-replacement-complete-source-equations-v1", certificateId: "sha256:ed7bc453bea4add335da67f1610ec38ce15c076aa2e8dd3afa4ef58edfb83915", artifactSha256: "bfb5aa723e36d4755b51809fd587082632d2308002dc199668db465b727123d4" },
  { family: "inventoryonce-transfer-correction-complete-source-equations-v2", certificateId: "sha256:119157925048c0c4bf402ea8d28568ad4b1a96d8332f762687da9fb6f1e36def", artifactSha256: "2b36b0ef664a749dab53ce4d3f54f2ca5eacd7c0e05e8dc1d4a06b73c095f106" },
  { family: "migration-plugin-helper-independent-source-closed-values-v3", certificateId: "sha256:945885132722aa1dc32b70b7a30d059be4f12c26de3296c6edda8936056fbdd7", artifactSha256: "dd2d300816956ca2d6725b988572c7f18040f33820538bb7a21210d6031e5763" },
  { family: "independent-catalog-read-semantic-closure-equations-v2", certificateId: "sha256:f9d1a11d40e1c7abbe8d2b5da2c217e30a486c11cb5b66003b50d565fe423978", artifactSha256: "67d676a3e69cdfce473335022cab7aff206f09f9a0f8560898def33cff4195b9" },
]);

/** Independently authored equation program for the complete local helper closure. */
const expectedFile = fileURLToPath(new URL("./value-equations.expected.ts.txt", import.meta.url));

/** Source/specification/checker inputs that rederive this family. */
const producerFiles = Object.freeze([
  "experiments/tla-conformance/storage-protocol-r7/value-equations.expected.ts.txt",
  "experiments/tla-conformance/storage-protocol-r7/value-family.mjs",
  "experiments/tla-conformance/quantity-values-r7/certificate.mjs",
  "experiments/tla-conformance/surface-bindings/lib/compiler-surface.mjs",
]);

/** Parse inert TypeScript equation text without executing or importing production code. */
function parseSource(fileName, text) {
  return ts.createSourceFile(fileName, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
}

/** Locate one exact named function or class constructor with a concrete body. */
function findCallable(source, equationId) {
  if (equationId.endsWith(".constructor")) {
    const className = equationId.slice(0, -".constructor".length);
    const classes = source.statements.filter((statement) =>
      ts.isClassDeclaration(statement) && statement.name?.text === className);
    assert.equal(classes.length, 1, `Expected one class '${className}'.`);
    const constructors = classes[0].members.filter((member) =>
      ts.isConstructorDeclaration(member) && member.body !== undefined);
    assert.equal(constructors.length, 1, `Expected one constructor '${equationId}'.`);
    return constructors[0];
  }
  const functions = source.statements.filter((statement) =>
    ts.isFunctionDeclaration(statement) && statement.name?.text === equationId && statement.body !== undefined);
  assert.equal(functions.length, 1, `Expected one function '${equationId}'.`);
  return functions[0];
}

/** Normalize the small constructor grammar, including `super` and `this`, without retaining AST objects. */
function normalizeConstructor(declaration) {
  const parameters = new Map();
  for (const [index, parameter] of declaration.parameters.entries()) {
    assert(ts.isIdentifier(parameter.name), "Storage constructors use simple parameters.");
    parameters.set(parameter.name.text, `parameter:${index}`);
  }
  function expression(node) {
    if (ts.isParenthesizedExpression(node)) return expression(node.expression);
    if (node.kind === ts.SyntaxKind.ThisKeyword) return ["this"];
    if (node.kind === ts.SyntaxKind.SuperKeyword) return ["super"];
    if (ts.isIdentifier(node)) return ["reference", parameters.get(node.text) ?? `source:${node.text}`];
    if (ts.isStringLiteral(node)) return ["string", node.text];
    if (node.kind === ts.SyntaxKind.NullKeyword) return ["null"];
    if (ts.isPropertyAccessExpression(node)) return ["property", expression(node.expression), node.name.text];
    if (ts.isCallExpression(node)) return ["call", expression(node.expression), node.arguments.map(expression)];
    if (ts.isBinaryExpression(node)) return ["binary", ts.tokenToString(node.operatorToken.kind), expression(node.left), expression(node.right)];
    if (ts.isTemplateExpression(node)) return ["template", node.head.text, node.templateSpans.map((span) => [expression(span.expression), span.literal.text])];
    if (ts.isObjectLiteralExpression(node)) return ["record", node.properties.length];
    throw new Error(`Unsupported constructor equation expression '${ts.SyntaxKind[node.kind]}'.`);
  }
  return {
    parameters: declaration.parameters.map((parameter, index) => ({
      identity: `parameter:${index}`,
      type: parameter.type?.getText().replaceAll(/\s+/gu, "") ?? null,
      default: parameter.initializer === undefined ? null : expression(parameter.initializer),
    })),
    body: declaration.body.statements.map((statement) => {
      assert(ts.isExpressionStatement(statement), "Storage constructors use expression statements only.");
      return expression(statement.expression);
    }),
  };
}

/** Normalize one local equation to a JSON term that cannot retain compiler-node identity. */
function normalizedEquation(declaration) {
  const term = ts.isConstructorDeclaration(declaration)
    ? normalizeConstructor(declaration)
    : normalizeQuantityValueCallable(declaration);
  return removeTypeComments(term);
}

/** Remove declaration comments embedded by TypeScript inside anonymous object type text. */
function removeTypeComments(value, field = "") {
  if (typeof value === "string") {
    return field === "type" ? value.replaceAll(/\/\*[\s\S]*?\*\//gu, "") : value;
  }
  if (Array.isArray(value)) return value.map((entry) => removeTypeComments(entry));
  if (value === null || typeof value !== "object") return value;
  return Object.fromEntries(Object.entries(value).map(([name, entry]) => [name, removeTypeComments(entry, name)]));
}

/** Return source text from a mutation override or the actual repository file. */
function sourceText(repositoryRoot, sourceOverrides, file) {
  return sourceOverrides.get(file) ?? fs.readFileSync(path.resolve(repositoryRoot, file), "utf8");
}

/** Build all seven public proofs from independent equations and their local recursive helpers. */
export function buildFamilyArtifact({ repositoryRoot, context, surface, sourceOverrides = new Map() }) {
  assert.equal(supportedSurfaceKeys.length, 7);
  const expected = parseSource(expectedFile, fs.readFileSync(expectedFile, "utf8"));
  const actualSources = new Map();
  for (const file of [...new Set(equations.map(([sourceFile]) => sourceFile))]) {
    const source = sourceOverrides.has(file)
      ? parseSource(path.resolve(repositoryRoot, file), sourceText(repositoryRoot, sourceOverrides, file))
      : context.program.getSourceFile(path.resolve(repositoryRoot, file));
    assert(source !== undefined, `Compiler omitted '${file}'.`);
    actualSources.set(file, source);
  }
  const derivedEquations = [];
  for (const [file, equationId] of equations) {
    const actual = findCallable(actualSources.get(file), equationId);
    const stated = findCallable(expected, equationId);
    const actualTerm = normalizedEquation(actual);
    const expectedTerm = normalizedEquation(stated);
    assert.deepEqual(actualTerm, expectedTerm, `Independent storage equation changed for '${equationId}'.`);
    derivedEquations.push({
      id: `${file}#${equationId}`,
      implementation: sourceOverrides.size === 0 ? spanOf(context, actual) : null,
      equationSha256: sha256(canonicalJson(expectedTerm)),
      term: expectedTerm,
    });
  }
  const callableByKey = new Map(surface.callables.map((callable) => [callable.key, callable]));
  const publicEquationByKey = new Map([
    [supportedSurfaceKeys[0], "src/storage.ts#InMemoryInventoryDurableStorage.constructor"],
    [supportedSurfaceKeys[1], "src/storage.ts#InventoryApplyingOperationConflictError.constructor"],
    [supportedSurfaceKeys[2], "src/storage.ts#InventoryWorldRevisionConflictError.constructor"],
    [supportedSurfaceKeys[3], "src/storage.ts#createInMemoryInventoryDurableStorage"],
    [supportedSurfaceKeys[4], "src/integrity.ts#inventoryDurablePlanDigest"],
    [supportedSurfaceKeys[5], "src/storage.ts#materializeInventoryDurableOperationWorld"],
    [supportedSurfaceKeys[6], "src/storage.ts#validateInventoryDurableOperationBeginInput"],
  ]);
  const proofs = supportedSurfaceKeys.map((surfaceKey) => {
    const callable = callableByKey.get(surfaceKey);
    assert(callable !== undefined, `Compiler omitted '${surfaceKey}'.`);
    return {
      surfaceKey,
      signatureHash: callable.signatureHash,
      declaration: callable.declaration,
      equationId: publicEquationByKey.get(surfaceKey),
    };
  });
  const inputFiles = [...new Set([
    ...producerFiles,
    ...equations.map(([file]) => file),
    "package.json",
  ])].sort(compareCodeUnits);
  const inputs = inputFiles.map((file) => ({
    file,
    sha256: sha256(sourceOverrides.get(file) ?? fs.readFileSync(path.resolve(repositoryRoot, file))),
  }));
  return {
    schemaVersion: 1,
    mode: "V",
    proofKind,
    sourceBase: "2eea09471b3bf8fcb61f38256e1c6a362149dad4",
    surfaceDigest: surface.digest,
    allAdmittedInputs: true,
    sampledInputs: 0,
    domain: {
      constructors: "all accepted constructor inputs plus every explicit guard",
      digest: "all structural plan parts with exact ordered JSON fields",
      validation: "all begin inputs through every source guard and catalog/event identity dependency",
      materialization: "all compact plans through exact base/root/digest and component-delta checks",
    },
    reusedCertificates,
    equations: derivedEquations,
    inputs,
    proofs,
  };
}
