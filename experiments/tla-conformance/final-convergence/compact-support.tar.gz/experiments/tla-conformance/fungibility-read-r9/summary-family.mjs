import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import {
  canonicalJson,
  sha256,
  spanOf,
  ts,
} from "../surface-bindings/lib/compiler-surface.mjs";
import { loadEvidenceCompilerContext } from "../surface-bindings/lib/binding-checker.mjs";
import {
  buildFamilyArtifact as buildFungibilityValue5Artifact,
  proofKind as fungibilityValue5ProofKind,
  supportedSurfaceKeys as fungibilityValue5SurfaceKeys,
} from "../fungibility-values5-r8/family.mjs";
import { expectedMethodTerm, findClassMethod, normalizeCallable } from "../authority-r5/catalog-published-source-equations.mjs";
import { strictDependencyReceipt } from "../throughput-r7/strict-dependency-receipt.mjs";

export const proofKind = "fungibility-summary-complete-values-v1";
export const supportedSurfaceKeys = Object.freeze([
  "export:.#summarizeInventoryFungibility::call[0]",
  "export:./kernel#summarizeInventoryFungibility::call[0]",
  "type:src/facade.ts#InventoryOnceReadSnapshotApi.fungibilitySummary::call[0]",
].sort());

const EXPECTED =
  "experiments/tla-conformance/fungibility-read-r9/equations.expected.ts.txt";
const VALUE5_EVIDENCE =
  "experiments/tla-conformance/fungibility-values5-r8/evidence.json";
const VALUE5_NORMALIZE_KEY =
  "export:.#normalizeInventoryFungibilityScope::call[0]";
const SNAPSHOT_SURFACE_KEY =
  "type:src/facade.ts#InventoryOnceReadSnapshotApi.fungibilitySummary::call[0]";
const SNAPSHOT_CONTRACT = Object.freeze({
  surfaceKey: SNAPSHOT_SURFACE_KEY,
  sourceFile: "src/facade.ts",
  className: "InventoryOnceReadSnapshotImplementation",
  methodName: "fungibilitySummary",
  equation:
    "result = summarizeInventoryFungibility({ catalog: this.catalog, projection: this.world.projection, fungibilityRevisionId: p0.fungibilityRevisionId, ...(p0.scope === undefined ? {} : { scope: p0.scope }) })",
  law: Object.freeze({
    kind: "direct-return",
    parameterCount: 1,
    defaults: Object.freeze([]),
    optionalParameters: Object.freeze([]),
    expression:
      "summarizeInventoryFungibility({ catalog: this.catalog, projection: this.world.projection, fungibilityRevisionId: p0.fungibilityRevisionId, ...(p0.scope === undefined ? {} : { scope: p0.scope }) })",
  }),
});


const CURRENT_STRICT_DEPENDENCIES = Object.freeze([
  "type:src/catalog.ts#InventoryCatalog.fungibilityRevision::call[0]",
  "type:src/catalog.ts#InventoryCatalog.itemRevision::call[0]",
  "export:./kernel#normalizeInventoryStockSelector::call[0]",
  "export:./kernel#findInventoryPositions::call[0]",
  "export:.#zeroQuantity::call[0]",
  "export:.#inventoryMeasurementAt::call[0]",
  "export:.#addQuantity::call[0]",
  "export:.#compareQuantity::call[0]",
  "export:.#negateQuantity::call[0]",
  "export:.#convertQuantityByReferenceExact::call[0]",
]);

const LOCAL_CONTRACTS = Object.freeze([
  {
    id: "src/fungibility.ts#selectorForFungibilityMember",
    file: "src/fungibility.ts",
    name: "selectorForFungibilityMember",
    law:
      "Create exactly one normalized selector for the member item/revision while preserving every common orthogonal scope dimension.",
    dependencies: ["export:./kernel#normalizeInventoryStockSelector::call[0]"],
  },
  {
    id: "src/fungibility.ts#selectedFungibilityPositions",
    file: "src/fungibility.ts",
    name: "selectedFungibilityPositions",
    law:
      "Return exactly the current projection positions selected by the normalized member selector in canonical position-search order.",
    dependencies: ["export:./kernel#findInventoryPositions::call[0]"],
  },
  {
    id: "src/fungibility.ts#summarizeInventoryFungibility",
    file: "src/fungibility.ts",
    name: "summarizeInventoryFungibility",
    law:
      "For the exact frozen pool revision and normalized scope, sum every member measurement exactly, split physical and deficit magnitudes by sign, convert all three totals through the frozen member-to-pool ratio, preserve each member breakdown, and return exact common-basis totals without altering item identity.",
    dependencies: [
      "type:src/catalog.ts#InventoryCatalog.fungibilityRevision::call[0]",
      "type:src/catalog.ts#InventoryCatalog.itemRevision::call[0]",
      VALUE5_NORMALIZE_KEY,
      "src/fungibility.ts#selectorForFungibilityMember",
      "src/fungibility.ts#selectedFungibilityPositions",
      "export:.#zeroQuantity::call[0]",
      "export:.#inventoryMeasurementAt::call[0]",
      "export:.#addQuantity::call[0]",
      "export:.#compareQuantity::call[0]",
      "export:.#negateQuantity::call[0]",
      "export:.#convertQuantityByReferenceExact::call[0]",
    ],
  },
]);

function source(repositoryRoot, context, file, sourceOverrides) {
  const changed = sourceOverrides.get(file);
  if (changed !== undefined) {
    return ts.createSourceFile(
      path.resolve(repositoryRoot, file),
      changed,
      ts.ScriptTarget.Latest,
      true,
      ts.ScriptKind.TS
    );
  }
  const current = context.program.getSourceFile(path.resolve(repositoryRoot, file));
  assert(current !== undefined && !current.isDeclarationFile, `Missing ${file}`);
  return current;
}

function findFunction(sourceFile, name) {
  const rows = sourceFile.statements.filter(
    (node) => ts.isFunctionDeclaration(node) && node.name?.text === name
  );
  assert.equal(rows.length, 1, `Expected one function ${name}`);
  assert(rows[0].body !== undefined, `Function ${name} has no body`);
  return rows[0];
}

function tokens(text) {
  const scanner = ts.createScanner(
    ts.ScriptTarget.Latest,
    true,
    ts.LanguageVariant.Standard,
    text
  );
  const result = [];
  for (;;) {
    const kind = scanner.scan();
    if (kind === ts.SyntaxKind.EndOfFileToken) break;
    result.push([ts.SyntaxKind[kind], scanner.getTokenText()]);
  }
  return result;
}

function term(sourceFile, declaration) {
  return tokens(declaration.getText(sourceFile));
}

function readJson(repositoryRoot, file) {
  return JSON.parse(fs.readFileSync(path.resolve(repositoryRoot, file), "utf8"));
}

function addInput(repositoryRoot, inputs, file) {
  if (inputs.has(file)) return;
  inputs.set(file, {
    file,
    sha256: sha256(fs.readFileSync(path.resolve(repositoryRoot, file))),
  });
}

function currentStrictDependencyReceipt(repositoryRoot, surface) {
  return strictDependencyReceipt({
    repositoryRoot,
    surface,
    requirements: CURRENT_STRICT_DEPENDENCIES,
    label: "fungibility-summary dependency",
  }).dependencies;
}

function value5Receipt({ repositoryRoot, context, surface, sourceOverrides }) {
  const artifact = buildFungibilityValue5Artifact({ repositoryRoot, context, surface, sourceOverrides });
  const proof = artifact.proofs.find((row) => row.surfaceKey === VALUE5_NORMALIZE_KEY);
  assert(proof !== undefined, "Value5 normalize proof missing");
  if (sourceOverrides.size > 0) {
    return { receipt: { surfaceKey: VALUE5_NORMALIZE_KEY, proofKind: fungibilityValue5ProofKind, mutationControl: true }, inputs: [] };
  }
  assert.equal(artifact.proofKind, fungibilityValue5ProofKind);
  assert.equal(artifact.surfaceDigest, surface.digest);
  assert.equal(artifact.allAdmittedInputs, true);
  assert.equal(artifact.sampledInputs, 0);
  assert.deepEqual(artifact.proofs.map((row) => row.surfaceKey).sort(), [...fungibilityValue5SurfaceKeys].sort());
  const recorded = readJson(repositoryRoot, VALUE5_EVIDENCE);
  assert.deepEqual(recorded, artifact, "Value5 recorded evidence differs from current rederived family.");
  const evidence = { file: VALUE5_EVIDENCE, sha256: sha256(fs.readFileSync(path.resolve(repositoryRoot, VALUE5_EVIDENCE))) };
  return {
    receipt: { surfaceKey: VALUE5_NORMALIZE_KEY, mode: "V", proofKind: fungibilityValue5ProofKind, evidence, equationId: proof.equationId },
    inputs: artifact.inputs ?? [],
  };
}

export function buildSummaryValueArtifact({
  repositoryRoot = process.cwd(),
  context = loadEvidenceCompilerContext(repositoryRoot, []),
  surface,
  sourceOverrides = new Map(),
} = {}) {
  assert(surface !== undefined, "surface required");
  const expectedText = fs.readFileSync(path.resolve(repositoryRoot, EXPECTED), "utf8");
  const expected = ts.createSourceFile(
    path.resolve(repositoryRoot, EXPECTED),
    expectedText,
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TS
  );
  assert.equal(expected.parseDiagnostics.length, 0, "Expected equation file must parse.");

  const equations = [];
  for (const contract of LOCAL_CONTRACTS) {
    const actualSource = source(repositoryRoot, context, contract.file, sourceOverrides);
    const actualDeclaration = findFunction(actualSource, contract.name);
    const expectedDeclaration = findFunction(expected, contract.name);
    const actualTerm = term(actualSource, actualDeclaration);
    const expectedTerm = term(expected, expectedDeclaration);
    assert.deepEqual(actualTerm, expectedTerm, `Independent equation changed: ${contract.id}`);
    equations.push({
      id: contract.id,
      law: contract.law,
      dependencies: contract.dependencies,
      termSha256: sha256(canonicalJson(actualTerm)),
      implementation:
        sourceOverrides.size === 0
          ? spanOf(context, actualDeclaration)
          : { file: contract.file, mutationControl: true },
    });
  }

  const facadeSource = source(repositoryRoot, context, "src/facade.ts", sourceOverrides);
  const snapshotDeclaration = findClassMethod(
    facadeSource,
    SNAPSHOT_CONTRACT.className,
    SNAPSHOT_CONTRACT.methodName
  );
  const snapshotActualTerm = normalizeCallable(snapshotDeclaration);
  const snapshotExpectedTerm = expectedMethodTerm(SNAPSHOT_CONTRACT);
  assert.deepEqual(
    snapshotActualTerm,
    snapshotExpectedTerm,
    `${SNAPSHOT_SURFACE_KEY} source equation changed.`
  );
  const snapshotClass = facadeSource.statements.find(
    (node) => ts.isClassDeclaration(node) && node.name?.text === SNAPSHOT_CONTRACT.className
  );
  assert(snapshotClass !== undefined);
  const snapshotHeritage = snapshotClass.heritageClauses?.flatMap((clause) =>
    clause.types.map((type) => type.expression.getText(facadeSource))
  ) ?? [];
  assert(
    snapshotHeritage.includes("InventoryOnceReadSnapshotApi"),
    "Snapshot implementation must implement InventoryOnceReadSnapshotApi."
  );
  const snapshotEquation = {
    id: "src/facade.ts#InventoryOnceReadSnapshotImplementation.fungibilitySummary",
    law: SNAPSHOT_CONTRACT.equation,
    dependencies: ["src/fungibility.ts#summarizeInventoryFungibility"],
    termSha256: sha256(canonicalJson(snapshotActualTerm)),
    implementation:
      sourceOverrides.size === 0
        ? spanOf(context, snapshotDeclaration)
        : { file: "src/facade.ts", mutationControl: true },
  };
  equations.push(snapshotEquation);

  const value5 = value5Receipt({ repositoryRoot, context, surface, sourceOverrides });
  if (sourceOverrides.size > 0) return { mutationControlAccepted: false };
  const currentDependencies = currentStrictDependencyReceipt(repositoryRoot, surface);

  const live = new Map(surface.callables.map((row) => [row.key, row]));
  const summary = equations.find((row) => row.id === "src/fungibility.ts#summarizeInventoryFungibility");
  assert(summary !== undefined);
  const proofs = supportedSurfaceKeys.map((surfaceKey) => {
    const callable = live.get(surfaceKey);
    assert(callable !== undefined, `Missing ${surfaceKey}`);
    const equation = surfaceKey === SNAPSHOT_SURFACE_KEY ? snapshotEquation : summary;
    return {
      surfaceKey,
      signatureHash: callable.signatureHash,
      declaration: callable.declaration,
      equationId: equation.id,
      semantics: {
        law: equation.law,
        completeExpectedTermSha256: equation.termSha256,
        localEquations: equations.map((row) => ({ id: row.id, termSha256: row.termSha256 })),
        currentStrictDependencies: currentDependencies,
        queuedDependency: value5.receipt,
        ...(surfaceKey === SNAPSHOT_SURFACE_KEY
          ? { sameFamilyDependency: summary.id }
          : {}),
      },
    };
  });

  const inputs = new Map();
  for (const file of [
    "experiments/tla-conformance/fungibility-read-r9/summary-family.mjs",
    EXPECTED,
    VALUE5_EVIDENCE,
    "experiments/tla-conformance/fungibility-values5-r8/family.mjs",
    "experiments/tla-conformance/throughput-r7/strict-dependency-receipt.mjs",
    "experiments/tla-conformance/authority-r5/catalog-published-source-equations.mjs",
    "experiments/tla-conformance/authority-r5/catalog-published-source-contracts.mjs",
    "src/fungibility.ts",
    "src/facade.ts",
    "src/catalog.ts",
    "src/projection.ts",
    "src/selectors.ts",
    "src/measurements.ts",
    "src/quantity.ts",
  ]) addInput(repositoryRoot, inputs, file);
  for (const input of value5.inputs) addInput(repositoryRoot, inputs, input.file);

  return {
    schemaVersion: 1,
    proofKind,
    route: "CERTIFIED_VALUE_EQUATION",
    family: "FungibilitySummary",
    surfaceDigest: surface.digest,
    domain:
      "All inputs admitted by the two direct summary exports plus the genuine frozen-snapshot fungibilitySummary signature. The full summary declaration and its two private selector helpers are checked against complete independent declaration terms; every external helper is either live-current strict V or the separately verified queued FungibilityValue5 normalize equation. No runtime samples, graph replay, or stateful action credit is used.",
    allAdmittedInputs: true,
    sampledInputs: 0,
    graphRuns: 0,
    replayRuns: 0,
    inputs: [...inputs.values()].sort((a, b) => a.file.localeCompare(b.file)),
    equations,
    currentStrictDependencies: currentDependencies,
    queuedDependencies: [value5.receipt],
    proofs,
  };
}

export const buildFamilyArtifact = buildSummaryValueArtifact;
