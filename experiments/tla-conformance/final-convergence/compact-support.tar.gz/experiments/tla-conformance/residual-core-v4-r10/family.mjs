import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { canonicalJson, sha256, ts } from "../surface-bindings/lib/compiler-surface.mjs";
import { buildFamilyArtifact as buildStorageValues } from "../storage-protocol-r7/value-family.mjs";
import { buildFamilyArtifact as buildMaterializeValues } from "../materialize1-r8/family.mjs";

export const proofKind="residual-core-pure-aliases-v4-v1";
export const supportedSurfaceKeys=Object.freeze([
  "export:.#findInventoryEventByOperationId::call[0]",
  "export:./kernel#findInventoryEventByOperationId::call[0]",
  "export:./storage#emptyInventoryWorldState::call[0]",
  "export:./storage#inventoryCatalogSnapshotDigest::call[0]",
]);
const EXPECTED="experiments/tla-conformance/residual-core-v4-r10/find.expected.ts.txt";
const SELF="experiments/tla-conformance/residual-core-v4-r10/family.mjs";
const FIND_ID="src/read-model.ts#findInventoryEventByOperationId";
const EMPTY_ID="src/world.ts#emptyInventoryWorldState";
const DIGEST_ID="src/integrity.ts#inventoryCatalogSnapshotDigest";
function sf(file,text){return ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);}
function functionDecl(source,name){const rows=source.statements.filter(x=>ts.isFunctionDeclaration(x)&&x.name?.text===name&&x.body!==undefined);assert.equal(rows.length,1,`Expected one ${name}`);return rows[0];}
function tokens(node,source){const text=source.text.slice(node.getStart(source),node.end),scan=ts.createScanner(ts.ScriptTarget.Latest,true,ts.LanguageVariant.Standard,text),out=[];for(;;){const k=scan.scan();if(k===ts.SyntaxKind.EndOfFileToken)break;out.push([ts.SyntaxKind[k],scan.getTokenText()]);}return out;}
function findEquation(root,overrides=new Map()){
 const actualText=overrides.get("src/read-model.ts")??fs.readFileSync(path.resolve(root,"src/read-model.ts"),"utf8");
 const actual=sf("src/read-model.ts",actualText),expected=sf(EXPECTED,fs.readFileSync(path.resolve(root,EXPECTED),"utf8"));
 const a=functionDecl(actual,"findInventoryEventByOperationId"),e=functionDecl(expected,"findInventoryEventByOperationId"),at=tokens(a,actual),et=tokens(e,expected);
 assert.deepEqual(at,et,"findInventoryEventByOperationId complete expected equation changed");
 return{equationId:FIND_ID,completeExpectedTerm:true,termSha256:sha256(canonicalJson(at)),implementationAstSha256:sha256(actualText.slice(a.getStart(actual),a.end))};
}
function addInput(root,map,file){if(map.has(file))return;map.set(file,{file,sha256:sha256(fs.readFileSync(path.resolve(root,file)))});}
export function buildFamilyArtifact({repositoryRoot=process.cwd(),context,surface,sourceOverrides=new Map(),storageArtifactOverride,materializeArtifactOverride}={}){
 assert(context&&surface); const find=findEquation(repositoryRoot,sourceOverrides); if(sourceOverrides.size>0)return{mutationControlAccepted:false,find};
 const storageCurrent=buildStorageValues({repositoryRoot,context,surface}); const storage=storageArtifactOverride?storageArtifactOverride(structuredClone(storageCurrent)):storageCurrent; assert.deepEqual(storage,storageCurrent,"Storage value dependency drifted");
 const empty=storage.equations.find(x=>x.id===EMPTY_ID);assert(empty!==undefined,"Storage complete empty-world equation missing");assert.equal(empty.implementation.astHash,"095773ae9c97eac998910f614bd1af4134491c7df35dcab040b2162667e08961");
 const materializeCurrent=buildMaterializeValues({repositoryRoot,context,surface}); const materialize=materializeArtifactOverride?materializeArtifactOverride(structuredClone(materializeCurrent)):materializeCurrent; assert.deepEqual(materialize,materializeCurrent,"Materialize value dependency drifted");
 const digest=materialize.rootEquations.find(x=>x.id===DIGEST_ID);assert(digest!==undefined&&digest.completeExpectedTerm===true,"Complete catalog-snapshot digest equation missing");
 const live=new Map(surface.callables.map(c=>[c.key,c])); const inputs=new Map();
 for(const artifact of [storageCurrent,materializeCurrent]) for(const input of artifact.inputs) addInput(repositoryRoot,inputs,input.file);
 for(const file of [SELF,EXPECTED,"src/read-model.ts","src/world.ts","src/integrity.ts","node_modules/typescript/package.json"])addInput(repositoryRoot,inputs,file);
 const proofs=supportedSurfaceKeys.map(surfaceKey=>{const c=live.get(surfaceKey);assert(c!==undefined,`Missing ${surfaceKey}`);let semantic;
   if(surfaceKey.includes("findInventoryEventByOperationId")){assert.equal(c.declaration.file,"src/read-model.ts");semantic={kind:"INDEPENDENT_COMPLETE_SOURCE_EQUATION",...find};}
   else if(surfaceKey.includes("emptyInventoryWorldState")){assert.equal(c.declaration.astHash,empty.implementation.astHash);semantic={kind:"REUSED_REDERIVED_COMPLETE_EQUATION",dependencyProofKind:storageCurrent.proofKind,equation:empty};}
   else {assert.equal(c.declaration.file,"src/integrity.ts");semantic={kind:"REUSED_REDERIVED_COMPLETE_EQUATION",dependencyProofKind:materializeCurrent.proofKind,equation:digest};}
   return{surfaceKey,signatureHash:c.signatureHash,declaration:c.declaration,semantic};
 });
 return{schemaVersion:1,proofKind,surfaceDigest:surface.digest,domain:"All valid typed inputs of the exact current implementations: complete branch/error/index semantics for findInventoryEventByOperationId; the independently rederived StorageProtocol empty world equation; and the independently rederived catalog-snapshot digest root equation plus its closed catalog dependency.",allAdmittedInputs:true,sampledInputs:0,inputs:[...inputs.values()].sort((a,b)=>a.file<b.file?-1:a.file>b.file?1:0),proofs};
}
