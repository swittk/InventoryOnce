import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import {
  canonicalJson,
  sha256,
  spanOf,
  ts,
} from "../surface-bindings/lib/compiler-surface.mjs";
import { loadEvidenceCompilerContext } from "../surface-bindings/lib/binding-checker.mjs";
import {
  buildFamilyArtifact as buildFungibilityValue5Artifact,
  proofKind as fungibilityValue5ProofKind,
  supportedSurfaceKeys as fungibilityValue5SurfaceKeys,
} from "../fungibility-values5-r8/family.mjs";
import { strictDependencyReceipt } from "../throughput-r7/strict-dependency-receipt.mjs";

export const proofKind = "fungibility-allocation-plan-complete-values-v1";
export const supportedSurfaceKeys = Object.freeze([
  "export:.#planInventoryFungibilityAllocation::call[0]",
  "export:./kernel#planInventoryFungibilityAllocation::call[0]",
].sort());

const EXPECTED =
  "experiments/tla-conformance/fungibility-plan-r9/equations.expected.ts.txt";
const VALUE5_EVIDENCE =
  "experiments/tla-conformance/fungibility-values5-r8/evidence.json";
const VALUE5_NORMALIZE_KEY =
  "export:.#normalizeInventoryFungibilityScope::call[0]";

const LOCAL_CONTRACTS = Object.freeze([
  ["planInventoryFungibilityAllocation", "Plan one exact common-basis FIFO/FEFO allocation across every member revision, preserving exact member identities, package increments, expiry/increment diagnostics, and active reservation feasibility before returning source lines."],
  ["validateFungibilityReservationEffect", "Accept depletion only without a destination and transfer only with a nonblank destination; reject every malformed reservation effect before allocation search."],
  ["fungibilityAllocationsPreserveReservations", "Apply the complete hypothetical allocation to sparse projection overlays, including destination rows for transfer, then accept exactly when the certified reservation feasibility projection reports Feasible."],
  ["createFungibilitySparseRecordOverlay", "Provide a tombstone-aware sparse record overlay whose get/set/delete/has operations preserve immutable-base reads while retaining only local what-if mutations."],
  ["addFungibilitySimulationIndex", "Insert one exact position identity into one sparse index bucket once and retain deterministic sorted order."],
  ["removeFungibilitySimulationIndex", "Remove exactly one position identity from one sparse index bucket and tombstone the bucket when it becomes empty."],
  ["addFungibilityCandidate", "Convert one exact eligible member source line into common pool units, derive its indivisible allocation increment, and retain the exact evidence needed to map allocator output back to physical identity."],
  ["fungibilityAllocationIncrement", "Return the smallest legal common-basis quantum, requiring whole measured/serialized positions and package multiples while otherwise retaining the member reference quantum."],
  ["positionHasIndependentMeasuredContents", "Return true exactly when any independent axis is required or currently nonzero."],
  ["selectorForFungibilityMember", "Create one normalized stock selector for the exact member item/revision while preserving every common fungibility scope dimension."],
  ["selectedFungibilityPositions", "Return exactly the projection positions selected by the certified stock-selector lookup."],
  ["totalPositivePrimary", "Sum only positive primary-axis quantities from selected non-transfer positions in exact quantity arithmetic."],
].map(([name, law]) => Object.freeze({
  id: `src/fungibility.ts#${name}`,
  name,
  law,
})));

const CURRENT_STRICT_DEPENDENCIES = Object.freeze([
  "type:src/catalog.ts#InventoryCatalog.fungibilityRevision::call[0]",
  "type:src/catalog.ts#InventoryCatalog.itemRevision::call[0]",
  "type:src/catalog.ts#InventoryCatalog.packagingRevision::call[0]",
  "export:./kernel#assertCanonicalInventoryTime::call[0]",
  "export:.#positiveQuantity::call[0]",
  "export:.#planInventoryAllocation::call[0]",
  "export:.#stockAmount::call[0]",
  "export:.#quantityToDecimalString::call[0]",
  "export:./kernel#allocateInventory::call[0]",
  "export:./kernel#inventoryStockPositionIdentity::call[0]",
  "export:.#convertQuantityByReferenceExact::call[0]",
  "export:.#inventoryAmountForPrimaryAllocation::call[0]",
  "export:.#resolveInventoryAmount::call[0]",
  "export:.#subtractInventoryMeasurements::call[0]",
  "export:.#inventoryMeasurementsAreZero::call[0]",
  "export:.#inventoryContainerIdentity::call[0]",
  "export:./kernel#normalizeInventoryStockPositionKey::call[0]",
  "export:.#zeroInventoryMeasurements::call[0]",
  "export:.#addInventoryMeasurements::call[0]",
  "export:./kernel#inspectInventoryReservationFeasibility::call[0]",
  "export:.#leastCommonQuantityMultiple::call[0]",
  "export:.#inventoryMeasurementAt::call[0]",
  "export:.#compareQuantity::call[0]",
  "export:.#zeroQuantity::call[0]",
  "export:./kernel#normalizeInventoryStockSelector::call[0]",
  "export:./kernel#findInventoryPositions::call[0]",
  "export:.#addQuantity::call[0]",
]);

function source(repositoryRoot, context, file, sourceOverrides) {
  const changed = sourceOverrides.get(file);
  if (changed !== undefined) {
    return ts.createSourceFile(
      path.resolve(repositoryRoot, file),
      changed,
      ts.ScriptTarget.Latest,
      true,
      ts.ScriptKind.TS
    );
  }
  const current = context.program.getSourceFile(path.resolve(repositoryRoot, file));
  assert(current !== undefined && !current.isDeclarationFile, `Missing ${file}`);
  return current;
}

function findFunction(sourceFile, name) {
  const rows = sourceFile.statements.filter(
    (node) => ts.isFunctionDeclaration(node) && node.name?.text === name
  );
  assert.equal(rows.length, 1, `Expected one function ${name}`);
  assert(rows[0].body !== undefined, `Function ${name} has no body`);
  return rows[0];
}

function tokens(text) {
  const scanner = ts.createScanner(
    ts.ScriptTarget.Latest,
    true,
    ts.LanguageVariant.Standard,
    text
  );
  const result = [];
  for (;;) {
    const kind = scanner.scan();
    if (kind === ts.SyntaxKind.EndOfFileToken) break;
    result.push([ts.SyntaxKind[kind], scanner.getTokenText()]);
  }
  return result;
}

function term(sourceFile, declaration) {
  return tokens(declaration.getText(sourceFile));
}

function readJson(repositoryRoot, file) {
  return JSON.parse(fs.readFileSync(path.resolve(repositoryRoot, file), "utf8"));
}

function addInput(repositoryRoot, inputs, file) {
  if (inputs.has(file)) return;
  inputs.set(file, {
    file,
    sha256: sha256(fs.readFileSync(path.resolve(repositoryRoot, file))),
  });
}

function currentStrictDependencyReceipt(repositoryRoot, surface) {
  return strictDependencyReceipt({ repositoryRoot, surface, requirements: CURRENT_STRICT_DEPENDENCIES, label: "fungibility-plan dependency" }).dependencies;
}

function value5Receipt({ repositoryRoot, context, surface, sourceOverrides }) {
  const artifact = buildFungibilityValue5Artifact({ repositoryRoot, context, surface, sourceOverrides });
  const proof = artifact.proofs.find((row) => row.surfaceKey === VALUE5_NORMALIZE_KEY);
  assert(proof !== undefined, "Value5 normalize proof missing");
  if (sourceOverrides.size > 0) return { receipt: { surfaceKey: VALUE5_NORMALIZE_KEY, mutationControl: true }, inputs: [] };
  assert.equal(artifact.proofKind, fungibilityValue5ProofKind);
  assert.equal(artifact.surfaceDigest, surface.digest);
  assert.equal(artifact.allAdmittedInputs, true);
  assert.equal(artifact.sampledInputs, 0);
  assert.deepEqual(artifact.proofs.map((row) => row.surfaceKey).sort(), [...fungibilityValue5SurfaceKeys].sort());
  const recorded = readJson(repositoryRoot, VALUE5_EVIDENCE);
  assert.deepEqual(recorded, artifact, "Value5 recorded evidence differs from current rederived family.");
  const evidence = { file: VALUE5_EVIDENCE, sha256: sha256(fs.readFileSync(path.resolve(repositoryRoot, VALUE5_EVIDENCE))) };
  return { receipt: { surfaceKey: VALUE5_NORMALIZE_KEY, mode: "V", proofKind: fungibilityValue5ProofKind, evidence, equationId: proof.equationId }, inputs: artifact.inputs ?? [] };
}

export function buildPlanValueArtifact({
  repositoryRoot = process.cwd(),
  context = loadEvidenceCompilerContext(repositoryRoot, []),
  surface,
  sourceOverrides = new Map(),
} = {}) {
  assert(surface !== undefined, "surface required");
  const expectedText = fs.readFileSync(path.resolve(repositoryRoot, EXPECTED), "utf8");
  const expected = ts.createSourceFile(
    path.resolve(repositoryRoot, EXPECTED),
    expectedText,
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TS
  );
  assert.equal(expected.parseDiagnostics.length, 0, "Expected planner equation file must parse.");
  const actual = source(repositoryRoot, context, "src/fungibility.ts", sourceOverrides);
  const equations = [];
  for (const contract of LOCAL_CONTRACTS) {
    const actualDeclaration = findFunction(actual, contract.name);
    const expectedDeclaration = findFunction(expected, contract.name);
    const actualTerm = term(actual, actualDeclaration);
    const expectedTerm = term(expected, expectedDeclaration);
    assert.deepEqual(actualTerm, expectedTerm, `Independent equation changed: ${contract.id}`);
    equations.push({
      id: contract.id,
      law: contract.law,
      termSha256: sha256(canonicalJson(actualTerm)),
      implementation:
        sourceOverrides.size === 0
          ? spanOf(context, actualDeclaration)
          : { file: "src/fungibility.ts", mutationControl: true },
    });
  }
  const value5 = value5Receipt({ repositoryRoot, context, surface, sourceOverrides });
  if (sourceOverrides.size > 0) return { mutationControlAccepted: false };
  const currentDependencies = currentStrictDependencyReceipt(repositoryRoot, surface);
  const main = equations.find(
    (row) => row.id === "src/fungibility.ts#planInventoryFungibilityAllocation"
  );
  assert(main !== undefined);
  const live = new Map(surface.callables.map((row) => [row.key, row]));
  const proofs = supportedSurfaceKeys.map((surfaceKey) => {
    const callable = live.get(surfaceKey);
    assert(callable !== undefined, `Missing ${surfaceKey}`);
    return {
      surfaceKey,
      signatureHash: callable.signatureHash,
      declaration: callable.declaration,
      equationId: main.id,
      semantics: {
        law: main.law,
        completeExpectedTermSha256: main.termSha256,
        localEquations: equations.map((row) => ({ id: row.id, termSha256: row.termSha256 })),
        currentStrictDependencies: currentDependencies,
        queuedDependency: value5.receipt,
      },
    };
  });
  const inputs = new Map();
  for (const file of [
    "experiments/tla-conformance/fungibility-plan-r9/value-family.mjs",
    EXPECTED,
    VALUE5_EVIDENCE,
    "experiments/tla-conformance/fungibility-values5-r8/family.mjs",
    "experiments/tla-conformance/throughput-r7/strict-dependency-receipt.mjs",
    "src/fungibility.ts",
    "src/allocation.ts",
    "src/amounts.ts",
    "src/catalog.ts",
    "src/events.ts",
    "src/measurements.ts",
    "src/model.ts",
    "src/picking.ts",
    "src/projection.ts",
    "src/reservations.ts",
    "src/quantity.ts",
    "src/selectors.ts",
  ]) addInput(repositoryRoot, inputs, file);
  for (const input of value5.inputs) addInput(repositoryRoot, inputs, input.file);
  return {
    schemaVersion: 1,
    route: "CERTIFIED_VALUE_EQUATION",
    proofKind,
    family: "FungibilityAllocationPlan",
    surfaceDigest: surface.digest,
    domain:
      "All arguments and worlds admitted by the two direct planner signatures. The complete planner and every private helper it transitively owns are checked against a frozen independent equation program; every imported runtime dependency is live-current strict A/B/V or the separately verified queued FungibilityValue5 normalization equation. The reservation-preservation callback is included in the complete local equation and delegates its final universal claim decision to the already-strict inspectInventoryReservationFeasibility B projection. No samples, native replay, graph replay, or stateful action credit are used.",
    allAdmittedInputs: true,
    sampledInputs: 0,
    graphRuns: 0,
    replayRuns: 0,
    inputs: [...inputs.values()].sort((a, b) => a.file.localeCompare(b.file)),
    equations,
    currentStrictDependencies: currentDependencies,
    queuedDependencies: [value5.receipt],
    proofs,
  };
}

export const buildFamilyArtifact = buildPlanValueArtifact;
