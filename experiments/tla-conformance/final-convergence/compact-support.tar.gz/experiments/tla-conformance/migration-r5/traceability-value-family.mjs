import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";

import { canonicalJson, sha256, spanOf, ts } from "../surface-bindings/lib/compiler-surface.mjs";

/** Trusted registration name for the independently specified traceability value family. */
export const proofKind = "traceability-pure-relations-rebuild-independent-equations-v1";
/** Every remaining compiler-reachable pure traceability helper, with existing identity credit excluded. */
export const supportedSurfaceKeys = Object.freeze([
  "export:./kernel#buildContainmentChildContainerIndex::call[0]",
  "export:./kernel#inventoryGenealogyAncestors::call[0]",
  "export:./kernel#inventoryTraceabilityRelationIdentity::call[0]",
  "export:./kernel#inventoryTraceabilityRelationsOfKind::call[0]",
]);
/** Separately authored branch-complete specification, never executed as the source implementation. */
const EXPECTED_FILE = "experiments/tla-conformance/migration-r5/traceability-values.expected.ts.txt";
/** Existing bounded native certificate retained only as a control. */
const BOUNDED_CERTIFICATE = "experiments/tla-conformance/migration-r5/artifacts/TraceabilityGraph/projection-value-certificate.json";
/** Existing bounded result stream retained by reference. */
const BOUNDED_OBSERVATIONS = "experiments/tla-conformance/migration-r5/artifacts/TraceabilityGraph/projection-value-observations.ndjson";

/** Public equations and recursive/local helpers that close the whole projection family. */
const contracts = Object.freeze([
  ["src/traceability.ts#buildContainmentChildContainerIndex", "src/traceability.ts", "buildContainmentChildContainerIndex"],
  ["src/traceability.ts#inventoryGenealogyAncestors", "src/traceability.ts", "inventoryGenealogyAncestors"],
  ["src/traceability.ts#inventoryTraceabilityRelationIdentity", "src/traceability.ts", "inventoryTraceabilityRelationIdentity"],
  ["src/traceability.ts#inventoryTraceabilityRelationsOfKind", "src/traceability.ts", "inventoryTraceabilityRelationsOfKind"],
  ["src/traceability.ts#compareRelation", "src/traceability.ts", "compareRelation"],
  ["src/traceability.ts#compareNode", "src/traceability.ts", "compareNode"],
  ["src/traceability-replay.ts#projectInventoryTraceabilityEvents", "src/traceability-replay.ts", "projectInventoryTraceabilityEvents"],
  ["src/traceability-replay.ts#validateAndIndexAddition", "src/traceability-replay.ts", "validateAndIndexAddition"],
  ["src/traceability-replay.ts#removeIndexedRelation", "src/traceability-replay.ts", "removeIndexedRelation"],
  ["src/traceability-replay.ts#assertNoGenealogyPath", "src/traceability-replay.ts", "assertNoGenealogyPath"],
  ["src/model.ts#assertInventoryIdentity", "src/model.ts", "assertInventoryIdentity"],
  ["src/model.ts#inventoryTraceabilityNodeIdentity", "src/model.ts", "inventoryTraceabilityNodeIdentity"],
  ["src/ordering.ts#compareInventoryIdentityText", "src/ordering.ts", "compareInventoryIdentityText"],
].map(([id, file, name]) => Object.freeze({ id, file, name, expected: `expected_${name}` })));

/** Exact package dependencies closed by this independent equation family without duplicate public credit. */
const expectedDependencies = new Map([
  ["src/traceability.ts#buildContainmentChildContainerIndex", ["src/model.ts#inventoryTraceabilityNodeIdentity"]],
  ["src/traceability.ts#inventoryGenealogyAncestors", ["src/model.ts#inventoryTraceabilityNodeIdentity", "src/traceability.ts#compareNode"]],
  ["src/traceability.ts#inventoryTraceabilityRelationIdentity", ["src/model.ts#inventoryTraceabilityNodeIdentity"]],
  ["src/traceability.ts#inventoryTraceabilityRelationsOfKind", ["src/traceability.ts#compareRelation"]],
  ["src/traceability.ts#compareRelation", ["src/ordering.ts#compareInventoryIdentityText", "src/traceability.ts#inventoryTraceabilityRelationIdentity"]],
  ["src/traceability.ts#compareNode", ["src/model.ts#inventoryTraceabilityNodeIdentity", "src/ordering.ts#compareInventoryIdentityText"]],
  ["src/traceability-replay.ts#projectInventoryTraceabilityEvents", ["src/traceability-replay.ts#removeIndexedRelation", "src/traceability-replay.ts#validateAndIndexAddition", "src/traceability.ts#buildContainmentChildContainerIndex", "src/traceability.ts#inventoryTraceabilityRelationIdentity"]],
  ["src/traceability-replay.ts#validateAndIndexAddition", ["src/model.ts#inventoryTraceabilityNodeIdentity", "src/traceability-replay.ts#assertNoGenealogyPath"]],
  ["src/traceability-replay.ts#removeIndexedRelation", ["src/model.ts#inventoryTraceabilityNodeIdentity"]],
  ["src/traceability-replay.ts#assertNoGenealogyPath", []],
  ["src/model.ts#assertInventoryIdentity", []],
  ["src/model.ts#inventoryTraceabilityNodeIdentity", ["src/model.ts#assertInventoryIdentity"]],
  ["src/ordering.ts#compareInventoryIdentityText", []],
]);

/** Scan semantic tokens while discarding only whitespace and comments. */
function scanTokens(text) {
  const scanner = ts.createScanner(ts.ScriptTarget.Latest, true, ts.LanguageVariant.Standard, text);
  const tokens = [];
  for (;;) {
    const kind = scanner.scan();
    if (kind === ts.SyntaxKind.EndOfFileToken) break;
    tokens.push([ts.SyntaxKind[kind], scanner.getTokenText()]);
  }
  return tokens;
}

/** Build a declaration-name-independent, branch-complete algorithm term. */
function completeCallableTerm(declaration, source) {
  return {
    async: declaration.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword) ?? false,
    generator: declaration.asteriskToken !== undefined,
    typeParameters: (declaration.typeParameters ?? []).map((row) => scanTokens(row.getText(source))),
    parameters: declaration.parameters.map((row) => scanTokens(row.getText(source))),
    returnType: declaration.type === undefined ? null : scanTokens(declaration.type.getText(source)),
    body: scanTokens(declaration.body.getText(source)),
  };
}

/** Locate one body-bearing top-level source function. */
function findFunction(source, name) {
  const found = source.statements.filter((node) => ts.isFunctionDeclaration(node) && node.name?.text === name && node.body !== undefined);
  assert.equal(found.length, 1, `Expected one concrete function '${name}'.`);
  return found[0];
}

/** Return a current compiler source or a test-only mutated source override. */
function sourceFor(repositoryRoot, context, file, overrides) {
  const override = overrides.get(file);
  if (override !== undefined) {
    return ts.createSourceFile(path.resolve(repositoryRoot, file), override, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  }
  const source = context.program.getSourceFile(path.resolve(repositoryRoot, file));
  assert(source !== undefined && !source.isDeclarationFile, `Compiler omitted '${file}'.`);
  return source;
}

/** Resolve one declaration to its stable package function identity. */
function packageDeclarationId(repositoryRoot, declaration) {
  const file = path.relative(repositoryRoot, declaration.getSourceFile().fileName).replaceAll("\\", "/");
  if (!file.startsWith("src/") || !ts.isFunctionDeclaration(declaration) || declaration.name === undefined) return null;
  return `${file}#${declaration.name.text}`;
}

/** Resolve every direct package call in one current algorithm body. */
function directPackageDependencies(repositoryRoot, context, declaration) {
  const dependencies = new Set();
  function recordFunctionValue(expression) {
    if (!ts.isIdentifier(expression) && !ts.isPropertyAccessExpression(expression)) return;
    let symbol = context.checker.getSymbolAtLocation(ts.isPropertyAccessExpression(expression) ? expression.name : expression);
    if (symbol !== undefined && (symbol.flags & ts.SymbolFlags.Alias) !== 0) {
      symbol = context.checker.getAliasedSymbol(symbol);
    }
    for (const candidate of symbol?.declarations ?? []) {
      const id = packageDeclarationId(repositoryRoot, candidate);
      if (id !== null) dependencies.add(id);
    }
  }
  function visit(node) {
    if (ts.isCallExpression(node) || ts.isNewExpression(node)) {
      const target = context.checker.getResolvedSignature(node)?.declaration;
      const id = target === undefined ? null : packageDeclarationId(repositoryRoot, target);
      if (id !== null) dependencies.add(id);
      recordFunctionValue(node.expression);
      for (const argument of node.arguments ?? []) recordFunctionValue(argument);
      if (target !== undefined && target.getSourceFile().isDeclarationFile) {
        assert(/[/\\]typescript[/\\]lib[/\\]lib\.[^/\\]+\.d\.ts$/u.test(target.getSourceFile().fileName), "Only pinned TypeScript standard-library calls are admitted.");
      }
    }
    if (ts.isPropertyAccessExpression(node)) {
      const symbol = context.checker.getSymbolAtLocation(node.name);
      assert(!(symbol?.declarations ?? []).some((row) => ts.isGetAccessorDeclaration(row) || ts.isSetAccessorDeclaration(row)), "Accessor-bearing values are outside the immutable-data domain.");
    }
    ts.forEachChild(node, visit);
  }
  visit(declaration.body);
  return [...dependencies].sort();
}

/** Build the whole independent family; overrides exist only for semantic mutation tests. */
export function buildTraceabilityValueArtifact({ repositoryRoot, context, surface, sourceOverrides = new Map() }) {
  const expectedText = fs.readFileSync(path.resolve(repositoryRoot, EXPECTED_FILE), "utf8");
  const expectedSource = ts.createSourceFile(EXPECTED_FILE, expectedText, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  const localIds = new Set(contracts.map((contract) => contract.id));
  const equations = [];
  for (const contract of contracts) {
    const source = sourceFor(repositoryRoot, context, contract.file, sourceOverrides);
    const implementation = findFunction(source, contract.name);
    const expected = findFunction(expectedSource, contract.expected);
    const actualTerm = completeCallableTerm(implementation, source);
    const expectedTerm = completeCallableTerm(expected, expectedSource);
    assert.deepEqual(actualTerm, expectedTerm, `Independent algorithm equation changed: ${contract.id}`);
    const dependencies = sourceOverrides.has(contract.file)
      ? expectedDependencies.get(contract.id)
      : directPackageDependencies(repositoryRoot, context, implementation);
    assert.deepEqual(dependencies, expectedDependencies.get(contract.id), `Dependency closure changed: ${contract.id}`);
    for (const dependency of dependencies) assert(localIds.has(dependency), `Unproved dependency '${dependency}'.`);
    equations.push({
      id: contract.id,
      implementation: sourceOverrides.has(contract.file) ? null : spanOf(context, implementation),
      independentExpectedFunction: contract.expected,
      termSha256: sha256(canonicalJson(expectedTerm)),
      dependencies,
    });
  }
  const boundedBytes = fs.readFileSync(path.resolve(repositoryRoot, BOUNDED_CERTIFICATE));
  const bounded = JSON.parse(boundedBytes.toString("utf8"));
  assert.equal(bounded.native.totalHelperCalls, 33_024);
  assert.equal(bounded.formal.states, 1_792);
  assert.equal(bounded.scope.actionCreditGranted, false);
  const observationBytes = fs.readFileSync(path.resolve(repositoryRoot, BOUNDED_OBSERVATIONS));
  assert.equal(sha256(observationBytes), bounded.observations.sha256);
  if (sourceOverrides.size > 0) return { mutationOnly: true, equations };
  const callableByKey = new Map(surface.callables.map((row) => [row.key, row]));
  const equationByName = new Map(equations.map((row) => [row.id.split("#")[1], row]));
  const proofs = supportedSurfaceKeys.map((surfaceKey) => {
    const callable = callableByKey.get(surfaceKey);
    assert(callable !== undefined, `Current surface omitted '${surfaceKey}'.`);
    const equation = equationByName.get(surfaceKey.match(/#([^:]+)::/)?.[1]);
    assert(equation !== undefined);
    assert.deepEqual(callable.declaration, equation.implementation);
    return { surfaceKey, signatureHash: callable.signatureHash, declaration: callable.declaration, equationId: equation.id, termSha256: equation.termSha256 };
  });
  const inputs = [
    EXPECTED_FILE,
    "experiments/tla-conformance/migration-r5/traceability-value-family.mjs",
    BOUNDED_CERTIFICATE,
    BOUNDED_OBSERVATIONS,
    "src/traceability.ts",
    "src/traceability-replay.ts",
    "src/model.ts",
    "src/ordering.ts",
  ].map((file) => ({ file, sha256: sha256(fs.readFileSync(path.resolve(repositoryRoot, file))) }));
  return {
    schemaVersion: 1,
    proofKind,
    surfaceDigest: surface.digest,
    allAdmittedInputs: true,
    sampledInputs: 0,
    domain: "All immutable plain InventoryTraceabilityState/relation/event records admitted by the public TypeScript shapes, with native Array/Map/Set/Object/JSON sorting and iteration semantics. The complete guards, ordering, iterative ancestry traversal, relation indexing, and ordered event rebuild equations are included.",
    inputs,
    independentSpecification: { file: EXPECTED_FILE, sha256: sha256(expectedText), executedProductionCode: false },
    dependencyEquations: equations
      .filter((equation) => [
        "src/model.ts#assertInventoryIdentity",
        "src/model.ts#inventoryTraceabilityNodeIdentity",
        "src/ordering.ts#compareInventoryIdentityText",
      ].includes(equation.id))
      .map((equation) => ({
        id: equation.id,
        declaration: equation.implementation,
        termSha256: equation.termSha256,
        publicCreditClaimed: false,
      })),
    boundedControl: { certificate: { file: BOUNDED_CERTIFICATE, sha256: sha256(boundedBytes) }, observations: { file: BOUNDED_OBSERVATIONS, sha256: sha256(observationBytes) }, helperCalls: 33_024, universalCredit: false },
    equations,
    proofs,
  };
}

/** Trusted shared-router entrypoint for re-deriving this exact whole family. */
export function buildFamilyArtifact(input) {
  return buildTraceabilityValueArtifact(input);
}
