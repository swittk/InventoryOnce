import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { canonicalJson, sha256, ts, nodeAtExactSpan, spanOf } from "../surface-bindings/lib/compiler-surface.mjs";
import { laws } from "./laws.mjs";

/** Reviewed V route identifier; no protocol/model candidate can enter this family. */
export const proofKind = "astra-authority-control-complete-values-v1";
/** Only these three pure exports have a complete value denotation in this certificate. */
export const supportedSurfaceKeys = Object.freeze(laws.map((law) => `export:.#${law.name}::call[0]`));
/** Exact owned directory, relative to the compiler root. */
export const directory = "experiments/tla-conformance/astra-authority-control-r8";
/** Transitive runtime values consumed by the three laws. */
const enumValues = new Map([
  ["InventoryAuthorityMode.Authoritative", "authoritative"],
  ["InventoryAuthorityActivationKind.LegacyCutover", "legacy-cutover"],
  ["InventoryAuthorityActivationKind.Greenfield", "greenfield"],
]);
/** Source/proof/compiler bytes needed to rederive the family, without unrelated native producers. */
const inputs = ["src/authority.ts", "src/authority-cutover.ts", `${directory}/family.mjs`, `${directory}/laws.mjs`,
  "experiments/tla-conformance/surface-bindings/lib/compiler-surface.mjs", "experiments/tla-conformance/throughput-r7/registered-value-family.mjs",
  "node_modules/typescript/package.json", "node_modules/typescript/lib/lib.es5.d.ts", "node_modules/typescript/lib/lib.es2022.error.d.ts", "package.json", "tsconfig.json"];

/** Resolve import aliases to the actual runtime declaration. */
function symbolAt(context, node) {
  const symbol = context.checker.getSymbolAtLocation(node);
  assert(symbol, `Unresolved runtime name ${node.getText()}`);
  return symbol.flags & ts.SymbolFlags.Alias ? context.checker.getAliasedSymbol(symbol) : symbol;
}

/** Require the exact native Error and enum sources; source spelling alone is not runtime identity. */
function runtimeValue(context, node, root) {
  const symbol = symbolAt(context, node);
  const declarations = symbol.declarations ?? [];
  assert(declarations.length > 0);
  if (node.getText() === "Error") {
    // ES2022 augments native Error with cause; both declarations must come from this exact installed compiler.
    const allowed = new Set(["lib.es5.d.ts", "lib.es2022.error.d.ts"].map((file) => fs.realpathSync(path.join(root, "node_modules/typescript/lib", file))));
    for (const declaration of declarations) assert(allowed.has(fs.realpathSync(declaration.getSourceFile().fileName)), "Shadowed Error");
    return { name: "Error", declarations: declarations.map((declaration) => spanOf(context, declaration)) };
  }
  assert.equal(declarations.length, 1);
  const declaration = declarations[0];
  assert(ts.isEnumMember(declaration) && declaration.initializer && ts.isStringLiteral(declaration.initializer), "Runtime value is not a literal enum member");
  assert.equal(path.relative(root, declaration.getSourceFile().fileName), "src/authority.ts");
  assert.equal(declaration.initializer.text, enumValues.get(node.getText()), "Enum semantic value changed");
  return { name: node.getText(), value: declaration.initializer.text, declaration: spanOf(context, declaration) };
}

/** Translate the entire supported syntax to terms; every unrecognized construct fails closed. */
export function sourceTerm(declaration, resolveRuntime) {
  assert(declaration.body && ts.isFunctionDeclaration(declaration));
  assert(!declaration.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword));
  /** Argument identities are alpha-normalized, without normalizing their order or defaults. */
  const parameters = declaration.parameters.map((parameter) => {
    assert(ts.isIdentifier(parameter.name) && !parameter.dotDotDotToken);
    return parameter.name.text;
  });
  /** Translate expressions without executing any application or production helper. */
  function expression(node) {
    if (ts.isParenthesizedExpression(node)) return expression(node.expression);
    if (ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) return ["literal", node.text];
    if (ts.isNumericLiteral(node)) return ["literal", Number(node.text)];
    if (ts.isIdentifier(node)) {
      const index = parameters.indexOf(node.text);
      assert(index >= 0, `Unproved free name ${node.text}`);
      return ["arg", index];
    }
    if (ts.isPropertyAccessExpression(node)) {
      if (enumValues.has(node.getText())) {
        resolveRuntime(node);
        return ["literal", enumValues.get(node.getText())];
      }
      return ["get", expression(node.expression), node.name.text];
    }
    if (ts.isBinaryExpression(node)) {
      const operator = node.operatorToken.getText();
      assert(["!==", "===", "<", "||"].includes(operator), `Unsupported operator ${operator}`);
      return [operator, expression(node.left), expression(node.right)];
    }
    if (ts.isNewExpression(node)) {
      assert(ts.isIdentifier(node.expression) && node.expression.text === "Error" && node.arguments?.length === 1, "Unproved constructor");
      resolveRuntime(node.expression);
      return ["error", expression(node.arguments[0])];
    }
    if (ts.isTemplateExpression(node)) return ["template", node.head.text, node.templateSpans.map((span) => [expression(span.expression), span.literal.text])];
    if (ts.isObjectLiteralExpression(node)) return ["record", node.properties.map((property) => {
      assert(ts.isPropertyAssignment(property) && ts.isIdentifier(property.name), "Unproved property/spread/getter");
      return [property.name.text, expression(property.initializer)];
    })];
    throw new Error(`Unproved expression ${ts.SyntaxKind[node.kind]}`);
  }
  /** Translate every statement, including full error text and implicit final undefined. */
  function statement(node) {
    if (ts.isIfStatement(node)) {
      assert(!node.elseStatement && ts.isBlock(node.thenStatement) && node.thenStatement.statements.length === 1);
      return ["if", expression(node.expression), statement(node.thenStatement.statements[0])];
    }
    if (ts.isThrowStatement(node)) return ["throw", expression(node.expression)];
    if (ts.isReturnStatement(node)) { assert(node.expression); return ["return", expression(node.expression)]; }
    throw new Error(`Unproved statement ${ts.SyntaxKind[node.kind]}`);
  }
  return [declaration.parameters.map((parameter) => parameter.initializer ? expression(parameter.initializer) : null), ...declaration.body.statements.map(statement)];
}

/** Rederive all guards, outputs, references, default values and transitive runtime identities. */
export function buildFamilyArtifact({ repositoryRoot, context, surface }) {
  const root = path.resolve(repositoryRoot);
  assert.equal(path.resolve(context.repositoryRoot), root);
  /** One independently declared law must join exactly one current compiler export. */
  const proofs = laws.map((law, index) => {
    const callable = surface.callables.find((candidate) => candidate.key === supportedSurfaceKeys[index]);
    assert(callable && callable.declaration.file === law.file);
    const source = context.program.getSourceFile(path.resolve(root, law.file));
    assert(source && sha256(source.text) === sha256(fs.readFileSync(path.resolve(root, law.file))), "Stale compiler source");
    const declaration = nodeAtExactSpan(source, callable.declaration.start.offset, callable.declaration.end.offset);
    assert(declaration && ts.isFunctionDeclaration(declaration) && declaration.name.text === law.name);
    assert.deepEqual(spanOf(context, declaration), callable.declaration);
    /** Exact runtime dependencies are collected only from the complete accepted syntax. */
    const dependencies = new Map();
    const term = sourceTerm(declaration, (node) => {
      const value = runtimeValue(context, node, root);
      dependencies.set(value.name, value);
    });
    assert.deepEqual(term, law.term, `Independent complete equation differs: ${law.name}`);
    return { surfaceKey: callable.key, signatureHash: callable.signatureHash, declaration: callable.declaration,
      relation: { kind: "EXACT_COMPILER_EXPORT", reachabilityPaths: callable.reachabilityPaths, symbolDeclarations: callable.symbolDeclarations },
      equation: law.term, runtimeValues: [...dependencies.values()], helperCalls: [] };
  });
  return { schemaVersion: 1, proofKind, mode: "V", surfaceDigest: surface.digest, sampledInputs: 0, allAdmittedInputs: true,
    domain: "All plain immutable authority records with published field types and native string/number values (including NaN, infinities and signed zero); all native mode strings and optional operation label. Native Error and standard property access, no replaced globals, proxies, accessors or concurrent mutation. No state-parser validation is assumed.",
    inputs: inputs.map((file) => ({ file, sha256: sha256(fs.readFileSync(path.resolve(root, file))) })), proofs };
}

/** A persisted certificate must equal a complete fresh derivation, even if an attacker re-signs it. */
export function verifyArtifact(input, recorded) {
  assert.equal(canonicalJson(recorded), canonicalJson(buildFamilyArtifact(input)), "Re-signed artifact differs from independent law");
}
