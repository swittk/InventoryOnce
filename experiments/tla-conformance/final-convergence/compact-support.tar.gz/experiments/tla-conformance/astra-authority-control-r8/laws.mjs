/** Independent terms: p0 is the authority state, or the actual mode for the mode guard. */
const state = (field) => ["get", ["arg", 0], field];
/** A native string length read has no application helper dependency. */
const length = (field) => ["get", state(field), "length"];
/** Strict comparison retains JavaScript number behavior, including NaN and negative zero. */
const compare = (operator, left, right) => [operator, left, ["literal", right]];
/** Rejection guards preserve left-to-right short-circuit evaluation order. */
const any = (...terms) => terms.reduce((left, right) => ["||", left, right]);
/** Return-field order and reference identity are part of the complete result equation. */
const fields = (...names) => names.map((name) => [name, state(name)]);
/** Complete independent laws; these terms are never evaluated from a sampled production result. */
export const laws = [
  {
    /** Exact public function and source module. */
    name: "inventoryAuthorityCutoverResult", file: "src/authority-cutover.ts",
    /** Full parameter/default, guard, error and returned-record equations. */
    term: [
      [null],
      ["if", any(compare("!==", state("activationKind"), "legacy-cutover"), ...["cutoverAuthorizationId", "sourcePlanDigest", "sourceCatalogDigest", "targetWorldRoot"].map((field) => compare("===", length(field), 0)), compare("<", state("targetWorldRevision"), 0)),
        ["throw", ["error", ["literal", "InventoryOnce authoritative state is missing cutover evidence."]]]],
      ["return", ["record", [["authority", ["arg", 0]], ["authorizationId", state("cutoverAuthorizationId")], ...fields("sourcePlanDigest", "sourceCatalogDigest", "targetWorldRoot", "targetWorldRevision")]]],
    ],
  },
  {
    /** Exact public function and source module. */
    name: "inventoryAuthorityGreenfieldResult", file: "src/authority-cutover.ts",
    /** Greenfield rejects wrong mode/kind, missing evidence, nonzero revision and legacy residue. */
    term: [
      [null],
      ["if", any(compare("!==", state("mode"), "authoritative"), compare("!==", state("activationKind"), "greenfield"), ...["greenfieldAuthorizationId", "adapterCertificationDigest", "targetWorldRoot"].map((field) => compare("===", length(field), 0)), compare("!==", state("targetWorldRevision"), 0), ...["sourceRoot", "sourcePlanDigest", "sourceCatalogDigest", "fenceToken"].map((field) => compare("!==", length(field), 0))),
        ["throw", ["error", ["literal", "InventoryOnce authoritative state does not contain valid greenfield evidence."]]]],
      ["return", ["record", [["authority", ["arg", 0]], ["authorizationId", state("greenfieldAuthorizationId")], ["targetWorldRoot", state("targetWorldRoot")], ["targetWorldRevision", ["literal", 0]]]]],
    ],
  },
  {
    /** Exact public function and source module. */
    name: "requireInventoryAuthorityMode", file: "src/authority.ts",
    /** The optional operation label defaults only for undefined, as in a native default parameter. */
    term: [
      [null, null, ["literal", "Inventory operation"]],
      ["if", ["!==", ["arg", 0], ["arg", 1]], ["throw", ["error", ["template", "", [[ ["arg", 2], " requires authority mode '"], [["arg", 1], "', current mode is '"], [["arg", 0], "'."]]]]]],
    ],
  },
];
