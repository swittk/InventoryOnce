import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { canonicalJson, discoverCompilerSurface, sha256, ts } from "../../surface-bindings/lib/compiler-surface.mjs";
import { loadEvidenceCompilerContext } from "../../surface-bindings/lib/binding-checker.mjs";
import { buildFamilyArtifact as buildEventValues, proofKind as eventProofKind } from "../../quantity-values-r7/event-values/registered-family-adapter.mjs";
import { buildValueContractArtifact } from "../../value-contracts/surface-binding.mjs";

export const proofKind="catalog-publication-event-complete-value-v1";
export const supportedSurfaceKeys=Object.freeze(["export:./kernel#createInventoryCatalogPublicationEvent::call[0]"]);
const EXPECTED="experiments/tla-conformance/catalog-public-lifecycle7-r9/publication-core-r10/equations.expected.ts.txt";
const EVENT_HELPER="src/commands.ts#createMovementEvent";
const CATALOG_SNAPSHOT="export:.#inventoryCatalogSnapshot::call[0]";

function source(root,file,override){const abs=path.resolve(root,file);return ts.createSourceFile(abs,override??fs.readFileSync(abs,"utf8"),ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);}
function findFunction(sf,name){const rows=sf.statements.filter((row)=>ts.isFunctionDeclaration(row)&&row.name?.text===name);assert.equal(rows.length,1,`Expected one function ${name}`);assert(rows[0].body!==undefined);return rows[0];}
function runtimeTerm(node,sf){let text=node.getText(sf).replace(/^export\s+/u,"");const name=node.name?.text;assert(name!==undefined);text=text.replace(new RegExp(`^(?:async\\s+)?function\\s+${name}\\b`),(match)=>match.replace(name,"__proof"));const emitted=ts.transpileModule(text,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.None,removeComments:true}}).outputText.trim();const scanner=ts.createScanner(ts.ScriptTarget.ES2022,true,ts.LanguageVariant.Standard,emitted),tokens=[];for(;;){const kind=scanner.scan();if(kind===ts.SyntaxKind.EndOfFileToken)break;tokens.push([ts.SyntaxKind[kind],scanner.getTokenText()]);}return tokens;}
function enumValue(sf,name,member){const rows=sf.statements.filter((row)=>ts.isEnumDeclaration(row)&&row.name.text===name);assert.equal(rows.length,1);const found=rows[0].members.find((row)=>row.name.getText(sf)===member);assert(found!==undefined&&ts.isStringLiteral(found.initializer));return found.initializer.text;}
function addInput(root,map,file){if(map.has(file))return;map.set(file,{file,sha256:sha256(fs.readFileSync(path.resolve(root,file)))});}

export function sourceEquationReceipt(root,sourceOverrides=new Map()){
 const actualSource=source(root,"src/commands.ts",sourceOverrides.get("src/commands.ts"));
 const expectedSource=source(root,EXPECTED);
 const actual=runtimeTerm(findFunction(actualSource,"createInventoryCatalogPublicationEvent"),actualSource);
 const expected=runtimeTerm(findFunction(expectedSource,"expectedCreateInventoryCatalogPublicationEvent"),expectedSource);
 assert.deepEqual(actual,expected,"Catalog publication event complete source equation drifted");
 const events=source(root,"src/events.ts",sourceOverrides.get("src/events.ts"));
 const kind=enumValue(events,"InventoryEventKind","CatalogPublication");
 assert.equal(kind,"catalog-publication","InventoryEventKind.CatalogPublication drifted");
 return{normalizedTermSha256:sha256(canonicalJson(actual)),eventKind:kind,completeBranchesChecked:true,allValidatedInputs:true,sampledInputs:0};
}
function eventReceipt(root,context,surface,override){const current=buildEventValues({repositoryRoot:root,context,surface});let artifact=override?override(structuredClone(current)):current;assert.deepEqual(artifact,current,"Event family dependency drifted");assert.equal(artifact.proofKind,eventProofKind);assert.equal(artifact.sampledInputs,0);const helper=artifact.semanticCore?.helperEquations?.find((row)=>row.id===EVENT_HELPER);assert(helper!==undefined,"Event family lost createMovementEvent helper equation");assert.deepEqual(helper.dependencies,["src/commands.ts#inventoryEventIdForOperation","src/events.ts#defineInventoryEvent"]);return{artifact,receipt:{proofKind:artifact.proofKind,certificateId:artifact.certificateId,helperId:helper.id,equationSha256:helper.equationSha256,declaration:helper.declaration,dependencies:helper.dependencies}};}
function catalogReceipt(root,context,surface,override){const current=buildValueContractArtifact({repositoryRoot:root,context,surface});let artifact=override?override(structuredClone(current)):current;assert.deepEqual(artifact,current,"Catalog snapshot dependency drifted");assert.equal(artifact.proofKind,"independent-closed-return-equations-v1");const proof=artifact.proofs.find((row)=>row.surfaceKey===CATALOG_SNAPSHOT);assert(proof!==undefined,"Value-contract family lost inventoryCatalogSnapshot proof");const callable=surface.callables.find((row)=>row.key===CATALOG_SNAPSHOT);assert(callable!==undefined);assert.equal(proof.signatureHash,callable.signatureHash);assert.deepEqual(proof.declaration,callable.declaration);return{artifact,receipt:{proofKind:artifact.proofKind,surfaceKey:CATALOG_SNAPSHOT,signatureHash:proof.signatureHash,declaration:proof.declaration,semantics:proof.semantics}};}
function semanticInputs(root,event,catalog){const map=new Map();for(const file of [EXPECTED,"experiments/tla-conformance/catalog-public-lifecycle7-r9/publication-core-r10/value-family.mjs","src/commands.ts","src/events.ts","node_modules/typescript/package.json"])addInput(root,map,file);for(const family of [event.artifact,catalog.artifact])for(const input of (family.inputs??family.producers??[]))addInput(root,map,input.file);return[...map.values()].sort((a,b)=>a.file<b.file?-1:a.file>b.file?1:0);}
export function buildFamilyArtifact({repositoryRoot=process.cwd(),context=loadEvidenceCompilerContext(repositoryRoot,[]),surface=discoverCompilerSurface(repositoryRoot),sourceOverrides=new Map(),eventArtifactOverride,catalogArtifactOverride}={}){
 const equation=sourceEquationReceipt(repositoryRoot,sourceOverrides);if(sourceOverrides.size>0)return{mutationControlAccepted:false,equation};
 const event=eventReceipt(repositoryRoot,context,surface,eventArtifactOverride),catalog=catalogReceipt(repositoryRoot,context,surface,catalogArtifactOverride),callable=surface.callables.find((row)=>row.key===supportedSurfaceKeys[0]);assert(callable!==undefined);
 return{schemaVersion:1,proofKind,surfaceDigest:surface.digest,domain:"Every typed CreateInventoryCatalogPublicationInput. The complete public wrapper equation delegates to the independently rederived Event45 createMovementEvent/defineInventoryEvent closure with exact CatalogPublication enum semantics and the current complete inventoryCatalogSnapshot value proof; there is no sampled runtime domain.",allAdmittedInputs:true,sampledInputs:0,inputs:semanticInputs(repositoryRoot,event,catalog),proofs:[{surfaceKey:supportedSurfaceKeys[0],signatureHash:callable.signatureHash,declaration:callable.declaration,semantics:{completeExpectedTerm:equation,eventMovementClosure:event.receipt,catalogSnapshot:catalog.receipt}}]};
}
