/** Stable discriminator for the complete transfer/correction value family. */
export const TRANSFER_CORRECTION_VALUE_PROOF_KIND =
  "inventoryonce-transfer-correction-complete-source-equations-v2";

/** Frozen production revision whose public semantics this candidate checks. */
export const SOURCE_BASE = "2eea09471b3bf8fcb61f38256e1c6a362149dad4";

/** Committed strict-271 receipt that independently anchors all reused dependencies. */
export const CURRENT_REGISTRATION_RECEIPT_SHA256 =
  "373b58894e134f8a4a4ba3bf22a54919842fa80bae5f0917c439f28376d0d201";

/** Exact eleven public rows rejected because the earlier evidence used scalar fixtures. */
export const ASSIGNED_SURFACE_KEYS = Object.freeze([
  "export:./kernel#createInventoryCorrectionEvent::call[0]",
  "export:./kernel#createInventoryReclassificationEvent::call[0]",
  "export:./kernel#createInventoryReclassificationManyEvent::call[0]",
  "export:./kernel#createInventoryTransferDispatchEvent::call[0]",
  "export:./kernel#createInventoryTransferEvent::call[0]",
  "export:./kernel#createInventoryTransferManyEvent::call[0]",
  "export:./kernel#createInventoryTransferPrepareEvent::call[0]",
  "export:./kernel#createInventoryTransferReceiveEvent::call[0]",
  "export:./kernel#createInventoryTransferReleaseEvent::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.reclassifyMany::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.transfer::call[0]",
]);

/** Concrete runtime declaration implementing each public surface equation. */
export const IMPLEMENTATION_BY_SURFACE_KEY = Object.freeze({
  "export:./kernel#createInventoryCorrectionEvent::call[0]":
    "src/corrections.ts#createInventoryCorrectionEvent",
  "export:./kernel#createInventoryReclassificationEvent::call[0]":
    "src/commands.ts#createInventoryReclassificationEvent",
  "export:./kernel#createInventoryReclassificationManyEvent::call[0]":
    "src/commands.ts#createInventoryReclassificationManyEvent",
  "export:./kernel#createInventoryTransferDispatchEvent::call[0]":
    "src/transfers.ts#createInventoryTransferDispatchEvent",
  "export:./kernel#createInventoryTransferEvent::call[0]":
    "src/commands.ts#createInventoryTransferEvent",
  "export:./kernel#createInventoryTransferManyEvent::call[0]":
    "src/commands.ts#createInventoryTransferManyEvent",
  "export:./kernel#createInventoryTransferPrepareEvent::call[0]":
    "src/transfers.ts#createInventoryTransferPrepareEvent",
  "export:./kernel#createInventoryTransferReceiveEvent::call[0]":
    "src/transfers.ts#createInventoryTransferReceiveEvent",
  "export:./kernel#createInventoryTransferReleaseEvent::call[0]":
    "src/transfers.ts#createInventoryTransferReleaseEvent",
  "type:src/facade.ts#InventoryOnceReplacementPlans.reclassifyMany::call[0]":
    "src/facade.ts#InventoryOnceReplacementPlansImplementation.reclassifyMany",
  "type:src/facade.ts#InventoryOnceReplacementPlans.transfer::call[0]":
    "src/facade.ts#InventoryOnceReplacementPlansImplementation.transfer",
});

/** Transfer/correction-specific declarations checked against independently stored terms. */
export const LOCAL_EQUATION_IDS = Object.freeze([
  "src/commands.ts#createInventoryReclassificationEvent",
  "src/commands.ts#createInventoryReclassificationManyEvent",
  "src/commands.ts#createInventoryTransferEvent",
  "src/commands.ts#createInventoryTransferManyEvent",
  "src/commands.ts#pairwiseReclassificationProvenanceTransfers",
  "src/corrections.ts#compareCorrectionStockEffect",
  "src/corrections.ts#compareCorrectionTraceabilityChange",
  "src/corrections.ts#createCorrectionPositiveLayerProvenanceOverrides",
  "src/corrections.ts#createCorrectionStockEffects",
  "src/corrections.ts#createCorrectionTraceabilityChanges",
  "src/corrections.ts#createInventoryCorrectionEvent",
  "src/corrections.ts#projectHistoryWithReplacement",
  "src/corrections.ts#reconcileHypotheticalTraceabilityChanges",
  "src/facade.ts#InventoryOnceReplacementPlanImplementation.constructor",
  "src/facade.ts#InventoryOnceReplacementPlansImplementation.constructor",
  "src/facade.ts#InventoryOnceReplacementPlansImplementation.reclassifyMany",
  "src/facade.ts#InventoryOnceReplacementPlansImplementation.transfer",
  "src/facade.ts#InventoryOnceStockImplementation.correct",
  "src/facade.ts#InventoryOnceTransfersImplementation.find",
  "src/facade.ts#commitInventoryTransferOperation",
  "src/facade.ts#createInventoryOnceEventResult",
  "src/facade.ts#readReplacementEventDraft",
  "src/facade.ts#requirePublishedInventoryTransfer",
  "src/projection.ts#applyIndexedIdentityMutations",
  "src/projection.ts#applyInventoryCommittedEventInternal",
  "src/projection.ts#captureConservedPositiveLayerStarts",
  "src/projection.ts#compareCommittedEventSequence",
  "src/projection.ts#emptyInventoryProjectionState",
  "src/projection.ts#inventoryContainerDefinitionFingerprint",
  "src/projection.ts#inventoryEventsInRecordSequence",
  "src/projection.ts#inventoryLotDefinitionFingerprint",
  "src/projection.ts#projectInventoryEvents",
  "src/projection.ts#quantityIsPositive",
  "src/projection.ts#recordIndexedIdentityMutation",
  "src/projection.ts#refreshTouchedSerialIndexes",
  "src/projection.ts#registerTouchedSerialPosition",
  "src/traceability-replay.ts#assertNoGenealogyPath",
  "src/traceability-replay.ts#projectInventoryTraceabilityEvents",
  "src/traceability-replay.ts#removeIndexedRelation",
  "src/traceability-replay.ts#validateAndIndexAddition",
  "src/traceability.ts#applyInventoryTraceabilityChanges",
  "src/traceability.ts#assertContainmentHasOneParentAndNoCycles",
  "src/traceability.ts#assertGenealogyHasNoCycles",
  "src/traceability.ts#assertNoGenealogyCycleFrom",
  "src/traceability.ts#buildContainmentChildContainerIndex",
  "src/traceability.ts#emptyInventoryTraceabilityState",
  "src/traceability.ts#inventoryTraceabilityRelationIdentity",
  "src/transfers.ts#applyInventoryTransferLifecycleEvent",
  "src/transfers.ts#assertDistinctLifecyclePositions",
  "src/transfers.ts#assertDistinctPositions",
  "src/transfers.ts#assertReceiptPackaging",
  "src/transfers.ts#assertTransferEventEffects",
  "src/transfers.ts#assertTransferNegativeEffectsHavePhysicalCapacity",
  "src/transfers.ts#assertUniqueTransferLineIds",
  "src/transfers.ts#combineExpectedEffects",
  "src/transfers.ts#createInventoryTransferDispatchEvent",
  "src/transfers.ts#createInventoryTransferPrepareEvent",
  "src/transfers.ts#createInventoryTransferReceiveEvent",
  "src/transfers.ts#createInventoryTransferReleaseEvent",
  "src/transfers.ts#dispatchEffects",
  "src/transfers.ts#fullRemainingReceiptLines",
  "src/transfers.ts#inventoryTransferDestinationPosition",
  "src/transfers.ts#inventoryTransferPreparedPosition",
  "src/transfers.ts#inventoryTransferRemainingMeasurements",
  "src/transfers.ts#inventoryTransferTransitPosition",
  "src/transfers.ts#prepareEffects",
  "src/transfers.ts#receiveEffects",
  "src/transfers.ts#releaseEffects",
  "src/transfers.ts#requireTransferLine",
  "src/transfers.ts#resolveRequestedReceiptLines",
  "src/transfers.ts#resolveTransferPrepareLine",
  "src/transfers.ts#transferAmountEvidence",
  "src/transfers.ts#transferCommandItem",
  "src/transfers.ts#transferEffect",
  "src/transfers.ts#transferLifecycleEvent",
  "src/transfers.ts#transferPositionWithPackaging",
]);

/** Private equations checked for result/read behavior without taking another surface credit. */
export const STRENGTHENING_EQUATION_IDS = Object.freeze([
  "src/facade.ts#InventoryOnceReplacementPlansImplementation.constructor",
  "src/facade.ts#InventoryOnceStockImplementation.correct",
  "src/facade.ts#InventoryOnceTransfersImplementation.find",
  "src/facade.ts#commitInventoryTransferOperation",
  "src/facade.ts#createInventoryOnceEventResult",
  "src/facade.ts#readReplacementEventDraft",
  "src/facade.ts#requirePublishedInventoryTransfer",
]);

/** Source files containing locally checked equations. */
export const LOCAL_SOURCE_FILES = Object.freeze([
  "src/commands.ts",
  "src/corrections.ts",
  "src/facade.ts",
  "src/projection.ts",
  "src/traceability-replay.ts",
  "src/traceability.ts",
  "src/transfers.ts",
]);

/** Local runtime values whose exact definitions affect the checked equations. */
export const LOCAL_SUPPORTING_VALUE_IDS = Object.freeze([
  "src/facade.ts#replacementEventDrafts",
  "src/projection.ts#InventoryDeficitPolicy",
  "src/transfers.ts#InventoryTransferStatus",
]);

/** Existing execution artifacts reused without regenerating their native graphs. */
export const REUSED_EXECUTION_FILES = Object.freeze([
  "experiments/tla-conformance/transfer-surface-r6/artifacts/CorrectionHistory/surface-execution-v2.json",
  "experiments/tla-conformance/transfer-surface-r6/artifacts/DurableTransferRefinement/surface-execution-v2.json",
  "experiments/tla-conformance/transfer-surface-r6/artifacts/TransferLifecycle/surface-execution-v2.json",
]);

/** Complete non-fixture input domain quantified by the independent equations. */
export const FAMILY_DOMAIN = Object.freeze({
  id: "ALL_VALIDATED_TRANSFER_CORRECTION_EVENT_VALUES_V2",
  values:
    "Every finite immutable plain record/array satisfying the published input types and every success or rejection guard in the independent equations; no fixture or sampled subset is used.",
  history:
    "Every internally valid committed projection and retained correction chain accepted by projectInventoryEvents, including omission, replacement, prior correction, definition, traceability, positive-layer provenance, and deficit-policy branches.",
  transfers:
    "Every internally valid prepare, dispatch, partial/full receive, and release value, including optional custodian, package, lot, container, owner, status, metadata, and multi-line branches.",
  mutation:
    "Inputs and published state are immutable for the duration of a call; only fresh local arrays, maps, sets, records, and opaque replacement-plan registrations may be mutated.",
  dependencies:
    "Quantity, measurement, identity, catalog, and common event-construction operations mean the exact separately registered family equations named by this certificate.",
  excluded:
    "Proxies, accessors, subclasses, monkey-patched built-ins, structurally forged catalogs/plans, cyclic values, concurrent input mutation, clocks, storage I/O, and application callbacks other than the separately checked correction wrapper are outside this V domain.",
});

/** Independent semantic laws grouped by the physical fact they construct or replay. */
export const FAMILY_LAWS = Object.freeze([
  Object.freeze({
    id: "atomic-location-and-reclassification-values-v2",
    equation:
      "Single and multi-line transfer/reclassification constructors resolve exact amounts, preserve every unmodified stock identity, produce paired negative/positive effects, aggregate lot/container definitions deterministically, reject empty or transfer-bound sources, and attach conserved positive-layer provenance only for exact one-to-one moves.",
  }),
  Object.freeze({
    id: "transfer-lifecycle-values-v2",
    equation:
      "Prepare reserves exact source measurements under one transfer identity; dispatch moves all prepared remainder to transit; receive accepts each named line at most once, never beyond remaining measurements, enforces package evidence, and moves to the exact destination; release restores every prepared line. Each branch emits its exact lifecycle action, effects, evidence, optional parties, and metadata.",
  }),
  Object.freeze({
    id: "append-only-correction-values-v2",
    equation:
      "A correction rejects invalid roots/times/replacements, replays retained history with the chosen omission or replacement, computes exact sorted stock/provenance/traceability deltas from current to desired truth, retains replacement definitions, and emits one append-only Correction event with explicit reason and frozen optional parties/metadata.",
  }),
  Object.freeze({
    id: "opaque-replacement-and-result-values-v2",
    equation:
      "Transfer and reclassifyMany replacement methods inject the bound catalog and synthetic operation identity, return only privately registered plans, and the correction wrapper rejects forged plans. Event/transfer result helpers resolve exact receipt identities from the published world and fail closed for missing events/transfers while preserving the coordinator replay flag.",
  }),
]);

/** Return the family law that governs one local equation. */
export function lawIdForEquation(equationId) {
  if (equationId.startsWith("src/corrections.ts#")) {
    return "append-only-correction-values-v2";
  }
  if (equationId.startsWith("src/transfers.ts#")) {
    return "transfer-lifecycle-values-v2";
  }
  if (equationId.startsWith("src/facade.ts#")) {
    return "opaque-replacement-and-result-values-v2";
  }
  return "atomic-location-and-reclassification-values-v2";
}
