import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  canonicalJson,
  compareCodeUnits,
  sha256,
  spanOf,
  ts,
} from "../../surface-bindings/lib/compiler-surface.mjs";
import {
  ASSIGNED_SURFACE_KEYS,
  FAMILY_DOMAIN,
  FAMILY_LAWS,
  IMPLEMENTATION_BY_SURFACE_KEY,
  LOCAL_EQUATION_IDS,
  LOCAL_SOURCE_FILES,
  LOCAL_SUPPORTING_VALUE_IDS,
  REUSED_EXECUTION_FILES,
  SOURCE_BASE,
  STRENGTHENING_EQUATION_IDS,
  CURRENT_REGISTRATION_RECEIPT_SHA256,
  TRANSFER_CORRECTION_VALUE_PROOF_KIND,
  lawIdForEquation,
} from "./contracts.mjs";

/** Directory containing this whole-family implementation and independent terms. */
const familyDirectory = path.dirname(fileURLToPath(import.meta.url));

/** Expected equation file for each production module owned by this family. */
const expectedFileBySource = new Map(
  LOCAL_SOURCE_FILES.map((file) => [
    file,
    path.join(familyDirectory, "expected", `${path.basename(file, ".ts")}.expected.ts.txt`),
  ])
);

/** Files whose bytes define the local semantic checker rather than production behavior. */
const producerFiles = Object.freeze([
  "experiments/tla-conformance/transfer-surface-r6/source-equations-r7/contracts.mjs",
  "experiments/tla-conformance/transfer-surface-r6/source-equations-r7/dependency-manifest.json",
  "experiments/tla-conformance/transfer-surface-r6/source-equations-r7/family.mjs",
  "experiments/tla-conformance/transfer-surface-r6/source-equations-r7/red-before.json",
  "experiments/tla-conformance/transfer-surface-r6/source-equations-r7/source-base-manifest.json",
  "experiments/tla-conformance/transfer-surface-r6/source-equations-r7/current-registration-receipt.json",
  "experiments/tla-conformance/transfer-surface-r6/value-equation-candidates.json",
  ...[...expectedFileBySource.values()].map((file) =>
    path.relative(path.resolve(familyDirectory, "../../../.."), file).replaceAll("\\", "/")
  ),
  "experiments/tla-conformance/surface-bindings/lib/compiler-surface.mjs",
  "node_modules/typescript/package.json",
  "package.json",
  "tsconfig.json",
]);

/** Reuse one fully derived family only inside an unchanged compiler pass. */
const passCache = new WeakMap();

/** Return a repository-relative portable file identity. */
function relativePath(repositoryRoot, fileName) {
  return path.relative(repositoryRoot, fileName).replaceAll("\\", "/");
}

/** Parse one independent equation source without importing production values. */
function parseSource(fileName, sourceText) {
  const source = ts.createSourceFile(
    fileName,
    sourceText,
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TS
  );
  assert.equal(source.parseDiagnostics.length, 0, `Cannot parse independent equations '${fileName}'.`);
  return source;
}

/** Return one concrete function, method, or constructor by stable equation identity. */
function findCallable(sourceByFile, equationId) {
  const separator = equationId.indexOf("#");
  assert(separator > 0, `Malformed equation identity '${equationId}'.`);
  const file = equationId.slice(0, separator);
  const qualifiedName = equationId.slice(separator + 1);
  const source = sourceByFile.get(file);
  assert(source !== undefined, `Missing equation source '${file}'.`);
  const pieces = qualifiedName.split(".");
  if (pieces.length === 1) {
    const matches = source.statements.filter(
      (statement) =>
        ts.isFunctionDeclaration(statement) &&
        statement.name?.text === qualifiedName &&
        statement.body !== undefined
    );
    assert.equal(matches.length, 1, `Expected one function '${equationId}'.`);
    return matches[0];
  }
  assert.equal(pieces.length, 2, `Unsupported qualified equation '${equationId}'.`);
  const [className, memberName] = pieces;
  const owners = source.statements.filter(
    (statement) => ts.isClassDeclaration(statement) && statement.name?.text === className
  );
  assert.equal(owners.length, 1, `Expected one class '${className}' in '${file}'.`);
  const matches = owners[0].members.filter((member) => {
    if (memberName === "constructor") return ts.isConstructorDeclaration(member);
    return (
      ts.isMethodDeclaration(member) &&
      ts.isIdentifier(member.name) &&
      member.name.text === memberName &&
      member.body !== undefined
    );
  });
  assert.equal(matches.length, 1, `Expected one member '${equationId}'.`);
  return matches[0];
}

/** Return one top-level enum or constant by stable supporting-value identity. */
function findSupportingValue(sourceByFile, valueId) {
  const separator = valueId.indexOf("#");
  assert(separator > 0, `Malformed supporting-value identity '${valueId}'.`);
  const file = valueId.slice(0, separator);
  const name = valueId.slice(separator + 1);
  const source = sourceByFile.get(file);
  assert(source !== undefined, `Missing supporting-value source '${file}'.`);
  const matches = source.statements.filter((statement) => {
    if (ts.isEnumDeclaration(statement)) return statement.name.text === name;
    if (!ts.isVariableStatement(statement)) return false;
    return statement.declarationList.declarations.some(
      (declaration) => ts.isIdentifier(declaration.name) && declaration.name.text === name
    );
  });
  assert.equal(matches.length, 1, `Expected one supporting value '${valueId}'.`);
  if (ts.isEnumDeclaration(matches[0])) return matches[0];
  const declaration = matches[0].declarationList.declarations.find(
    (candidate) => ts.isIdentifier(candidate.name) && candidate.name.text === name
  );
  assert(declaration !== undefined);
  return declaration;
}

/** Return a stable source identity for one concrete compiler-resolved callable. */
function declarationId(repositoryRoot, declaration) {
  const file = relativePath(repositoryRoot, declaration.getSourceFile().fileName);
  if (ts.isConstructorDeclaration(declaration)) {
    const owner = declaration.parent.name?.getText(declaration.getSourceFile());
    assert(owner !== undefined, "Certified constructor needs a named class.");
    return `${file}#${owner}.constructor`;
  }
  const name = declaration.name?.getText(declaration.getSourceFile());
  assert(name !== undefined, "Certified source callable needs a stable name.");
  if (ts.isMethodDeclaration(declaration) || ts.isGetAccessorDeclaration(declaration)) {
    const owner = declaration.parent.name?.getText(declaration.getSourceFile());
    assert(owner !== undefined, "Certified method needs a named class.");
    return `${file}#${owner}.${name}`;
  }
  return `${file}#${name}`;
}

/** Return whether a source declaration is already represented inside one checked body. */
function declarationIsInside(declaration, owner) {
  let current = declaration;
  while (current !== undefined) {
    if (current === owner) return true;
    current = current.parent;
  }
  return false;
}

/** Convert one syntax node to a bounded JSON term with no compiler objects retained. */
function normalizedSyntax(node, source) {
  const children = node.getChildren(source);
  if (children.length === 0) {
    return [ts.SyntaxKind[node.kind], node.getText(source)];
  }
  return [
    ts.SyntaxKind[node.kind],
    children.map((child) => normalizedSyntax(child, source)),
  ];
}

/** Normalize every runtime-relevant part of one complete callable equation. */
export function normalizeTransferCorrectionCallable(declaration) {
  assert(declaration.body !== undefined, "A source equation needs one concrete body.");
  const source = declaration.getSourceFile();
  return {
    async:
      declaration.modifiers?.some(
        (modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword
      ) ?? false,
    generator: declaration.asteriskToken !== undefined,
    parameters: declaration.parameters.map((parameter) => ({
      name: normalizedSyntax(parameter.name, source),
      rest: parameter.dotDotDotToken !== undefined,
      optional: parameter.questionToken !== undefined,
      initializer:
        parameter.initializer === undefined
          ? null
          : normalizedSyntax(parameter.initializer, source),
    })),
    body: normalizedSyntax(declaration.body, source),
  };
}

/** Normalize one enum or constant whose runtime value changes an equation. */
function normalizeSupportingValue(declaration) {
  const source = declaration.getSourceFile();
  if (ts.isEnumDeclaration(declaration)) {
    return [
      "enum",
      declaration.members.map((member) => [
        member.name.getText(source),
        member.initializer === undefined
          ? null
          : normalizedSyntax(member.initializer, source),
      ]),
    ];
  }
  assert(ts.isVariableDeclaration(declaration));
  assert(declaration.initializer !== undefined, "Supporting constant needs an initializer.");
  const declarationList = declaration.parent;
  assert(ts.isVariableDeclarationList(declarationList));
  return [
    (declarationList.flags & ts.NodeFlags.Const) !== 0 ? "const" : "mutable",
    normalizedSyntax(declaration.initializer, source),
  ];
}

/** Resolve a TypeScript alias to its concrete source symbol. */
function resolvedSymbol(context, node) {
  let symbol = context.checker.getSymbolAtLocation(node);
  if (symbol !== undefined && (symbol.flags & ts.SymbolFlags.Alias) !== 0) {
    symbol = context.checker.getAliasedSymbol(symbol);
  }
  return symbol;
}

/** Return a source callable body from a resolved symbol when one exists. */
function sourceCallableFromSymbol(symbol) {
  const declarations = (symbol?.declarations ?? []).filter(
    (declaration) =>
      !declaration.getSourceFile().isDeclarationFile &&
      (ts.isFunctionDeclaration(declaration) ||
        ts.isMethodDeclaration(declaration) ||
        ts.isConstructorDeclaration(declaration) ||
        ts.isGetAccessorDeclaration(declaration)) &&
      declaration.body !== undefined
  );
  if (declarations.length === 0) return undefined;
  assert.equal(declarations.length, 1, "Source callable has ambiguous runtime bodies.");
  return declarations[0];
}

/** Return the body declaration selected by one compiler-resolved call/new expression. */
function sourceCallableFromCall(context, node) {
  const declaration = context.checker.getResolvedSignature(node)?.declaration;
  if (
    declaration === undefined ||
    declaration.getSourceFile().isDeclarationFile ||
    declaration.body === undefined
  ) {
    return undefined;
  }
  if (
    ts.isFunctionDeclaration(declaration) ||
    ts.isMethodDeclaration(declaration) ||
    ts.isConstructorDeclaration(declaration) ||
    ts.isGetAccessorDeclaration(declaration)
  ) {
    return declaration;
  }
  return undefined;
}

/** Return a readable ambient operation identity without serializing compiler nodes. */
function ambientOperation(node, declaration) {
  const source = declaration.getSourceFile();
  const owner = declaration.parent.name?.getText(source);
  const name = declaration.name?.getText(source) ?? "<anonymous>";
  const expression = node.expression;
  if (ts.isIdentifier(expression)) return expression.text;
  if (ts.isPropertyAccessExpression(expression)) {
    if (ts.isIdentifier(expression.expression)) {
      return `${expression.expression.text}.${expression.name.text}`;
    }
    return `${owner ?? "ambient"}.${expression.name.text}`;
  }
  return `${owner ?? "ambient"}.${name}`;
}

/** Build dependency indexes while preserving registered versus pending status. */
function dependencyIndex(manifest) {
  assert.equal(manifest.schemaVersion, 1, "Dependency manifest schema changed.");
  assert.equal(manifest.sourceBase, SOURCE_BASE);
  assert.equal(manifest.families.length, 4);
  assert.equal(
    canonicalJson(manifest.families.map((family) => family.proofKind).sort(compareCodeUnits)),
    canonicalJson([
      "independent-catalog-snapshot-closed-equations-v1",
      "independent-identity-values-closed-equations-v1",
      "inventoryonce-event-replacement-complete-source-equations-v1",
      "inventoryonce-quantity-measurement-complete-source-equations-v1",
    ])
  );
  const equations = new Map();
  const supportingValues = new Map();
  for (const family of manifest.families) {
    assert.equal(typeof family.proofKind, "string");
    assert.match(family.artifactSha256, /^[0-9a-f]{64}$/u);
    assert.equal(typeof family.registered, "boolean");
    assert.equal(
      family.status,
      family.registered ? "REGISTERED" : "PENDING_REGISTERED_FAMILY"
    );
    assert(Array.isArray(family.equations) && family.equations.length > 0);
    for (const equation of family.equations) {
      assert.equal(typeof equation.id, "string");
      assert.match(equation.sourceHash, /^[0-9a-f]{64}$/u);
      assert(!equations.has(equation.id), `Dependency equation repeated: ${equation.id}`);
      equations.set(equation.id, {
        proofKind: family.proofKind,
        certificateId: family.certificateId,
        artifactSha256: family.artifactSha256,
        sourceHash: equation.sourceHash,
        registered: family.registered,
      });
    }
    for (const value of family.supportingValues ?? []) {
      assert.equal(typeof value.id, "string");
      assert.match(value.sourceHash, /^[0-9a-f]{64}$/u);
      assert(!supportingValues.has(value.id), `Dependency supporting value repeated: ${value.id}`);
      supportingValues.set(value.id, {
        proofKind: family.proofKind,
        certificateId: family.certificateId,
        artifactSha256: family.artifactSha256,
        sourceHash: value.sourceHash,
        registered: family.registered,
      });
    }
  }
  return { equations, supportingValues };
}

/** Recheck the committed strict-271 receipt so a re-signed manifest cannot invent dependency registration. */
function verifyStrictRegistrationReceipt(manifest) {
  const receiptPath = path.join(familyDirectory, "current-registration-receipt.json");
  const receiptBytes = fs.readFileSync(receiptPath);
  assert.equal(sha256(receiptBytes), CURRENT_REGISTRATION_RECEIPT_SHA256);
  assert.equal(sha256(receiptBytes), manifest.strictRegistrationReceipt.receiptSha256);
  const receipt = JSON.parse(receiptBytes.toString("utf8"));
  assert.equal(receipt.schemaVersion, 2);
  assert.equal(receipt.status, "CURRENT_STRICT_DEPENDENCY_RECEIPT");
  assert.equal(receipt.hubCommit, "3f49bd79e4ac7c1deb21b26b137cdcd3640d5f32");
  assert.equal(receipt.hubCommit, manifest.strictRegistrationReceipt.hubCommit);
  assert.equal(receipt.sourceBase, SOURCE_BASE);
  assert.equal(receipt.surfaceDigest, "6a3bdd7dd66a3e352c1dca251d654406a5b25bef3c502c5392785384be5b93c1");
  assert.equal(receipt.strictCallables, 271);
  assert.equal(receipt.admissionReport.strictGatePassed, true);
  assert.equal(receipt.admissionReport.sha256, manifest.strictRegistrationReceipt.admissionReportSha256);
  assert.equal(receipt.surfaceBindings.sha256, manifest.strictRegistrationReceipt.surfaceBindingsSha256);
  const registeredByProofKind = new Map(
    receipt.families.map((family) => [family.proofKind, family])
  );
  const baselineByProofKind = new Map(
    receipt.baselineBindings.map((binding) => [binding.proofKind, binding])
  );
  for (const family of manifest.families) {
    const review = registeredByProofKind.get(family.proofKind) ?? baselineByProofKind.get(family.proofKind);
    assert.equal(family.registered, review !== undefined, `Manifest registration differs from strict receipt: ${family.proofKind}`);
    assert(review !== undefined, `Current strict receipt omitted dependency: ${family.proofKind}`);
    assert.equal(family.artifactSha256, review.artifactSha256, `Dependency artifact differs from strict receipt: ${family.proofKind}`);
    const reviewedCertificate = review.certificateId ?? review.familyId;
    if (reviewedCertificate !== undefined && !family.proofKind.startsWith("independent-catalog-")) {
      assert.equal(family.certificateId, reviewedCertificate, `Dependency certificate differs from strict receipt: ${family.proofKind}`);
    }
  }
  for (const proofKind of receipt.notRegisteredProofKinds) {
    assert.equal(registeredByProofKind.has(proofKind), false);
  }
}

/** Map one source enum/member or top-level variable to its semantic identity. */
function supportingValueId(repositoryRoot, declaration) {
  let owner = declaration;
  if (ts.isEnumMember(owner)) owner = owner.parent;
  if (ts.isVariableDeclaration(owner)) {
    if (!ts.isSourceFile(owner.parent.parent.parent)) return undefined;
  } else if (!ts.isEnumDeclaration(owner)) {
    return undefined;
  }
  const name = owner.name?.getText(owner.getSourceFile());
  if (name === undefined) return undefined;
  return `${relativePath(repositoryRoot, owner.getSourceFile().fileName)}#${name}`;
}

/** Inspect the exact transitive callable closure while stopping only at registered families. */
function inspectClosure({
  repositoryRoot,
  context,
  seeds,
  localById,
  localSupportingById,
  dependencyById,
  dependencySupportingById,
}) {
  const pendingDeclarations = [...seeds];
  const checkedLocal = new Set();
  const reused = new Map();
  const pendingDependencies = new Map();
  const ambient = new Map();
  const checkedSupporting = new Map();
  const reusedSupporting = new Map();
  const pendingSupporting = new Map();
  const unresolved = new Set();

  while (pendingDeclarations.length > 0) {
    const declaration = pendingDeclarations.shift();
    const id = declarationId(repositoryRoot, declaration);
    if (checkedLocal.has(id) || reused.has(id) || pendingDependencies.has(id)) continue;
    const local = localById.get(id);
    if (local === undefined) {
      const dependency = dependencyById.get(id);
      if (dependency === undefined) {
        unresolved.add(id);
      } else {
        const implementation = spanOf(context, declaration);
        assert.equal(
          implementation.sourceHash,
          dependency.sourceHash,
          `Registered dependency source changed: ${id}`
        );
        (dependency.registered ? reused : pendingDependencies).set(id, dependency);
      }
      continue;
    }
    checkedLocal.add(id);

    /** Inspect runtime calls and callable references, excluding erased type syntax. */
    function visit(node) {
      if (ts.isTypeNode(node)) return;
      if (ts.isCallExpression(node) || ts.isNewExpression(node)) {
        const signature = context.checker.getResolvedSignature(node)?.declaration;
        if (signature?.getSourceFile().isDeclarationFile) {
          const operation = ambientOperation(node, signature);
          const declarationSpan = spanOf(context, signature);
          const key = `${operation}:${declarationSpan.file}:${declarationSpan.start.offset}`;
          ambient.set(key, { operation, declaration: declarationSpan });
        }
        const target = sourceCallableFromCall(context, node);
        if (target !== undefined && !declarationIsInside(target, declaration)) {
          pendingDeclarations.push(target);
        }
      }
      if (ts.isIdentifier(node)) {
        const symbol = resolvedSymbol(context, node);
        const target = sourceCallableFromSymbol(symbol);
        if (target !== undefined && !declarationIsInside(target, declaration)) {
          pendingDeclarations.push(target);
        }
        for (const sourceDeclaration of symbol?.declarations ?? []) {
          if (
            sourceDeclaration.getSourceFile().isDeclarationFile ||
            declarationIsInside(sourceDeclaration, declaration)
          ) {
            continue;
          }
          const valueId = supportingValueId(repositoryRoot, sourceDeclaration);
          if (valueId === undefined) continue;
          const localValue = localSupportingById.get(valueId);
          if (localValue !== undefined) {
            checkedSupporting.set(valueId, localValue);
            continue;
          }
          const dependencyValue = dependencySupportingById.get(valueId);
          if (dependencyValue === undefined) {
            unresolved.add(`supporting-value:${valueId}`);
            continue;
          }
          let owner = sourceDeclaration;
          if (ts.isEnumMember(owner)) owner = owner.parent;
          const implementation = spanOf(context, owner);
          assert.equal(
            implementation.sourceHash,
            dependencyValue.sourceHash,
            `Registered supporting value source changed: ${valueId}`
          );
          (dependencyValue.registered ? reusedSupporting : pendingSupporting)
            .set(valueId, dependencyValue);
        }
      }
      ts.forEachChild(node, visit);
    }

    visit(declaration.body);
  }

  assert.equal(
    unresolved.size,
    0,
    `Unproved transitive source callables: ${[...unresolved].sort(compareCodeUnits).join(", ")}`
  );
  return {
    checkedLocal: [...checkedLocal].sort(compareCodeUnits),
    reused: [...reused].map(([id, dependency]) => ({ id, ...dependency }))
      .sort((left, right) => compareCodeUnits(left.id, right.id)),
    pending: [...pendingDependencies].map(([id, dependency]) => ({ id, ...dependency }))
      .sort((left, right) => compareCodeUnits(left.id, right.id)),
    localSupporting: [...checkedSupporting].map(([id, row]) => ({
      id,
      declaration: row.declaration,
      equationSha256: row.equationSha256,
    })).sort((left, right) => compareCodeUnits(left.id, right.id)),
    reusedSupporting: [...reusedSupporting].map(([id, dependency]) => ({
      id,
      ...dependency,
    })).sort((left, right) => compareCodeUnits(left.id, right.id)),
    pendingSupporting: [...pendingSupporting].map(([id, dependency]) => ({
      id,
      ...dependency,
    })).sort((left, right) => compareCodeUnits(left.id, right.id)),
    ambient: [...ambient.values()].sort((left, right) =>
      compareCodeUnits(canonicalJson(left), canonicalJson(right))
    ),
  };
}

/** Return the exact pending callable/value dependency identities for one closure. */
function pendingDependencyIdsFor(closure) {
  return [
    ...closure.pending.map((dependency) => dependency.id),
    ...closure.pendingSupporting.map((dependency) => `supporting-value:${dependency.id}`),
  ].sort(compareCodeUnits);
}

/** Reduce one callable's closure to the registered/pending paths retained in evidence. */
function proofDependencySummary(surfaceKey, closure) {
  const pendingDependencyIds = pendingDependencyIdsFor(closure);
  return {
    surfaceKey,
    status: pendingDependencyIds.length === 0
      ? "CLOSED_REGISTERED_DEPENDENCIES"
      : "PENDING_REGISTERED_DEPENDENCIES",
    localEquationIds: closure.checkedLocal,
    registeredEquationIds: closure.reused.map((dependency) => dependency.id),
    pendingDependencyIds,
    localSupportingValueIds: closure.localSupporting.map((value) => value.id),
    registeredSupportingValueIds: closure.reusedSupporting.map((value) => value.id),
  };
}

/** Verify one frozen execution stream includes exact state/result/original-Next checks. */
function summarizeExecutionEvidence(repositoryRoot, file) {
  const absolute = path.resolve(repositoryRoot, file);
  const bytes = fs.readFileSync(absolute);
  const evidence = JSON.parse(bytes.toString("utf8"));
  assert.equal(evidence.schemaVersion, 2, `${file} schema changed.`);
  assert.equal(evidence.status, "PASS", `${file} is not passing evidence.`);
  assert(Array.isArray(evidence.executions) && evidence.executions.length > 0);
  assert(Array.isArray(evidence.reverse?.edges));
  assert.equal(evidence.reverse.edges.length, evidence.executions.length);
  for (const execution of evidence.executions) {
    assert.equal(execution.formalEnabled, true);
    assert.equal(execution.outcome, "accepted");
    assert.equal(execution.checked.sourceState, true);
    assert.equal(execution.checked.state, true);
    assert.equal(execution.checked.result, true);
    assert.equal(execution.checked.enabledness, true);
    assert.equal(canonicalJson(execution.expectedSourceState), canonicalJson(execution.actualSourceState));
    assert.equal(canonicalJson(execution.expectedState), canonicalJson(execution.actualState));
    assert.equal(canonicalJson(execution.expectedResult), canonicalJson(execution.actualResult));
    assert.equal(execution.checkpoint.forkConcreteId.length, 64);
  }
  for (const reverse of evidence.reverse.edges) {
    assert.equal(reverse.originalNextAccepted, true);
  }
  const sourceInputs = [];
  const referencedInputs = [
    ...evidence.producer.files.map((input) => ({ file: input.file, sha256: input.sha256 })),
    { file: evidence.model.source, sha256: evidence.model.sourceHash },
    { file: evidence.model.config.file, sha256: evidence.model.config.sha256 },
    {
      file: evidence.checkpointEquivalence.evidence.file,
      sha256: evidence.checkpointEquivalence.evidence.sha256,
    },
  ];
  for (const input of referencedInputs) {
    const inputBytes = fs.readFileSync(path.resolve(repositoryRoot, input.file));
    assert.equal(sha256(inputBytes), input.sha256, `Frozen proof input changed: ${input.file}`);
    sourceInputs.push(input);
  }
  for (const observation of evidence.surfaceObservations) {
    const sourceReference = observation.sourceReference;
    const sourceBytes = fs.readFileSync(path.resolve(repositoryRoot, sourceReference.file));
    assert.equal(sha256(sourceBytes), sourceReference.sourceHash);
    const sourceTextValue = sourceBytes.toString("utf8");
    assert.equal(
      sha256(sourceTextValue.slice(sourceReference.start, sourceReference.end)),
      sourceReference.astHash,
      `Execution source reference changed: ${sourceReference.file}`
    );
  }
  return {
    file,
    sha256: sha256(bytes),
    model: evidence.model.name,
    sourceHash: evidence.model.sourceHash,
    config: evidence.model.config,
    executionCount: evidence.executions.length,
    stateChecks: evidence.executions.length,
    resultChecks: evidence.executions.length,
    originalNextChecks: evidence.reverse.edges.length,
    sourceInputs,
    surfaceObservations: evidence.surfaceObservations.map((observation) => ({
      surfaceKey: observation.surfaceKey,
      sourceReference: observation.sourceReference,
      occurrenceCount: observation.edgeIds.length,
    })),
  };
}

/** Reuse the old real-TypeScript calls only as forward witnesses, never as universal proof. */
function summarizeForwardWitnesses(repositoryRoot) {
  const file = "experiments/tla-conformance/transfer-surface-r6/value-equation-candidates.json";
  const bytes = fs.readFileSync(path.resolve(repositoryRoot, file));
  assert.equal(
    sha256(bytes),
    "a9000d71656cc466f2eaf68564fd0848c63bdc1947cb217fccefe5a082e50817",
    "Frozen real-TypeScript forward witnesses changed."
  );
  const evidence = JSON.parse(bytes.toString("utf8"));
  assert.equal(evidence.domain, "DECLARED_EXACT_SCALAR_TRANSFER_FIXTURES_V1");
  assert.equal(evidence.proofCreditGranted, false);
  assert.equal(evidence.candidates.length, 11);
  assert(evidence.candidates.every((candidate) => candidate.exactValueEqual === true));
  assert(evidence.candidates.every((candidate) => candidate.negativeMutationRejected === true));
  assert.equal(
    canonicalJson(evidence.candidates.map((candidate) => candidate.surfaceKey)),
    canonicalJson(ASSIGNED_SURFACE_KEYS)
  );
  return {
    file,
    sha256: sha256(bytes),
    runtime: "real TypeScript constructor/planner calls",
    witnessCount: evidence.candidates.length,
    exactForwardValues: evidence.candidates.length,
    rejectedValueMutations: evidence.candidates.length,
    proofCreditGranted: false,
    completeProofSuppliedBy: "independent complete source equations",
  };
}

/** Load current source text, substituting only explicit in-memory mutation controls. */
function sourceText(repositoryRoot, file, sourceOverrides) {
  return sourceOverrides.get(file) ?? fs.readFileSync(path.resolve(repositoryRoot, file), "utf8");
}

/** Build exact interface-to-implementation and prior-execution source-flow joins. */
function buildSourceFlowJoins({ context, surface, localById, executionEvidence }) {
  const facade = context.program.getSourceFile(path.resolve(context.repositoryRoot, "src/facade.ts"));
  assert(facade !== undefined);
  const replacementImplementation = facade.statements.find(
    (statement) =>
      ts.isClassDeclaration(statement) &&
      statement.name?.text === "InventoryOnceReplacementPlansImplementation"
  );
  assert(
    replacementImplementation !== undefined && ts.isClassDeclaration(replacementImplementation),
    "Missing replacement-plan implementation class."
  );
  const implementsReplacementPlans = replacementImplementation.heritageClauses?.some(
    (clause) =>
      clause.token === ts.SyntaxKind.ImplementsKeyword &&
      clause.types.some((type) => type.expression.getText(facade) === "InventoryOnceReplacementPlans")
  ) ?? false;
  assert.equal(implementsReplacementPlans, true, "Replacement implementation lost its interface join.");

  const callableByKey = new Map(surface.callables.map((callable) => [callable.key, callable]));
  const correctionWrapper = localById.get("src/facade.ts#InventoryOnceStockImplementation.correct");
  const planConstructor = localById.get(
    "src/facade.ts#InventoryOnceReplacementPlansImplementation.constructor"
  );
  const opaqueConstructor = localById.get(
    "src/facade.ts#InventoryOnceReplacementPlanImplementation.constructor"
  );
  const planReader = localById.get("src/facade.ts#readReplacementEventDraft");
  assert(correctionWrapper !== undefined && planConstructor !== undefined);
  assert(opaqueConstructor !== undefined && planReader !== undefined);

  const plannerRows = ASSIGNED_SURFACE_KEYS
    .filter((surfaceKey) => surfaceKey.startsWith("type:"))
    .map((surfaceKey) => {
      const callable = callableByKey.get(surfaceKey);
      const equationId = IMPLEMENTATION_BY_SURFACE_KEY[surfaceKey];
      const implementation = localById.get(equationId);
      assert(callable !== undefined && implementation !== undefined);
      return {
        surfaceKey,
        publicDeclaration: callable.declaration,
        implementation: spanOf(context, implementation),
        implementsInterface: "InventoryOnceReplacementPlans",
        constructionCallsite: spanOf(context, correctionWrapper),
        implementationConstructor: spanOf(context, planConstructor),
        opaquePlanConstructor: spanOf(context, opaqueConstructor),
        opaquePlanReader: spanOf(context, planReader),
        relation: "CORRECTION_CALLBACK_RECEIVES_THE_UNIQUE_TYPED_IMPLEMENTATION",
      };
    });

  const causalRows = [];
  for (const evidence of executionEvidence) {
    for (const observation of evidence.surfaceObservations) {
      const callable = callableByKey.get(observation.surfaceKey);
      assert(callable !== undefined, `Execution evidence names unknown surface '${observation.surfaceKey}'.`);
      causalRows.push({
        surfaceKey: observation.surfaceKey,
        publicDeclaration: callable.declaration,
        model: evidence.model,
        executionEvidence: { file: evidence.file, sha256: evidence.sha256 },
        sourceReference: observation.sourceReference,
        occurrenceCount: observation.occurrenceCount,
        stateChecks: evidence.stateChecks,
        resultChecks: evidence.resultChecks,
        originalNextChecks: evidence.originalNextChecks,
        creditGrantedHere: false,
      });
    }
  }
  return { plannerRows, causalRows };
}

/** Build the complete eleven-row family and zero-credit result/read strengthening in one pass. */
export function buildTransferCorrectionValueFamily({
  repositoryRoot,
  context,
  surface,
  sourceOverrides = new Map(),
  dependencyManifestOverride,
}) {
  const root = path.resolve(repositoryRoot);
  assert.equal(ASSIGNED_SURFACE_KEYS.length, 11, "Transfer/correction surface cardinality changed.");
  assert.equal(new Set(ASSIGNED_SURFACE_KEYS).size, 11, "Transfer/correction rows repeat.");

  const dependencyManifestPath = path.join(familyDirectory, "dependency-manifest.json");
  const dependencyManifestBytes = dependencyManifestOverride === undefined
    ? fs.readFileSync(dependencyManifestPath)
    : Buffer.from(`${JSON.stringify(dependencyManifestOverride, null, 2)}\n`);
  const dependencyManifest = JSON.parse(dependencyManifestBytes.toString("utf8"));
  verifyStrictRegistrationReceipt(dependencyManifest);
  const dependencies = dependencyIndex(dependencyManifest);
  const sourceBaseManifestPath = path.join(familyDirectory, "source-base-manifest.json");
  const sourceBaseManifest = JSON.parse(fs.readFileSync(sourceBaseManifestPath, "utf8"));
  assert.equal(sourceBaseManifest.schemaVersion, 1);
  assert.equal(sourceBaseManifest.sourceBase, SOURCE_BASE);
  assert.equal(sourceBaseManifest.sources.length, LOCAL_SOURCE_FILES.length);
  assert.equal(
    canonicalJson(sourceBaseManifest.sources.map((source) => source.file).sort(compareCodeUnits)),
    canonicalJson([...LOCAL_SOURCE_FILES].sort(compareCodeUnits))
  );
  for (const sourceInput of sourceBaseManifest.sources) {
    assert(LOCAL_SOURCE_FILES.includes(sourceInput.file));
    assert.equal(
      sha256(fs.readFileSync(path.resolve(root, sourceInput.file))),
      sourceInput.sha256,
      `Local source differs from frozen base: ${sourceInput.file}`
    );
  }
  const redBeforePath = path.join(familyDirectory, "red-before.json");
  const redBefore = JSON.parse(fs.readFileSync(redBeforePath, "utf8"));
  assert.equal(redBefore.schemaVersion, 1);
  assert.equal(redBefore.sourceBase, SOURCE_BASE);
  assert.equal(redBefore.surfaceDigest, surface.digest);
  assert.equal(redBefore.rejectedCount, 11);
  assert.equal(redBefore.priorEvidenceDomain, "DECLARED_EXACT_SCALAR_TRANSFER_FIXTURES_V1");
  assert.equal(
    canonicalJson(redBefore.rows.map((row) => row.surfaceKey)),
    canonicalJson(ASSIGNED_SURFACE_KEYS),
    "Red-before identities changed."
  );
  const actualSourceByFile = new Map(
    LOCAL_SOURCE_FILES.map((file) => {
      const absolute = path.resolve(root, file);
      const source = sourceOverrides.has(file)
        ? parseSource(absolute, sourceText(root, file, sourceOverrides))
        : context.program.getSourceFile(absolute);
      assert(source !== undefined, `Compiler omitted local source '${file}'.`);
      return [file, source];
    })
  );
  const expectedSourceByFile = new Map(
    LOCAL_SOURCE_FILES.map((file) => {
      const expectedFile = expectedFileBySource.get(file);
      assert(expectedFile !== undefined);
      return [file, parseSource(expectedFile, fs.readFileSync(expectedFile, "utf8"))];
    })
  );

  const localById = new Map();
  const equations = [];
  for (const equationId of LOCAL_EQUATION_IDS) {
    const actual = findCallable(actualSourceByFile, equationId);
    const expected = findCallable(expectedSourceByFile, equationId);
    const actualTerm = normalizeTransferCorrectionCallable(actual);
    const expectedTerm = normalizeTransferCorrectionCallable(expected);
    assert.equal(
      canonicalJson(actualTerm),
      canonicalJson(expectedTerm),
      `Independent source equation changed: ${equationId}`
    );
    localById.set(equationId, actual);
    equations.push({
      id: equationId,
      lawId: lawIdForEquation(equationId),
      declaration: sourceOverrides.size === 0 ? spanOf(context, actual) : null,
      equationSha256: sha256(canonicalJson(expectedTerm)),
      term: expectedTerm,
      strengtheningOnly: STRENGTHENING_EQUATION_IDS.includes(equationId),
    });
  }

  const localSupportingById = new Map();
  const supportingValues = [];
  for (const valueId of LOCAL_SUPPORTING_VALUE_IDS) {
    const actual = findSupportingValue(actualSourceByFile, valueId);
    const expected = findSupportingValue(expectedSourceByFile, valueId);
    const actualTerm = normalizeSupportingValue(actual);
    const expectedTerm = normalizeSupportingValue(expected);
    assert.equal(
      canonicalJson(actualTerm),
      canonicalJson(expectedTerm),
      `Independent supporting-value equation changed: ${valueId}`
    );
    const row = {
      id: valueId,
      declaration: sourceOverrides.size === 0 ? spanOf(context, actual) : null,
      equationSha256: sha256(canonicalJson(expectedTerm)),
      term: expectedTerm,
    };
    localSupportingById.set(valueId, row);
    supportingValues.push(row);
  }

  const callableByKey = new Map(surface.callables.map((callable) => [callable.key, callable]));
  const proofSeeds = [];
  const proofs = [];
  for (const surfaceKey of ASSIGNED_SURFACE_KEYS) {
    const callable = callableByKey.get(surfaceKey);
    assert(callable !== undefined, `Compiler omitted '${surfaceKey}'.`);
    assert.equal(callable.signatureHash, sha256(canonicalJson(callable.signature)));
    const equationId = IMPLEMENTATION_BY_SURFACE_KEY[surfaceKey];
    const implementation = localById.get(equationId);
    assert(implementation !== undefined, `No implementation equation for '${surfaceKey}'.`);
    proofSeeds.push(implementation);
    const isInterfaceMethod = surfaceKey.startsWith("type:");
    if (!isInterfaceMethod && sourceOverrides.size === 0) {
      assert.equal(canonicalJson(callable.declaration), canonicalJson(spanOf(context, implementation)));
    }
    proofs.push({
      surfaceKey,
      mode: "V",
      signature: callable.signature,
      signatureHash: callable.signatureHash,
      declaration: callable.declaration,
      implementation: sourceOverrides.size === 0 ? spanOf(context, implementation) : null,
      relation: isInterfaceMethod
        ? "COMPILER_TYPED_OPAQUE_REPLACEMENT_IMPLEMENTATION"
        : "COMPILER_RESOLVED_EXACT_EXPORT",
      equationId,
      equationSha256: equations.find((equation) => equation.id === equationId).equationSha256,
      lawId: lawIdForEquation(equationId),
    });
  }

  let closure = {
    checkedLocal: [],
    reused: [],
    pending: [],
    localSupporting: [],
    reusedSupporting: [],
    pendingSupporting: [],
    ambient: [],
  };
  let proofDependencyClosures = [];
  if (sourceOverrides.size === 0) {
    closure = inspectClosure({
      repositoryRoot: root,
      context,
      seeds: proofSeeds,
      localById,
      localSupportingById,
      dependencyById: dependencies.equations,
      dependencySupportingById: dependencies.supportingValues,
    });
    const expectedCoreEquations = LOCAL_EQUATION_IDS
      .filter((equationId) => !STRENGTHENING_EQUATION_IDS.includes(equationId))
      .sort(compareCodeUnits);
    assert.equal(
      canonicalJson(closure.checkedLocal),
      canonicalJson(expectedCoreEquations),
      "The transfer/correction-specific recursive equation closure changed."
    );
    proofDependencyClosures = proofSeeds.map((seed, index) =>
      proofDependencySummary(
        proofs[index].surfaceKey,
        inspectClosure({
          repositoryRoot: root,
          context,
          seeds: [seed],
          localById,
          localSupportingById,
          dependencyById: dependencies.equations,
          dependencySupportingById: dependencies.supportingValues,
        })
      )
    );
  }

  const pendingDependencyIds = pendingDependencyIdsFor(closure);
  for (let index = 0; index < proofs.length; index += 1) {
    const proofClosure = proofDependencyClosures[index];
    proofs[index].dependencyStatus = proofClosure?.status ?? "MUTATION_CHECK_NOT_ADMISSIBLE";
    proofs[index].pendingDependencyIds = proofClosure?.pendingDependencyIds ?? [];
  }

  const executionEvidence = REUSED_EXECUTION_FILES.map((file) =>
    summarizeExecutionEvidence(root, file)
  );
  const forwardWitnesses = summarizeForwardWitnesses(root);
  const sourceFlowJoins = sourceOverrides.size === 0
    ? buildSourceFlowJoins({ context, surface, localById, executionEvidence })
    : { plannerRows: [], causalRows: [] };
  const semanticFiles = new Set([
    ...LOCAL_SOURCE_FILES,
    ...producerFiles,
    ...REUSED_EXECUTION_FILES,
    ...executionEvidence.flatMap((evidence) =>
      evidence.sourceInputs.map((input) => input.file)
    ),
    ...closure.ambient.map((operation) => operation.declaration.file),
  ]);
  const inputs = [...semanticFiles].sort(compareCodeUnits).map((file) => ({
    file,
    sha256:
      file === relativePath(root, dependencyManifestPath)
        ? sha256(dependencyManifestBytes)
        : sha256(sourceOverrides.get(file) ?? fs.readFileSync(path.resolve(root, file))),
  }));

  const semanticCore = {
    sourceBase: SOURCE_BASE,
    redBefore,
    domain: FAMILY_DOMAIN,
    laws: FAMILY_LAWS,
    equations,
    supportingValues,
    closure: {
      complete: sourceOverrides.size === 0,
      localEquationIds: closure.checkedLocal,
      registeredDependencies: closure.reused,
      pendingDependencies: closure.pending,
      localSupportingValues: closure.localSupporting,
      registeredSupportingValues: closure.reusedSupporting,
      pendingSupportingValues: closure.pendingSupporting,
      ambientOperations: closure.ambient,
      bySurface: proofDependencyClosures,
    },
    strengthening: {
      creditGranted: false,
      equationIds: STRENGTHENING_EQUATION_IDS,
      executionEvidence,
      forwardWitnesses,
      sourceFlowJoins,
      nativeGraphRuns: 0,
      originalGraphRuns: 0,
      producerReplayRuns: 0,
    },
  };
  const certificateId = `VALUE_CERTIFICATE_FAMILY:sha256:${sha256(canonicalJson(semanticCore))}`;
  const result = {
    schemaVersion: 1,
    mode: "V",
    proofKind: TRANSFER_CORRECTION_VALUE_PROOF_KIND,
    certificateId,
    sourceBase: SOURCE_BASE,
    surfaceDigest: surface.digest,
    allAdmittedInputs: pendingDependencyIds.length === 0,
    sampledInputs: 0,
    domain: FAMILY_DOMAIN,
    inputs,
    semanticCore,
    proofs,
  };
  if (sourceOverrides.size === 0) passCache.set(context, result);
  return result;
}

/** Strict registered-family adapter identity list. */
export const supportedSurfaceKeys = ASSIGNED_SURFACE_KEYS;

/** Strict registered-family adapter builder. */
export const buildFamilyArtifact = buildTransferCorrectionValueFamily;

/** Rebuild current semantics and reject a re-signed but false recorded family. */
export function verifyTransferCorrectionValueFamily({
  repositoryRoot,
  context,
  surface,
  recorded,
}) {
  const current = passCache.get(context) ??
    buildTransferCorrectionValueFamily({ repositoryRoot, context, surface });
  assert.equal(
    canonicalJson(recorded),
    canonicalJson(current),
    "Recorded transfer/correction family differs from current independent equations."
  );
  return current;
}
