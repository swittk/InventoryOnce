import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  canonicalJson,
  sha256,
  ts,
} from "../surface-bindings/lib/compiler-surface.mjs";
import { buildIndependentV9Artifact } from "../migration-helper-causal-r7/independent-v9-laws.mjs";
import { buildCatalogFoundationFamilyArtifact } from "../catalog-foundation-r7/family.mjs";
import { buildTransferCorrectionValueFamily } from "../transfer-surface-r6/source-equations-r7/family.mjs";

const DIRECTORY = "experiments/tla-conformance/materialize1-r8";
const FAMILY_FILE = `${DIRECTORY}/family.mjs`;
const EXPECTED_FILE = `${DIRECTORY}/roots-and-wrapper.expected.ts.txt`;
const CATALOG_RECORDED_FILE = "experiments/tla-conformance/throughput-r7/evidence/catalog-foundation-values.json";
const TRANSFER_RECORDED_FILE = "experiments/tla-conformance/throughput-r7/evidence/transfer-correction-values.json";
const MIGRATION_RECORDED_FILE = "experiments/tla-conformance/throughput-r7/evidence/migration-helper-values.json";

export const proofKind = "migration-durable-world-materialize-complete-values-v1";
export const supportedSurfaceKeys = Object.freeze([
  "export:./storage#materializeInventoryDurableMigrationWorld::call[0]",
]);

const ROOT_LAWS = Object.freeze([
  Object.freeze({ id: "src/integrity.ts#inventoryWorldContentRoots", file: "src/integrity.ts", name: "inventoryWorldContentRoots", dependencies: [
    "src/integrity.ts#inventoryCatalogSnapshotDigest",
    "src/integrity.ts#inventoryProjectionDigest",
    "src/integrity.ts#inventoryReservationBookDigest",
    "src/integrity.ts#inventoryCountBookDigest",
    "src/digest.ts#inventorySha256",
  ] }),
  Object.freeze({ id: "src/integrity.ts#inventoryCatalogSnapshotDigest", file: "src/integrity.ts", name: "inventoryCatalogSnapshotDigest", dependencies: ["src/catalog.ts#inventoryCatalogFromSnapshot"] }),
  Object.freeze({ id: "src/integrity.ts#inventoryProjectionDigest", file: "src/integrity.ts", name: "inventoryProjectionDigest", dependencies: ["src/integrity.ts#sortedRecordRows", "src/digest.ts#inventorySha256"] }),
  Object.freeze({ id: "src/integrity.ts#inventoryReservationBookDigest", file: "src/integrity.ts", name: "inventoryReservationBookDigest", dependencies: ["src/integrity.ts#sortedRecordRows", "src/digest.ts#inventorySha256"] }),
  Object.freeze({ id: "src/integrity.ts#inventoryCountBookDigest", file: "src/integrity.ts", name: "inventoryCountBookDigest", dependencies: ["src/integrity.ts#sortedRecordRows", "src/digest.ts#inventorySha256"] }),
  Object.freeze({ id: "src/integrity.ts#sortedRecordRows", file: "src/integrity.ts", name: "sortedRecordRows", dependencies: [] }),
  Object.freeze({ id: "src/projection.ts#applyInventoryCommittedEvent", file: "src/projection.ts", name: "applyInventoryCommittedEvent", dependencies: ["src/projection.ts#applyInventoryCommittedEventInternal"] }),
]);

function rootDir() {
  return path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../..");
}
function sourceText(root, file, overrides) {
  const override = overrides?.get(file);
  return override ?? fs.readFileSync(path.resolve(root, file), "utf8");
}
function fileRef(root, file, overrides) {
  return { file, sha256: sha256(sourceText(root, file, overrides)) };
}
function sourceFile(file, text) {
  const source = ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  assert.equal(source.parseDiagnostics.length, 0, `Source does not parse: ${file}`);
  return source;
}
function findFunction(source, name) {
  const rows = source.statements.filter((statement) =>
    ts.isFunctionDeclaration(statement) && statement.name?.text === name && statement.body !== undefined
  );
  assert.equal(rows.length, 1, `Expected one function '${name}' in ${source.fileName}.`);
  return rows[0];
}
function scanTokens(text) {
  const scanner = ts.createScanner(ts.ScriptTarget.Latest, true, ts.LanguageVariant.Standard, text);
  const result = [];
  for (let token = scanner.scan(); token !== ts.SyntaxKind.EndOfFileToken; token = scanner.scan()) {
    result.push([ts.SyntaxKind[token], scanner.getTokenText()]);
  }
  return result;
}
function normalizedCallable(declaration, source) {
  return {
    typeParameters: (declaration.typeParameters ?? []).map((row) => scanTokens(row.getText(source))),
    parameters: declaration.parameters.map((row) => scanTokens(row.getText(source))),
    returnType: declaration.type === undefined ? null : scanTokens(declaration.type.getText(source)),
    body: scanTokens(declaration.body.getText(source)),
  };
}
export function buildRootEquations(root, sourceOverrides = new Map()) {
  const expectedText = fs.readFileSync(path.resolve(root, EXPECTED_FILE), "utf8");
  const expected = sourceFile(EXPECTED_FILE, expectedText);
  const actualByFile = new Map();
  const rows = [];
  for (const law of ROOT_LAWS) {
    let actualSource = actualByFile.get(law.file);
    if (actualSource === undefined) {
      actualSource = sourceFile(law.file, sourceText(root, law.file, sourceOverrides));
      actualByFile.set(law.file, actualSource);
    }
    const actual = findFunction(actualSource, law.name);
    const wanted = findFunction(expected, law.name);
    const actualTerm = normalizedCallable(actual, actualSource);
    const expectedTerm = normalizedCallable(wanted, expected);
    assert.equal(
      canonicalJson(actualTerm),
      canonicalJson(expectedTerm),
      `Complete digest/wrapper equation changed: ${law.id}`
    );
    rows.push({
      id: law.id,
      lawId: "migration-materialize-root-and-wrapper-v1",
      termSha256: sha256(canonicalJson(expectedTerm)),
      dependencies: law.dependencies,
      completeExpectedTerm: true,
    });
  }
  return rows;
}
function equationById(rows, id) {
  const matches = rows.filter((row) => row.id === id);
  assert.equal(matches.length, 1, `Expected one equation '${id}'.`);
  return matches[0];
}
function catalogEquation(artifact, id) {
  const matches = artifact.equations.filter((row) => row.id === id);
  assert.equal(matches.length, 1, `Catalog foundation lost '${id}'.`);
  return matches[0];
}
function transferEquation(artifact, id) {
  const matches = artifact.semanticCore.equations.filter((row) => row.id === id);
  assert.equal(matches.length, 1, `Transfer/correction family lost '${id}'.`);
  return matches[0];
}
function v9Proof(artifact, surfaceKey) {
  const matches = artifact.proofs.filter((row) => row.surfaceKey === surfaceKey);
  assert.equal(matches.length, 1, `Migration helper proof lost '${surfaceKey}'.`);
  return matches[0];
}
function v9Local(artifact, id) {
  const matches = artifact.localLaws.filter((row) => row.id === id);
  assert.equal(matches.length, 1, `Migration helper local law lost '${id}'.`);
  return matches[0];
}
function mergeInputs(rows) {
  const byFile = new Map();
  for (const row of rows) {
    const prior = byFile.get(row.file);
    if (prior !== undefined) assert.equal(prior.sha256, row.sha256, `Input '${row.file}' has conflicting identities.`);
    byFile.set(row.file, row);
  }
  return [...byFile.values()].sort((left, right) => left.file.localeCompare(right.file));
}
function recordedArtifact(root, file) {
  return JSON.parse(fs.readFileSync(path.resolve(root, file), "utf8"));
}

export function buildFamilyArtifact({ repositoryRoot: root = rootDir(), context, surface, sourceOverrides = new Map() } = {}) {
  assert(context !== undefined && surface !== undefined, "Current compiler context and surface are required.");
  assert.equal(surface.callables.length, 535);

  // Rebuild the original complete Materialize/validator/SHA equations against current source.
  const migration = buildIndependentV9Artifact({ repositoryRoot: root, sourceOverrides, context, surface });
  const materialize = v9Proof(migration, supportedSurfaceKeys[0]);
  const validate = v9Local(migration, "src/storage.ts#validateInventoryDurableMigrationPlanAgainstBase");
  const rootsEqual = v9Local(migration, "src/storage.ts#inventoryWorldContentRootsEqual");
  const planDigest = v9Proof(migration, "export:./storage#inventoryDurableMigrationPlanDigest::call[0]");
  const shaLaw = v9Local(migration, "src/digest.ts#inventorySha256");
  const rotateLaw = v9Local(migration, "src/digest.ts#rotateRight");
  assert.equal(materialize.completeExpectedTerm.termSha256, "20f20d40f7bccebe4162b09cca6e521c3b7786b7a29715b9ab548e31a1e89cfd");
  assert.equal(validate.completeExpectedTerm.termSha256, "a63cba18a783425b885ac3d301413f6562a67ed4184fc26f557766338c658b86");
  assert.equal(rootsEqual.completeExpectedTerm.termSha256, "3a30b6addeecaf9768c04d47771df8b26f57bc768d15794bedcf9075e83c5659");
  assert.equal(planDigest.completeExpectedTerm.termSha256, "72964d804bdb2a1081604127173d18e6ce6033a24871378c919d43704170235e");
  assert.equal(shaLaw.gaps.length, 0);
  assert.equal(rotateLaw.gaps.length, 0);

  // Rebuild the already-reviewed complete catalog semantics, not merely its recorded label.
  const catalog = buildCatalogFoundationFamilyArtifact({ repositoryRoot: root, context, surface, sourceOverrides });
  assert.equal(catalog.proofKind, "independent-catalog-foundation-closed-equations-v1");
  assert.equal(catalog.allAdmittedInputs, true);
  assert.equal(catalog.sampledInputs, 0);
  const catalogFromSnapshot = catalogEquation(catalog, "src/catalog.ts#inventoryCatalogFromSnapshot");
  const catalogRetainsSnapshot = catalogEquation(catalog, "src/catalog.ts#assertInventoryCatalogRetainsSnapshot");

  // Rebuild the full event reducer equation. This is universal source semantics, unlike the count-only A receipt.
  const transfer = buildTransferCorrectionValueFamily({ repositoryRoot: root, context, surface, sourceOverrides });
  assert.equal(transfer.proofKind, "inventoryonce-transfer-correction-complete-source-equations-v2");
  assert.equal(transfer.allAdmittedInputs, true);
  assert.equal(transfer.sampledInputs, 0);
  const eventReducer = transferEquation(transfer, "src/projection.ts#applyInventoryCommittedEventInternal");
  assert.equal(eventReducer.equationSha256, "7c258a0cd6881d0163cca5041071777e9a78615a1725b6435e6c0cd5e9728301");

  // Independently close all pure world-root components plus the public event wrapper.
  const rootEquations = buildRootEquations(root, sourceOverrides);
  const worldRoots = equationById(rootEquations, "src/integrity.ts#inventoryWorldContentRoots");
  const catalogSnapshotDigest = equationById(rootEquations, "src/integrity.ts#inventoryCatalogSnapshotDigest");
  const projectionDigest = equationById(rootEquations, "src/integrity.ts#inventoryProjectionDigest");
  const reservationDigest = equationById(rootEquations, "src/integrity.ts#inventoryReservationBookDigest");
  const countDigest = equationById(rootEquations, "src/integrity.ts#inventoryCountBookDigest");
  const sortedRows = equationById(rootEquations, "src/integrity.ts#sortedRecordRows");
  const publicApply = equationById(rootEquations, "src/projection.ts#applyInventoryCommittedEvent");

  const callable = surface.callables.find((row) => row.key === supportedSurfaceKeys[0]);
  assert(callable !== undefined, "Compiler surface lost materializeInventoryDurableMigrationWorld.");
  assert.deepEqual(callable.declaration, materialize.completeExpectedTerm.implementation, "Materialize public declaration no longer matches its complete source law.");

  const inputs = mergeInputs([
    fileRef(root, FAMILY_FILE, sourceOverrides),
    fileRef(root, EXPECTED_FILE, sourceOverrides),
    fileRef(root, "src/integrity.ts", sourceOverrides),
    fileRef(root, "src/projection.ts", sourceOverrides),
    fileRef(root, "src/storage.ts", sourceOverrides),
    fileRef(root, "src/catalog.ts", sourceOverrides),
    fileRef(root, "src/digest.ts", sourceOverrides),
    fileRef(root, "experiments/tla-conformance/migration-helper-causal-r7/independent-v9-laws.mjs", sourceOverrides),
    fileRef(root, "experiments/tla-conformance/migration-helper-causal-r7/v9.expected.ts.txt", sourceOverrides),
    fileRef(root, "experiments/tla-conformance/catalog-foundation-r7/family.mjs", sourceOverrides),
    fileRef(root, "experiments/tla-conformance/transfer-surface-r6/source-equations-r7/family.mjs", sourceOverrides),
    fileRef(root, CATALOG_RECORDED_FILE, sourceOverrides),
    fileRef(root, TRANSFER_RECORDED_FILE, sourceOverrides),
    fileRef(root, MIGRATION_RECORDED_FILE, sourceOverrides),
    ...catalog.inputs,
    ...transfer.inputs,
  ]);

  const proof = {
    surfaceKey: supportedSurfaceKeys[0],
    signatureHash: callable.signatureHash,
    declaration: callable.declaration,
    implementationId: materialize.implementationId,
    completeExpectedTerm: materialize.completeExpectedTerm,
    lawId: "migration-durable-world-materialize-composition-v1",
    dependencies: {
      localValidator: {
        id: validate.id,
        termSha256: validate.completeExpectedTerm.termSha256,
        rootsEqualityTermSha256: rootsEqual.completeExpectedTerm.termSha256,
      },
      planDigest: {
        surfaceKey: planDigest.surfaceKey,
        termSha256: planDigest.completeExpectedTerm.termSha256,
        sha256Law: shaLaw.completeExpectedTerm.termSha256,
        rotateRightLaw: rotateLaw.completeExpectedTerm.termSha256,
      },
      catalog: {
        fromSnapshot: { id: catalogFromSnapshot.id, termSha256: catalogFromSnapshot.termSha256, lawId: catalogFromSnapshot.lawId },
        retainsSnapshot: { id: catalogRetainsSnapshot.id, termSha256: catalogRetainsSnapshot.termSha256, lawId: catalogRetainsSnapshot.lawId },
      },
      eventProjection: {
        publicWrapper: publicApply,
        internalReducer: { id: eventReducer.id, equationSha256: eventReducer.equationSha256, lawId: eventReducer.lawId },
      },
      worldRoots: {
        worldRoots,
        catalogSnapshotDigest,
        projectionDigest,
        reservationDigest,
        countDigest,
        sortedRows,
        sha256Law: shaLaw.completeExpectedTerm.termSha256,
      },
    },
  };

  return {
    schemaVersion: 1,
    mode: "V",
    proofKind,
    family: "MigrationDurableWorldMaterializeV1",
    surfaceDigest: surface.digest,
    domain: "Every typed InventoryWorldState and InventoryDurableMigrationPlan admitted by the complete source guards: exact plan/base roots, retained catalog, ordered committed migration events, deficit policy, source dispositions, and SHA-256 content roots. No finite fixture or producer-action restriction.",
    allAdmittedInputs: true,
    sampledInputs: 0,
    sourceCallableClosureComplete: true,
    inputs,
    dependencyArtifacts: {
      catalogFoundation: { proofKind: catalog.proofKind, certificateId: catalog.certificateId, artifactSha256: sha256(canonicalJson(catalog)) },
      transferCorrection: { proofKind: transfer.proofKind, artifactSha256: sha256(canonicalJson(transfer)) },
      migrationHelperCompleteTerms: { proofKind: migration.proofKind, artifactSha256: sha256(canonicalJson(migration)) },
    },
    rootEquations,
    proofs: [proof],
  };
}
