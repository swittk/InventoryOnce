import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { canonicalJson, sha256 } from "../surface-bindings/lib/compiler-surface.mjs";

export const RECEIPT_FILE="experiments/tla-conformance/new-source-honest486-r43/source-irrelevance.json";
export const RECEIPT_SHA256="5497f5e926f011fe3404f46f7665619df7950b10529c000f07bbf40fc9baba5b";
export const RECEIPT_CONTENT_SHA256="ed13e159fa06bc45d6435fb86aa4812be05a6a25741f7e665ee8f5d7a3a19f93";
const OLD="19676c735dac922b66753fc713d1434bac28ffc9";
const CURRENT_SURFACE="c151b12edf5aac6fcd1fad6d435c36eae481af153a86888517b851f5da290af3";
let cached;
function bytes(root,file){return fs.readFileSync(path.resolve(root,file));}
function git(root,args){return execFileSync("git",args,{cwd:root,encoding:"utf8",maxBuffer:16*1024*1024});}
function currentDelta(root){return git(root,["diff","--name-only",OLD,"--","src"]).split(/\r?\n/u).filter(Boolean).sort();}
function validateReceiptIdentity(receipt){const copy=structuredClone(receipt);delete copy.contentSha256;assert.equal(sha256(canonicalJson(copy)),RECEIPT_CONTENT_SHA256,"R43 irrelevance receipt content id changed");assert.equal(receipt.contentSha256,RECEIPT_CONTENT_SHA256);}
export function loadPinnedNewSourceIrrelevance({repositoryRoot:root=process.cwd(),surface}={}){
  assert(surface!==undefined);assert.equal(surface.digest,CURRENT_SURFACE);assert.equal(surface.callables.length,535);
  const sourceHashes=[sha256(bytes(root,"src/authority.ts")),sha256(bytes(root,"src/authority-cutover.ts"))].join(":");
  const cacheKey=`${path.resolve(root)}:${surface.digest}:${sourceHashes}`;
  if(cached?.key===cacheKey){for(const ref of cached.inputs)assert.equal(sha256(bytes(root,ref.file)),ref.sha256,`Cached R43 input changed: ${ref.file}`);return cached.value;}
  const receiptBytes=bytes(root,RECEIPT_FILE);assert.equal(sha256(receiptBytes),RECEIPT_SHA256,"Pinned R43 irrelevance receipt changed");const receipt=JSON.parse(receiptBytes.toString("utf8"));validateReceiptIdentity(receipt);assert.equal(receipt.status,"PASS");assert.equal(receipt.totalCurrentizableRows,429);assert.equal(receipt.producerRows,123);assert.equal(receipt.valueRows,306);assert.deepEqual(currentDelta(root),["src/authority-cutover.ts","src/authority.ts"]);
  assert.equal(receipt.changedSource.authority.newSha256,sha256(bytes(root,"src/authority.ts")));assert.equal(receipt.changedSource.authorityCutover.newSha256,sha256(bytes(root,"src/authority-cutover.ts")));
  const live=new Map(surface.callables.map(row=>[row.key,row]));
  const unique=new Map(),semantic=new Map();
  const merge=(map,file,expected,label)=>{const earlier=map.get(file);assert(earlier===undefined||earlier.sha256===expected,`Conflicting R43 ${label} ${file}`);map.set(file,{file,sha256:expected});};
  const add=(file,expected)=>{merge(unique,file,expected,"input");merge(semantic,file,expected,"semantic input");};
  const addSemantic=(file,expected)=>merge(semantic,file,expected,"semantic input");
  add(RECEIPT_FILE,RECEIPT_SHA256);add(receipt.corrected471.registry.file,receipt.corrected471.registry.sha256);add(receipt.corrected471.report.file,receipt.corrected471.report.sha256);add("src/authority.ts",receipt.changedSource.authority.newSha256);add("src/authority-cutover.ts",receipt.changedSource.authorityCutover.newSha256);
  for(const family of receipt.families){add(family.artifact.file,family.artifact.sha256);for(const ref of family.reachableFiles)add(ref.file,ref.sha256);for(const ref of family.inheritedCurrentInputs??[])addSemantic(ref.file,ref.sha256);for(const proof of family.proofs){const callable=live.get(proof.surfaceKey);assert(callable!==undefined,`R43 callable missing ${proof.surfaceKey}`);assert.equal(callable.signatureHash,proof.signatureHash,`R43 signature drift ${proof.surfaceKey}`);assert.deepEqual(callable.declaration,proof.declaration,`R43 declaration drift ${proof.surfaceKey}`);}}
  assert.equal(receipt.inheritedSemanticInputs?.references,2418,"R43 total inherited semantic input reference census changed");
  assert.equal(receipt.inheritedSemanticInputs?.uniqueCurrentFiles,435,"R43 total inherited semantic input unique-file census changed");
  assert.equal(receipt.inheritedSemanticInputs?.previouslyOmittedReferences,1707,"R43 previously omitted semantic input reference census changed");
  assert.equal(receipt.inheritedSemanticInputs?.previouslyOmittedUniqueFiles,395,"R43 previously omitted semantic input unique-file census changed");
  assert.equal(receipt.inheritedSemanticInputs?.changedInputReferences,14,"R43 reviewed Authority input substitution census changed");
  for(const ref of semantic.values())assert.equal(sha256(bytes(root,ref.file)),ref.sha256,`R43 pinned semantic input drifted: ${ref.file}`);
  const inputs=[...unique.values()].sort((a,b)=>a.file.localeCompare(b.file));
  const semanticInputs=[...semantic.values()].sort((a,b)=>a.file.localeCompare(b.file));
  const value={receipt,producerFamilies:receipt.families.filter(f=>f.modeClass==="PRODUCER"),valueFamilies:receipt.families.filter(f=>f.modeClass==="VALUE"),inputs,semanticInputs};cached={key:cacheKey,inputs:semanticInputs,value};return value;
}
