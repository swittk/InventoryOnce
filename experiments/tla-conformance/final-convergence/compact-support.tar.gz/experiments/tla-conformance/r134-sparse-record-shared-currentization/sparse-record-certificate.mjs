import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  canonicalJson,
  discoverCompilerSurface,
  loadCompilerContext,
  sha256,
  spanOf,
  ts,
} from "../surface-bindings/lib/compiler-surface.mjs";
import { findFunction, normalizeCallable } from "../authority-r5/catalog-published-source-equations.mjs";

/** Final reviewed public surface for the sparse-record current-source dependency. */
export const R134_CURRENT_SURFACE =
  "ec078013972d9ee2b4ba84d28cfa7449a18dc29679d81766e314db6a6139b81e";
/** Final reviewed product source commit whose sparse-record bytes are certified. */
export const R134_CURRENT_SOURCE = "428f50a0abdf1dec0d96d36419d51df106247044";
/** Sparse helper source whose own-key semantics are independently specified. */
export const SPARSE_RECORD_SOURCE = "src/sparse-record.ts";
/** Persisted compact receipt for downstream current-source families. */
export const SPARSE_RECORD_RECEIPT =
  "experiments/tla-conformance/r134-sparse-record-shared-currentization/sparse-record-certificate.json";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../..");
const HELPER_KEYS = Object.freeze([
  "src/sparse-record.ts#inventorySparseRecordHas",
  "src/sparse-record.ts#inventorySparseRecordValue",
]);
let cached;

/** Parse one independently stated sparse-record helper equation. */
function expectedFunction(source) {
  const file = ts.createSourceFile("r134-sparse-record.expected.ts", source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  assert.equal(file.parseDiagnostics.length, 0);
  return findFunction(file, "expected");
}

/** Re-derive both helper equations against independently stated own-key semantics. */
export function buildSparseRecordCertificate({ sourceOverrides = new Map() } = {}) {
  const surface = discoverCompilerSurface(ROOT);
  assert.equal(surface.digest, R134_CURRENT_SURFACE);
  assert.equal(surface.callables.length, 535);
  const context = loadCompilerContext(ROOT);
  const sourceText = sourceOverrides.get(SPARSE_RECORD_SOURCE) ?? fs.readFileSync(path.resolve(ROOT, SPARSE_RECORD_SOURCE), "utf8");
  const source = sourceOverrides.has(SPARSE_RECORD_SOURCE)
    ? ts.createSourceFile(path.resolve(ROOT, SPARSE_RECORD_SOURCE), sourceText, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS)
    : context.program.getSourceFile(path.resolve(ROOT, SPARSE_RECORD_SOURCE));
  assert.notEqual(source, undefined);
  const expected = new Map([
    [
      "inventorySparseRecordHas",
      expectedFunction("function expected(record, key) { return Object.prototype.hasOwnProperty.call(record, key); }"),
    ],
    [
      "inventorySparseRecordValue",
      expectedFunction("function expected(record, key) { return inventorySparseRecordHas(record, key) ? record[key] : undefined; }"),
    ],
  ]);
  const equations = [];
  for (const name of ["inventorySparseRecordHas", "inventorySparseRecordValue"]) {
    const actualDeclaration = findFunction(source, name);
    const expectedDeclaration = expected.get(name);
    assert.notEqual(expectedDeclaration, undefined);
    const actualTerm = normalizeCallable(actualDeclaration);
    const expectedTerm = normalizeCallable(expectedDeclaration);
    assert.deepEqual(actualTerm, expectedTerm, `Sparse-record equation changed: ${name}`);
    equations.push({
      key: `src/sparse-record.ts#${name}`,
      declaration: sourceOverrides.size === 0 ? spanOf(context, actualDeclaration) : { file: SPARSE_RECORD_SOURCE, mutationControl: true },
      termSha256: sha256(canonicalJson(actualTerm)),
      term: actualTerm,
    });
  }
  if (sourceOverrides.size > 0) return { mutationControlAccepted: true };
  const core = {
    schemaVersion: 1,
    status: "CURRENT_INDEPENDENT_SPARSE_RECORD_EQUATIONS",
    sourceBase: R134_CURRENT_SOURCE,
    surfaceDigest: surface.digest,
    source: {
      file: SPARSE_RECORD_SOURCE,
      sha256: sha256(fs.readFileSync(path.resolve(ROOT, SPARSE_RECORD_SOURCE))),
    },
    independentSpecification: {
      kind: "R134_NON_EXECUTED_SOURCE_EQUATIONS",
      historicalEquivalentVerifier: {
        file: "experiments/tla-conformance/value-contracts/catalog-family.mjs",
        sha256: sha256(fs.readFileSync(path.resolve(ROOT, "experiments/tla-conformance/value-contracts/catalog-family.mjs"))),
      },
    },
    laws: [
      {
        key: HELPER_KEYS[0],
        law: "Own-key membership is exactly Object.prototype.hasOwnProperty.call(record, key); inherited prototype properties never count.",
      },
      {
        key: HELPER_KEYS[1],
        law: "Value lookup returns record[key] exactly when the record owns key, otherwise undefined; inherited properties are never observable values.",
      },
    ],
    equations,
    proofCreditGrantedByThisReceipt: 0,
  };
  return { ...core, contentSha256: sha256(canonicalJson(core)) };
}

/** Verify the persisted receipt and cache the independently re-derived result in this process. */
export function verifySparseRecordCertificate() {
  if (cached !== undefined) return cached;
  const expected = buildSparseRecordCertificate();
  const actual = JSON.parse(fs.readFileSync(path.resolve(ROOT, SPARSE_RECORD_RECEIPT), "utf8"));
  assert.deepEqual(actual, expected, "Sparse-record current certificate differs from independent source equations.");
  cached = actual;
  return actual;
}

/** Write or compare the deterministic compact receipt. */
async function main() {
  const expected = buildSparseRecordCertificate();
  const file = path.resolve(ROOT, SPARSE_RECORD_RECEIPT);
  const text = `${JSON.stringify(expected, null, 2)}\n`;
  if (process.argv.includes("--check")) {
    assert.equal(fs.readFileSync(file, "utf8"), text, "Sparse-record current certificate is stale.");
  } else {
    fs.writeFileSync(file, text);
  }
  if (process.argv.includes("--mutation-control")) {
    const source = fs.readFileSync(path.resolve(ROOT, SPARSE_RECORD_SOURCE), "utf8");
    const changed = source.replace(
      "return Object.prototype.hasOwnProperty.call(record, key);",
      "return key in record;",
    );
    assert.notEqual(changed, source);
    assert.throws(
      () => buildSparseRecordCertificate({ sourceOverrides: new Map([[SPARSE_RECORD_SOURCE, changed]]) }),
      /Sparse-record equation changed: inventorySparseRecordHas/u,
    );
  }
  process.stdout.write(`${JSON.stringify({ status: "PASS", contentSha256: expected.contentSha256, equations: expected.equations.length })}\n`);
}

if (process.argv[1] !== undefined && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  await main();
}
