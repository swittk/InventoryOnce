import assert from "node:assert/strict";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { ts } from "../surface-bindings/lib/compiler-surface.mjs";
import { LOCAL_EQUATION_IDS } from "../transfer-surface-r6/source-equations-r7/contracts.mjs";

const currentSource = "6cafd49ff4b3729f80ae35d9fc0220f7a8a4b55a";
const surfaceDigest = "cc97e53a60ad9a4a700ee0c21f926e05b3a09dbd1ee739d94354a228fc47877a";
const changedIds = new Set([
  "src/corrections.ts#createInventoryCorrectionEvent",
  "src/corrections.ts#projectHistoryWithReplacement",
  "src/facade.ts#InventoryOnceTransfersImplementation.find",
  "src/facade.ts#commitInventoryTransferOperation",
  "src/facade.ts#createInventoryOnceEventResult",
  "src/facade.ts#requirePublishedInventoryTransfer",
  "src/projection.ts#applyIndexedIdentityMutations",
  "src/projection.ts#applyInventoryCommittedEventInternal",
  "src/projection.ts#emptyInventoryProjectionState",
  "src/transfers.ts#applyInventoryTransferLifecycleEvent",
]);
const helpers = new Set([
  "createInventorySparseRecord",
  "inventorySparseRecordValue",
  "setInventorySparseRecordValue",
  "cloneInventorySparseRecord",
]);
function sha(value) { return crypto.createHash("sha256").update(value).digest("hex"); }
function parse(file, text) {
  const source = ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  assert.equal(source.parseDiagnostics.length, 0, `parse failed: ${file}`);
  return source;
}
function findCallable(source, id) {
  const qualified = id.slice(id.indexOf("#") + 1);
  const parts = qualified.split(".");
  if (parts.length === 1) {
    const rows = source.statements.filter((row) => ts.isFunctionDeclaration(row) && row.name?.text === qualified && row.body);
    assert.equal(rows.length, 1, `missing function ${id}`);
    return rows[0];
  }
  const owners = source.statements.filter((row) => ts.isClassDeclaration(row) && row.name?.text === parts[0]);
  assert.equal(owners.length, 1, `missing class ${parts[0]}`);
  const rows = owners[0].members.filter((row) => parts[1] === "constructor"
    ? ts.isConstructorDeclaration(row)
    : ts.isMethodDeclaration(row) && ts.isIdentifier(row.name) && row.name.text === parts[1] && row.body);
  assert.equal(rows.length, 1, `missing member ${id}`);
  return rows[0];
}
function children(node) { const out = []; ts.forEachChild(node, (child) => { out.push(child); }); return out; }
function callName(node) { return ts.isCallExpression(node) && ts.isIdentifier(node.expression) ? node.expression.text : null; }
function leafText(node) {
  if (ts.isIdentifier(node) || ts.isStringLiteral(node) || ts.isNumericLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) return node.text;
  return null;
}
function equivalent(oldNode, currentNode, rewrites) {
  if (ts.isElementAccessExpression(oldNode) && callName(currentNode) === "inventorySparseRecordValue") {
    assert.equal(currentNode.arguments.length, 2);
    if (!equivalent(oldNode.expression, currentNode.arguments[0], rewrites)) return false;
    if (!equivalent(oldNode.argumentExpression, currentNode.arguments[1], rewrites)) return false;
    rewrites.inventorySparseRecordValue += 1;
    return true;
  }
  if (ts.isObjectLiteralExpression(oldNode) && oldNode.properties.length === 0 && callName(currentNode) === "createInventorySparseRecord") {
    assert.equal(currentNode.arguments.length, 0);
    rewrites.createInventorySparseRecord += 1;
    return true;
  }
  if (ts.isBinaryExpression(oldNode) && oldNode.operatorToken.kind === ts.SyntaxKind.EqualsToken && ts.isElementAccessExpression(oldNode.left) && callName(currentNode) === "setInventorySparseRecordValue") {
    assert.equal(currentNode.arguments.length, 3);
    if (!equivalent(oldNode.left.expression, currentNode.arguments[0], rewrites)) return false;
    if (!equivalent(oldNode.left.argumentExpression, currentNode.arguments[1], rewrites)) return false;
    if (!equivalent(oldNode.right, currentNode.arguments[2], rewrites)) return false;
    rewrites.setInventorySparseRecordValue += 1;
    return true;
  }
  if (ts.isObjectLiteralExpression(oldNode) && oldNode.properties.length === 1 && ts.isSpreadAssignment(oldNode.properties[0]) && callName(currentNode) === "cloneInventorySparseRecord") {
    assert.equal(currentNode.arguments.length, 1);
    if (!equivalent(oldNode.properties[0].expression, currentNode.arguments[0], rewrites)) return false;
    rewrites.cloneInventorySparseRecord += 1;
    return true;
  }
  if (oldNode.kind !== currentNode.kind) return false;
  const oldText = leafText(oldNode), currentText = leafText(currentNode);
  if (oldText !== null || currentText !== null) return oldText === currentText;
  const left = children(oldNode), right = children(currentNode);
  if (left.length !== right.length) return false;
  for (let i = 0; i < left.length; i += 1) if (!equivalent(left[i], right[i], rewrites)) return false;
  return true;
}

const files = [...new Set(LOCAL_EQUATION_IDS.map((id) => id.slice(0, id.indexOf("#"))))];
const currentByFile = new Map();
const expectedByFile = new Map();
for (const file of files) {
  currentByFile.set(file, parse(file, fs.readFileSync(file, "utf8")));
  const expected = path.join("experiments/tla-conformance/transfer-surface-r6/source-equations-r7/expected", `${path.basename(file, ".ts")}.expected.ts.txt`);
  expectedByFile.set(file, parse(expected, fs.readFileSync(expected, "utf8")));
}
const equationRows = [];
let unchanged = 0;
for (const id of LOCAL_EQUATION_IDS) {
  const file = id.slice(0, id.indexOf("#"));
  const oldNode = findCallable(expectedByFile.get(file), id);
  const currentNode = findCallable(currentByFile.get(file), id);
  const rewrites = { createInventorySparseRecord: 0, inventorySparseRecordValue: 0, setInventorySparseRecordValue: 0, cloneInventorySparseRecord: 0 };
  const ok = equivalent(oldNode, currentNode, rewrites);
  const rewriteCount = Object.values(rewrites).reduce((a,b) => a+b, 0);
  if (!ok) throw new Error(`Unclassified semantic change: ${id}`);
  if (changedIds.has(id)) assert(rewriteCount > 0, `Expected sparse-record transition missing: ${id}`);
  else { assert.equal(rewriteCount, 0, `Unexpected transition outside frozen ten: ${id}`); unchanged += 1; }
  equationRows.push({ id, rewriteCount, rewrites });
}
assert.equal(unchanged, 66);
assert.equal(equationRows.filter((row) => row.rewriteCount > 0).length, 10);

const sparseSource = fs.readFileSync("src/sparse-record.ts", "utf8");
const sparseAst = parse("src/sparse-record.ts", sparseSource);
const sparseFunctions = {};
for (const name of [...helpers, "cloneInventorySparseRecord"]) {
  const fn = sparseAst.statements.find((row) => ts.isFunctionDeclaration(row) && row.name?.text === name);
  assert(fn?.body, `missing sparse helper ${name}`);
  sparseFunctions[name] = sha(fn.getText(sparseAst));
}
const r134 = JSON.parse(fs.readFileSync("experiments/tla-conformance/r137-transfer-correction-r118-currentization/r134-sparse-record-certificate.json", "utf8"));
assert.equal(r134.status, "CURRENT_INDEPENDENT_SPARSE_RECORD_EQUATIONS");
assert.equal(r134.sourceBase, currentSource);
assert.equal(r134.surfaceDigest, surfaceDigest);
assert.equal(r134.source.sha256, sha(sparseSource));
assert.deepEqual(r134.laws.map((row) => row.key).sort(), [
  "src/sparse-record.ts#inventorySparseRecordHas",
  "src/sparse-record.ts#inventorySparseRecordValue",
]);
const output = {
  schemaVersion: 1,
  status: "CURRENT_R118_TRANSFER_CORRECTION_TRANSITION_CLASSIFIED",
  sourceBase: currentSource,
  surfaceDigest,
  historicalFamily: "inventoryonce-transfer-correction-complete-source-equations-v2",
  equations: { total: LOCAL_EQUATION_IDS.length, unchanged, transitioned: 10, rows: equationRows.filter((row) => row.rewriteCount > 0) },
  sparseRecord: {
    sourceSha256: sha(sparseSource),
    functionAstTextSha256: sparseFunctions,
    r134CertificateSha256: sha(fs.readFileSync("experiments/tla-conformance/r137-transfer-correction-r118-currentization/r134-sparse-record-certificate.json")),
    establishedLaws: r134.laws,
    additionalDirectSourceLaws: [
      "createInventorySparseRecord returns a fresh Object.create(null) record.",
      "setInventorySparseRecordValue defines one own enumerable/configurable/writable data property without invoking __proto__ setters.",
      "cloneInventorySparseRecord copies Object.entries into a fresh prototype-free record through setInventorySparseRecordValue.",
    ],
  },
  proofCreditGrantedByThisReceipt: 0,
};
output.contentSha256 = sha(JSON.stringify(output));
const target = "experiments/tla-conformance/r137-transfer-correction-r118-currentization/transition-classification.json";
fs.writeFileSync(target, `${JSON.stringify(output, null, 2)}\n`);
console.log(JSON.stringify({ status: output.status, unchanged, transitioned: 10, rewriteTotals: equationRows.reduce((acc,row) => { for (const [k,v] of Object.entries(row.rewrites)) acc[k]=(acc[k]??0)+v; return acc; }, {}), contentSha256: output.contentSha256 }, null, 2));
