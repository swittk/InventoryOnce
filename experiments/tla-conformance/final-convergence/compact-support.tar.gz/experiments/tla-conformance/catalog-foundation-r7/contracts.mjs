/** Stable identity for the complete catalogue-foundation source-equation family. */
export const CATALOG_FOUNDATION_FAMILY_ID =
  "inventoryonce.catalog-foundation.closed-source-equations.v1";

/** Exact public aliases assigned by the catalogue-foundation owner manifest. */
export const ASSIGNED_SURFACE_KEYS = Object.freeze([
  "export:.#InventoryCatalog.define::call[0]",
  "export:.#assertInventoryCatalogRetainsSnapshot::call[0]",
  "export:.#assertMeasurementsMatchItem::call[0]",
  "export:.#assertPositionMatchesItem::call[0]",
  "export:.#defineInventoryCatalog::call[0]",
  "export:.#defineInventoryCollection::call[0]",
  "export:.#defineInventoryComposition::call[0]",
  "export:.#defineInventoryFungibilityPool::call[0]",
  "export:.#defineInventoryItem::call[0]",
  "export:.#defineInventoryPackaging::call[0]",
  "export:.#defineInventoryTransformation::call[0]",
  "export:.#defineScalarInventoryFungibilityPool::call[0]",
  "export:.#defineScalarInventoryItem::call[0]",
  "export:.#defineScalarInventoryPackaging::call[0]",
  "export:.#emptyInventoryCatalogSnapshot::call[0]",
  "export:.#extendInventoryCatalog::call[0]",
  "export:.#inventoryCatalogFromSnapshot::call[0]",
  "export:./kernel#InventoryCatalog.define::call[0]",
  "export:./kernel#assertInventoryCatalogRetainsSnapshot::call[0]",
  "export:./kernel#assertMeasurementsMatchItem::call[0]",
  "export:./kernel#assertPositionMatchesItem::call[0]",
  "export:./kernel#defineInventoryCatalog::call[0]",
  "export:./kernel#defineInventoryCollection::call[0]",
  "export:./kernel#defineInventoryComposition::call[0]",
  "export:./kernel#defineInventoryFungibilityPool::call[0]",
  "export:./kernel#defineInventoryItem::call[0]",
  "export:./kernel#defineInventoryPackaging::call[0]",
  "export:./kernel#defineInventoryTransformation::call[0]",
  "export:./kernel#defineScalarInventoryFungibilityPool::call[0]",
  "export:./kernel#defineScalarInventoryItem::call[0]",
  "export:./kernel#defineScalarInventoryPackaging::call[0]",
  "export:./kernel#emptyInventoryCatalogSnapshot::call[0]",
  "export:./kernel#extendInventoryCatalog::call[0]",
  "export:./kernel#inventoryCatalogFromSnapshot::call[0]",
  "type:src/catalog.ts#InventoryCatalog.activeFungibilityPool::call[0]",
  "type:src/catalog.ts#InventoryCatalog.fungibilityRevision::call[0]",
]);

/** Catalogue-owned callables independently specified by this family. */
export const LOCAL_EQUATION_IDS = Object.freeze([
  "src/catalog.ts#InventoryCatalog.activeFungibilityPool",
  "src/catalog.ts#InventoryCatalog.constructor",
  "src/catalog.ts#InventoryCatalog.define",
  "src/catalog.ts#InventoryCatalog.fungibilityRevision",
  "src/catalog.ts#assertCompositionOutputLotPolicy",
  "src/catalog.ts#assertInventoryCatalogRetainsSnapshot",
  "src/catalog.ts#assertMeasurementAxis",
  "src/catalog.ts#assertPositionMatchesItem",
  "src/catalog.ts#assertTrackingRequirement",
  "src/catalog.ts#cloneAndFreezeInventoryCollectionRevision",
  "src/catalog.ts#cloneAndFreezeInventoryCompositionRevision",
  "src/catalog.ts#cloneAndFreezeInventoryFungibilityRevision",
  "src/catalog.ts#cloneAndFreezeInventoryIdentifiers",
  "src/catalog.ts#cloneAndFreezeInventoryItemRevision",
  "src/catalog.ts#cloneAndFreezeInventoryMeasurements",
  "src/catalog.ts#cloneAndFreezeInventoryMetadata",
  "src/catalog.ts#cloneAndFreezeInventoryMetadataValue",
  "src/catalog.ts#cloneAndFreezeInventoryPackagingRevision",
  "src/catalog.ts#cloneAndFreezeQuantity",
  "src/catalog.ts#compareCollectionMember",
  "src/catalog.ts#compareCollectionRevision",
  "src/catalog.ts#compareCollectionRollup",
  "src/catalog.ts#compareCollectionRollupMember",
  "src/catalog.ts#compareCompositionOutput",
  "src/catalog.ts#compareCompositionRevision",
  "src/catalog.ts#compareDimensionDefinition",
  "src/catalog.ts#compareFungibilityMember",
  "src/catalog.ts#compareFungibilityRevision",
  "src/catalog.ts#compareItemRevision",
  "src/catalog.ts#compareMeasurementAxisDefinition",
  "src/catalog.ts#comparePackagingRevision",
  "src/catalog.ts#compareTransformationLine",
  "src/catalog.ts#createInventoryCatalogParts",
  "src/catalog.ts#defineInventoryCatalog",
  "src/catalog.ts#defineInventoryCollection",
  "src/catalog.ts#defineInventoryComposition",
  "src/catalog.ts#defineInventoryFungibilityPool",
  "src/catalog.ts#defineInventoryItem",
  "src/catalog.ts#defineInventoryPackaging",
  "src/catalog.ts#defineInventoryTransformation",
  "src/catalog.ts#defineScalarInventoryFungibilityPool",
  "src/catalog.ts#defineScalarInventoryItem",
  "src/catalog.ts#defineScalarInventoryPackaging",
  "src/catalog.ts#emptyInventoryCatalogSnapshot",
  "src/catalog.ts#extendInventoryCatalog",
  "src/catalog.ts#findItemMeasurementAxis",
  "src/catalog.ts#inventoryCatalogDigest",
  "src/catalog.ts#inventoryCatalogFromSnapshot",
  "src/catalog.ts#inventoryCollectionRevisionDigest",
  "src/catalog.ts#inventoryCompositionRevisionDigest",
  "src/catalog.ts#inventoryFungibilityRevisionDigest",
  "src/catalog.ts#inventoryItemRevisionDigest",
  "src/catalog.ts#inventoryPackagingRevisionDigest",
  "src/catalog.ts#inventoryTransformationRevisionDigest",
  "src/catalog.ts#measurementAxisDefinitionDigest",
  "src/catalog.ts#mergeInventoryCatalogRevisionFamily",
  "src/catalog.ts#normalizeInventoryCollectionDefinitions",
  "src/catalog.ts#normalizeInventoryCollectionRollups",
  "src/catalog.ts#normalizeInventoryCompositionOutput",
  "src/catalog.ts#quantityDefinitionDigest",
  "src/catalog.ts#stringRecordDigest",
  "src/catalog.ts#validateCompositionGraph",
  "src/catalog.ts#validateInnerPackaging",
  "src/sparse-record.ts#createInventorySparseRecord",
  "src/sparse-record.ts#setInventorySparseRecordValue",
  "src/digest.ts#inventorySha256",
  "src/digest.ts#rotateRight",
  "src/measurements.ts#inventoryMeasurementsFingerprint",
  "src/measurements.ts#measurementFingerprint",
  "src/measurements.ts#scalarInventoryMeasurements",
]);

/** Runtime constants whose exact definitions are part of the local equations. */
export const SUPPORTING_VALUE_IDS = Object.freeze([
  "src/catalog.ts#InventoryCollectionMemberKind",
  "src/catalog.ts#InventoryCompositionOutputAmountKind",
  "src/catalog.ts#InventoryCompositionOutputLotPolicy",
  "src/catalog.ts#InventoryMeasurementAxisRole",
  "src/catalog.ts#InventoryMeasurementRequirement",
  "src/catalog.ts#InventoryTrackingRequirement",
  "src/digest.ts#SHA256_INITIAL_HASH",
  "src/digest.ts#SHA256_ROUND_CONSTANTS",
]);

/** Production files required to bind every public alias and resolved call edge. */
export const SOURCE_FILES = Object.freeze([
  "src/canonical.ts",
  "src/catalog.ts",
  "src/digest.ts",
  "src/index.ts",
  "src/kernel.ts",
  "src/measurements.ts",
  "src/model.ts",
  "src/ordering.ts",
  "src/quantity.ts",
  "src/sparse-record.ts",
]);

/** Exact native operations allowed only after compiler resolution to installed TypeScript libraries. */
export const ALLOWED_STANDARD_OPERATIONS = Object.freeze([
  "Array.includes",
  "Array.join",
  "Array.map",
  "Array.push",
  "Array.sort",
  "Array.isArray",
  "BigInt",
  "Error",
  "Map",
  "Map.get",
  "Map.has",
  "Map.keys",
  "Map.set",
  "Map.values",
  "Math.ceil",
  "Number",
  "Number.isFinite",
  "Number.isSafeInteger",
  "Number.toString",
  "Object.create",
  "Object.defineProperty",
  "Object.entries",
  "Object.freeze",
  "Object.values",
  "Set",
  "Set.add",
  "Set.delete",
  "Set.has",
  "String.padStart",
  "String.trim",
  "TextEncoder",
  "TextEncoder.encode",
  "Uint8Array",
  "Uint8Array.set",
  "Uint32Array",
]);

/** Independently stated semantic groups attached to every local equation. */
export const FAMILY_LAWS = Object.freeze([
  Object.freeze({
    id: "catalog-definition-normalization-v1",
    equation:
      "Definitions validate exact identities, measurement axes and units, tracking, positive quantities, duplicate ids, graph membership and cycles before recursively cloning and freezing every retained value.",
  }),
  Object.freeze({
    id: "catalog-complete-construction-v1",
    equation:
      "Complete catalog construction normalizes every revision family, rejects missing or mismatched active revisions, builds exact lookup maps, sorts all retained families, validates package/composition/collection graphs, and fingerprints the resulting immutable catalog.",
  }),
  Object.freeze({
    id: "catalog-retention-and-extension-v1",
    equation:
      "Snapshot loading recomputes and checks the exact root digest; retention compares every retained revision digest; extension merges identical revisions, rejects changed identities, moves only supplied active pointers, and preserves object identity for an unchanged digest.",
  }),
  Object.freeze({
    id: "catalog-digest-identity-v1",
    equation:
      "Revision and root digests include every meaning-bearing field in fixed order, sort unordered records and revision families, preserve the legacy empty-transformation root shape, and use the complete built-in-free SHA-256 equation.",
  }),
  Object.freeze({
    id: "catalog-position-and-lookup-v1",
    equation:
      "Position validation enforces required and forbidden lot/serial identities and rejects undeclared qualified dimensions; fungibility lookups return exactly one retained revision or throw their exact unknown-identity error.",
  }),
]);

/** Choose the semantic law governing one equation without relying on source text. */
export function lawIdForEquation(equationId) {
  if (
    equationId.includes("Digest") ||
    equationId.includes("Fingerprint") ||
    equationId.startsWith("src/digest.ts#")
  ) return "catalog-digest-identity-v1";
  if (
    equationId.includes("RetainsSnapshot") ||
    equationId.includes("FromSnapshot") ||
    equationId.includes("extendInventoryCatalog") ||
    equationId.includes("mergeInventoryCatalog")
  ) return "catalog-retention-and-extension-v1";
  if (
    equationId.includes("Position") ||
    equationId.includes("TrackingRequirement") ||
    equationId.includes("FungibilityPool") ||
    equationId.includes("fungibilityRevision")
  ) return "catalog-position-and-lookup-v1";
  if (
    equationId.includes("createInventorySparseRecord") ||
    equationId.includes("createInventoryCatalogParts") ||
    equationId.includes("InventoryCatalog.constructor") ||
    equationId.includes("InventoryCatalog.define") ||
    equationId.endsWith("#defineInventoryCatalog") ||
    equationId.endsWith("#emptyInventoryCatalogSnapshot")
  ) return "catalog-complete-construction-v1";
  return "catalog-definition-normalization-v1";
}
