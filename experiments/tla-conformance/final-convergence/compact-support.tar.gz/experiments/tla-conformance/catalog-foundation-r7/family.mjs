import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  canonicalJson,
  compareCodeUnits,
  nodeAtExactSpan,
  sha256,
  spanOf,
  ts,
} from "../surface-bindings/lib/compiler-surface.mjs";
import { buildFamilyArtifact as buildQuantityValues } from "../quantity-values-r7/certificate.mjs";
import {
  buildFamilyArtifact as buildIdentityValues,
  identityValuesProofKind,
} from "../identity-values-r7/family.mjs";
import {
  buildCatalogFamilyArtifact,
  catalogProofKind,
} from "../value-contracts/catalog-family.mjs";
import {
  ALLOWED_STANDARD_OPERATIONS,
  ASSIGNED_SURFACE_KEYS,
  CATALOG_FOUNDATION_FAMILY_ID,
  FAMILY_LAWS,
  LOCAL_EQUATION_IDS,
  SOURCE_FILES,
  SUPPORTING_VALUE_IDS,
  lawIdForEquation,
} from "./contracts.mjs";
import { normalizeCatalogCallable } from "./normalize.mjs";

/** Exact production revision requested for this source-bound family. */
export const CATALOG_FOUNDATION_SOURCE_BASE =
  "2eea09471b3bf8fcb61f38256e1c6a362149dad4";

/** Strict registered-value-family discriminator for the catalogue foundation. */
export const proofKind =
  "independent-catalog-foundation-closed-equations-v1";

/** Inert independent equation program parsed without importing production code. */
const equationProgramPath = fileURLToPath(
  new URL("./equations.expected.ts.txt", import.meta.url)
);

/** Exact authority-side independent extension specification reused during authorship. */
const reusedAuthoritySpecification = Object.freeze({
  file: "authority-r5/catalog-read-laws/catalog-extension.expected.ts.txt",
  sha256: "82def6081863bbb29e41a581c8cb455b14651dd6cccb319eda757ed4251c677e",
  equationIds: Object.freeze([
    "src/catalog.ts#extendInventoryCatalog",
    "src/catalog.ts#mergeInventoryCatalogRevisionFamily",
  ]),
});

/** Source-equation implementation and specification files bound into each result. */
const producerFiles = Object.freeze([
  "experiments/tla-conformance/catalog-foundation-r7/contracts.mjs",
  "experiments/tla-conformance/catalog-foundation-r7/equations.expected.ts.txt",
  "experiments/tla-conformance/catalog-foundation-r7/family.mjs",
  "experiments/tla-conformance/catalog-foundation-r7/normalize.mjs",
]);

/** Reuse one complete immutable compiler pass only while all semantic bytes agree. */
const passCache = new WeakMap();

/** Reject one incomplete, impure, or unresolved catalogue equation. */
function fail(message) {
  throw new Error(`Catalogue-foundation equation rejected: ${message}`);
}

/** Return one exact callable identity for a source declaration. */
function declarationKey(repositoryRoot, declaration) {
  const source = declaration.getSourceFile();
  const file = path.relative(repositoryRoot, source.fileName).replaceAll("\\", "/");
  const name = ts.isConstructorDeclaration(declaration)
    ? "constructor"
    : declaration.name?.getText(source);
  assert(name !== undefined, "A source callable needs a stable name.");
  const owner = ts.isMethodDeclaration(declaration) || ts.isConstructorDeclaration(declaration)
    ? `${declaration.parent.name?.getText(source)}.`
    : "";
  return `${file}#${owner}${name}`;
}

/** Resolve one TypeScript alias to its concrete declaration symbol. */
function resolveSymbol(context, symbol) {
  return symbol !== undefined && (symbol.flags & ts.SymbolFlags.Alias) !== 0
    ? context.checker.getAliasedSymbol(symbol)
    : symbol;
}

/** Visit only runtime syntax, skipping erased types and assertion wrappers. */
function visitRuntime(node, visitor) {
  if (ts.isTypeNode(node)) return;
  visitor(node);
  if (
    ts.isAsExpression(node) ||
    ts.isTypeAssertionExpression(node) ||
    ts.isNonNullExpression(node)
  ) {
    visitRuntime(node.expression, visitor);
    return;
  }
  ts.forEachChild(node, (child) => visitRuntime(child, visitor));
}

/** Return a package source callable when a symbol denotes one ordinary body. */
function sourceCallableDeclaration(context, symbol) {
  const resolved = resolveSymbol(context, symbol);
  const callables = (resolved?.declarations ?? []).filter(
    (declaration) =>
      !declaration.getSourceFile().isDeclarationFile &&
      (
        ts.isFunctionDeclaration(declaration) ||
        ts.isMethodDeclaration(declaration) ||
        ts.isConstructorDeclaration(declaration)
      ) &&
      declaration.body !== undefined
  );
  if (callables.length === 0) return undefined;
  assert.equal(callables.length, 1, "Source callable symbol has ambiguous bodies.");
  return callables[0];
}

/** Locate one actual or expected callable from its fixed equation identity. */
function findCallable(sourceByFile, specificationSource, equationId) {
  const [file, qualifiedName] = equationId.split("#");
  const source = specificationSource ?? sourceByFile.get(file);
  assert(source !== undefined, `Missing equation source '${file}'.`);
  const pieces = qualifiedName.split(".");
  if (pieces.length === 1) {
    const matches = source.statements.filter(
      (statement) =>
        ts.isFunctionDeclaration(statement) &&
        statement.name?.text === qualifiedName &&
        statement.body !== undefined
    );
    assert.equal(matches.length, 1, `Expected one function '${equationId}'.`);
    return matches[0];
  }
  const [className, memberName] = pieces;
  const classes = source.statements.filter(
    (statement) => ts.isClassDeclaration(statement) && statement.name?.text === className
  );
  assert.equal(classes.length, 1, `Expected one class '${className}'.`);
  const members = classes[0].members.filter((member) => {
    if (memberName === "constructor") {
      return ts.isConstructorDeclaration(member) && member.body !== undefined;
    }
    return (
      ts.isMethodDeclaration(member) &&
      ts.isIdentifier(member.name) &&
      member.name.text === memberName &&
      member.body !== undefined
    );
  });
  assert.equal(members.length, 1, `Expected one member '${equationId}'.`);
  return members[0];
}

/** Locate one enum or top-level constant used by the runtime equations. */
function findSupportingValue(sourceByFile, specificationSource, valueId) {
  const [file, name] = valueId.split("#");
  const source = specificationSource ?? sourceByFile.get(file);
  assert(source !== undefined, `Missing supporting-value source '${file}'.`);
  const matches = source.statements.filter((statement) => {
    if (ts.isEnumDeclaration(statement)) return statement.name.text === name;
    if (!ts.isVariableStatement(statement)) return false;
    return statement.declarationList.declarations.some(
      (declaration) => ts.isIdentifier(declaration.name) && declaration.name.text === name
    );
  });
  assert.equal(matches.length, 1, `Expected one supporting value '${valueId}'.`);
  if (ts.isEnumDeclaration(matches[0])) return matches[0];
  const declaration = matches[0].declarationList.declarations.find(
    (candidate) => ts.isIdentifier(candidate.name) && candidate.name.text === name
  );
  assert(declaration !== undefined);
  return declaration;
}

/** Normalize the finite enum/number-array constant grammar used by this family. */
function normalizeSupportingValue(declaration) {
  if (ts.isEnumDeclaration(declaration)) {
    return [
      "enum",
      declaration.members.map((member) => [
        member.name.getText(declaration.getSourceFile()),
        member.initializer?.getText(declaration.getSourceFile()) ?? null,
      ]),
    ];
  }
  assert(ts.isVariableDeclaration(declaration));
  assert(declaration.initializer !== undefined);
  assert(ts.isArrayLiteralExpression(declaration.initializer));
  return [
    "constant-array",
    declaration.initializer.elements.map((element) => {
      assert(ts.isNumericLiteral(element), "Supporting arrays contain only numeric constants.");
      return element.text;
    }),
  ];
}

/** Map one source enum member or top-level constant to its fixed identity. */
function sourceSupportingValueId(repositoryRoot, declaration) {
  if (declaration.getSourceFile().isDeclarationFile) return undefined;
  let owner = declaration;
  if (ts.isEnumMember(owner)) owner = owner.parent;
  if (!ts.isEnumDeclaration(owner) && !ts.isVariableDeclaration(owner)) return undefined;
  if (ts.isVariableDeclaration(owner) && !ts.isSourceFile(owner.parent.parent.parent)) {
    return undefined;
  }
  const file = path.relative(repositoryRoot, owner.getSourceFile().fileName).replaceAll("\\", "/");
  const name = owner.name?.getText(owner.getSourceFile());
  return name === undefined ? undefined : `${file}#${name}`;
}

/** Resolve the exact installed TypeScript standard-library directory. */
function trustedTypeScriptLibraryDirectory(repositoryRoot) {
  const packagePath = fs.realpathSync(
    path.resolve(repositoryRoot, "node_modules/typescript/package.json")
  );
  return fs.realpathSync(path.join(path.dirname(packagePath), "lib"));
}

/** Require a declaration file to be a real installed TypeScript library file. */
function requireTrustedTypeScriptLibraryFile(repositoryRoot, fileName) {
  const trustedDirectory = trustedTypeScriptLibraryDirectory(repositoryRoot);
  const actualFile = fs.realpathSync(fileName);
  if (
    !actualFile.startsWith(`${trustedDirectory}${path.sep}`) ||
    !/^lib\.[^.].*\.d\.ts$/u.test(path.basename(actualFile))
  ) fail(`declaration '${fileName}' is outside the trusted TypeScript library.`);
  return actualFile;
}

/** Require a declaration to come from TypeScript's libraries or installed Node declarations. */
function requireTrustedStandardDeclarationFile(repositoryRoot, fileName) {
  const actualFile = fs.realpathSync(fileName);
  const typeScriptDirectory = trustedTypeScriptLibraryDirectory(repositoryRoot);
  if (
    actualFile.startsWith(`${typeScriptDirectory}${path.sep}`) &&
    /^lib\.[^.].*\.d\.ts$/u.test(path.basename(actualFile))
  ) return actualFile;
  const nodePackagePath = fs.realpathSync(
    path.resolve(repositoryRoot, "node_modules/@types/node/package.json")
  );
  const nodeDirectory = fs.realpathSync(path.dirname(nodePackagePath));
  if (
    actualFile.startsWith(`${nodeDirectory}${path.sep}`) &&
    actualFile.endsWith(".d.ts")
  ) return actualFile;
  fail(`declaration '${fileName}' is outside trusted TypeScript and Node libraries.`);
}

/** Reject locally replaced standard roots such as Object, Map, or TextEncoder. */
function validateStandardRootIdentity(context, call) {
  const expression = call.expression;
  let root;
  if (
    ts.isIdentifier(expression) &&
    ["BigInt", "Error", "Map", "Number", "Set", "TextEncoder", "Uint8Array", "Uint32Array"].includes(expression.text)
  ) {
    root = expression;
  } else if (
    ts.isPropertyAccessExpression(expression) &&
    ts.isIdentifier(expression.expression) &&
    ["Array", "Math", "Number", "Object"].includes(expression.expression.text)
  ) {
    root = expression.expression;
  }
  if (root === undefined) return;
  const symbol = resolveSymbol(context, context.checker.getSymbolAtLocation(root));
  if (symbol === undefined || (symbol.declarations ?? []).length === 0) {
    fail(`standard root '${root.text}' has no compiler declaration identity.`);
  }
  const runtimeDeclarations = symbol.declarations.filter(
    (declaration) =>
      ts.isVariableDeclaration(declaration) ||
      ts.isFunctionDeclaration(declaration) ||
      ts.isClassDeclaration(declaration) ||
      ts.isEnumDeclaration(declaration) ||
      ts.isInterfaceDeclaration(declaration)
  );
  if (runtimeDeclarations.length === 0) {
    fail(`standard root '${root.text}' has no runtime declaration.`);
  }
  for (const declaration of runtimeDeclarations) {
    if (!declaration.getSourceFile().isDeclarationFile) {
      fail(`standard root '${root.text}' was replaced by package source.`);
    }
    requireTrustedStandardDeclarationFile(context.repositoryRoot, declaration.getSourceFile().fileName);
  }
}

/** Derive one stable native-operation identity from the compiler-selected declaration. */
function standardOperation(context, call, target) {
  requireTrustedStandardDeclarationFile(context.repositoryRoot, target.getSourceFile().fileName);
  validateStandardRootIdentity(context, call);
  const expression = call.expression;
  if (ts.isIdentifier(expression)) return expression.text;
  if (!ts.isPropertyAccessExpression(expression)) {
    fail(`dynamic native call '${expression.getText()}' is outside the plain-value domain.`);
  }
  if (ts.isIdentifier(expression.expression)) {
    const root = expression.expression.text;
    if (["Array", "Math", "Number", "Object"].includes(root)) {
      return `${root}.${expression.name.text}`;
    }
  }
  let ownerName = target.parent?.name?.getText(target.getSourceFile());
  if (ownerName === "ReadonlyArray") ownerName = "Array";
  if (ownerName === "ReadonlyMap") ownerName = "Map";
  if (ownerName === "ReadonlySet") ownerName = "Set";
  if (ownerName === "Number") ownerName = "Number";
  if (ownerName === undefined) {
    fail(`native call '${expression.getText()}' has no fixed receiver declaration.`);
  }
  return `${ownerName}.${expression.name.text}`;
}

/** Return whether one declaration is lexically nested inside the inspected callable. */
function isNestedInside(declaration, owner) {
  return (
    declaration.getSourceFile() === owner.getSourceFile() &&
    declaration.getStart() >= owner.body.getStart() &&
    declaration.getEnd() <= owner.body.getEnd()
  );
}

/** Return a same-callable parameter index for a callback call, when present. */
function callbackParameterIndex(context, owner, call) {
  if (!ts.isIdentifier(call.expression)) return undefined;
  const symbol = resolveSymbol(context, context.checker.getSymbolAtLocation(call.expression));
  for (let index = 0; index < owner.parameters.length; index += 1) {
    const parameter = owner.parameters[index];
    const parameterSymbol = ts.isIdentifier(parameter.name)
      ? resolveSymbol(context, context.checker.getSymbolAtLocation(parameter.name))
      : undefined;
    if (parameterSymbol !== undefined && parameterSymbol === symbol) return index;
  }
  return undefined;
}

/** Inspect one actual body for source, constant, native, callback, and accessor dependencies. */
function inspectActualEquation(context, repositoryRoot, declaration) {
  const sourceDependencies = new Set();
  const supportingValues = new Set();
  const standardOperations = new Set();
  const standardDeclarations = new Map();
  const callbackDependencies = new Set();
  const discoveredCallables = new Map();
  visitRuntime(declaration.body, (node) => {
    if (ts.isPropertyAccessExpression(node) || ts.isElementAccessExpression(node)) {
      const symbolNode = ts.isPropertyAccessExpression(node) ? node.name : node.argumentExpression;
      const symbol = symbolNode === undefined
        ? undefined
        : resolveSymbol(context, context.checker.getSymbolAtLocation(symbolNode));
      for (const candidate of symbol?.declarations ?? []) {
        if (ts.isGetAccessorDeclaration(candidate) || ts.isSetAccessorDeclaration(candidate)) {
          fail(`accessor-backed value '${node.getText()}' is outside the immutable data domain.`);
        }
      }
    }
    if (ts.isIdentifier(node)) {
      const symbol = resolveSymbol(context, context.checker.getSymbolAtLocation(node));
      const callable = sourceCallableDeclaration(context, symbol);
      if (callable !== undefined && callable !== declaration && !isNestedInside(callable, declaration)) {
        const key = declarationKey(repositoryRoot, callable);
        sourceDependencies.add(key);
        discoveredCallables.set(key, callable);
      }
      for (const candidate of symbol?.declarations ?? []) {
        const valueId = sourceSupportingValueId(repositoryRoot, candidate);
        if (valueId !== undefined) {
          if (!SUPPORTING_VALUE_IDS.includes(valueId)) {
            fail(`unknown nonlocal runtime value '${valueId}' in '${declarationKey(repositoryRoot, declaration)}'.`);
          }
          supportingValues.add(valueId);
        }
      }
    }
    if (ts.isCallExpression(node) || ts.isNewExpression(node)) {
      const callbackIndex = callbackParameterIndex(context, declaration, node);
      if (callbackIndex !== undefined) {
        callbackDependencies.add(`parameter:${callbackIndex}`);
        return;
      }
      const target = context.checker.getResolvedSignature(node)?.declaration;
      if (target === undefined) fail(`unresolved call '${node.getText()}'.`);
      if (isNestedInside(target, declaration)) return;
      if (target.getSourceFile().isDeclarationFile) {
        const operation = standardOperation(context, node, target);
        if (!ALLOWED_STANDARD_OPERATIONS.includes(operation)) {
          fail(`native operation '${operation}' is not independently admitted.`);
        }
        standardOperations.add(operation);
        const targetSpan = spanOf(context, target);
        standardDeclarations.set(
          `${operation}:${targetSpan.file}:${targetSpan.start.offset}`,
          { operation, declaration: targetSpan }
        );
        return;
      }
      if (
        (
          ts.isFunctionDeclaration(target) ||
          ts.isMethodDeclaration(target) ||
          ts.isConstructorDeclaration(target)
        ) &&
        target.body !== undefined
      ) {
        const key = declarationKey(repositoryRoot, target);
        sourceDependencies.add(key);
        discoveredCallables.set(key, target);
        return;
      }
      fail(`source call '${node.getText()}' has no named equation body.`);
    }
  });
  return {
    sourceDependencies: [...sourceDependencies].sort(compareCodeUnits),
    supportingValues: [...supportingValues].sort(compareCodeUnits),
    standardOperations: [...standardOperations].sort(compareCodeUnits),
    standardDeclarations: [...standardDeclarations.values()].sort((left, right) =>
      compareCodeUnits(
        `${left.operation}:${left.declaration.file}:${left.declaration.start.offset}`,
        `${right.operation}:${right.declaration.file}:${right.declaration.start.offset}`
      )
    ),
    callbackDependencies: [...callbackDependencies].sort(compareCodeUnits),
    discoveredCallables,
  };
}

/** Return dependency names declared by the independent expected equation program. */
function expectedDependencies(declaration, allEquationIds) {
  const functionByName = new Map();
  const methodByName = new Map();
  for (const equationId of allEquationIds) {
    const qualifiedName = equationId.split("#")[1];
    const pieces = qualifiedName.split(".");
    if (pieces.length === 1) functionByName.set(pieces[0], equationId);
    else methodByName.set(pieces[1], equationId);
  }
  const supportingByName = new Map(
    SUPPORTING_VALUE_IDS.map((valueId) => [valueId.split("#")[1], valueId])
  );
  const sourceDependencies = new Set();
  const supportingValues = new Set();
  visitRuntime(declaration.body, (node) => {
    if (ts.isIdentifier(node)) {
      const supporting = supportingByName.get(node.text);
      if (supporting !== undefined) supportingValues.add(supporting);
    }
    if (ts.isCallExpression(node) || ts.isNewExpression(node)) {
      if (ts.isIdentifier(node.expression)) {
        if (ts.isNewExpression(node) && node.expression.text === "InventoryCatalog") {
          sourceDependencies.add("src/catalog.ts#InventoryCatalog.constructor");
        } else {
          const dependency = functionByName.get(node.expression.text);
          if (dependency !== undefined) sourceDependencies.add(dependency);
        }
      } else if (ts.isPropertyAccessExpression(node.expression)) {
        const dependency = methodByName.get(node.expression.name.text);
        if (dependency !== undefined) sourceDependencies.add(dependency);
      }
      for (const argument of node.arguments ?? []) {
        if (!ts.isIdentifier(argument)) continue;
        const dependency = functionByName.get(argument.text);
        if (dependency !== undefined) sourceDependencies.add(dependency);
      }
    }
  });
  return {
    sourceDependencies: [...sourceDependencies].sort(compareCodeUnits),
    supportingValues: [...supportingValues].sort(compareCodeUnits),
  };
}

/** Declare the only higher-order parameter calls in the local source closure. */
function expectedCallbackDependencies(equationId) {
  return equationId === "src/catalog.ts#mergeInventoryCatalogRevisionFamily"
    ? ["parameter:2", "parameter:3"]
    : [];
}

/** Count explicit mutation and control effects already represented in a complete term. */
function effectProfile(declaration) {
  const profile = {
    assignments: 0,
    propertyAssignments: 0,
    thisAssignments: 0,
    updates: 0,
    throws: 0,
    returns: 0,
    breaks: 0,
    continues: 0,
    mutatingMethodCalls: [],
  };
  const mutatingMethods = new Set(["add", "delete", "push", "set", "sort"]);
  visitRuntime(declaration.body, (node) => {
    if (
      ts.isBinaryExpression(node) &&
      node.operatorToken.kind >= ts.SyntaxKind.FirstAssignment &&
      node.operatorToken.kind <= ts.SyntaxKind.LastAssignment
    ) {
      profile.assignments += 1;
      if (ts.isPropertyAccessExpression(node.left) || ts.isElementAccessExpression(node.left)) {
        profile.propertyAssignments += 1;
        const receiver = node.left.expression;
        if (receiver.kind === ts.SyntaxKind.ThisKeyword) profile.thisAssignments += 1;
      }
    }
    if (
      (ts.isPrefixUnaryExpression(node) || ts.isPostfixUnaryExpression(node)) &&
      [ts.SyntaxKind.PlusPlusToken, ts.SyntaxKind.MinusMinusToken].includes(node.operator)
    ) profile.updates += 1;
    if (ts.isThrowStatement(node)) profile.throws += 1;
    if (ts.isReturnStatement(node)) profile.returns += 1;
    if (ts.isBreakStatement(node)) profile.breaks += 1;
    if (ts.isContinueStatement(node)) profile.continues += 1;
    if (
      ts.isCallExpression(node) &&
      ts.isPropertyAccessExpression(node.expression) &&
      mutatingMethods.has(node.expression.name.text)
    ) profile.mutatingMethodCalls.push(node.expression.name.text);
  });
  profile.mutatingMethodCalls.sort(compareCodeUnits);
  return profile;
}

/** Build a compiler program whose in-memory mutations retain real resolution. */
function loadOverriddenContext(repositoryRoot, sourceOverrides) {
  const root = path.resolve(repositoryRoot);
  for (const file of sourceOverrides.keys()) {
    if (!SOURCE_FILES.includes(file)) fail(`source override '${file}' is outside the closed family.`);
  }
  const configPath = path.join(root, "tsconfig.json");
  const config = ts.readConfigFile(configPath, ts.sys.readFile);
  if (config.error !== undefined) fail("cannot read TypeScript configuration for mutation control.");
  const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root, undefined, configPath);
  if (parsed.errors.length !== 0) fail("TypeScript configuration diagnostics changed.");
  const overridesByAbsolutePath = new Map(
    [...sourceOverrides].map(([file, text]) => [path.resolve(root, file), text])
  );
  const host = ts.createCompilerHost(parsed.options, true);
  const originalGetSourceFile = host.getSourceFile.bind(host);
  host.getSourceFile = (fileName, languageVersion, onError, shouldCreateNewSourceFile) => {
    const override = overridesByAbsolutePath.get(path.resolve(fileName));
    return override === undefined
      ? originalGetSourceFile(fileName, languageVersion, onError, shouldCreateNewSourceFile)
      : ts.createSourceFile(fileName, override, languageVersion, true, ts.ScriptKind.TS);
  };
  host.readFile = (fileName) =>
    overridesByAbsolutePath.get(path.resolve(fileName)) ?? ts.sys.readFile(fileName);
  const program = ts.createProgram({ rootNames: parsed.fileNames, options: parsed.options, host });
  const diagnostics = ts.getPreEmitDiagnostics(program);
  if (diagnostics.length !== 0) {
    fail(`mutated compiler program has ${diagnostics.length} diagnostic(s).`);
  }
  return { repositoryRoot: root, program, checker: program.getTypeChecker() };
}

/** Parse the immutable independent specification and reject syntax damage. */
function loadSpecification() {
  const bytes = fs.readFileSync(equationProgramPath);
  const source = ts.createSourceFile(
    equationProgramPath,
    bytes.toString("utf8"),
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TS
  );
  assert.equal(source.parseDiagnostics.length, 0, "Independent equation program has syntax errors.");
  return { bytes, source };
}

/** Return a catalogue artifact equation id for one exact implementation span. */
function catalogEquationId(repositoryRoot, context, artifact, proof) {
  const source = context.program.getSourceFile(path.resolve(repositoryRoot, proof.implementation.file));
  assert(source !== undefined);
  const declaration = nodeAtExactSpan(
    source,
    proof.implementation.start.offset,
    proof.implementation.end.offset
  );
  assert(
    declaration !== undefined &&
      (ts.isFunctionDeclaration(declaration) || ts.isMethodDeclaration(declaration)) &&
      declaration.body !== undefined
  );
  return declarationKey(repositoryRoot, declaration);
}

/** Merge content identities while rejecting conflicting hashes for one file. */
function mergeInputs(rows) {
  const byFile = new Map();
  for (const row of rows) {
    const old = byFile.get(row.file);
    assert(old === undefined || old.sha256 === row.sha256, `Conflicting semantic input '${row.file}'.`);
    byFile.set(row.file, row);
  }
  return [...byFile.values()].sort((left, right) => compareCodeUnits(left.file, right.file));
}

/** Build all local equations once and bind all 36 aliases to 19 implementations. */
export function buildCatalogFoundationFamilyArtifact({
  repositoryRoot,
  context,
  surface,
  sourceOverrides = new Map(),
}) {
  const root = path.resolve(repositoryRoot);
  assert.equal(ASSIGNED_SURFACE_KEYS.length, 36);
  assert.equal(new Set(ASSIGNED_SURFACE_KEYS).size, 36);
  assert.equal(LOCAL_EQUATION_IDS.length, 70);
  assert.equal(new Set(LOCAL_EQUATION_IDS).size, 70);
  const { bytes: specificationBytes, source: specificationSource } = loadSpecification();

  const quantityOverrides = new Map(
    [...sourceOverrides].filter(([file]) =>
      ["src/canonical.ts", "src/measurements.ts", "src/ordering.ts", "src/quantity.ts"].includes(file)
    )
  );
  const catalogOverrides = new Map(
    [...sourceOverrides].filter(([file]) =>
      ["src/catalog.ts", "src/facade.ts", "src/model.ts", "src/ordering.ts"].includes(file)
    )
  );
  const identityOverrides = new Map(
    [...sourceOverrides].filter(([file]) =>
      [
        "src/amounts.ts",
        "src/canonical.ts",
        "src/catalog.ts",
        "src/measurements.ts",
        "src/model.ts",
        "src/ordering.ts",
        "src/quantity.ts",
        "src/selectors.ts",
        "src/usability.ts",
      ].includes(file)
    )
  );
  const quantityArtifact = buildQuantityValues({
    repositoryRoot: root,
    context,
    surface,
    sourceOverrides: quantityOverrides,
  });
  const catalogArtifact = buildCatalogFamilyArtifact({
    repositoryRoot: root,
    context,
    surface,
    sourceOverrides: catalogOverrides,
  });
  const identityArtifact = buildIdentityValues({
    repositoryRoot: root,
    context,
    surface,
    sourceOverrides: identityOverrides,
  });
  const quantityArtifactDigest = sha256(canonicalJson(quantityArtifact));
  const catalogArtifactDigest = sha256(canonicalJson(catalogArtifact));
  const identityArtifactDigest = sha256(canonicalJson(identityArtifact));

  const localInputs = [...new Set([...SOURCE_FILES, ...producerFiles])].map((file) => ({
    file,
    sha256: sha256(sourceOverrides.get(file) ?? fs.readFileSync(path.resolve(root, file))),
  }));
  const inputs = mergeInputs([
    ...localInputs,
    ...quantityArtifact.inputs,
    ...catalogArtifact.inputs,
    ...identityArtifact.inputs,
  ]);
  const cacheKey = sha256(canonicalJson({
    surfaceDigest: surface.digest,
    inputs,
    quantityArtifactDigest,
    catalogArtifactDigest,
    identityArtifactDigest,
  }));
  const cached = sourceOverrides.size === 0 ? passCache.get(context) : undefined;
  if (cached?.key === cacheKey) return cached.value;

  const activeContext = sourceOverrides.size === 0
    ? context
    : loadOverriddenContext(root, sourceOverrides);
  assert.equal(path.resolve(activeContext.repositoryRoot), root);
  const sourceByFile = new Map(
    SOURCE_FILES.map((file) => {
      const source = activeContext.program.getSourceFile(path.resolve(root, file));
      assert(source !== undefined && !source.isDeclarationFile, `Missing compiler source '${file}'.`);
      return [file, source];
    })
  );

  const expectedById = new Map(
    LOCAL_EQUATION_IDS.map((equationId) => [
      equationId,
      findCallable(sourceByFile, specificationSource, equationId),
    ])
  );
  const expectedSupportingById = new Map(
    SUPPORTING_VALUE_IDS.map((valueId) => [
      valueId,
      findSupportingValue(sourceByFile, specificationSource, valueId),
    ])
  );

  const externalEquationIds = new Set(identityArtifact.equations.map((equation) => equation.id));
  for (const helper of catalogArtifact.helperEquations) externalEquationIds.add(helper.key);
  for (const proof of catalogArtifact.proofs) {
    externalEquationIds.add(catalogEquationId(root, activeContext, catalogArtifact, proof));
  }
  const quantityEquations = [
    ...quantityArtifact.semanticCore.memberEquations,
    ...quantityArtifact.semanticCore.helperEquations,
  ];
  const quantityEquationIds = new Set(quantityEquations.map((equation) => equation.id));
  const allExpectedEquationIds = [...new Set([
    ...LOCAL_EQUATION_IDS,
    ...externalEquationIds,
    ...quantityEquationIds,
  ])];

  const callableByKey = new Map(surface.callables.map((callable) => [callable.key, callable]));
  const publicProofSeeds = [];
  const pendingLocal = [];
  const usedExternalDependencies = new Set();
  for (const surfaceKey of ASSIGNED_SURFACE_KEYS) {
    const callable = callableByKey.get(surfaceKey);
    assert(callable !== undefined, `Compiler omitted assigned callable '${surfaceKey}'.`);
    assert.equal(
      callable.signatureHash,
      sha256(canonicalJson(callable.signature)),
      `Compiler signature identity drifted for '${surfaceKey}'.`
    );
    const qualifiedName = surfaceKey.slice(surfaceKey.indexOf("#") + 1, surfaceKey.indexOf("::"));
    const equationId = `src/catalog.ts#${qualifiedName}`;
    assert(
      LOCAL_EQUATION_IDS.includes(equationId) || externalEquationIds.has(equationId),
      `Assigned callable has no local or reused equation '${equationId}'.`
    );
    let implementation;
    if (sourceOverrides.size === 0) {
      const source = sourceByFile.get(callable.declaration.file);
      assert(source !== undefined, `Callable source is outside the closed family: ${surfaceKey}`);
      implementation = nodeAtExactSpan(
        source,
        callable.declaration.start.offset,
        callable.declaration.end.offset
      );
      assert(
        implementation !== undefined &&
          (ts.isFunctionDeclaration(implementation) || ts.isMethodDeclaration(implementation)) &&
          implementation.body !== undefined,
        `Callable '${surfaceKey}' is not one exact implementation.`
      );
      assert.equal(
        canonicalJson(callable.declaration),
        canonicalJson(spanOf(activeContext, implementation)),
        `Compiler span changed for '${surfaceKey}'.`
      );
    } else {
      implementation = findCallable(sourceByFile, undefined, equationId);
    }
    if (LOCAL_EQUATION_IDS.includes(equationId)) pendingLocal.push(implementation);
    else usedExternalDependencies.add(equationId);
    publicProofSeeds.push({ surfaceKey, callable, implementation, equationId });
  }

  const actualLocalById = new Map();
  while (pendingLocal.length > 0) {
    const declaration = pendingLocal.shift();
    const equationId = declarationKey(root, declaration);
    if (actualLocalById.has(equationId)) continue;
    assert(LOCAL_EQUATION_IDS.includes(equationId), `Unexpected local equation '${equationId}'.`);
    const inspected = inspectActualEquation(activeContext, root, declaration);
    actualLocalById.set(equationId, { declaration, inspected });
    for (const [dependencyId, dependency] of inspected.discoveredCallables) {
      if (LOCAL_EQUATION_IDS.includes(dependencyId)) pendingLocal.push(dependency);
      else {
        assert(externalEquationIds.has(dependencyId), `Uncertified source dependency '${dependencyId}'.`);
        usedExternalDependencies.add(dependencyId);
      }
    }
  }
  assert.equal(
    canonicalJson([...actualLocalById.keys()].sort(compareCodeUnits)),
    canonicalJson([...LOCAL_EQUATION_IDS].sort(compareCodeUnits)),
    "The compiler-resolved local source-callable closure changed."
  );

  const supportingValues = SUPPORTING_VALUE_IDS.map((valueId) => {
    const expected = expectedSupportingById.get(valueId);
    const actual = findSupportingValue(sourceByFile, undefined, valueId);
    const expectedTerm = normalizeSupportingValue(expected);
    const actualTerm = normalizeSupportingValue(actual);
    assert.equal(
      canonicalJson(actualTerm),
      canonicalJson(expectedTerm),
      `Supporting runtime value changed: ${valueId}`
    );
    return { id: valueId, declaration: spanOf(activeContext, actual), term: expectedTerm };
  });

  const equations = LOCAL_EQUATION_IDS.map((equationId) => {
    const actualRow = actualLocalById.get(equationId);
    const expectedDeclaration = expectedById.get(equationId);
    assert(actualRow !== undefined && expectedDeclaration !== undefined);
    const expectedTerm = normalizeCatalogCallable(expectedDeclaration);
    const actualTerm = normalizeCatalogCallable(actualRow.declaration);
    assert.equal(
      canonicalJson(actualTerm),
      canonicalJson(expectedTerm),
      `Independent complete term changed: ${equationId}`
    );
    const expectedDependency = expectedDependencies(expectedDeclaration, allExpectedEquationIds);
    assert.equal(
      canonicalJson(actualRow.inspected.sourceDependencies),
      canonicalJson(expectedDependency.sourceDependencies),
      `Compiler-resolved source dependencies changed: ${equationId}`
    );
    assert.equal(
      canonicalJson(actualRow.inspected.supportingValues),
      canonicalJson(expectedDependency.supportingValues),
      `Compiler-resolved supporting values changed: ${equationId}`
    );
    assert.equal(
      canonicalJson(actualRow.inspected.callbackDependencies),
      canonicalJson(expectedCallbackDependencies(equationId)),
      `Callback dependencies changed: ${equationId}`
    );
    const expectedEffects = effectProfile(expectedDeclaration);
    const actualEffects = effectProfile(actualRow.declaration);
    assert.equal(
      canonicalJson(actualEffects),
      canonicalJson(expectedEffects),
      `Explicit effect profile changed: ${equationId}`
    );
    return {
      id: equationId,
      lawId: lawIdForEquation(equationId),
      declaration: spanOf(activeContext, actualRow.declaration),
      term: expectedTerm,
      termSha256: sha256(canonicalJson(expectedTerm)),
      dependencies: expectedDependency.sourceDependencies,
      supportingValues: expectedDependency.supportingValues,
      standardOperations: actualRow.inspected.standardOperations,
      standardDeclarations: actualRow.inspected.standardDeclarations,
      callbackDependencies: expectedCallbackDependencies(equationId),
      effects: expectedEffects,
    };
  });
  const equationById = new Map(equations.map((equation) => [equation.id, equation]));
  const allStandardOperations = new Set(
    equations.flatMap((equation) => equation.standardOperations)
  );
  assert.equal(
    canonicalJson([...allStandardOperations].sort(compareCodeUnits)),
    canonicalJson([...ALLOWED_STANDARD_OPERATIONS].sort(compareCodeUnits)),
    "Native-operation closure differs from the independently declared set."
  );

  const externalDependencyRows = [...usedExternalDependencies].sort(compareCodeUnits).map((equationId) => {
    const identityEquation = identityArtifact.equations.find((equation) => equation.id === equationId);
    if (identityEquation !== undefined) {
      return {
        equationId,
        proofKind: identityValuesProofKind,
        artifactSha256: identityArtifactDigest,
        declaration: identityEquation.declaration,
        termSha256: sha256(canonicalJson(identityEquation.term)),
      };
    }
    const catalogHelper = catalogArtifact.helperEquations.find((equation) => equation.key === equationId);
    if (catalogHelper !== undefined) {
      return {
        equationId,
        proofKind: catalogProofKind,
        artifactSha256: catalogArtifactDigest,
        declaration: catalogHelper.declaration,
        termSha256: sha256(canonicalJson(catalogHelper.term)),
      };
    }
    const catalogProofs = catalogArtifact.proofs.filter(
      (proof) => catalogEquationId(root, activeContext, catalogArtifact, proof) === equationId
    );
    assert.equal(catalogProofs.length, 1, `Expected one reused catalog equation '${equationId}'.`);
    return {
      equationId,
      proofKind: catalogProofKind,
      artifactSha256: catalogArtifactDigest,
      declaration: catalogProofs[0].implementation,
      sourceSurfaceKey: catalogProofs[0].surfaceKey,
      termSha256: sha256(canonicalJson(catalogProofs[0].term)),
    };
  });

  const proofs = publicProofSeeds.map(({ surfaceKey, callable, implementation, equationId }) => ({
    surfaceKey,
    signatureHash: callable.signatureHash,
    signature: callable.signature,
    declaration: callable.declaration,
    implementation: spanOf(activeContext, implementation),
    relation: sourceOverrides.size === 0
      ? {
          kind: "COMPILER_RESOLVED_EXACT_EXPORT",
          reachabilityPaths: callable.reachabilityPaths,
          symbolDeclarations: callable.symbolDeclarations,
        }
      : { kind: "MUTATION_CONTROL_ONLY" },
    equationId,
    lawId: LOCAL_EQUATION_IDS.includes(equationId)
      ? equationById.get(equationId).lawId
      : "catalog-definition-normalization-v1",
    dependencies: LOCAL_EQUATION_IDS.includes(equationId)
      ? equationById.get(equationId).dependencies
      : [],
    ...(LOCAL_EQUATION_IDS.includes(equationId)
      ? {}
      : {
          reusedFrom: externalDependencyRows.find((row) => row.equationId === equationId) ?? {
            equationId,
            proofKind: identityValuesProofKind,
            artifactSha256: identityArtifactDigest,
          },
        }),
  }));
  assert.equal(
    canonicalJson(proofs.map((proof) => proof.surfaceKey)),
    canonicalJson(ASSIGNED_SURFACE_KEYS),
    "Public proof order or identity changed."
  );
  const uniqueImplementations = new Set(proofs.map((proof) => proof.equationId));
  assert.equal(uniqueImplementations.size, 19, "Assigned aliases no longer share 19 implementations.");

  const quantityDependencyIds = [...usedExternalDependencies]
    .filter((equationId) => quantityEquationIds.has(equationId))
    .sort(compareCodeUnits);
  const resultWithoutId = {
    schemaVersion: 1,
    mode: "V",
    proofKind,
    familyId: CATALOG_FOUNDATION_FAMILY_ID,
    sourceBase: CATALOG_FOUNDATION_SOURCE_BASE,
    surfaceDigest: surface.digest,
    domain: {
      id: "VALIDATED_IMMUTABLE_CATALOG_FOUNDATION_VALUES_V1",
      quantified:
        "Every non-proxied plain-value input satisfying the published TypeScript shapes and every guard in the complete normalized equations; no fixture or finite-sample restriction.",
      exactness:
        "Quantities, units, revision ids, active pointers, graph membership, root/revision digests, and SHA-256 words use the exact equations and rejection branches; there is no epsilon arithmetic.",
      storage:
        "Only fresh local arrays, maps, sets, typed arrays, records, or a newly allocated InventoryCatalog instance are mutated; caller-owned inputs and retained catalog state remain read-only.",
      builtins:
        "Array, Map, Set, Object, Number, Math, String, TextEncoder, Uint8Array, Uint32Array, BigInt, and Error operations resolve to real installed TypeScript standard-library declarations and use ordinary unmodified runtime semantics.",
      callbacks:
        "The private revision-family merge invokes only its two named parameters; the public extension equation binds every call to an inline revision-id projection and one exact independently checked revision-digest equation.",
    },
    excluded: [
      "Proxies, accessors, subclasses, monkey-patched built-ins, custom collection/string/typed-array lookalikes, and own-property method shadowing.",
      "Concurrent mutation of inputs, catalog values, prototypes, or the source compiler snapshot during a call.",
      "Calling the private generic merge helper outside the exact bindings present in extendInventoryCatalog.",
    ],
    allAdmittedInputs: true,
    sampledInputs: 0,
    sourceCallableClosureComplete: true,
    localEquationCount: equations.length,
    externalEquationDependencyCount: externalDependencyRows.length,
    assignedSurfaceCount: proofs.length,
    uniqueImplementationCount: uniqueImplementations.size,
    inputs,
    specification: {
      file: path.relative(root, equationProgramPath).replaceAll("\\", "/"),
      sha256: sha256(specificationBytes),
      independentlyDeclared: true,
      executedProductionCode: false,
      reusedAuthoritySpecification,
    },
    reusedCertificates: [
      {
        proofKind: quantityArtifact.proofKind,
        artifactSha256: quantityArtifactDigest,
        surfaceDigest: quantityArtifact.surfaceDigest,
        equationIds: quantityDependencyIds,
      },
      {
        proofKind: identityValuesProofKind,
        artifactSha256: identityArtifactDigest,
        surfaceDigest: identityArtifact.surfaceDigest,
        equationIds: externalDependencyRows
          .filter((row) => row.proofKind === identityValuesProofKind)
          .map((row) => row.equationId),
      },
      {
        proofKind: catalogProofKind,
        artifactSha256: catalogArtifactDigest,
        surfaceDigest: catalogArtifact.surfaceDigest,
        equationIds: externalDependencyRows
          .filter((row) => row.proofKind === catalogProofKind)
          .map((row) => row.equationId),
      },
    ],
    laws: FAMILY_LAWS,
    supportingValues,
    equations,
    externalDependencies: externalDependencyRows,
    proofs,
  };
  const result = {
    ...resultWithoutId,
    certificateId: `sha256:${sha256(canonicalJson(resultWithoutId))}`,
  };
  if (sourceOverrides.size === 0) passCache.set(context, { key: cacheKey, value: result });
  return result;
}

/** Rebuild current semantics and reject changed recorded evidence. */
export function verifyCatalogFoundationFamilyArtifact({
  repositoryRoot,
  context,
  surface,
  recorded,
}) {
  const current = buildCatalogFoundationFamilyArtifact({ repositoryRoot, context, surface });
  assert.equal(
    canonicalJson(recorded),
    canonicalJson(current),
    "Recorded catalogue-foundation certificate differs from current independent equations."
  );
  return current;
}

/** Trusted throughput-r7 adapter name for the complete family builder. */
export const buildFamilyArtifact = buildCatalogFoundationFamilyArtifact;

/** Exact 36-member allow-list consumed by the registered value-family route. */
export const supportedSurfaceKeys = ASSIGNED_SURFACE_KEYS;
