import assert from "node:assert/strict";

import { ts } from "../surface-bindings/lib/compiler-surface.mjs";

/** Reject syntax outside the deliberately finite catalogue-equation grammar. */
function fail(message) {
  throw new Error(`Catalogue equation normalization rejected: ${message}`);
}

/** Render one operator without depending on source whitespace. */
function operatorName(token) {
  return ts.tokenToString(token.kind) ?? ts.SyntaxKind[token.kind];
}

/** Normalize one complete callable while erasing only bound names and TypeScript types. */
export function normalizeCatalogCallable(declaration) {
  assert(declaration.body !== undefined, "Equation callable needs a concrete body.");
  const counters = { local: 0, lambda: 0 };
  const environment = new Map();

  /** Normalize a fixed or computed property name. */
  function propertyName(name, scopedEnvironment) {
    if (ts.isIdentifier(name) || ts.isStringLiteral(name) || ts.isNumericLiteral(name)) {
      return ["fixed", name.text];
    }
    if (ts.isComputedPropertyName(name)) {
      return ["computed", expression(name.expression, scopedEnvironment)];
    }
    fail(`unsupported property name '${name.getText()}'.`);
  }

  /** Bind one identifier or destructuring pattern to a stable name-independent identity. */
  function bindingPattern(name, identity, scopedEnvironment) {
    if (ts.isIdentifier(name)) {
      scopedEnvironment.set(name.text, identity);
      return ["binding", identity];
    }
    if (ts.isObjectBindingPattern(name)) {
      return [
        "object-binding",
        name.elements.map((element, index) => {
          const property = element.propertyName === undefined
            ? ts.isIdentifier(element.name)
              ? ["fixed", element.name.text]
              : ["position", index]
            : propertyName(element.propertyName, scopedEnvironment);
          const childIdentity = `${identity}.object:${index}`;
          return [
            element.dotDotDotToken === undefined ? "field" : "rest",
            property,
            bindingPattern(element.name, childIdentity, scopedEnvironment),
            element.initializer === undefined
              ? ["no-default"]
              : expression(element.initializer, scopedEnvironment),
          ];
        }),
      ];
    }
    if (ts.isArrayBindingPattern(name)) {
      return [
        "array-binding",
        name.elements.map((element, index) => {
          if (ts.isOmittedExpression(element)) return ["omitted", index];
          const childIdentity = `${identity}.array:${index}`;
          return [
            element.dotDotDotToken === undefined ? "element" : "rest",
            bindingPattern(element.name, childIdentity, scopedEnvironment),
            element.initializer === undefined
              ? ["no-default"]
              : expression(element.initializer, scopedEnvironment),
          ];
        }),
      ];
    }
    fail(`unsupported binding pattern '${name.getText()}'.`);
  }

  /** Normalize one runtime expression and every nested callback body. */
  function expression(node, scopedEnvironment = environment) {
    if (ts.isParenthesizedExpression(node)) return expression(node.expression, scopedEnvironment);
    if (
      ts.isAsExpression(node) ||
      ts.isTypeAssertionExpression(node) ||
      ts.isNonNullExpression(node)
    ) return expression(node.expression, scopedEnvironment);
    if (node.kind === ts.SyntaxKind.ThisKeyword) return ["this"];
    if (ts.isIdentifier(node)) {
      return ["reference", scopedEnvironment.get(node.text) ?? `source:${node.text}`];
    }
    if (ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) {
      return ["string", node.text];
    }
    if (ts.isNumericLiteral(node)) return ["number", node.text];
    if (ts.isBigIntLiteral(node)) return ["bigint", node.text];
    if (ts.isRegularExpressionLiteral(node)) return ["regexp", node.text];
    if (node.kind === ts.SyntaxKind.TrueKeyword) return ["boolean", true];
    if (node.kind === ts.SyntaxKind.FalseKeyword) return ["boolean", false];
    if (node.kind === ts.SyntaxKind.NullKeyword) return ["null"];
    if (ts.isPropertyAccessExpression(node)) {
      return [
        "property",
        expression(node.expression, scopedEnvironment),
        node.name.text,
        node.questionDotToken === undefined ? "required" : "optional",
      ];
    }
    if (ts.isElementAccessExpression(node)) {
      assert(node.argumentExpression !== undefined);
      return [
        "element",
        expression(node.expression, scopedEnvironment),
        expression(node.argumentExpression, scopedEnvironment),
        node.questionDotToken === undefined ? "required" : "optional",
      ];
    }
    if (ts.isCallExpression(node)) {
      return [
        "call",
        expression(node.expression, scopedEnvironment),
        node.arguments.map((argument) => expression(argument, scopedEnvironment)),
        node.questionDotToken === undefined ? "required" : "optional",
      ];
    }
    if (ts.isNewExpression(node)) {
      return [
        "new",
        expression(node.expression, scopedEnvironment),
        (node.arguments ?? []).map((argument) => expression(argument, scopedEnvironment)),
      ];
    }
    if (ts.isBinaryExpression(node)) {
      return [
        "binary",
        operatorName(node.operatorToken),
        expression(node.left, scopedEnvironment),
        expression(node.right, scopedEnvironment),
      ];
    }
    if (ts.isConditionalExpression(node)) {
      return [
        "conditional",
        expression(node.condition, scopedEnvironment),
        expression(node.whenTrue, scopedEnvironment),
        expression(node.whenFalse, scopedEnvironment),
      ];
    }
    if (ts.isPrefixUnaryExpression(node)) {
      return [
        "prefix",
        ts.tokenToString(node.operator) ?? ts.SyntaxKind[node.operator],
        expression(node.operand, scopedEnvironment),
      ];
    }
    if (ts.isPostfixUnaryExpression(node)) {
      return [
        "postfix",
        ts.tokenToString(node.operator) ?? ts.SyntaxKind[node.operator],
        expression(node.operand, scopedEnvironment),
      ];
    }
    if (ts.isTypeOfExpression(node)) return ["typeof", expression(node.expression, scopedEnvironment)];
    if (ts.isVoidExpression(node)) return ["void", expression(node.expression, scopedEnvironment)];
    if (ts.isSpreadElement(node)) return ["spread", expression(node.expression, scopedEnvironment)];
    if (ts.isArrayLiteralExpression(node)) {
      return [
        "array",
        node.elements.map((element) =>
          ts.isOmittedExpression(element) ? ["omitted"] : expression(element, scopedEnvironment)
        ),
      ];
    }
    if (ts.isObjectLiteralExpression(node)) {
      return [
        "record",
        node.properties.map((property) => {
          if (ts.isPropertyAssignment(property)) {
            return [
              "field",
              propertyName(property.name, scopedEnvironment),
              expression(property.initializer, scopedEnvironment),
            ];
          }
          if (ts.isShorthandPropertyAssignment(property)) {
            return [
              "field",
              ["fixed", property.name.text],
              expression(property.name, scopedEnvironment),
            ];
          }
          if (ts.isSpreadAssignment(property)) {
            return ["spread", expression(property.expression, scopedEnvironment)];
          }
          fail(`unsupported object member '${property.getText()}'.`);
        }),
      ];
    }
    if (ts.isArrowFunction(node) || ts.isFunctionExpression(node)) {
      const childEnvironment = new Map(scopedEnvironment);
      const lambdaId = counters.lambda;
      counters.lambda += 1;
      const parameters = node.parameters.map((parameter, index) => ({
        pattern: bindingPattern(parameter.name, `lambda:${lambdaId}:${index}`, childEnvironment),
        optional: parameter.questionToken !== undefined,
        rest: parameter.dotDotDotToken !== undefined,
        default: parameter.initializer === undefined
          ? null
          : expression(parameter.initializer, childEnvironment),
      }));
      return [
        "lambda",
        parameters,
        ts.isBlock(node.body)
          ? statement(node.body, childEnvironment)
          : expression(node.body, childEnvironment),
      ];
    }
    if (ts.isTemplateExpression(node)) {
      return [
        "template",
        node.head.text,
        node.templateSpans.map((span) => [
          expression(span.expression, scopedEnvironment),
          span.literal.text,
        ]),
      ];
    }
    fail(`unsupported expression '${ts.SyntaxKind[node.kind]}': ${node.getText()}`);
  }

  /** Normalize a branch while preserving whether braces create a nested scope. */
  function branch(node, scopedEnvironment) {
    return ts.isBlock(node)
      ? ["block", statements(node.statements, new Map(scopedEnvironment))]
      : ["single", statement(node, new Map(scopedEnvironment))];
  }

  /** Normalize a statement sequence in source order. */
  function statements(sourceStatements, scopedEnvironment) {
    return sourceStatements.map((sourceStatement) => statement(sourceStatement, scopedEnvironment));
  }

  /** Normalize a variable declaration and bind its complete pattern. */
  function variableDeclaration(declaration, scopedEnvironment) {
    const initializer = declaration.initializer === undefined
      ? ["undefined"]
      : expression(declaration.initializer, scopedEnvironment);
    const identity = `local:${counters.local}`;
    counters.local += 1;
    return ["declaration", bindingPattern(declaration.name, identity, scopedEnvironment), initializer];
  }

  /** Normalize one runtime statement and every branch below it. */
  function statement(node, scopedEnvironment = environment) {
    if (ts.isBlock(node)) return ["block", statements(node.statements, new Map(scopedEnvironment))];
    if (ts.isVariableStatement(node)) {
      const declarationKind = (node.declarationList.flags & ts.NodeFlags.Const) !== 0
        ? "const"
        : (node.declarationList.flags & ts.NodeFlags.Let) !== 0
          ? "let"
          : "var";
      return [
        "variables",
        declarationKind,
        node.declarationList.declarations.map((declaration) =>
          variableDeclaration(declaration, scopedEnvironment)
        ),
      ];
    }
    if (ts.isIfStatement(node)) {
      return [
        "if",
        expression(node.expression, scopedEnvironment),
        branch(node.thenStatement, scopedEnvironment),
        node.elseStatement === undefined
          ? ["no-else"]
          : branch(node.elseStatement, scopedEnvironment),
      ];
    }
    if (ts.isReturnStatement(node)) {
      return [
        "return",
        node.expression === undefined ? ["undefined"] : expression(node.expression, scopedEnvironment),
      ];
    }
    if (ts.isThrowStatement(node)) return ["throw", expression(node.expression, scopedEnvironment)];
    if (ts.isExpressionStatement(node)) return ["expression", expression(node.expression, scopedEnvironment)];
    if (ts.isForOfStatement(node)) {
      const childEnvironment = new Map(scopedEnvironment);
      let initializer;
      if (ts.isVariableDeclarationList(node.initializer)) {
        const declarationKind = (node.initializer.flags & ts.NodeFlags.Const) !== 0
          ? "const"
          : (node.initializer.flags & ts.NodeFlags.Let) !== 0
            ? "let"
            : "var";
        initializer = [
          declarationKind,
          node.initializer.declarations.map((declaration) =>
            variableDeclaration(declaration, childEnvironment)
          ),
        ];
      } else {
        initializer = ["assignment", expression(node.initializer, childEnvironment)];
      }
      return [
        "for-of",
        node.awaitModifier === undefined ? "sync" : "await",
        initializer,
        expression(node.expression, scopedEnvironment),
        branch(node.statement, childEnvironment),
      ];
    }
    if (ts.isForStatement(node)) {
      const childEnvironment = new Map(scopedEnvironment);
      let initializer = ["none"];
      if (node.initializer !== undefined) {
        initializer = ts.isVariableDeclarationList(node.initializer)
          ? [
              (node.initializer.flags & ts.NodeFlags.Const) !== 0
                ? "const"
                : (node.initializer.flags & ts.NodeFlags.Let) !== 0
                  ? "let"
                  : "var",
              node.initializer.declarations.map((declaration) =>
                variableDeclaration(declaration, childEnvironment)
              ),
            ]
          : ["expression", expression(node.initializer, childEnvironment)];
      }
      return [
        "for",
        initializer,
        node.condition === undefined ? ["none"] : expression(node.condition, childEnvironment),
        node.incrementor === undefined ? ["none"] : expression(node.incrementor, childEnvironment),
        branch(node.statement, childEnvironment),
      ];
    }
    if (ts.isWhileStatement(node)) {
      return [
        "while",
        expression(node.expression, scopedEnvironment),
        branch(node.statement, new Map(scopedEnvironment)),
      ];
    }
    if (ts.isContinueStatement(node)) return ["continue"];
    if (ts.isBreakStatement(node)) return ["break"];
    fail(`unsupported statement '${ts.SyntaxKind[node.kind]}': ${node.getText()}`);
  }

  const parameters = declaration.parameters.map((parameter, index) => ({
    pattern: bindingPattern(parameter.name, `parameter:${index}`, environment),
    optional: parameter.questionToken !== undefined,
    rest: parameter.dotDotDotToken !== undefined,
    default: parameter.initializer === undefined
      ? null
      : expression(parameter.initializer, environment),
  }));
  return {
    async: declaration.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword) ?? false,
    generator: declaration.asteriskToken !== undefined,
    parameters,
    body: ["block", statements(declaration.body.statements, environment)],
  };
}
