import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { sha256, nodeAtExactSpan, ts } from "../surface-bindings/lib/compiler-surface.mjs";
import { buildIndependentV9Artifact } from "./independent-v9-laws.mjs";

/** This route admits only the closed pure fragment; callback behavior is not converted to V credit. */
export const proofKind = "migration-plugin-helper-independent-source-closed-values-v3";
/** Exact six public members closed by the independent laws and rederived transitive dependencies. */
export const supportedSurfaceKeys = [
  "export:./migrations#defineInventoryLegacyQuery::call[0]",
  "export:./migrations#defineInventoryMigrationPlugin::call[0]",
  "export:./migrations#defineInventoryMigrationSourcePlugin::call[0]",
  "export:./migrations#inventoryMigrationProblem::call[0]",
  "export:./storage#inventoryDurableMigrationPlanDigest::call[0]",
  "export:./storage#validateInventoryMigrationManifestBeginInput::call[0]",
];
/** Source fields are ordinary immutable data, never injected accessors or replaced host built-ins. */
function checkBindingsAndEnums(repositoryRoot, context, independent) {
  const source=context.program.getSourceFile(path.resolve(repositoryRoot,"src/migrations.ts"));
  assert(source!==undefined);
  for(const [owner,member,value] of [["InventoryMigrationDiagnosticSeverity","Error","error"],["InventoryMigrationDiagnosticCode","AmbiguousLegacyMeaning","ambiguous-legacy-meaning"]]) {
    const enums=source.statements.filter((node)=>ts.isEnumDeclaration(node)&&node.name.text===owner);
    assert.equal(enums.length,1);
    const members=enums[0].members.filter((node)=>node.name.getText(source)===member);
    assert.equal(members.length,1);assert(ts.isStringLiteral(members[0].initializer));
    assert.equal(members[0].initializer.text,value,`Independent enum law changed: ${owner}.${member}`);
  }
  const visited=new Set();
  for(const row of [...independent.proofs,...independent.localLaws]) {
    const span=row.completeExpectedTerm.implementation;
    const source=context.program.getSourceFile(path.resolve(repositoryRoot,span.file));
    const declaration=nodeAtExactSpan(source,span.start.offset,span.end.offset);
    assert(declaration!==undefined&&ts.isFunctionDeclaration(declaration));
    if(visited.has(declaration))continue;visited.add(declaration);
    function inspect(node) {
      if(ts.isCallExpression(node)||ts.isNewExpression(node)) {
        const target=context.checker.getResolvedSignature(node)?.declaration;
        assert(target!==undefined,`Unresolved semantic call: ${node.getText()}`);
        if(target.getSourceFile().isDeclarationFile) {
          assert(/[/\\]typescript[/\\]lib[/\\]lib\.[^/\\]+\.d\.ts$/u.test(target.getSourceFile().fileName),"Only immutable standard-library effects may be assumed.");
        } else {
          assert(ts.isFunctionDeclaration(target)||ts.isArrowFunction(target)||ts.isFunctionExpression(target),"Unexpected source callback/constructor.");
        }
      }
      if(ts.isPropertyAccessExpression(node)) {
        const symbol=context.checker.getSymbolAtLocation(node.name);
        assert(!(symbol?.declarations??[]).some((candidate)=>ts.isGetAccessorDeclaration(candidate)||ts.isSetAccessorDeclaration(candidate)),"Accessor-bearing data requires an explicit effect proof.");
      }
      ts.forEachChild(node,inspect);
    }
    inspect(declaration.body);
  }
}
/** Re-derive complete source equations and their recursive proofs once per registered compiler pass. */
export function buildFamilyArtifact({ repositoryRoot, context, surface }) {
  const independent=buildIndependentV9Artifact({repositoryRoot,context,surface});
  const additiveClosed = [...supportedSurfaceKeys, "export:./migrations#inventoryMigrationPositionsMatch::call[0]"].sort();
  assert.deepEqual([...independent.disposition.independentlyClosed].sort(), additiveClosed, "Independent helper closure changed outside the reviewed additive frontier.");
  for (const surfaceKey of supportedSurfaceKeys) assert(independent.disposition.independentlyClosed.includes(surfaceKey), `Existing V6 proof disappeared: ${surfaceKey}`);
  checkBindingsAndEnums(repositoryRoot,context,independent);
  const publicByKey=new Map(surface.callables.map((row)=>[row.key,row]));
  const proofByKey=new Map(independent.proofs.map((row)=>[row.surfaceKey,row]));
  const proofs=supportedSurfaceKeys.map((surfaceKey)=>{
    const callable=publicByKey.get(surfaceKey),proved=proofByKey.get(surfaceKey);
    assert(callable!==undefined&&proved!==undefined);
    assert.equal(proved.status,"INDEPENDENTLY_CLOSED");
    assert.deepEqual(callable.declaration,proved.completeExpectedTerm.implementation,"The proof must resolve the exact public implementation, not a same-name function.");
    return {surfaceKey,signatureHash:callable.signatureHash,declaration:callable.declaration,
      completeExpectedTerm:proved.completeExpectedTerm,dependencies:proved.dependencies};
  });
  const inputs=new Map();
  function input(file) {
    const actual=sha256(fs.readFileSync(path.resolve(repositoryRoot,file))),prior=inputs.get(file);
    assert(prior===undefined||prior.sha256===actual,`Conflicting proof identity: ${file}`);
    inputs.set(file,{file,sha256:actual});
  }
  // The corrected independent engine rederives quantity/identity laws from immutable reviewed Git certificates.
  // Do not require unrelated current proof-packaging files from those historical certificates to stay byte-identical.
  for(const file of fs.readdirSync(path.resolve(repositoryRoot,"src")))if(file.endsWith(".ts"))input(`src/${file}`);
  for(const file of ["v9.expected.ts.txt","independent-v9-laws.mjs","registered-value-family.mjs","artifacts/runtime-causal.json","import-source-receipt.json"])input(`experiments/tla-conformance/migration-helper-causal-r7/${file}`);
  input("experiments/tla-conformance/admission-audit/bank-current/canonical-535.json");
  return {schemaVersion:1,proofKind,surfaceDigest:surface.digest,allAdmittedInputs:true,sampledInputs:0,
    domain:"Declared immutable plain TypeScript inputs and unmodified built-ins. Six pure identity/diagnostic/digest/manifest-validation functions; callback reads, arbitrary migration execution, storage publication, and world materialization are excluded.",
    inputs:[...inputs.values()].sort((a,b)=>a.file<b.file?-1:a.file>b.file?1:0),
    independentSpecification:independent.expectedSpecification,independentDependencies:independent.independentDependencies,
    localLaws:independent.localLaws,supportingValues:independent.supportingValues,
    excluded:independent.disposition.blocked,proofs};
}
