import assert from "node:assert/strict";
import { isDeepStrictEqual } from "node:util";

function same(left, right) { return isDeepStrictEqual(left, right); }

function verifyQueryRun(run, expectedEntrypoint) {
  assert.equal(run.entrypoint, expectedEntrypoint);
  assert.equal(run.sourceBefore.readCount, 0);
  assert.equal(run.sourceBefore.lastCursor, null);
  assert(Array.isArray(run.transitions) && run.transitions.length > 0);
  const rows = [];
  let cursor;
  for (let index = 0; index < run.transitions.length; index += 1) {
    const t = run.transitions[index];
    assert.equal(t.causeId, `${run.runId}/page/${index}`);
    assert.equal(t.queryId, run.queryId);
    assert.equal(t.callIndex, index);
    assert.equal(t.input.limit, run.pageSize);
    assert.equal(t.input.cursor, cursor);
    assert.equal(t.preState.readCount, index);
    assert.equal(t.postState.readCount, index + 1);
    if (index > 0) assert(same(t.preState, run.transitions[index - 1].postState));
    rows.push(...t.returnedRows);
    cursor = t.nextCursor === null ? undefined : t.nextCursor;
  }
  const last = run.transitions.at(-1);
  assert.equal(last.nextCursor, null);
  assert(same(last.postState, run.sourceAfter));
  assert(same(rows, run.resultRows));
}

function verifyPlugin(plan, expectedInvocation) {
  assert.equal(plan.invocationId, expectedInvocation);
  verifyQueryRun(plan.queryRun, "InventoryLegacyQueryReader.readAll");
  assert.deepEqual(plan.callbackObservedRowIds, plan.queryRun.resultRows.map((row) => row.id));
  assert.equal(plan.callbackReturnedMigrationId, plan.resultMigrationId);
  assert.equal(plan.resultOperationIds.length, plan.callbackObservedRowIds.length);
  assert.equal(typeof plan.resultPlanDigest, "string");
  assert(plan.resultPlanDigest.length > 0);
}

export function verifyCausalB4Runtime(document) {
  assert.equal(document.schemaVersion, 1);
  assert.equal(document.proofKind, "migration-plugin-helper-causal-runtime-v1");
  verifyQueryRun(document.directRead, "readAllInventoryLegacyQuery");
  verifyQueryRun(document.readerRead, "InventoryLegacyQueryReader.readAll");
  verifyPlugin(document.pluginPlan, "ordinary-plugin-plan");
  verifyPlugin(document.sourcePluginPlan, "source-plugin-plan");
  assert(document.disabledDomain.zeroPageSizeRejected);
  assert(document.disabledDomain.repeatedCursorRejected);
  assert(document.disabledDomain.emptyCursorRejected);
  assert(document.disabledDomain.rowBoundRejected);
  return true;
}
