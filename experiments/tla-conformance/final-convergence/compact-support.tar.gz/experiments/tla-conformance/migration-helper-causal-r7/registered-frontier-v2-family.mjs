import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { canonicalJson, sha256 } from "../surface-bindings/lib/compiler-surface.mjs";
import { buildIndependentV9Artifact } from "./independent-v9-laws.mjs";
import { buildFamilyArtifact as buildCausalB4 } from "./registered-causal-b4-family.mjs";

export const proofKind = "migration-plugin-helper-frontier-v2-values-v3";
export const supportedSurfaceKeys = Object.freeze([
  "export:./migrations#createInventoryLegacyQueryReader::call[0]",
  "export:./migrations#inventoryMigrationPositionsMatch::call[0]",
]);

const B4_FILE = "experiments/tla-conformance/migration-helper-causal-r7/artifacts/causal-b4-producer.json";

function addInput(repositoryRoot, inputs, file) {
  if (inputs.has(file)) return;
  inputs.set(file, { file, sha256: sha256(fs.readFileSync(path.resolve(repositoryRoot, file))) });
}

export function buildFamilyArtifact({ repositoryRoot, context, surface }) {
  const independent = buildIndependentV9Artifact({ repositoryRoot, context, surface });
  const byKey = new Map(independent.proofs.map((proof) => [proof.surfaceKey, proof]));
  const live = new Map(surface.callables.map((callable) => [callable.key, callable]));
  const b4 = buildCausalB4({ repositoryRoot, context, surface });
  assert.equal(b4.proofs.length, 4);
  assert(b4.proofs.every((proof) => proof.mode === "B"));
  const b4Bytes = fs.readFileSync(path.resolve(repositoryRoot, B4_FILE));
  assert.equal(canonicalJson(JSON.parse(b4Bytes.toString("utf8"))), canonicalJson(b4), "Persisted B4 dependency differs from current causal truth");
  const b4Receipt = { file: B4_FILE, sha256: sha256(b4Bytes), proofKind: b4.proofKind, rows: b4.proofs.map(({ surfaceKey, mode }) => ({ surfaceKey, mode })) };

  const proofs = supportedSurfaceKeys.map((surfaceKey) => {
    const sourceProof = byKey.get(surfaceKey);
    assert(sourceProof !== undefined, `Independent proof missing ${surfaceKey}`);
    if (surfaceKey.endsWith("#createInventoryLegacyQueryReader::call[0]")) {
      assert.equal(sourceProof.status, "READY_WITH_PAIRED_B_DEPENDENCY");
    } else {
      assert.equal(sourceProof.status, "INDEPENDENTLY_CLOSED");
    }
    const callable = live.get(surfaceKey);
    assert(callable !== undefined);
    return {
      surfaceKey,
      signatureHash: callable.signatureHash,
      declaration: callable.declaration,
      semantics: {
        completeExpectedTerm: sourceProof.completeExpectedTerm,
        dependencies: sourceProof.dependencies,
        status: surfaceKey.endsWith("#createInventoryLegacyQueryReader::call[0]")
          ? "INDEPENDENTLY_CLOSED_WITH_CAUSAL_B4_DEPENDENCY"
          : "INDEPENDENTLY_CLOSED",
        ...(surfaceKey.endsWith("#createInventoryLegacyQueryReader::call[0]") ? { causalB4Dependency: b4Receipt } : {}),
      },
    };
  });

  const inputs = new Map();
  for (const input of b4.inputs) inputs.set(input.file, input);
  for (const file of [
    "experiments/tla-conformance/migration-helper-causal-r7/independent-v9-laws.mjs",
    "experiments/tla-conformance/migration-helper-causal-r7/v9.expected.ts.txt",
    "experiments/tla-conformance/migration-helper-causal-r7/registered-frontier-v2-family.mjs",
    B4_FILE,
  ]) addInput(repositoryRoot, inputs, file);
  for (const name of fs.readdirSync(path.resolve(repositoryRoot, "src")).filter((name) => name.endsWith(".ts")).sort()) addInput(repositoryRoot, inputs, `src/${name}`);
  addInput(repositoryRoot, inputs, "node_modules/typescript/package.json");

  return {
    schemaVersion: 1,
    proofKind,
    surfaceDigest: surface.digest,
    domain: "Exactly the two still-red MigrationPluginHelpers V frontier rows: positionsMatch is independently complete-source closed; the reader factory is independently complete-source closed with its exact readAll callback dependency discharged by the same current causal B4 producer family.",
    allAdmittedInputs: true,
    sampledInputs: 0,
    inputs: [...inputs.values()].sort((a,b) => a.file.localeCompare(b.file)),
    causalB4Dependency: b4Receipt,
    proofs,
  };
}
