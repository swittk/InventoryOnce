import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import {
  canonicalJson,
  discoverCompilerSurface,
  sha256,
  spanOf,
  ts,
} from "../surface-bindings/lib/compiler-surface.mjs";
import { loadEvidenceCompilerContext } from "../surface-bindings/lib/binding-checker.mjs";
import { buildFamilyArtifact as buildCurrentQuantityCertificate } from "../quantity-values-r7/certificate.mjs";
import { buildFamilyArtifact as buildCurrentIdentityCertificate } from "../identity-values-r7/family.mjs";

/** Exact independently authored expected-term source. */
const EXPECTED_FILE = "experiments/tla-conformance/migration-helper-causal-r7/v9.expected.ts.txt";
/** Exact causal runtime artifact paired with the four callback-bearing B rows. */
const CAUSAL_FILE = "experiments/tla-conformance/migration-helper-causal-r7/artifacts/runtime-causal.json";
/** Independently reviewed quantity/measurement certificate commit. */
const QUANTITY_COMMIT = "5d13503";
/** Independently reviewed identity/value certificate commit. */
const IDENTITY_COMMIT = "02cf9387d669fd8655a71933849862cac8693cd9";
/** Current committed strict bank supplying unchanged Snapshot producer receipts. */
const BANK_FILE = "experiments/tla-conformance/admission-audit/bank-current/canonical-535.json";

/** Nine public V rows and their independently authored expected callable names. */
export const v9Contracts = [
  ["export:./migrations#createInventoryLegacyQueryReader::call[0]", "src/migration-plugin.ts", "createInventoryLegacyQueryReader", "expected_createInventoryLegacyQueryReader"],
  ["export:./migrations#defineInventoryLegacyQuery::call[0]", "src/migration-plugin.ts", "defineInventoryLegacyQuery", "expected_defineInventoryLegacyQuery"],
  ["export:./migrations#defineInventoryMigrationPlugin::call[0]", "src/migration-plugin.ts", "defineInventoryMigrationPlugin", "expected_defineInventoryMigrationPlugin"],
  ["export:./migrations#defineInventoryMigrationSourcePlugin::call[0]", "src/migration-plugin.ts", "defineInventoryMigrationSourcePlugin", "expected_defineInventoryMigrationSourcePlugin"],
  ["export:./migrations#inventoryMigrationPositionsMatch::call[0]", "src/migrations.ts", "inventoryMigrationPositionsMatch", "expected_inventoryMigrationPositionsMatch"],
  ["export:./migrations#inventoryMigrationProblem::call[0]", "src/migrations.ts", "inventoryMigrationProblem", "expected_inventoryMigrationProblem"],
  ["export:./storage#inventoryDurableMigrationPlanDigest::call[0]", "src/integrity.ts", "inventoryDurableMigrationPlanDigest", "expected_inventoryDurableMigrationPlanDigest"],
  ["export:./storage#materializeInventoryDurableMigrationWorld::call[0]", "src/storage.ts", "materializeInventoryDurableMigrationWorld", "expected_materializeInventoryDurableMigrationWorld"],
  ["export:./storage#validateInventoryMigrationManifestBeginInput::call[0]", "src/storage.ts", "validateInventoryMigrationManifestBeginInput", "expected_validateInventoryMigrationManifestBeginInput"],
].map(([surfaceKey, file, implementation, expected]) => ({ surfaceKey, file, implementation, expected }));

/** Local/private helper laws that are independently specified rather than recursively source-printed. */
const localLawContracts = [
  ["src/digest.ts#inventorySha256", "src/digest.ts", "inventorySha256", "expected_inventorySha256"],
  ["src/digest.ts#rotateRight", "src/digest.ts", "rotateRight", "expected_rotateRight"],
  ["src/storage.ts#validateBeginInventoryMigrationManifest", "src/storage.ts", "validateBeginInventoryMigrationManifest", "expected_validateBeginInventoryMigrationManifest"],
  ["src/storage.ts#migrationSourceDispositionsEqual", "src/storage.ts", "migrationSourceDispositionsEqual", "expected_migrationSourceDispositionsEqual"],
  ["src/migration-evidence.ts#inventoryMigrationSourceDispositionFingerprint", "src/migration-evidence.ts", "inventoryMigrationSourceDispositionFingerprint", "expected_inventoryMigrationSourceDispositionFingerprint"],
  ["src/storage.ts#validateInventoryDurableMigrationPlanAgainstBase", "src/storage.ts", "validateInventoryDurableMigrationPlanAgainstBase", "expected_validateInventoryDurableMigrationPlanAgainstBase"],
  ["src/storage.ts#inventoryWorldContentRootsEqual", "src/storage.ts", "inventoryWorldContentRootsEqual", "expected_inventoryWorldContentRootsEqual"],
].map(([id, file, implementation, expected]) => ({ id, file, implementation, expected }));

/** Exact direct package-function dependencies expected from each independently specified law. */
const expectedDependencies = new Map([
  ["src/migration-plugin.ts#createInventoryLegacyQueryReader", ["src/migration-plugin.ts#readAllInventoryLegacyQuery"]],
  ["src/migration-plugin.ts#defineInventoryLegacyQuery", []],
  ["src/migration-plugin.ts#defineInventoryMigrationPlugin", []],
  ["src/migration-plugin.ts#defineInventoryMigrationSourcePlugin", []],
  ["src/migrations.ts#inventoryMigrationPositionsMatch", [
    "src/measurements.ts#inventoryMeasurementsEqual",
    "src/migrations.ts#dryRunInventoryMigration",
    "src/model.ts#inventoryStockPositionIdentity",
  ]],
  ["src/migrations.ts#inventoryMigrationProblem", []],
  ["src/integrity.ts#inventoryDurableMigrationPlanDigest", ["src/digest.ts#inventorySha256"]],
  ["src/storage.ts#materializeInventoryDurableMigrationWorld", ["src/storage.ts#validateInventoryDurableMigrationPlanAgainstBase"]],
  ["src/storage.ts#validateInventoryMigrationManifestBeginInput", ["src/storage.ts#validateBeginInventoryMigrationManifest"]],
  ["src/digest.ts#inventorySha256", ["src/digest.ts#rotateRight"]],
  ["src/digest.ts#rotateRight", []],
  ["src/storage.ts#validateBeginInventoryMigrationManifest", ["src/storage.ts#migrationSourceDispositionsEqual"]],
  ["src/storage.ts#migrationSourceDispositionsEqual", [
    "src/canonical.ts#inventoryIntentFingerprint",
    "src/migration-evidence.ts#inventoryMigrationSourceDispositionFingerprint",
  ]],
  ["src/migration-evidence.ts#inventoryMigrationSourceDispositionFingerprint", ["src/canonical.ts#inventoryMetadataFingerprint"]],
  ["src/storage.ts#validateInventoryDurableMigrationPlanAgainstBase", [
    "src/catalog.ts#assertInventoryCatalogRetainsSnapshot",
    "src/catalog.ts#inventoryCatalogFromSnapshot",
    "src/integrity.ts#inventoryDurableMigrationPlanDigest",
    "src/integrity.ts#inventoryWorldContentRoots",
    "src/projection.ts#applyInventoryCommittedEvent",
    "src/storage.ts#inventoryWorldContentRootsEqual",
  ]],
  ["src/storage.ts#inventoryWorldContentRootsEqual", []],
]);

/** Read one Git blob with a bounded output cap large enough for current certificates. */
function gitBlob(repositoryRoot, specification) {
  return execFileSync("git", ["show", specification], { cwd: repositoryRoot, maxBuffer: 64 * 1024 * 1024 });
}

/** Return one current compiler source or one mutation-only parsed override. */
function currentSource(repositoryRoot, context, file, sourceOverrides) {
  const override = sourceOverrides.get(file);
  if (override !== undefined) {
    return ts.createSourceFile(path.resolve(repositoryRoot, file), override, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  }
  const source = context.program.getSourceFile(path.resolve(repositoryRoot, file));
  assert(source !== undefined && !source.isDeclarationFile, `Missing source ${file}`);
  return source;
}

/** Find one concrete top-level function. */
function findFunction(source, name) {
  const rows = source.statements.filter((node) => ts.isFunctionDeclaration(node) && node.name?.text === name);
  assert.equal(rows.length, 1, `Expected one function ${name}`);
  assert(rows[0].body !== undefined, `${name} has no body`);
  return rows[0];
}

/** Normalize source tokens while removing only whitespace/comments and the declaration's own name. */
function scanTokens(text) {
  const scanner = ts.createScanner(ts.ScriptTarget.Latest, true, ts.LanguageVariant.Standard, text);
  const tokens = [];
  for (;;) {
    const kind = scanner.scan();
    if (kind === ts.SyntaxKind.EndOfFileToken) break;
    tokens.push([ts.SyntaxKind[kind], scanner.getTokenText()]);
  }
  return tokens;
}

/** Produce a branch-complete callable term independent of source formatting and declaration name. */
function completeCallableTerm(declaration, source) {
  return {
    async: declaration.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword) ?? false,
    generator: declaration.asteriskToken !== undefined,
    typeParameters: (declaration.typeParameters ?? []).map((row) => scanTokens(row.getText(source))),
    parameters: declaration.parameters.map((row) => scanTokens(row.getText(source))),
    returnType: declaration.type === undefined ? null : scanTokens(declaration.type.getText(source)),
    body: scanTokens(declaration.body.getText(source)),
  };
}

/** Parse all independently authored expected functions exactly once. */
function expectedTerms(repositoryRoot) {
  const text = fs.readFileSync(path.resolve(repositoryRoot, EXPECTED_FILE), "utf8");
  const source = ts.createSourceFile(EXPECTED_FILE, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  const functions = new Map();
  const values = new Map();
  for (const statement of source.statements) {
    if (ts.isFunctionDeclaration(statement) && statement.name !== undefined && statement.body !== undefined) {
      functions.set(statement.name.text, completeCallableTerm(statement, source));
    }
    if (ts.isVariableStatement(statement)) {
      for (const declaration of statement.declarationList.declarations) {
        if (ts.isIdentifier(declaration.name) && declaration.initializer !== undefined) {
          values.set(declaration.name.text, {
            type: declaration.type === undefined ? null : scanTokens(declaration.type.getText(source)),
            initializer: scanTokens(declaration.initializer.getText(source)),
          });
        }
      }
    }
  }
  return { file: { file: EXPECTED_FILE, sha256: sha256(text) }, functions, values };
}

/** Resolve a package implementation declaration into one stable semantic id. */
function packageDeclarationId(repositoryRoot, declaration) {
  const file = path.relative(repositoryRoot, declaration.getSourceFile().fileName).replaceAll("\\", "/");
  if (!file.startsWith("src/")) return null;
  if (ts.isFunctionDeclaration(declaration) && declaration.name !== undefined) return `${file}#${declaration.name.text}`;
  if (ts.isMethodDeclaration(declaration) && declaration.name !== undefined) {
    const owner = declaration.parent?.name?.getText(declaration.getSourceFile());
    return `${file}#${owner === undefined ? "" : `${owner}.`}${declaration.name.getText(declaration.getSourceFile())}`;
  }
  return null;
}

/** Resolve direct package-function values/calls without recursively walking into their bodies. */
function directPackageDependencies(repositoryRoot, context, declaration) {
  const dependencies = new Set();
  function recordResolved(target) {
    if (target === undefined) return;
    let resolved = target;
    if (ts.isIdentifier(target) || ts.isPropertyAccessExpression(target)) {
      let symbol = context.checker.getSymbolAtLocation(ts.isPropertyAccessExpression(target) ? target.name : target);
      if (symbol !== undefined && (symbol.flags & ts.SymbolFlags.Alias) !== 0) symbol = context.checker.getAliasedSymbol(symbol);
      const sourceDeclaration = symbol?.declarations?.find((row) => packageDeclarationId(repositoryRoot, row) !== null);
      if (sourceDeclaration !== undefined) dependencies.add(packageDeclarationId(repositoryRoot, sourceDeclaration));
    }
    return resolved;
  }
  function visit(node) {
    if (ts.isCallExpression(node) || ts.isNewExpression(node)) {
      const target = context.checker.getResolvedSignature(node)?.declaration;
      const id = target === undefined ? null : packageDeclarationId(repositoryRoot, target);
      if (id !== null) dependencies.add(id);
      recordResolved(node.expression);
      for (const argument of node.arguments ?? []) recordResolved(argument);
    }
    ts.forEachChild(node, visit);
  }
  visit(declaration.body);
  return [...dependencies].sort();
}

/** Exact current declaration identity used to bind reused independent certificates. */
function currentDeclaration(repositoryRoot, context, file, name) {
  const declaration = findFunction(currentSource(repositoryRoot, context, file, new Map()), name);
  return { declaration, span: spanOf(context, declaration) };
}

/** Load and pin the reviewed quantity certificate directly from its immutable Git commit. */
function quantityCertificate(repositoryRoot, context, surface) {
  const document = buildCurrentQuantityCertificate({ repositoryRoot, context, surface });
  assert.equal(document.proofKind, "inventoryonce-quantity-measurement-complete-source-equations-v1");
  return { commit: "R131_CURRENT_SOURCE", sha256: sha256(canonicalJson(document)), document };
}

/** Rebuild the independently reviewed identity certificate on exact current source. */
function identityCertificate(repositoryRoot, context, surface) {
  const document = buildCurrentIdentityCertificate({ repositoryRoot, context, surface });
  assert.equal(document.proofKind, "independent-identity-values-closed-equations-v1");
  return { commit: "R131_CURRENT_SOURCE", sha256: sha256(canonicalJson(document)), document };
}

/** Bind one current helper exactly to an independently reviewed quantity equation. */
function quantityReceipt(repositoryRoot, context, certificate, id) {
  const rows = [...certificate.document.semanticCore.memberEquations, ...certificate.document.semanticCore.helperEquations].filter((row) => row.id === id);
  assert.equal(rows.length, 1, `Quantity certificate missing ${id}`);
  const [file, name] = id.split("#");
  const current = currentDeclaration(repositoryRoot, context, file, name);
  assert.deepEqual(current.span, rows[0].implementation, `Quantity dependency drifted: ${id}`);
  return { kind: "INDEPENDENT_QUANTITY_EQUATION", id, certificateCommit: certificate.commit, certificateSha256: certificate.sha256, equationSha256: rows[0].equationSha256 };
}

/** Bind one current helper exactly to an independently reviewed identity equation. */
function identityReceipt(repositoryRoot, context, certificate, id) {
  const rows = certificate.document.equations.filter((row) => row.id === id);
  assert.equal(rows.length, 1, `Identity certificate missing ${id}`);
  const [file, name] = id.split("#");
  const current = currentDeclaration(repositoryRoot, context, file, name);
  assert.deepEqual(current.span, rows[0].declaration, `Identity dependency drifted: ${id}`);
  return { kind: "INDEPENDENT_IDENTITY_EQUATION", id, certificateCommit: certificate.commit, certificateSha256: certificate.sha256, lawId: rows[0].lawId };
}

/** Reuse one existing strict Snapshot producer only after its execution artifact hash is current. */
function strictSnapshotReceipt(repositoryRoot, surfaceKey) {
  const bank = JSON.parse(fs.readFileSync(path.resolve(repositoryRoot, BANK_FILE), "utf8"));
  const row = bank.rows.find((candidate) => candidate.callable.key === surfaceKey);
  assert(row !== undefined && row.binding.mode !== "HARD_RED", `Snapshot producer is not strict: ${surfaceKey}`);
  const execution = row.binding.execution;
  assert(execution !== undefined);
  const bytes = fs.readFileSync(path.resolve(repositoryRoot, execution.file));
  assert.equal(sha256(bytes), execution.sha256, `Snapshot execution drifted: ${surfaceKey}`);
  return { kind: "STRICT_SNAPSHOT_PRODUCER", surfaceKey, mode: row.binding.mode, execution };
}

/** Retain the repaired callback B evidence as a paired-but-not-yet-globally-admitted dependency. */
function pairedCausalReceipt(repositoryRoot, id) {
  const bytes = fs.readFileSync(path.resolve(repositoryRoot, CAUSAL_FILE));
  const document = JSON.parse(bytes.toString("utf8"));
  assert.equal(document.proofKind, "migration-plugin-helper-causal-runtime-v1");
  assert.equal(sha256(bytes), "db76e559e9019216bf38f2b284c20a14faf878b216132a9f504d03e75624a263");
  assert.equal(document.directRead.transitions.length, 2);
  assert.equal(document.readerRead.transitions.length, 2);
  assert.equal(document.directRead.sourceAfter.readCount, 2);
  assert.equal(document.readerRead.sourceAfter.readCount, 2);
  assert.deepEqual(document.directRead.resultRows, document.readerRead.resultRows);
  return { kind: "PAIRED_B_CAUSAL_RUNTIME_READY", id, artifact: { file: CAUSAL_FILE, sha256: sha256(bytes) }, globallyAdmitted: false };
}

/** Resolve one direct semantic dependency without treating source identity as a semantic proof. */
function resolveDependency(repositoryRoot, context, quantity, identity, localIds, dependency) {
  if (localIds.has(dependency)) return { kind: "INDEPENDENT_LOCAL_EXPECTED_TERM", id: dependency };
  if (dependency === "src/migration-plugin.ts#readAllInventoryLegacyQuery") return pairedCausalReceipt(repositoryRoot, dependency);
  if (dependency === "src/migrations.ts#dryRunInventoryMigration") return strictSnapshotReceipt(repositoryRoot, "export:./migrations#dryRunInventoryMigration::call[0]");
  if (["src/measurements.ts#inventoryMeasurementsEqual", "src/canonical.ts#inventoryIntentFingerprint"].includes(dependency)) {
    return quantityReceipt(repositoryRoot, context, quantity, dependency);
  }
  if (["src/model.ts#inventoryStockPositionIdentity", "src/canonical.ts#inventoryMetadataFingerprint"].includes(dependency)) {
    return identityReceipt(repositoryRoot, context, identity, dependency);
  }
  if (dependency === "src/integrity.ts#inventoryDurableMigrationPlanDigest") return { kind: "SAME_V9_COMPLETE_EXPECTED_TERM", id: dependency };
  const blockers = {
    "src/integrity.ts#inventoryWorldContentRoots": "AUTHORITY_COMPLETE_WORLD_ROOT_LAW_PENDING",
    "src/catalog.ts#inventoryCatalogFromSnapshot": "AUTHORITY_COMPLETE_CATALOG_REHYDRATION_LAW_PENDING",
    "src/catalog.ts#assertInventoryCatalogRetainsSnapshot": "AUTHORITY_COMPLETE_CATALOG_RETENTION_LAW_PENDING",
    "src/projection.ts#applyInventoryCommittedEvent": "COMPLETE_MIGRATION_EVENT_PROJECTION_LAW_PENDING",
  };
  if (blockers[dependency] !== undefined) return { kind: "NAMED_GAP", id: blockers[dependency], dependency };
  throw new Error(`Unclassified semantic dependency ${dependency}`);
}

/** Compare one actual complete term against its separately authored expected term. */
function proveExpectedTerm(repositoryRoot, context, expected, contract, sourceOverrides) {
  const source = currentSource(repositoryRoot, context, contract.file, sourceOverrides);
  const actual = findFunction(source, contract.implementation);
  const expectedTerm = expected.functions.get(contract.expected);
  assert(expectedTerm !== undefined, `Expected term missing ${contract.expected}`);
  const term = completeCallableTerm(actual, source);
  assert.deepEqual(term, expectedTerm, `Complete expected term mismatch: ${contract.implementation}`);
  return { termSha256: sha256(canonicalJson(term)), implementation: sourceOverrides.size === 0 ? spanOf(context, actual) : { file: contract.file, mutatedControl: true } };
}

/** Compare SHA supporting constants independently of the production function body. */
function proveShaSupportingValues(repositoryRoot, context, expected, sourceOverrides) {
  const source = currentSource(repositoryRoot, context, "src/digest.ts", sourceOverrides);
  const rows = [];
  for (const name of ["SHA256_INITIAL_HASH", "SHA256_ROUND_CONSTANTS"]) {
    const declarations = [];
    for (const statement of source.statements) {
      if (!ts.isVariableStatement(statement)) continue;
      for (const declaration of statement.declarationList.declarations) {
        if (ts.isIdentifier(declaration.name) && declaration.name.text === name) declarations.push(declaration);
      }
    }
    assert.equal(declarations.length, 1);
    const declaration = declarations[0];
    assert(declaration.initializer !== undefined);
    const actual = {
      type: declaration.type === undefined ? null : scanTokens(declaration.type.getText(source)),
      initializer: scanTokens(declaration.initializer.getText(source)),
    };
    const wanted = expected.values.get(name);
    assert(wanted !== undefined);
    assert.deepEqual(actual, wanted, `SHA supporting constant changed: ${name}`);
    rows.push({ name, termSha256: sha256(canonicalJson(actual)) });
  }
  return rows;
}

/** Recursively propagate named gaps through independently specified local helper laws. */
function transitiveGaps(receipts, localById, seen = new Set()) {
  const gaps = [];
  for (const receipt of receipts) {
    if (receipt.kind === "NAMED_GAP") {
      gaps.push(receipt);
      continue;
    }
    if (receipt.kind !== "INDEPENDENT_LOCAL_EXPECTED_TERM" || seen.has(receipt.id)) continue;
    const local = localById.get(receipt.id);
    assert(local !== undefined, `Local law missing ${receipt.id}`);
    const childSeen = new Set(seen);
    childSeen.add(receipt.id);
    gaps.push(...transitiveGaps(local.dependencies, localById, childSeen));
  }
  return [...new Map(gaps.map((gap) => [gap.id, gap])).values()].sort((left, right) => left.id.localeCompare(right.id));
}

/** Return whether a dependency chain still relies on one not-yet-globally-admitted paired B producer. */
function hasPairedB(receipts, localById, seen = new Set()) {
  for (const receipt of receipts) {
    if (receipt.kind === "PAIRED_B_CAUSAL_RUNTIME_READY" && !receipt.globallyAdmitted) return true;
    if (receipt.kind !== "INDEPENDENT_LOCAL_EXPECTED_TERM" || seen.has(receipt.id)) continue;
    const local = localById.get(receipt.id);
    assert(local !== undefined, `Local law missing ${receipt.id}`);
    const childSeen = new Set(seen); childSeen.add(receipt.id);
    if (hasPairedB(local.dependencies, localById, childSeen)) return true;
  }
  return false;
}

/** Build the independently specified V9 family; mutations are source-only negative controls. */
export function buildIndependentV9Artifact({ repositoryRoot = process.cwd(), sourceOverrides = new Map(), context = loadEvidenceCompilerContext(repositoryRoot, []), surface = discoverCompilerSurface(repositoryRoot) } = {}) {
  const expected = expectedTerms(repositoryRoot);
  const quantity = quantityCertificate(repositoryRoot, context, surface);
  const identity = identityCertificate(repositoryRoot, context, surface);
  const localIds = new Set(localLawContracts.map((row) => row.id));
  const proofs = [];
  const localLaws = [];

  for (const contract of v9Contracts) {
    const proved = proveExpectedTerm(repositoryRoot, context, expected, contract, sourceOverrides);
    if (sourceOverrides.size > 0) continue;
    const actual = findFunction(currentSource(repositoryRoot, context, contract.file, sourceOverrides), contract.implementation);
    const id = `${contract.file}#${contract.implementation}`;
    const dependencies = directPackageDependencies(repositoryRoot, context, actual);
    assert.deepEqual(dependencies, expectedDependencies.get(id), `Direct dependency set changed: ${id}`);
    const receipts = dependencies.map((dependency) => resolveDependency(repositoryRoot, context, quantity, identity, localIds, dependency));
    proofs.push({
      surfaceKey: contract.surfaceKey,
      implementationId: id,
      completeExpectedTerm: proved,
      dependencies: receipts,
      status: "PENDING_TRANSITIVE_DISPOSITION",
      gaps: [],
    });
  }

  if (sourceOverrides.size > 0) {
    for (const contract of localLawContracts) {
      proveExpectedTerm(repositoryRoot, context, expected, contract, sourceOverrides);
    }
    proveShaSupportingValues(repositoryRoot, context, expected, sourceOverrides);
    return { mutationControlAccepted: false };
  }

  for (const contract of localLawContracts) {
    const proved = proveExpectedTerm(repositoryRoot, context, expected, contract, sourceOverrides);
    const actual = findFunction(currentSource(repositoryRoot, context, contract.file, sourceOverrides), contract.implementation);
    const dependencies = directPackageDependencies(repositoryRoot, context, actual);
    assert.deepEqual(dependencies, expectedDependencies.get(contract.id), `Direct helper dependency set changed: ${contract.id}`);
    const receipts = dependencies.map((dependency) => resolveDependency(repositoryRoot, context, quantity, identity, localIds, dependency));
    localLaws.push({ id: contract.id, completeExpectedTerm: proved, dependencies: receipts, gaps: [] });
  }

  const localById = new Map(localLaws.map((law) => [law.id, law]));
  for (const law of localLaws) law.gaps = transitiveGaps(law.dependencies, localById, new Set([law.id]));
  for (const proof of proofs) {
    proof.gaps = transitiveGaps(proof.dependencies, localById);
    proof.status = proof.gaps.length > 0
      ? "BLOCKED_DEPENDENCY_GAP"
      : hasPairedB(proof.dependencies, localById)
        ? "READY_WITH_PAIRED_B_DEPENDENCY"
        : "INDEPENDENTLY_CLOSED";
  }

  const supportingValues = proveShaSupportingValues(repositoryRoot, context, expected, sourceOverrides);
  const allGaps = [...proofs.flatMap((proof) => proof.gaps), ...localLaws.flatMap((law) => law.gaps)];
  const gapById = new Map(allGaps.map((gap) => [gap.id, gap]));
  return {
    schemaVersion: 1,
    proofKind: "migration-plugin-helper-independent-complete-v9-equations-v2",
    semanticSourceBase: "2eea09471b3bf8fcb61f38256e1c6a362149dad4",
    expectedSpecification: expected.file,
    independentDependencies: {
      quantity: { commit: quantity.commit, artifactSha256: quantity.sha256, proofKind: quantity.document.proofKind },
      identity: { commit: identity.commit, artifactSha256: identity.sha256, proofKind: identity.document.proofKind },
    },
    allAdmittedInputs: true,
    sampledInputs: 0,
    // Retain exact transitive input receipts for additive compatibility with the already-banked V6 wrapper.
    reusedInputs: [...new Map([...quantity.document.inputs, ...identity.document.inputs].map((row) => [row.file, row])).values()],
    proofs,
    localLaws,
    supportingValues,
    disposition: {
      independentlyClosed: proofs.filter((proof) => proof.status === "INDEPENDENTLY_CLOSED").map((proof) => proof.surfaceKey),
      readyWithPairedB: proofs.filter((proof) => proof.status === "READY_WITH_PAIRED_B_DEPENDENCY").map((proof) => proof.surfaceKey),
      blocked: proofs.filter((proof) => proof.status === "BLOCKED_DEPENDENCY_GAP").map((proof) => ({ surfaceKey: proof.surfaceKey, gaps: proof.gaps })),
      namedGaps: [...gapById.values()].sort((left, right) => left.id.localeCompare(right.id)),
    },
  };
}

/** Require recorded independent-law evidence to equal a fresh rederivation. */
export function verifyIndependentV9Artifact(recorded, repositoryRoot = process.cwd()) {
  assert.deepEqual(recorded, buildIndependentV9Artifact({ repositoryRoot }), "Recorded independent V9 artifact differs from fresh complete expected laws");
  return true;
}
