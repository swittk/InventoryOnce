import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { canonicalJson, discoverCompilerSurface, sha256, spanOf, ts } from "../surface-bindings/lib/compiler-surface.mjs";
import { loadEvidenceCompilerContext } from "../surface-bindings/lib/binding-checker.mjs";
import { buildIndependentV9Artifact } from "./independent-v9-laws.mjs";
import { verifyCausalB4Runtime } from "./causal-runtime-verifier.mjs";

export const proofKind = "migration-plugin-helper-causal-b4-producer-v1";
export const supportedSurfaceRows = Object.freeze([
  { surfaceKey: "export:./migrations#createInventoryMigrationPlanFromPlugin::call[0]", mode: "B" },
  { surfaceKey: "export:./migrations#createInventoryMigrationPlanFromSourcePlugin::call[0]", mode: "B" },
  { surfaceKey: "export:./migrations#readAllInventoryLegacyQuery::call[0]", mode: "B" },
  { surfaceKey: "type:src/migration-plugin.ts#InventoryLegacyQueryReader.readAll::call[0]", mode: "B" },
]);

const SOURCE = "src/migration-plugin.ts";
const EXPECTED = "experiments/tla-conformance/migration-helper-causal-r7/b4.expected.ts.txt";
const CAUSAL = "experiments/tla-conformance/migration-helper-causal-r7/artifacts/runtime-causal.json";
const CAUSAL_VERIFIER = "experiments/tla-conformance/migration-helper-causal-r7/causal-runtime-verifier.mjs";
const OLD_BANK = "experiments/tla-conformance/admission-audit/bank-current/canonical-535.json";
/** Same-process cache for one exact current-source B4 producer; every declared input is rechecked before reuse. */
let currentBuildCache;

const laws = Object.freeze({
  "export:./migrations#readAllInventoryLegacyQuery::call[0]": "Validate positive safe bounds, repeatedly invoke the actual application query.readPage with exact cursor/limit, append callback rows in order, reject overflow/empty/repeated cursor/page exhaustion, and return only the callback-caused complete row sequence.",
  "type:src/migration-plugin.ts#InventoryLegacyQueryReader.readAll::call[0]": "The factory-created reader delegates its exact query and captured options to readAllInventoryLegacyQuery; it does not reconstruct callback rows or detached source state.",
  "export:./migrations#createInventoryMigrationPlanFromPlugin::call[0]": "Invoke the actual plugin.createDeclaration with the real bounded reader, then pass exactly that returned declaration and the supplied catalog into strict defineInventoryMigration; the returned plan is caused by the callback result.",
  "export:./migrations#createInventoryMigrationPlanFromSourcePlugin::call[0]": "Invoke the actual plugin.createBundle with the real bounded reader, return the callback-provided catalog, and compile exactly the callback-provided declaration against that catalog through strict defineInventoryMigration.",
});

function scanTokens(text) {
  const scanner = ts.createScanner(ts.ScriptTarget.Latest, true, ts.LanguageVariant.Standard, text);
  const result = [];
  for (;;) {
    const kind = scanner.scan();
    if (kind === ts.SyntaxKind.EndOfFileToken) break;
    result.push([ts.SyntaxKind[kind], scanner.getTokenText()]);
  }
  return result;
}

function currentSource(repositoryRoot, context, overrides) {
  const replacement = overrides.get(SOURCE);
  if (replacement !== undefined) return ts.createSourceFile(path.resolve(repositoryRoot, SOURCE), replacement, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  const source = context.program.getSourceFile(path.resolve(repositoryRoot, SOURCE));
  assert(source !== undefined && !source.isDeclarationFile);
  return source;
}

function findFunction(source, name) {
  const rows = source.statements.filter((row) => ts.isFunctionDeclaration(row) && row.name?.text === name);
  assert.equal(rows.length, 1, `Expected one function ${name}`);
  assert(rows[0].body !== undefined);
  return rows[0];
}

function findExpectedArrow(source) {
  for (const statement of source.statements) {
    if (!ts.isVariableStatement(statement)) continue;
    for (const declaration of statement.declarationList.declarations) {
      if (ts.isIdentifier(declaration.name) && declaration.name.text === "expectedInventoryLegacyQueryReaderReadAll") {
        assert(ts.isArrowFunction(declaration.initializer));
        return declaration.initializer;
      }
    }
  }
  throw new Error("Expected reader arrow missing.");
}

function findActualReaderArrow(source) {
  const factory = findFunction(source, "createInventoryLegacyQueryReader");
  let found;
  function visit(node) {
    if (ts.isPropertyAssignment(node) && node.name.getText(source) === "readAll" && ts.isArrowFunction(node.initializer)) {
      assert.equal(found, undefined, "Ambiguous reader.readAll implementation");
      found = node.initializer;
    }
    ts.forEachChild(node, visit);
  }
  visit(factory.body);
  assert(found !== undefined, "reader.readAll implementation missing");
  return found;
}

function callableTerm(node, source) {
  return scanTokens(node.getText(source));
}

function expectedDocument(repositoryRoot) {
  const file = path.resolve(repositoryRoot, EXPECTED);
  const text = fs.readFileSync(file, "utf8");
  return { file: EXPECTED, source: ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS) };
}

function assertExpectedFunction(actualSource, expectedSource, name) {
  const actual = findFunction(actualSource, name);
  const expected = findFunction(expectedSource, name);
  const actualTerm = callableTerm(actual, actualSource);
  const expectedTerm = callableTerm(expected, expectedSource);
  assert.deepEqual(actualTerm, expectedTerm, `Complete expected B term mismatch: ${name}`);
  return { actual, termSha256: sha256(canonicalJson(actualTerm)) };
}

function assertExpectedReaderArrow(actualSource, expectedSource) {
  const actual = findActualReaderArrow(actualSource);
  const expected = findExpectedArrow(expectedSource);
  const a = callableTerm(actual, actualSource);
  const e = callableTerm(expected, expectedSource);
  assert.deepEqual(a, e, "Complete expected reader.readAll arrow mismatch");
  return { actual, termSha256: sha256(canonicalJson(a)) };
}

function strictDefineReceipt(repositoryRoot, context, surface) {
  const bank = JSON.parse(fs.readFileSync(path.resolve(repositoryRoot, OLD_BANK), "utf8"));
  const key = "export:./migrations#defineInventoryMigration::call[0]";
  const row = bank.rows.find((candidate) => candidate.callable.key === key);
  assert(row !== undefined && row.binding.mode !== "HARD_RED");
  const live = surface.callables.find((candidate) => candidate.key === key);
  assert(live !== undefined);
  assert.equal(live.signatureHash, row.callable.signatureHash);
  assert.deepEqual(live.declaration, row.callable.declaration);
  const execution = row.binding.execution;
  assert(execution !== undefined);
  const bytes = fs.readFileSync(path.resolve(repositoryRoot, execution.file));
  assert.equal(sha256(bytes), execution.sha256);
  const source = context.program.getSourceFile(path.resolve(repositoryRoot, live.declaration.file));
  assert(source !== undefined);
  return { surfaceKey: key, mode: row.binding.mode, execution, declaration: live.declaration, signatureHash: live.signatureHash };
}

function causalReceipt(repositoryRoot) {
  const bytes = fs.readFileSync(path.resolve(repositoryRoot, CAUSAL));
  const document = JSON.parse(bytes.toString("utf8"));
  assert.equal(verifyCausalB4Runtime(document), true);
  return { file: CAUSAL, sha256: sha256(bytes), proofKind: document.proofKind, document };
}

function addInput(repositoryRoot, inputs, file) {
  if (inputs.has(file)) return;
  inputs.set(file, { file, sha256: sha256(fs.readFileSync(path.resolve(repositoryRoot, file))) });
}

function buildSemanticCore({ repositoryRoot, context, surface, sourceOverrides = new Map() }) {
  const source = currentSource(repositoryRoot, context, sourceOverrides);
  const expected = expectedDocument(repositoryRoot);
  const helper = assertExpectedFunction(source, expected.source, "assertPositiveSafeInteger");
  const readAll = assertExpectedFunction(source, expected.source, "readAllInventoryLegacyQuery");
  const ordinary = assertExpectedFunction(source, expected.source, "createInventoryMigrationPlanFromPlugin");
  const sourcePlugin = assertExpectedFunction(source, expected.source, "createInventoryMigrationPlanFromSourcePlugin");
  const reader = assertExpectedReaderArrow(source, expected.source);
  if (sourceOverrides.size > 0) return { mutationControlAccepted: false };

  const v9 = buildIndependentV9Artifact({ repositoryRoot, context, surface });
  const factory = v9.proofs.find((proof) => proof.surfaceKey === "export:./migrations#createInventoryLegacyQueryReader::call[0]");
  assert(factory !== undefined && factory.status === "READY_WITH_PAIRED_B_DEPENDENCY");
  const strictDefine = strictDefineReceipt(repositoryRoot, context, surface);
  const causal = causalReceipt(repositoryRoot);
  const live = new Map(surface.callables.map((callable) => [callable.key, callable]));

  const terms = new Map([
    ["export:./migrations#readAllInventoryLegacyQuery::call[0]", { termSha256: readAll.termSha256, implementation: spanOf(context, readAll.actual), dependency: { local: "assertPositiveSafeInteger", termSha256: helper.termSha256 }, externalBoundary: "InventoryLegacyQuery.readPage", causalMember: "directRead" }],
    ["type:src/migration-plugin.ts#InventoryLegacyQueryReader.readAll::call[0]", { termSha256: reader.termSha256, implementation: spanOf(context, reader.actual), dependency: { sameFamily: "export:./migrations#readAllInventoryLegacyQuery::call[0]", factoryExpectedTerm: factory.completeExpectedTerm }, externalBoundary: null, causalMember: "readerRead" }],
    ["export:./migrations#createInventoryMigrationPlanFromPlugin::call[0]", { termSha256: ordinary.termSha256, implementation: spanOf(context, ordinary.actual), dependencies: [{ supportingV: "export:./migrations#createInventoryLegacyQueryReader::call[0]", factoryExpectedTerm: factory.completeExpectedTerm }, { strictProducer: strictDefine }], externalBoundary: "InventoryMigrationPlugin.createDeclaration", causalMember: "pluginPlan" }],
    ["export:./migrations#createInventoryMigrationPlanFromSourcePlugin::call[0]", { termSha256: sourcePlugin.termSha256, implementation: spanOf(context, sourcePlugin.actual), dependencies: [{ supportingV: "export:./migrations#createInventoryLegacyQueryReader::call[0]", factoryExpectedTerm: factory.completeExpectedTerm }, { strictProducer: strictDefine }], externalBoundary: "InventoryMigrationSourcePlugin.createBundle", causalMember: "sourcePluginPlan" }],
  ]);

  const proofs = supportedSurfaceRows.map(({ surfaceKey, mode }) => {
    const callable = live.get(surfaceKey);
    assert(callable !== undefined, `Surface missing ${surfaceKey}`);
    const semantics = terms.get(surfaceKey);
    assert(semantics !== undefined);
    return { surfaceKey, mode, signatureHash: callable.signatureHash, declaration: callable.declaration, law: laws[surfaceKey], semantics, causalEvidence: { file: causal.file, sha256: causal.sha256, member: semantics.causalMember } };
  });

  return { proofs, strictDefine, causal: { file: causal.file, sha256: causal.sha256, proofKind: causal.proofKind }, supportingFactory: factory };
}

export function buildFamilyArtifact({ repositoryRoot = process.cwd(), context = loadEvidenceCompilerContext(repositoryRoot, []), surface = discoverCompilerSurface(repositoryRoot), sourceOverrides = new Map() } = {}) {
  if (sourceOverrides.size === 0 && currentBuildCache?.surfaceDigest === surface.digest) {
    for (const input of currentBuildCache.artifact.inputs) {
      const actual = sha256(fs.readFileSync(path.resolve(repositoryRoot, input.file)));
      assert.equal(actual, input.sha256, `Cached B4 input changed: ${input.file}`);
      if (input.file.startsWith("src/") && input.file.endsWith(".ts")) {
        const source = context.program.getSourceFile(path.resolve(repositoryRoot, input.file));
        assert(source !== undefined, `Compiler omitted cached B4 source: ${input.file}`);
        assert.equal(sha256(source.text), input.sha256, `Compiler snapshot is stale: ${input.file}`);
      }
    }
    return currentBuildCache.artifact;
  }
  const core = buildSemanticCore({ repositoryRoot, context, surface, sourceOverrides });
  if (sourceOverrides.size > 0) return core;
  const inputs = new Map();
  for (const file of [SOURCE, EXPECTED, CAUSAL, CAUSAL_VERIFIER, "experiments/tla-conformance/migration-helper-causal-r7/registered-causal-b4-family.mjs", "experiments/tla-conformance/migration-helper-causal-r7/independent-v9-laws.mjs", "experiments/tla-conformance/migration-helper-causal-r7/v9.expected.ts.txt", "experiments/tla-conformance/migration-helper-causal-r7/causal-runtime.ts", OLD_BANK]) addInput(repositoryRoot, inputs, file);
  addInput(repositoryRoot, inputs, core.strictDefine.execution.file);
  addInput(repositoryRoot, inputs, core.strictDefine.declaration.file);
  const artifact = {
    schemaVersion: 1,
    route: "REGISTERED_CERTIFIED_PRODUCER",
    proofKind,
    family: "MigrationPluginHelpersCausalB4",
    surfaceDigest: surface.digest,
    domain: "All values admitted by the exact four public TypeScript signatures. Application-owned readPage/createDeclaration/createBundle callbacks remain explicit typed external boundaries; the complete InventoryOnce-owned control flow is independently term-checked, while retained real callback chains establish causal source association without inventing formal Snapshot edges.",
    allAdmittedInputs: true,
    sampledInputs: 0,
    causalWitnessRuns: 4,
    producerGraphRuns: 0,
    producerReplayRuns: 0,
    inputs: [...inputs.values()].sort((a,b) => a.file.localeCompare(b.file)),
    causalEvidence: core.causal,
    proofs: core.proofs,
  };
  currentBuildCache = { surfaceDigest: surface.digest, artifact };
  return artifact;
}

export function verifyRecordedCausalB4(recorded, repositoryRoot = process.cwd()) {
  const current = buildFamilyArtifact({ repositoryRoot });
  assert.deepEqual(recorded, current, "Recorded causal B4 family differs from current complete source/causal truth");
  return true;
}
