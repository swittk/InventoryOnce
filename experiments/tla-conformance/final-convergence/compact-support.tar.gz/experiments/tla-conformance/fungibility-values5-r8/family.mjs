import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { canonicalJson, sha256, spanOf, ts } from "../surface-bindings/lib/compiler-surface.mjs";
import { loadEvidenceCompilerContext } from "../surface-bindings/lib/binding-checker.mjs";
import { buildIdentityValuesFamilyArtifact } from "../identity-values-r7/family.mjs";

export const proofKind = "fungibility-scope-policy-batch-complete-values-v1";
export const supportedSurfaceKeys = Object.freeze([
  "export:.#inventoryFungibilityScopeIdentity::call[0]",
  "export:.#inventoryPolicyBatchAllocationLinesByReference::call[0]",
  "export:.#normalizeInventoryFungibilityScope::call[0]",
  "export:./kernel#inventoryFungibilityScopeIdentity::call[0]",
  "export:./kernel#normalizeInventoryFungibilityScope::call[0]",
].sort());

const EXPECTED="experiments/tla-conformance/fungibility-values5-r8/equations.expected.ts.txt";
const IDENTITY_DEP="src/selectors.ts#normalizeInventoryStockSelector";
const contracts=Object.freeze([
  {id:"src/fungibility.ts#normalizeInventoryFungibilityScope",file:"src/fungibility.ts",name:"normalizeInventoryFungibilityScope",law:"Normalize all common pool scope dimensions through the exact stock-selector normalization equation, inject only the synthetic item discriminator for validation, then remove item and item-revision dimensions from the returned common scope.",dependencies:[IDENTITY_DEP]},
  {id:"src/fungibility.ts#inventoryFungibilityScopeIdentity",file:"src/fungibility.ts",name:"inventoryFungibilityScopeIdentity",law:"Serialize exactly the normalized fungibility scope with JSON.stringify and no caller-form representation.",dependencies:["src/fungibility.ts#normalizeInventoryFungibilityScope"]},
  {id:"src/facade.ts#inventoryPolicyBatchAllocationLinesByReference",file:"src/facade.ts",name:"inventoryPolicyBatchAllocationLinesByReference",law:"Visit allocations in order, require every native request id to have an application reference, append every native allocation line in input order to that reference, and return the resulting reference map without rebuilding allocation truth.",dependencies:[]},
]);
const equationByKey=Object.freeze({
  "export:.#inventoryFungibilityScopeIdentity::call[0]":"src/fungibility.ts#inventoryFungibilityScopeIdentity",
  "export:./kernel#inventoryFungibilityScopeIdentity::call[0]":"src/fungibility.ts#inventoryFungibilityScopeIdentity",
  "export:.#normalizeInventoryFungibilityScope::call[0]":"src/fungibility.ts#normalizeInventoryFungibilityScope",
  "export:./kernel#normalizeInventoryFungibilityScope::call[0]":"src/fungibility.ts#normalizeInventoryFungibilityScope",
  "export:.#inventoryPolicyBatchAllocationLinesByReference::call[0]":"src/facade.ts#inventoryPolicyBatchAllocationLinesByReference",
});

function source(root,context,file,overrides){
  const changed=overrides.get(file); if(changed!==undefined)return ts.createSourceFile(path.resolve(root,file),changed,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
  const s=context.program.getSourceFile(path.resolve(root,file)); assert(s!==undefined&&!s.isDeclarationFile,`Missing ${file}`); return s;
}
function findFunction(s,name){const rows=s.statements.filter(n=>ts.isFunctionDeclaration(n)&&n.name?.text===name);assert.equal(rows.length,1,`Expected one function ${name}`);assert(rows[0].body!==undefined);return rows[0];}
function tokens(text){const scanner=ts.createScanner(ts.ScriptTarget.Latest,true,ts.LanguageVariant.Standard,text);const out=[];for(;;){const k=scanner.scan();if(k===ts.SyntaxKind.EndOfFileToken)break;out.push([ts.SyntaxKind[k],scanner.getTokenText()]);}return out;}
function term(s,d){return tokens(d.getText(s));}
function addInput(root,inputs,file){if(inputs.has(file))return;inputs.set(file,{file,sha256:sha256(fs.readFileSync(path.resolve(root,file)))});}

function identityReceipt({repositoryRoot,context,surface,sourceOverrides}){
  const artifact=buildIdentityValuesFamilyArtifact({repositoryRoot,context,surface,sourceOverrides});
  const equation=artifact.equations.find(row=>row.id===IDENTITY_DEP);assert(equation!==undefined,"Identity selector equation missing");
  assert.equal(equation.lawId,"selector-normalization-v1");
  return {id:IDENTITY_DEP,lawId:equation.lawId,declaration:equation.declaration,termSha256:sha256(canonicalJson(equation.term)),dependencies:equation.dependencies,inputs:artifact.inputs};
}

export function buildFamilyArtifact({repositoryRoot=process.cwd(),context=loadEvidenceCompilerContext(repositoryRoot,[]),surface,sourceOverrides=new Map()}={}){
  assert(surface!==undefined,"surface required");
  const expectedText=fs.readFileSync(path.resolve(repositoryRoot,EXPECTED),"utf8");
  const expected=ts.createSourceFile(path.resolve(repositoryRoot,EXPECTED),expectedText,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);assert.equal(expected.parseDiagnostics.length,0);
  const identity=identityReceipt({repositoryRoot,context,surface,sourceOverrides});
  const equations=[];
  for(const c of contracts){const aSource=source(repositoryRoot,context,c.file,sourceOverrides),a=findFunction(aSource,c.name),e=findFunction(expected,c.name);const actual=term(aSource,a),wanted=term(expected,e);assert.deepEqual(actual,wanted,`Independent equation changed: ${c.id}`);equations.push({id:c.id,law:c.law,dependencies:c.dependencies,termSha256:sha256(canonicalJson(actual)),implementation:sourceOverrides.size===0?spanOf(context,a):{file:c.file,mutationControl:true}});}
  if(sourceOverrides.size>0)return {mutationControlAccepted:false};
  const eq=new Map(equations.map(x=>[x.id,x])),live=new Map(surface.callables.map(c=>[c.key,c]));
  const proofs=supportedSurfaceKeys.map(surfaceKey=>{const callable=live.get(surfaceKey);assert(callable!==undefined,`Missing ${surfaceKey}`);const equation=eq.get(equationByKey[surfaceKey]);assert(equation!==undefined);return {surfaceKey,signatureHash:callable.signatureHash,declaration:callable.declaration,equationId:equation.id,semantics:{law:equation.law,completeExpectedTermSha256:equation.termSha256,dependencies:equation.dependencies.map(id=>id===IDENTITY_DEP?{kind:"INDEPENDENT_IDENTITY_EQUATION",...identity}:{kind:"SAME_FAMILY_COMPLETE_EQUATION",id})}};});
  const inputs=new Map();for(const f of ["experiments/tla-conformance/fungibility-values5-r8/family.mjs",EXPECTED,"experiments/tla-conformance/identity-values-r7/family.mjs","experiments/tla-conformance/identity-values-r7/equations.ts.txt","src/fungibility.ts","src/facade.ts","src/selectors.ts"])addInput(repositoryRoot,inputs,f);for(const i of identity.inputs??[])addInput(repositoryRoot,inputs,i.file);
  return {schemaVersion:1,proofKind,surfaceDigest:surface.digest,domain:"All inputs admitted by the exact five public TypeScript signatures. Three pure implementations are checked against separately authored complete declaration terms; selector normalization is recursively tied to the independent identity-selector equation. No runtime samples or stateful action credit.",allAdmittedInputs:true,sampledInputs:0,inputs:[...inputs.values()].sort((a,b)=>a.file.localeCompare(b.file)),equations,identityDependency:{id:identity.id,lawId:identity.lawId,declaration:identity.declaration,termSha256:identity.termSha256,dependencies:identity.dependencies},proofs};
}
