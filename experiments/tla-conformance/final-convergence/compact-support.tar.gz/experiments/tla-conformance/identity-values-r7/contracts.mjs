/** Stable identity for the complete identity/value source-equation family. */
export const IDENTITY_VALUES_FAMILY_ID =
  "inventoryonce.identity-values.closed-source-equations.v1";

/** Exact public aliases assigned to this batch by the owner manifest. */
export const ASSIGNED_SURFACE_KEYS = Object.freeze([
  "export:.#assertInventoryAmountSum::call[0]",
  "export:.#everythingInInventoryStockSelector::call[0]",
  "export:.#inventoryAmountFromUnit::call[0]",
  "export:.#inventoryContainerIdentity::call[0]",
  "export:.#inventoryLotIdentity::call[0]",
  "export:.#inventoryMeasuredAmountFromVector::call[0]",
  "export:.#inventoryPositionEffectiveUseBy::call[0]",
  "export:.#inventoryPositionIsExpiredAt::call[0]",
  "export:.#inventoryStockSelector::call[0]",
  "export:.#measuredStockAmount::call[0]",
  "export:.#packageAmount::call[0]",
  "export:.#resolveInventoryAmount::call[0]",
  "export:.#stockAmount::call[0]",
  "export:./kernel#assertInventoryAmountSum::call[0]",
  "export:./kernel#assertInventoryIdentity::call[0]",
  "export:./kernel#assertPositionInsideSelector::call[0]",
  "export:./kernel#everythingInInventoryStockSelector::call[0]",
  "export:./kernel#inventoryAmountFromUnit::call[0]",
  "export:./kernel#inventoryContainerIdentity::call[0]",
  "export:./kernel#inventoryIntentFingerprint::call[0]",
  "export:./kernel#inventoryLotIdentity::call[0]",
  "export:./kernel#inventoryMeasuredAmountFromVector::call[0]",
  "export:./kernel#inventoryMetadataFingerprint::call[0]",
  "export:./kernel#inventoryMetadataValueFingerprint::call[0]",
  "export:./kernel#inventoryPositionEffectiveUseBy::call[0]",
  "export:./kernel#inventoryPositionIsExpiredAt::call[0]",
  "export:./kernel#inventorySerialIdentity::call[0]",
  "export:./kernel#inventoryStockPositionIdentity::call[0]",
  "export:./kernel#inventoryStockPositionMatchesNormalizedSelector::call[0]",
  "export:./kernel#inventoryStockPositionMatchesSelector::call[0]",
  "export:./kernel#inventoryStockSelector::call[0]",
  "export:./kernel#inventoryStockSelectorIdentity::call[0]",
  "export:./kernel#inventoryStockSelectorIsSubset::call[0]",
  "export:./kernel#inventoryTraceabilityNodeIdentity::call[0]",
  "export:./kernel#measuredStockAmount::call[0]",
  "export:./kernel#normalizeInventoryStockPositionKey::call[0]",
  "export:./kernel#normalizeInventoryStockSelector::call[0]",
  "export:./kernel#packageAmount::call[0]",
  "export:./kernel#resolveInventoryAmount::call[0]",
  "export:./kernel#stockAmount::call[0]",
]);

/** Independently declared source callables that form the exact transitive closure. */
export const EQUATION_IDS = Object.freeze([
  "src/amounts.ts#assertInventoryAmountSum",
  "src/amounts.ts#createMeasuredVector",
  "src/amounts.ts#inventoryAmountFromUnit",
  "src/amounts.ts#inventoryMeasuredAmountFromVector",
  "src/amounts.ts#measuredStockAmount",
  "src/amounts.ts#packageAmount",
  "src/amounts.ts#resolveInventoryAmount",
  "src/amounts.ts#stockAmount",
  "src/amounts.ts#validateIndependentAmountInputs",
  "src/canonical.ts#assertFiniteInventoryIntentFingerprintNumbers",
  "src/canonical.ts#inventoryIntentFingerprint",
  "src/canonical.ts#inventoryMetadataFingerprint",
  "src/canonical.ts#inventoryMetadataValueFingerprint",
  "src/canonical.ts#isInventoryMetadataArray",
  "src/catalog.ts#InventoryCatalog.itemRevision",
  "src/catalog.ts#InventoryCatalog.packagingRevision",
  "src/catalog.ts#assertMeasurementsMatchItem",
  "src/catalog.ts#findIndependentAxis",
  "src/measurements.ts#addInventoryMeasurements",
  "src/measurements.ts#assertSamePrimaryMeasurementAxis",
  "src/measurements.ts#compareMeasurementAxis",
  "src/measurements.ts#inventoryMeasurement",
  "src/measurements.ts#inventoryMeasurementVector",
  "src/measurements.ts#inventoryMeasurementsEqual",
  "src/measurements.ts#multiplyInventoryMeasurementsByWholeNumber",
  "src/measurements.ts#positiveInventoryMeasurements",
  "src/measurements.ts#zeroInventoryMeasurements",
  "src/model.ts#assertInventoryIdentity",
  "src/model.ts#compareQualifiedDimension",
  "src/model.ts#inventoryContainerIdentity",
  "src/model.ts#inventoryLotIdentity",
  "src/model.ts#inventorySerialIdentity",
  "src/model.ts#inventoryStockPositionIdentity",
  "src/model.ts#inventoryTraceabilityNodeIdentity",
  "src/model.ts#normalizeInventoryStockPositionKey",
  "src/model.ts#qualifiedDimensionIdentityTuple",
  "src/ordering.ts#compareInventoryIdentityText",
  "src/quantity.ts#addQuantity",
  "src/quantity.ts#assertDecimals",
  "src/quantity.ts#assertSafeInteger",
  "src/quantity.ts#assertSameUnit",
  "src/quantity.ts#compareQuantity",
  "src/quantity.ts#integerAtDecimals",
  "src/quantity.ts#multiplyQuantityByWholeNumber",
  "src/quantity.ts#parseQuantity",
  "src/quantity.ts#positiveQuantity",
  "src/quantity.ts#powerOfTen",
  "src/quantity.ts#quantity",
  "src/quantity.ts#quantityEq",
  "src/quantity.ts#quantityToDecimalString",
  "src/quantity.ts#quantityWholeMultipleCount",
  "src/quantity.ts#safeNumber",
  "src/quantity.ts#unitCode",
  "src/quantity.ts#zeroQuantity",
  "src/selectors.ts#assertPositionInsideSelector",
  "src/selectors.ts#compareQualifiedDimensionSelector",
  "src/selectors.ts#everythingInInventoryStockSelector",
  "src/selectors.ts#inventoryStockPositionMatchesNormalizedSelector",
  "src/selectors.ts#inventoryStockPositionMatchesSelector",
  "src/selectors.ts#inventoryStockSelector",
  "src/selectors.ts#inventoryStockSelectorIdentity",
  "src/selectors.ts#inventoryStockSelectorIsSubset",
  "src/selectors.ts#normalizeIdentitySet",
  "src/selectors.ts#normalizeInventoryStockSelector",
  "src/selectors.ts#normalizeOptionalIdentityConstraint",
  "src/selectors.ts#normalizeOptionalIdentitySet",
  "src/selectors.ts#normalizeQualifiedDimensionSelectors",
  "src/selectors.ts#optionalIdentityConstraintIsSubset",
  "src/selectors.ts#optionalIdentityConstraintMatches",
  "src/selectors.ts#optionalSetIsSubset",
  "src/selectors.ts#optionalSetMatches",
  "src/selectors.ts#qualifiedDimensionsMatch",
  "src/selectors.ts#qualifiedSelectorIsSubset",
  "src/usability.ts#inventoryPositionEffectiveUseBy",
  "src/usability.ts#inventoryPositionIsExpiredAt",
]);

/** Runtime values whose definitions affect a source equation without adding a call edge. */
export const SUPPORTING_VALUE_IDS = Object.freeze([
  "src/amounts.ts#InventoryAmountKind",
  "src/catalog.ts#InventoryMeasurementRequirement",
  "src/model.ts#InventoryTraceabilityNodeKind",
  "src/quantity.ts#MAXIMUM_QUANTITY_DECIMALS",
  "src/selectors.ts#InventoryOptionalIdentityConstraintKind",
]);

/** Existing strict-68 catalog equations reused by exact implementation identity. */
export const REUSED_CATALOG_EQUATION_IDS = Object.freeze([
  "src/catalog.ts#InventoryCatalog.itemRevision",
  "src/catalog.ts#InventoryCatalog.packagingRevision",
  "src/model.ts#assertInventoryIdentity",
  "src/model.ts#inventoryContainerIdentity",
  "src/model.ts#inventoryLotIdentity",
  "src/ordering.ts#compareInventoryIdentityText",
]);

/** Source inputs needed to resolve every equation, data field, and public export relation. */
export const SOURCE_FILES = Object.freeze([
  "src/amounts.ts",
  "src/canonical.ts",
  "src/catalog.ts",
  "src/index.ts",
  "src/kernel.ts",
  "src/measurements.ts",
  "src/model.ts",
  "src/ordering.ts",
  "src/projection.ts",
  "src/quantity.ts",
  "src/selectors.ts",
  "src/usability.ts",
]);

/** Runtime library calls admitted only with these exact compiler-resolved operation names. */
export const ALLOWED_STANDARD_OPERATIONS = Object.freeze([
  "Array.isArray",
  "BigInt",
  "Error",
  "JSON.stringify",
  "Map",
  "Math.abs",
  "Math.max",
  "Number",
  "Number.isFinite",
  "Number.isSafeInteger",
  "Object.keys",
  "RegExp.exec",
  "Set",
  "String",
  "Array.filter",
  "Array.includes",
  "Array.map",
  "Array.push",
  "Array.sort",
  "Map.get",
  "Map.set",
  "Set.add",
  "Set.has",
  "String.padStart",
  "String.slice",
  "String.trim",
]);

/** Independent whole-family semantic laws referenced by the shared equation bodies. */
export const FAMILY_LAWS = Object.freeze([
  {
    id: "exact-amount-resolution-v1",
    equation:
      "Measured inputs parse exact finite decimals, preserve axis/unit identity, reject duplicate or invalid axes, and resolve packages only through one exact retained revision; package multiplication and amount sums use aligned scaled-integer arithmetic and exact equality, with every membership, positivity, configured-axis, and whole-count guard preserved.",
  },
  {
    id: "canonical-identity-v1",
    equation:
      "Identities reject empty or padded text, normalize qualified dimensions by code-unit order with duplicate rejection, and serialize fixed typed tuples; trace nodes enforce the lot-only item qualifier before serialization.",
  },
  {
    id: "canonical-fingerprint-v1",
    equation:
      "Intent arrays reject undefined and non-finite numbers recursively before JSON serialization; metadata recursively emits key-sorted, delimiter-safe JSON fragments, rejects undefined and non-finite values, and preserves array order.",
  },
  {
    id: "selector-normalization-v1",
    equation:
      "Selectors validate the item, sort/deduplicate every allowed identity set, reject empty/ambiguous constraints and duplicate qualified dimensions, then match or compare subsets independently for every fixed and qualified dimension with omitted constraints remaining broad.",
  },
  {
    id: "effective-use-by-v1",
    equation:
      "Use-by is the lexicographically earlier defined value from the exact lot and container identities; expiry is inclusive and false when neither value exists.",
  },
  {
    id: "exact-quantity-measurement-dependencies-v1",
    equation:
      "All supporting quantity and measurement helpers retain exact safe scaled-integer arithmetic, unit/precision guards, axis normalization, deterministic ordering, and fail-closed overflow or invalid-input behavior used by the amount laws.",
  },
]);

/** Return the whole-family law that explains one concrete source equation. */
export function lawIdForEquation(equationId) {
  if (equationId.startsWith("src/amounts.ts#")) return "exact-amount-resolution-v1";
  if (equationId.startsWith("src/canonical.ts#")) return "canonical-fingerprint-v1";
  if (equationId.startsWith("src/selectors.ts#")) return "selector-normalization-v1";
  if (equationId.startsWith("src/usability.ts#")) return "effective-use-by-v1";
  if (
    equationId.startsWith("src/quantity.ts#") ||
    equationId.startsWith("src/measurements.ts#") ||
    equationId.startsWith("src/catalog.ts#")
  ) {
    return "exact-quantity-measurement-dependencies-v1";
  }
  return "canonical-identity-v1";
}
