import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  canonicalJson,
  compareCodeUnits,
  nodeAtExactSpan,
  sha256,
  spanOf,
  ts,
} from "../surface-bindings/lib/compiler-surface.mjs";
import {
  buildCatalogFamilyArtifact,
  catalogProofKind,
} from "../value-contracts/catalog-family.mjs";
import {
  ALLOWED_STANDARD_OPERATIONS,
  ASSIGNED_SURFACE_KEYS,
  EQUATION_IDS,
  FAMILY_LAWS,
  IDENTITY_VALUES_FAMILY_ID,
  REUSED_CATALOG_EQUATION_IDS,
  SOURCE_FILES,
  SUPPORTING_VALUE_IDS,
  lawIdForEquation,
} from "./contracts.mjs";

/** Exact production revision requested for this source-bound experiment. */
export const IDENTITY_VALUES_SOURCE_BASE =
  "2eea09471b3bf8fcb61f38256e1c6a362149dad4";

/** Strict V router discriminator for this reusable family certificate. */
export const identityValuesProofKind =
  "independent-identity-values-closed-equations-v1";

/** Independent equation program parsed without importing or executing production code. */
const equationProgramPath = fileURLToPath(new URL("./equations.ts.txt", import.meta.url));

/** Source-equation implementation and specification files bound into every receipt. */
const producerFiles = Object.freeze([
  "experiments/tla-conformance/authority-r5/catalog-published-source-contracts.mjs",
  "experiments/tla-conformance/authority-r5/catalog-published-source-equations.mjs",
  "experiments/tla-conformance/identity-values-r7/contracts.mjs",
  "experiments/tla-conformance/identity-values-r7/equations.ts.txt",
  "experiments/tla-conformance/identity-values-r7/family.mjs",
  "experiments/tla-conformance/surface-bindings/lib/compiler-surface.mjs",
  "experiments/tla-conformance/value-contracts/catalog-family.mjs",
  "experiments/tla-conformance/value-contracts/surface-binding.mjs",
  "node_modules/typescript/lib/lib.es2015.collection.d.ts",
  "node_modules/typescript/lib/lib.es2015.core.d.ts",
  "node_modules/typescript/lib/lib.es2015.iterable.d.ts",
  "node_modules/typescript/lib/lib.es2016.array.include.d.ts",
  "node_modules/typescript/lib/lib.es2017.string.d.ts",
  "node_modules/typescript/lib/lib.es2020.bigint.d.ts",
  "node_modules/typescript/lib/lib.es2022.error.d.ts",
  "node_modules/typescript/lib/lib.es5.d.ts",
  "node_modules/typescript/package.json",
  "package.json",
  "tsconfig.json",
]);

/** Reuse one complete immutable compiler pass only while every byte identity is unchanged. */
const passCache = new WeakMap();

/** Reject one malformed or semantically incomplete equation with stable context. */
function fail(message) {
  throw new Error(`Identity/value equation rejected: ${message}`);
}

/** Render one binary or assignment operator without depending on printer whitespace. */
function operatorName(token) {
  return ts.tokenToString(token.kind) ?? ts.SyntaxKind[token.kind];
}

/** Return whether a binary token mutates its left operand. */
function isAssignmentOperator(kind) {
  return kind >= ts.SyntaxKind.FirstAssignment && kind <= ts.SyntaxKind.LastAssignment;
}

/** Normalize one callable into a complete name-insensitive runtime syntax equation. */
export function normalizeIdentityValueCallable(declaration) {
  assert(declaration.body !== undefined, "Equation callable needs a concrete body.");
  const counters = { local: 0, lambda: 0 };
  const environment = new Map();

  /** Normalize one property name without evaluating computed source. */
  function propertyName(name, scopedEnvironment) {
    if (ts.isIdentifier(name) || ts.isStringLiteral(name) || ts.isNumericLiteral(name)) {
      return ["fixed", name.text];
    }
    if (ts.isComputedPropertyName(name)) {
      return ["computed", expression(name.expression, scopedEnvironment)];
    }
    fail(`unsupported property name '${name.getText()}'.`);
  }

  /** Bind an identifier or destructuring pattern to one stable runtime source. */
  function bindingPattern(name, identity, scopedEnvironment) {
    if (ts.isIdentifier(name)) {
      scopedEnvironment.set(name.text, identity);
      return ["binding", identity];
    }
    if (ts.isObjectBindingPattern(name)) {
      return [
        "object-binding",
        name.elements.map((element, index) => {
          const property = element.propertyName === undefined
            ? ts.isIdentifier(element.name)
              ? ["fixed", element.name.text]
              : ["position", index]
            : propertyName(element.propertyName, scopedEnvironment);
          const childIdentity = `${identity}.object:${index}`;
          const child = bindingPattern(element.name, childIdentity, scopedEnvironment);
          return [
            element.dotDotDotToken === undefined ? "field" : "rest",
            property,
            child,
            element.initializer === undefined
              ? ["no-default"]
              : expression(element.initializer, scopedEnvironment),
          ];
        }),
      ];
    }
    if (ts.isArrayBindingPattern(name)) {
      return [
        "array-binding",
        name.elements.map((element, index) => {
          if (ts.isOmittedExpression(element)) return ["omitted", index];
          const childIdentity = `${identity}.array:${index}`;
          return [
            element.dotDotDotToken === undefined ? "element" : "rest",
            bindingPattern(element.name, childIdentity, scopedEnvironment),
            element.initializer === undefined
              ? ["no-default"]
              : expression(element.initializer, scopedEnvironment),
          ];
        }),
      ];
    }
    fail(`unsupported binding pattern '${name.getText()}'.`);
  }

  /** Normalize one expression in the deliberately finite equation grammar. */
  function expression(node, scopedEnvironment = environment) {
    if (ts.isParenthesizedExpression(node)) return expression(node.expression, scopedEnvironment);
    if (
      ts.isAsExpression(node) ||
      ts.isTypeAssertionExpression(node) ||
      ts.isNonNullExpression(node)
    ) {
      return expression(node.expression, scopedEnvironment);
    }
    if (node.kind === ts.SyntaxKind.ThisKeyword) return ["this"];
    if (ts.isIdentifier(node)) {
      return ["reference", scopedEnvironment.get(node.text) ?? `source:${node.text}`];
    }
    if (ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) {
      return ["string", node.text];
    }
    if (ts.isNumericLiteral(node)) return ["number", node.text];
    if (ts.isBigIntLiteral(node)) return ["bigint", node.text];
    if (ts.isRegularExpressionLiteral(node)) return ["regexp", node.text];
    if (node.kind === ts.SyntaxKind.TrueKeyword) return ["boolean", true];
    if (node.kind === ts.SyntaxKind.FalseKeyword) return ["boolean", false];
    if (node.kind === ts.SyntaxKind.NullKeyword) return ["null"];
    if (ts.isPropertyAccessExpression(node)) {
      return [
        "property",
        expression(node.expression, scopedEnvironment),
        node.name.text,
        node.questionDotToken === undefined ? "required" : "optional",
      ];
    }
    if (ts.isElementAccessExpression(node)) {
      assert(node.argumentExpression !== undefined);
      return [
        "element",
        expression(node.expression, scopedEnvironment),
        expression(node.argumentExpression, scopedEnvironment),
        node.questionDotToken === undefined ? "required" : "optional",
      ];
    }
    if (ts.isCallExpression(node)) {
      return [
        "call",
        expression(node.expression, scopedEnvironment),
        node.arguments.map((argument) => expression(argument, scopedEnvironment)),
        node.questionDotToken === undefined ? "required" : "optional",
      ];
    }
    if (ts.isNewExpression(node)) {
      return [
        "new",
        expression(node.expression, scopedEnvironment),
        (node.arguments ?? []).map((argument) => expression(argument, scopedEnvironment)),
      ];
    }
    if (ts.isBinaryExpression(node)) {
      return [
        "binary",
        operatorName(node.operatorToken),
        expression(node.left, scopedEnvironment),
        expression(node.right, scopedEnvironment),
      ];
    }
    if (ts.isConditionalExpression(node)) {
      return [
        "conditional",
        expression(node.condition, scopedEnvironment),
        expression(node.whenTrue, scopedEnvironment),
        expression(node.whenFalse, scopedEnvironment),
      ];
    }
    if (ts.isPrefixUnaryExpression(node)) {
      return [
        "prefix",
        ts.tokenToString(node.operator) ?? ts.SyntaxKind[node.operator],
        expression(node.operand, scopedEnvironment),
      ];
    }
    if (ts.isPostfixUnaryExpression(node)) {
      return [
        "postfix",
        ts.tokenToString(node.operator) ?? ts.SyntaxKind[node.operator],
        expression(node.operand, scopedEnvironment),
      ];
    }
    if (ts.isTypeOfExpression(node)) return ["typeof", expression(node.expression, scopedEnvironment)];
    if (ts.isVoidExpression(node)) return ["void", expression(node.expression, scopedEnvironment)];
    if (ts.isSpreadElement(node)) return ["spread", expression(node.expression, scopedEnvironment)];
    if (ts.isArrayLiteralExpression(node)) {
      return [
        "array",
        node.elements.map((element) =>
          ts.isOmittedExpression(element)
            ? ["omitted"]
            : expression(element, scopedEnvironment)
        ),
      ];
    }
    if (ts.isObjectLiteralExpression(node)) {
      return [
        "record",
        node.properties.map((property) => {
          if (ts.isPropertyAssignment(property)) {
            return [
              "field",
              propertyName(property.name, scopedEnvironment),
              expression(property.initializer, scopedEnvironment),
            ];
          }
          if (ts.isShorthandPropertyAssignment(property)) {
            return [
              "field",
              ["fixed", property.name.text],
              expression(property.name, scopedEnvironment),
            ];
          }
          if (ts.isSpreadAssignment(property)) {
            return ["spread", expression(property.expression, scopedEnvironment)];
          }
          fail(`unsupported object member '${property.getText()}'.`);
        }),
      ];
    }
    if (ts.isArrowFunction(node)) {
      const childEnvironment = new Map(scopedEnvironment);
      const lambdaId = counters.lambda;
      counters.lambda += 1;
      const parameters = node.parameters.map((parameter, index) => ({
        pattern: bindingPattern(
          parameter.name,
          `lambda:${lambdaId}:${index}`,
          childEnvironment
        ),
        optional: parameter.questionToken !== undefined,
        rest: parameter.dotDotDotToken !== undefined,
        default: parameter.initializer === undefined
          ? null
          : expression(parameter.initializer, childEnvironment),
      }));
      return [
        "lambda",
        parameters,
        ts.isBlock(node.body)
          ? statement(node.body, childEnvironment)
          : expression(node.body, childEnvironment),
      ];
    }
    if (ts.isTemplateExpression(node)) {
      return [
        "template",
        node.head.text,
        node.templateSpans.map((span) => [
          expression(span.expression, scopedEnvironment),
          span.literal.text,
        ]),
      ];
    }
    fail(`unsupported expression '${ts.SyntaxKind[node.kind]}': ${node.getText()}`);
  }

  /** Normalize a branch while preserving the presence of braces and its local scope. */
  function branch(node, scopedEnvironment) {
    return ts.isBlock(node)
      ? ["block", statements(node.statements, new Map(scopedEnvironment))]
      : ["single", statement(node, new Map(scopedEnvironment))];
  }

  /** Normalize a sequence in source order. */
  function statements(sourceStatements, scopedEnvironment) {
    return sourceStatements.map((sourceStatement) =>
      statement(sourceStatement, scopedEnvironment)
    );
  }

  /** Normalize one variable declaration and bind its complete pattern. */
  function variableDeclaration(declaration, scopedEnvironment) {
    const initializer = declaration.initializer === undefined
      ? ["undefined"]
      : expression(declaration.initializer, scopedEnvironment);
    const identity = `local:${counters.local}`;
    counters.local += 1;
    const pattern = bindingPattern(declaration.name, identity, scopedEnvironment);
    return ["declaration", pattern, initializer];
  }

  /** Normalize one statement and every complete branch beneath it. */
  function statement(node, scopedEnvironment = environment) {
    if (ts.isBlock(node)) {
      return ["block", statements(node.statements, new Map(scopedEnvironment))];
    }
    if (ts.isVariableStatement(node)) {
      const declarationKind = (node.declarationList.flags & ts.NodeFlags.Const) !== 0
        ? "const"
        : (node.declarationList.flags & ts.NodeFlags.Let) !== 0
          ? "let"
          : "var";
      return [
        "variables",
        declarationKind,
        node.declarationList.declarations.map((declaration) =>
          variableDeclaration(declaration, scopedEnvironment)
        ),
      ];
    }
    if (ts.isIfStatement(node)) {
      return [
        "if",
        expression(node.expression, scopedEnvironment),
        branch(node.thenStatement, scopedEnvironment),
        node.elseStatement === undefined
          ? ["no-else"]
          : branch(node.elseStatement, scopedEnvironment),
      ];
    }
    if (ts.isReturnStatement(node)) {
      return [
        "return",
        node.expression === undefined
          ? ["undefined"]
          : expression(node.expression, scopedEnvironment),
      ];
    }
    if (ts.isThrowStatement(node)) {
      return ["throw", expression(node.expression, scopedEnvironment)];
    }
    if (ts.isExpressionStatement(node)) {
      return ["expression", expression(node.expression, scopedEnvironment)];
    }
    if (ts.isForOfStatement(node)) {
      const childEnvironment = new Map(scopedEnvironment);
      let initializer;
      if (ts.isVariableDeclarationList(node.initializer)) {
        const declarationKind = (node.initializer.flags & ts.NodeFlags.Const) !== 0
          ? "const"
          : (node.initializer.flags & ts.NodeFlags.Let) !== 0
            ? "let"
            : "var";
        initializer = [
          declarationKind,
          node.initializer.declarations.map((declaration) =>
            variableDeclaration(declaration, childEnvironment)
          ),
        ];
      } else {
        initializer = ["assignment", expression(node.initializer, childEnvironment)];
      }
      return [
        "for-of",
        node.awaitModifier === undefined ? "sync" : "await",
        initializer,
        expression(node.expression, scopedEnvironment),
        branch(node.statement, childEnvironment),
      ];
    }
    if (ts.isForStatement(node)) {
      const childEnvironment = new Map(scopedEnvironment);
      let initializer = ["none"];
      if (node.initializer !== undefined) {
        initializer = ts.isVariableDeclarationList(node.initializer)
          ? [
              (node.initializer.flags & ts.NodeFlags.Const) !== 0
                ? "const"
                : (node.initializer.flags & ts.NodeFlags.Let) !== 0
                  ? "let"
                  : "var",
              node.initializer.declarations.map((declaration) =>
                variableDeclaration(declaration, childEnvironment)
              ),
            ]
          : ["expression", expression(node.initializer, childEnvironment)];
      }
      return [
        "for",
        initializer,
        node.condition === undefined
          ? ["none"]
          : expression(node.condition, childEnvironment),
        node.incrementor === undefined
          ? ["none"]
          : expression(node.incrementor, childEnvironment),
        branch(node.statement, childEnvironment),
      ];
    }
    if (ts.isContinueStatement(node)) return ["continue"];
    if (ts.isBreakStatement(node)) return ["break"];
    fail(`unsupported statement '${ts.SyntaxKind[node.kind]}': ${node.getText()}`);
  }

  const parameters = declaration.parameters.map((parameter, index) => ({
    pattern: bindingPattern(parameter.name, `parameter:${index}`, environment),
    optional: parameter.questionToken !== undefined,
    rest: parameter.dotDotDotToken !== undefined,
    default: parameter.initializer === undefined
      ? null
      : expression(parameter.initializer, environment),
  }));
  return {
    async:
      declaration.modifiers?.some(
        (modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword
      ) ?? false,
    generator: declaration.asteriskToken !== undefined,
    parameters,
    body: ["block", statements(declaration.body.statements, environment)],
  };
}

/** Return one exact equation key for a concrete source callable declaration. */
function declarationKey(repositoryRoot, declaration) {
  const source = declaration.getSourceFile();
  const file = path.relative(repositoryRoot, source.fileName).replaceAll("\\", "/");
  const owner = ts.isMethodDeclaration(declaration)
    ? `${declaration.parent.name?.getText(source)}.`
    : "";
  return `${file}#${owner}${declaration.name?.getText(source)}`;
}

/** Locate one expected or production callable by its independently declared equation id. */
function findCallable(sourceByFile, specificationSource, equationId) {
  const [file, qualifiedName] = equationId.split("#");
  const source = specificationSource ?? sourceByFile.get(file);
  assert(source !== undefined, `Missing equation source '${file}'.`);
  const pieces = qualifiedName.split(".");
  if (pieces.length === 1) {
    const matches = source.statements.filter(
      (statement) =>
        ts.isFunctionDeclaration(statement) &&
        statement.name?.text === qualifiedName &&
        statement.body !== undefined
    );
    assert.equal(matches.length, 1, `Expected one function '${equationId}'.`);
    return matches[0];
  }
  const [className, methodName] = pieces;
  const classes = source.statements.filter(
    (statement) => ts.isClassDeclaration(statement) && statement.name?.text === className
  );
  assert.equal(classes.length, 1, `Expected one class '${className}'.`);
  const methods = classes[0].members.filter(
    (member) =>
      ts.isMethodDeclaration(member) &&
      ts.isIdentifier(member.name) &&
      member.name.text === methodName &&
      member.body !== undefined
  );
  assert.equal(methods.length, 1, `Expected one method '${equationId}'.`);
  return methods[0];
}

/** Locate one enum or top-level constant used by the runtime equations. */
function findSupportingValue(sourceByFile, specificationSource, valueId) {
  const [file, name] = valueId.split("#");
  const source = specificationSource ?? sourceByFile.get(file);
  assert(source !== undefined, `Missing supporting-value source '${file}'.`);
  const matches = source.statements.filter((statement) => {
    if (ts.isEnumDeclaration(statement)) return statement.name.text === name;
    if (!ts.isVariableStatement(statement)) return false;
    return statement.declarationList.declarations.some(
      (declaration) => ts.isIdentifier(declaration.name) && declaration.name.text === name
    );
  });
  assert.equal(matches.length, 1, `Expected one supporting value '${valueId}'.`);
  if (ts.isEnumDeclaration(matches[0])) return matches[0];
  const declaration = matches[0].declarationList.declarations.find(
    (candidate) => ts.isIdentifier(candidate.name) && candidate.name.text === name
  );
  assert(declaration !== undefined);
  return declaration;
}

/** Normalize an enum or constant whose runtime value affects a callable equation. */
function normalizeSupportingValue(declaration) {
  if (ts.isEnumDeclaration(declaration)) {
    return [
      "enum",
      declaration.members.map((member) => [
        member.name.getText(declaration.getSourceFile()),
        member.initializer?.getText(declaration.getSourceFile()) ?? null,
      ]),
    ];
  }
  assert(ts.isVariableDeclaration(declaration));
  assert(declaration.initializer !== undefined, "Supporting constant needs an initializer.");
  if (ts.isNumericLiteral(declaration.initializer)) {
    return ["constant-number", declaration.initializer.text];
  }
  fail(`unsupported supporting value '${declaration.getText()}'.`);
}

/** Resolve one alias symbol to the concrete declaration owner chosen by TypeScript. */
function resolveSymbol(context, symbol) {
  return symbol !== undefined && (symbol.flags & ts.SymbolFlags.Alias) !== 0
    ? context.checker.getAliasedSymbol(symbol)
    : symbol;
}

/** Visit runtime syntax while skipping erased type-only children. */
function visitRuntime(node, visitor) {
  if (ts.isTypeNode(node)) return;
  visitor(node);
  if (
    ts.isAsExpression(node) ||
    ts.isTypeAssertionExpression(node) ||
    ts.isNonNullExpression(node)
  ) {
    visitRuntime(node.expression, visitor);
    return;
  }
  ts.forEachChild(node, (child) => visitRuntime(child, visitor));
}

/** Return a source callable body declaration when one symbol denotes it. */
function sourceCallableDeclaration(context, symbol) {
  const resolved = resolveSymbol(context, symbol);
  const callables = (resolved?.declarations ?? []).filter(
    (declaration) =>
      !declaration.getSourceFile().isDeclarationFile &&
      (ts.isFunctionDeclaration(declaration) || ts.isMethodDeclaration(declaration)) &&
      declaration.body !== undefined
  );
  if (callables.length === 0) return undefined;
  assert.equal(callables.length, 1, "Source callable symbol has ambiguous bodies.");
  return callables[0];
}

/** Map one source enum member or top-level constant to its certificate identity. */
function sourceSupportingValueId(repositoryRoot, declaration) {
  if (declaration.getSourceFile().isDeclarationFile) return undefined;
  let owner = declaration;
  if (ts.isEnumMember(owner)) owner = owner.parent;
  if (!ts.isEnumDeclaration(owner) && !ts.isVariableDeclaration(owner)) return undefined;
  if (ts.isVariableDeclaration(owner) && !ts.isSourceFile(owner.parent.parent.parent)) {
    return undefined;
  }
  const source = owner.getSourceFile();
  const file = path.relative(repositoryRoot, source.fileName).replaceAll("\\", "/");
  const name = owner.name?.getText(source);
  return name === undefined ? undefined : `${file}#${name}`;
}

/** Resolve the one installed TypeScript library directory trusted by this compiler pass. */
function trustedTypeScriptLibraryDirectory(repositoryRoot) {
  const packagePath = fs.realpathSync(
    path.resolve(repositoryRoot, "node_modules/typescript/package.json")
  );
  return fs.realpathSync(path.join(path.dirname(packagePath), "lib"));
}

/** Require one declaration file to be an actual file below the installed TypeScript lib. */
function requireTrustedTypeScriptLibraryFile(repositoryRoot, fileName) {
  const trustedDirectory = trustedTypeScriptLibraryDirectory(repositoryRoot);
  const actualFile = fs.realpathSync(fileName);
  if (
    !actualFile.startsWith(`${trustedDirectory}${path.sep}`) ||
    !/^lib\.[^.].*\.d\.ts$/u.test(path.basename(actualFile))
  ) {
    fail(`declaration '${fileName}' is outside the trusted TypeScript library.`);
  }
  return actualFile;
}

/** Reject a locally supplied Math/JSON/Number/etc. object with library-looking methods. */
function validateStandardRootIdentity(context, call) {
  const expression = call.expression;
  let root;
  if (ts.isIdentifier(expression)) {
    root = expression;
  } else if (
    ts.isPropertyAccessExpression(expression) &&
    ts.isIdentifier(expression.expression) &&
    ["Array", "JSON", "Math", "Number", "Object"].includes(expression.expression.text)
  ) {
    root = expression.expression;
  }
  if (root === undefined) return;
  const symbol = resolveSymbol(context, context.checker.getSymbolAtLocation(root));
  if (symbol === undefined || (symbol.declarations ?? []).length === 0) {
    fail(`standard root '${root.text}' has no compiler declaration identity.`);
  }
  const runtimeDeclarations = symbol.declarations.filter(
    (declaration) =>
      ts.isVariableDeclaration(declaration) ||
      ts.isFunctionDeclaration(declaration) ||
      ts.isClassDeclaration(declaration) ||
      ts.isEnumDeclaration(declaration)
  );
  if (runtimeDeclarations.length === 0) {
    fail(`standard root '${root.text}' has no runtime value declaration.`);
  }
  for (const declaration of runtimeDeclarations) {
    if (!declaration.getSourceFile().isDeclarationFile) {
      fail(`standard root '${root.text}' was replaced by package source.`);
    }
    requireTrustedTypeScriptLibraryFile(
      context.repositoryRoot,
      declaration.getSourceFile().fileName
    );
  }
}

/** Derive one stable standard-library operation name from its compiler target. */
function standardOperation(context, call, target) {
  const sourceFile = target.getSourceFile().fileName;
  requireTrustedTypeScriptLibraryFile(context.repositoryRoot, sourceFile);
  validateStandardRootIdentity(context, call);
  const expression = call.expression;
  if (ts.isIdentifier(expression)) return expression.text;
  if (!ts.isPropertyAccessExpression(expression)) {
    fail(`dynamic standard call '${expression.getText()}' is outside the equation domain.`);
  }
  if (ts.isIdentifier(expression.expression)) {
    const root = expression.expression.text;
    if (["Array", "JSON", "Math", "Number", "Object"].includes(root)) {
      return `${root}.${expression.name.text}`;
    }
  }
  let ownerName = target.parent?.name?.getText(target.getSourceFile());
  if (ownerName === "ReadonlyArray") ownerName = "Array";
  if (ownerName === "ReadonlyMap") ownerName = "Map";
  if (ownerName === undefined && ts.isRegularExpressionLiteral(expression.expression)) {
    ownerName = "RegExp";
  }
  if (ownerName === undefined) {
    fail(`standard call '${expression.getText()}' has no fixed receiver declaration.`);
  }
  return `${ownerName}.${expression.name.text}`;
}

/** Infer the standard operation declared by an independent expected call expression. */
function expectedStandardOperation(call, sourceFunctionNames, sourceMethodNames) {
  const expression = call.expression;
  if (ts.isIdentifier(expression)) {
    if (sourceFunctionNames.has(expression.text)) return undefined;
    return expression.text;
  }
  if (!ts.isPropertyAccessExpression(expression)) return "UNSUPPORTED_DYNAMIC_CALL";
  if (sourceMethodNames.has(expression.name.text)) return undefined;
  if (ts.isIdentifier(expression.expression)) {
    const root = expression.expression.text;
    if (["Array", "JSON", "Math", "Number", "Object"].includes(root)) {
      return `${root}.${expression.name.text}`;
    }
  }
  const methodOwner = new Map([
    ["filter", "Array"],
    ["includes", "Array"],
    ["map", "Array"],
    ["push", "Array"],
    ["sort", "Array"],
    ["get", "Map"],
    ["set", "Map"],
    ["add", "Set"],
    ["has", "Set"],
    ["padStart", "String"],
    ["slice", "String"],
    ["trim", "String"],
    ["exec", "RegExp"],
  ]);
  const owner = methodOwner.get(expression.name.text);
  return owner === undefined
    ? `UNSUPPORTED.${expression.name.text}`
    : `${owner}.${expression.name.text}`;
}

/** Return the fixed source dependency graph declared by the independent equation text. */
function expectedDependencies(specificationSource, expectedById) {
  const functionIdByName = new Map();
  const methodIdByName = new Map();
  for (const equationId of EQUATION_IDS) {
    const qualifiedName = equationId.split("#")[1];
    const pieces = qualifiedName.split(".");
    const name = pieces.at(-1);
    (pieces.length === 2 ? methodIdByName : functionIdByName).set(name, equationId);
  }
  const supportingIdByName = new Map(
    SUPPORTING_VALUE_IDS.map((valueId) => [valueId.split("#")[1], valueId])
  );
  const byEquation = new Map();
  for (const [equationId, declaration] of expectedById) {
    const sourceDependencies = new Set();
    const supportingValues = new Set();
    const standardOperations = new Set();
    visitRuntime(declaration.body, (node) => {
      if (ts.isCallExpression(node) || ts.isNewExpression(node)) {
        if (ts.isIdentifier(node.expression)) {
          const dependency = functionIdByName.get(node.expression.text);
          if (dependency !== undefined) sourceDependencies.add(dependency);
        } else if (ts.isPropertyAccessExpression(node.expression)) {
          const dependency = methodIdByName.get(node.expression.name.text);
          if (dependency !== undefined) sourceDependencies.add(dependency);
        }
        const operation = expectedStandardOperation(
          node,
          new Set(functionIdByName.keys()),
          new Set(methodIdByName.keys())
        );
        if (operation !== undefined) standardOperations.add(operation);
      }
      if (ts.isIdentifier(node)) {
        const dependency = functionIdByName.get(node.text);
        if (
          dependency !== undefined &&
          ((ts.isCallExpression(node.parent) || ts.isNewExpression(node.parent)) &&
            node.parent.arguments?.includes(node))
        ) {
          sourceDependencies.add(dependency);
        }
        const supporting = supportingIdByName.get(node.text);
        if (supporting !== undefined) supportingValues.add(supporting);
      }
    });
    byEquation.set(equationId, {
      sourceDependencies: [...sourceDependencies].sort(compareCodeUnits),
      supportingValues: [...supportingValues].sort(compareCodeUnits),
      standardOperations: [...standardOperations].sort(compareCodeUnits),
    });
  }
  return byEquation;
}

/** Require assignments and mutating built-ins to affect only fresh local storage. */
function validateNoExternalEffects(context, declaration, callOperations) {
  const localSymbols = new Set();
  const freshLocalSymbols = new Set();
  /** Return whether an initializer allocates the local storage mutated by an equation. */
  function isFreshLocalInitializer(initializer) {
    if (
      ts.isAsExpression(initializer) ||
      ts.isTypeAssertionExpression(initializer) ||
      ts.isNonNullExpression(initializer)
    ) {
      return isFreshLocalInitializer(initializer.expression);
    }
    if (ts.isArrayLiteralExpression(initializer) || ts.isObjectLiteralExpression(initializer)) {
      return true;
    }
    if (
      ts.isNewExpression(initializer) &&
      ts.isIdentifier(initializer.expression) &&
      ["Map", "Set"].includes(initializer.expression.text)
    ) {
      return true;
    }
    return (
      ts.isCallExpression(initializer) &&
      ts.isPropertyAccessExpression(initializer.expression) &&
      ts.isIdentifier(initializer.expression.expression) &&
      initializer.expression.expression.text === "Object" &&
      initializer.expression.name.text === "keys"
    );
  }
  visitRuntime(declaration.body, (node) => {
    if (ts.isVariableDeclaration(node)) {
      const collect = (name) => {
        if (ts.isIdentifier(name)) {
          const symbol = context.checker.getSymbolAtLocation(name);
          if (symbol !== undefined) localSymbols.add(symbol);
        } else {
          for (const element of name.elements) {
            if (!ts.isOmittedExpression(element)) collect(element.name);
          }
        }
      };
      collect(node.name);
      if (ts.isIdentifier(node.name) && node.initializer !== undefined && isFreshLocalInitializer(node.initializer)) {
        const symbol = context.checker.getSymbolAtLocation(node.name);
        if (symbol !== undefined) freshLocalSymbols.add(symbol);
      }
    }
  });
  const mutationOperations = new Set(["Array.push", "Array.sort", "Map.set", "Set.add"]);
  visitRuntime(declaration.body, (node) => {
    if (ts.isBinaryExpression(node) && isAssignmentOperator(node.operatorToken.kind)) {
      if (!ts.isIdentifier(node.left)) fail(`property or non-local assignment '${node.getText()}'.`);
      const symbol = context.checker.getSymbolAtLocation(node.left);
      if (symbol === undefined || !localSymbols.has(symbol)) {
        fail(`assignment escapes fresh local storage: '${node.getText()}'.`);
      }
    }
    if (
      (ts.isPrefixUnaryExpression(node) || ts.isPostfixUnaryExpression(node)) &&
      [ts.SyntaxKind.PlusPlusToken, ts.SyntaxKind.MinusMinusToken].includes(node.operator)
    ) {
      if (!ts.isIdentifier(node.operand)) fail(`non-local update '${node.getText()}'.`);
      const symbol = context.checker.getSymbolAtLocation(node.operand);
      if (symbol === undefined || !localSymbols.has(symbol)) {
        fail(`update escapes fresh local storage: '${node.getText()}'.`);
      }
    }
  });
  for (const { call, operation } of callOperations) {
    if (!mutationOperations.has(operation)) continue;
    assert(ts.isPropertyAccessExpression(call.expression));
    const receiver = call.expression.expression;
    if (!ts.isIdentifier(receiver)) {
      fail(`mutating built-in '${call.expression.getText()}' has a non-local receiver.`);
    }
    const symbol = context.checker.getSymbolAtLocation(receiver);
    if (symbol === undefined || !freshLocalSymbols.has(symbol)) {
      fail(`mutating built-in '${call.expression.getText()}' escapes fresh local storage.`);
    }
  }
}

/** Inspect one actual body for exact source/value/library dependencies and side effects. */
function inspectActualEquation(context, repositoryRoot, declaration) {
  const sourceDependencies = new Set();
  const supportingValues = new Set();
  const standardOperations = new Set();
  const standardDeclarations = new Map();
  const discoveredCallables = new Map();
  const callOperations = [];
  visitRuntime(declaration.body, (node) => {
    if (ts.isPropertyAccessExpression(node) || ts.isElementAccessExpression(node)) {
      const symbolNode = ts.isPropertyAccessExpression(node) ? node.name : node.argumentExpression;
      const symbol = symbolNode === undefined
        ? undefined
        : resolveSymbol(context, context.checker.getSymbolAtLocation(symbolNode));
      for (const candidate of symbol?.declarations ?? []) {
        if (ts.isGetAccessorDeclaration(candidate) || ts.isSetAccessorDeclaration(candidate)) {
          fail(`accessor-backed value '${node.getText()}' is outside the immutable data domain.`);
        }
      }
    }
    if (ts.isIdentifier(node)) {
      const symbol = resolveSymbol(context, context.checker.getSymbolAtLocation(node));
      const callable = sourceCallableDeclaration(context, symbol);
      if (callable !== undefined && callable !== declaration) {
        const key = declarationKey(repositoryRoot, callable);
        sourceDependencies.add(key);
        discoveredCallables.set(key, callable);
      }
      for (const candidate of symbol?.declarations ?? []) {
        const valueId = sourceSupportingValueId(repositoryRoot, candidate);
        if (valueId !== undefined) {
          if (!SUPPORTING_VALUE_IDS.includes(valueId)) {
            fail(`unknown nonlocal runtime value '${valueId}' in '${declarationKey(repositoryRoot, declaration)}'.`);
          }
          supportingValues.add(valueId);
        }
      }
    }
    if (ts.isCallExpression(node) || ts.isNewExpression(node)) {
      const target = context.checker.getResolvedSignature(node)?.declaration;
      if (target === undefined) fail(`unresolved call '${node.getText()}'.`);
      if (target.getSourceFile().isDeclarationFile) {
        const operation = standardOperation(context, node, target);
        if (!ALLOWED_STANDARD_OPERATIONS.includes(operation)) {
          fail(`standard operation '${operation}' is not independently admitted.`);
        }
        standardOperations.add(operation);
        callOperations.push({ call: node, operation });
        const targetSpan = spanOf(context, target);
        standardDeclarations.set(
          `${operation}:${targetSpan.file}:${targetSpan.start.offset}`,
          { operation, declaration: targetSpan }
        );
      } else if (
        (ts.isFunctionDeclaration(target) || ts.isMethodDeclaration(target)) &&
        target.body !== undefined
      ) {
        const key = declarationKey(repositoryRoot, target);
        sourceDependencies.add(key);
        discoveredCallables.set(key, target);
      } else {
        fail(`source call '${node.getText()}' has no independently checked ordinary body.`);
      }
    }
  });
  validateNoExternalEffects(context, declaration, callOperations);
  return {
    sourceDependencies: [...sourceDependencies].sort(compareCodeUnits),
    supportingValues: [...supportingValues].sort(compareCodeUnits),
    standardOperations: [...standardOperations].sort(compareCodeUnits),
    standardDeclarations: [...standardDeclarations.values()].sort((left, right) =>
      compareCodeUnits(
        `${left.operation}:${left.declaration.file}:${left.declaration.start.offset}`,
        `${right.operation}:${right.declaration.file}:${right.declaration.start.offset}`
      )
    ),
    discoveredCallables,
  };
}

/** Build a compiler program whose in-memory mutations retain real TypeScript resolution. */
function loadOverriddenContext(repositoryRoot, sourceOverrides) {
  const root = path.resolve(repositoryRoot);
  for (const file of sourceOverrides.keys()) {
    if (!SOURCE_FILES.includes(file)) fail(`source override '${file}' is outside the closed family.`);
  }
  const configPath = path.join(root, "tsconfig.json");
  const config = ts.readConfigFile(configPath, ts.sys.readFile);
  if (config.error !== undefined) fail("cannot read TypeScript configuration for mutation control.");
  const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root, undefined, configPath);
  if (parsed.errors.length !== 0) fail("TypeScript configuration diagnostics changed.");
  const overridesByAbsolutePath = new Map(
    [...sourceOverrides].map(([file, text]) => [path.resolve(root, file), text])
  );
  const host = ts.createCompilerHost(parsed.options, true);
  const originalGetSourceFile = host.getSourceFile.bind(host);
  host.getSourceFile = (fileName, languageVersion, onError, shouldCreateNewSourceFile) => {
    const override = overridesByAbsolutePath.get(path.resolve(fileName));
    return override === undefined
      ? originalGetSourceFile(fileName, languageVersion, onError, shouldCreateNewSourceFile)
      : ts.createSourceFile(fileName, override, languageVersion, true, ts.ScriptKind.TS);
  };
  host.readFile = (fileName) =>
    overridesByAbsolutePath.get(path.resolve(fileName)) ?? ts.sys.readFile(fileName);
  const program = ts.createProgram({ rootNames: parsed.fileNames, options: parsed.options, host });
  const diagnostics = ts.getPreEmitDiagnostics(program);
  if (diagnostics.length !== 0) {
    fail(`mutated compiler program has ${diagnostics.length} diagnostic(s).`);
  }
  return {
    repositoryRoot: root,
    program,
    checker: program.getTypeChecker(),
  };
}

/** Parse the immutable independent specification and reject any syntax damage. */
function loadSpecification() {
  const bytes = fs.readFileSync(equationProgramPath);
  const source = ts.createSourceFile(
    equationProgramPath,
    bytes.toString("utf8"),
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TS
  );
  assert.equal(source.parseDiagnostics.length, 0, "Independent equation program has syntax errors.");
  return { bytes, source };
}

/** Return the exact assigned public equation id from one implementation declaration. */
function equationIdForCallable(repositoryRoot, declaration) {
  const key = declarationKey(repositoryRoot, declaration);
  assert(EQUATION_IDS.includes(key), `Assigned callable resolved outside the equation family: ${key}`);
  return key;
}

/** Resolve one reused equation from the already-admitted catalog family by exact source identity. */
function reusedCatalogEquation(catalogArtifact, equationId, implementationSpan) {
  const helper = catalogArtifact.helperEquations.find((row) => row.key === equationId);
  if (helper !== undefined) {
    assert.deepEqual(helper.declaration, implementationSpan, `Reused catalog helper span changed: ${equationId}`);
    return {
      kind: "CATALOG_HELPER_EQUATION",
      term: helper.term,
      declaration: helper.declaration,
    };
  }
  const proofs = catalogArtifact.proofs.filter(
    (proof) =>
      proof.implementation.file === implementationSpan.file &&
      proof.implementation.start.offset === implementationSpan.start.offset &&
      proof.implementation.end.offset === implementationSpan.end.offset
  );
  assert.equal(proofs.length, 1, `Expected one reused catalog proof for '${equationId}'.`);
  return {
    kind: "CATALOG_PUBLIC_EQUATION",
    term: proofs[0].term,
    declaration: proofs[0].implementation,
    sourceSurfaceKey: proofs[0].surfaceKey,
  };
}

/** Build all 75 equations once and bind all 40 public aliases to the shared results. */
export function buildIdentityValuesFamilyArtifact({
  repositoryRoot,
  context,
  surface,
  sourceOverrides = new Map(),
}) {
  const root = path.resolve(repositoryRoot);
  assert.equal(ASSIGNED_SURFACE_KEYS.length, 40);
  assert.equal(new Set(ASSIGNED_SURFACE_KEYS).size, 40);
  assert.equal(EQUATION_IDS.length, 75);
  assert.equal(new Set(EQUATION_IDS).size, 75);
  const { bytes: specificationBytes, source: specificationSource } = loadSpecification();
  const catalogSourceFiles = new Set(["src/catalog.ts", "src/facade.ts", "src/model.ts", "src/ordering.ts"]);
  const catalogOverrides = new Map(
    [...sourceOverrides].filter(([file]) => catalogSourceFiles.has(file))
  );
  const catalogArtifact = buildCatalogFamilyArtifact({
    repositoryRoot: root,
    context,
    surface,
    sourceOverrides: catalogOverrides,
  });
  const catalogArtifactDigest = sha256(canonicalJson(catalogArtifact));
  const inputFiles = [...new Set([...SOURCE_FILES, ...producerFiles])].sort(compareCodeUnits);
  const inputByFile = new Map(inputFiles.map((file) => [file, {
    file,
    sha256: sha256(sourceOverrides.get(file) ?? fs.readFileSync(path.resolve(root, file))),
  }]));
  for (const input of catalogArtifact.inputs) {
    const existing = inputByFile.get(input.file);
    if (existing !== undefined) {
      assert.equal(existing.sha256, input.sha256, `Reused catalog input changed: ${input.file}`);
    } else {
      inputByFile.set(input.file, input);
    }
  }
  const inputs = [...inputByFile.values()].sort((left, right) =>
    compareCodeUnits(left.file, right.file)
  );
  const cacheKey = sha256(
    canonicalJson({ surface: surface.digest, inputs, catalogArtifactDigest })
  );
  const old = sourceOverrides.size === 0 ? passCache.get(context) : undefined;
  if (old?.key === cacheKey) return old.value;

  const activeContext = sourceOverrides.size === 0
    ? context
    : loadOverriddenContext(root, sourceOverrides);
  assert.equal(path.resolve(activeContext.repositoryRoot), root);
  const sourceByFile = new Map(
    SOURCE_FILES.map((file) => {
      const source = activeContext.program.getSourceFile(path.resolve(root, file));
      assert(source !== undefined && !source.isDeclarationFile, `Missing compiler source '${file}'.`);
      return [file, source];
    })
  );
  const expectedById = new Map(
    EQUATION_IDS.filter(
      (equationId) => !REUSED_CATALOG_EQUATION_IDS.includes(equationId)
    ).map((equationId) => [
      equationId,
      findCallable(sourceByFile, specificationSource, equationId),
    ])
  );
  const expectedDependencyById = expectedDependencies(specificationSource, expectedById);
  const actualById = new Map();
  const pending = [];

  const callableByKey = new Map(surface.callables.map((callable) => [callable.key, callable]));
  const publicProofSeeds = [];
  for (const surfaceKey of ASSIGNED_SURFACE_KEYS) {
    const callable = callableByKey.get(surfaceKey);
    assert(callable !== undefined, `Compiler omitted assigned callable '${surfaceKey}'.`);
    assert.equal(
      callable.signatureHash,
      sha256(canonicalJson(callable.signature)),
      `Compiler signature identity drifted for '${surfaceKey}'.`
    );
    let implementation;
    if (sourceOverrides.size === 0) {
      const source = sourceByFile.get(callable.declaration.file);
      assert(source !== undefined, `Callable source is outside the closed family: ${surfaceKey}`);
      implementation = nodeAtExactSpan(
        source,
        callable.declaration.start.offset,
        callable.declaration.end.offset
      );
      assert(
        implementation !== undefined &&
          ts.isFunctionDeclaration(implementation) &&
          implementation.body !== undefined,
        `Callable '${surfaceKey}' is not one exact source function.`
      );
      assert.deepEqual(callable.declaration, spanOf(activeContext, implementation));
    } else {
      const functionName = surfaceKey.slice(surfaceKey.indexOf("#") + 1, surfaceKey.indexOf("::"));
      const possibleIds = EQUATION_IDS.filter((equationId) => equationId.endsWith(`#${functionName}`));
      assert.equal(possibleIds.length, 1, `Mutation control cannot locate '${functionName}'.`);
      implementation = findCallable(sourceByFile, undefined, possibleIds[0]);
    }
    const equationId = equationIdForCallable(root, implementation);
    pending.push(implementation);
    publicProofSeeds.push({ surfaceKey, callable, implementation, equationId });
  }

  while (pending.length > 0) {
    const declaration = pending.shift();
    const equationId = declarationKey(root, declaration);
    if (actualById.has(equationId)) continue;
    const inspected = inspectActualEquation(activeContext, root, declaration);
    actualById.set(equationId, { declaration, inspected });
    for (const dependency of inspected.discoveredCallables.values()) {
      pending.push(dependency);
    }
  }
  assert.deepEqual(
    [...actualById.keys()].sort(compareCodeUnits),
    [...EQUATION_IDS].sort(compareCodeUnits),
    "The compiler-resolved transitive source-callable closure changed."
  );

  const supportingValues = SUPPORTING_VALUE_IDS.map((valueId) => {
    const expected = findSupportingValue(sourceByFile, specificationSource, valueId);
    const actual = findSupportingValue(sourceByFile, undefined, valueId);
    const expectedTerm = normalizeSupportingValue(expected);
    const actualTerm = normalizeSupportingValue(actual);
    assert.deepEqual(actualTerm, expectedTerm, `Supporting runtime value changed: ${valueId}`);
    return {
      id: valueId,
      declaration: spanOf(activeContext, actual),
      term: expectedTerm,
    };
  });

  const equations = EQUATION_IDS.map((equationId) => {
    const actualRow = actualById.get(equationId);
    assert(actualRow !== undefined);
    const actualSpan = spanOf(activeContext, actualRow.declaration);
    if (REUSED_CATALOG_EQUATION_IDS.includes(equationId)) {
      const reused = reusedCatalogEquation(catalogArtifact, equationId, actualSpan);
      return {
        id: equationId,
        lawId: lawIdForEquation(equationId),
        declaration: actualSpan,
        term: reused.term,
        dependencies: actualRow.inspected.sourceDependencies,
        supportingValues: actualRow.inspected.supportingValues,
        standardOperations: actualRow.inspected.standardOperations,
        standardDeclarations: actualRow.inspected.standardDeclarations,
        reusedFrom: {
          proofKind: catalogProofKind,
          artifactSha256: catalogArtifactDigest,
          relation: reused.kind,
          ...(reused.sourceSurfaceKey === undefined
            ? {}
            : { sourceSurfaceKey: reused.sourceSurfaceKey }),
        },
      };
    }
    const expectedDeclaration = expectedById.get(equationId);
    assert(expectedDeclaration !== undefined);
    const expectedTerm = normalizeIdentityValueCallable(expectedDeclaration);
    const actualTerm = normalizeIdentityValueCallable(actualRow.declaration);
    assert.deepEqual(actualTerm, expectedTerm, `Independent equation changed: ${equationId}`);
    const expectedDependency = expectedDependencyById.get(equationId);
    assert(expectedDependency !== undefined);
    assert.deepEqual(
      actualRow.inspected.sourceDependencies,
      expectedDependency.sourceDependencies,
      `Compiler-resolved source dependency changed: ${equationId}`
    );
    assert.deepEqual(
      actualRow.inspected.supportingValues,
      expectedDependency.supportingValues,
      `Compiler-resolved free value changed: ${equationId}`
    );
    assert.deepEqual(
      actualRow.inspected.standardOperations,
      expectedDependency.standardOperations,
      `Compiler-resolved standard operation changed: ${equationId}`
    );
    return {
      id: equationId,
      lawId: lawIdForEquation(equationId),
      declaration: actualSpan,
      term: expectedTerm,
      dependencies: expectedDependency.sourceDependencies,
      supportingValues: expectedDependency.supportingValues,
      standardOperations: expectedDependency.standardOperations,
      standardDeclarations: actualRow.inspected.standardDeclarations,
    };
  });
  const equationById = new Map(equations.map((equation) => [equation.id, equation]));
  const proofs = publicProofSeeds.map(({ surfaceKey, callable, implementation, equationId }) => ({
    surfaceKey,
    signatureHash: callable.signatureHash,
    signature: callable.signature,
    declaration: callable.declaration,
    implementation: spanOf(activeContext, implementation),
    relation: sourceOverrides.size === 0
      ? {
          kind: "COMPILER_RESOLVED_EXACT_EXPORT",
          reachabilityPaths: callable.reachabilityPaths,
          symbolDeclarations: callable.symbolDeclarations,
        }
      : { kind: "MUTATION_CONTROL_ONLY" },
    equationId,
    lawId: equationById.get(equationId).lawId,
    dependencies: equationById.get(equationId).dependencies,
  }));
  assert.deepEqual(
    proofs.map((proof) => proof.surfaceKey),
    ASSIGNED_SURFACE_KEYS,
    "Public proof order or identity changed."
  );
  const uniqueImplementations = new Set(proofs.map((proof) => proof.equationId));
  assert.equal(uniqueImplementations.size, 27, "Assigned aliases no longer share 27 exact implementations.");
  const allStandardOperations = new Set(
    equations.flatMap((equation) => equation.standardOperations)
  );
  assert.deepEqual(
    [...allStandardOperations].sort(compareCodeUnits),
    [...ALLOWED_STANDARD_OPERATIONS].sort(compareCodeUnits),
    "Declared immutable standard-operation domain differs from the equation closure."
  );

  const result = {
    schemaVersion: 1,
    mode: "V",
    proofKind: identityValuesProofKind,
    familyId: IDENTITY_VALUES_FAMILY_ID,
    sourceBase: IDENTITY_VALUES_SOURCE_BASE,
    surfaceDigest: surface.digest,
    domain: {
      id: "VALIDATED_IMMUTABLE_IDENTITY_AMOUNT_SELECTOR_VALUES_V1",
      quantified:
        "Every input satisfying the published TypeScript shapes and the guards in these equations; no fixture or finite sample restriction.",
      arithmetic:
        "Safe scaled integers and bigint intermediates only; units and decimal precision are exact and every overflow, sign, whole-count, required-axis, and mismatch guard remains part of the equation.",
      data:
        "Non-proxied plain records plus ordinary native Array, Map, Set, String, RegExp, JSON, Math, Number, BigInt, Object, and Error semantics, with the input graph immutable for the duration of a call.",
      catalog:
        "Only exact validated InventoryCatalog instances with unshadowed itemRevision and packagingRevision methods and unchanged private maps/retained arrays.",
      mutation:
        "Only fresh local arrays, maps, sets, and scalar locals are mutated; caller-owned values, catalog state, projections, and prototypes are read-only.",
    },
    excluded: [
      "Proxies, accessors, subclasses, monkey-patched built-ins, custom collection/string lookalikes, and own-property method shadowing.",
      "Concurrent mutation of inputs or catalog/projection state during a call.",
      "Structurally injected catalog objects that were not produced by the validated InventoryCatalog constructor path.",
    ],
    allAdmittedInputs: true,
    sampledInputs: 0,
    sourceCallableClosureComplete: true,
    sourceCallableClosureCount: equations.length,
    assignedSurfaceCount: proofs.length,
    uniqueImplementationCount: uniqueImplementations.size,
    inputs,
    specification: {
      file: path.relative(root, equationProgramPath).replaceAll("\\", "/"),
      sha256: sha256(specificationBytes),
      independentlyDeclared: true,
      executedProductionCode: false,
    },
    reusedCertificates: [
      {
        proofKind: catalogProofKind,
        artifactSha256: catalogArtifactDigest,
        surfaceDigest: catalogArtifact.surfaceDigest,
        equationIds: REUSED_CATALOG_EQUATION_IDS,
      },
    ],
    laws: FAMILY_LAWS,
    supportingValues,
    equations,
    proofs,
  };
  if (sourceOverrides.size === 0) passCache.set(context, { key: cacheKey, value: result });
  return result;
}

/** Rebuild current semantics and reject altered evidence even when an attacker re-signs it. */
export function verifyIdentityValuesFamilyArtifact({
  repositoryRoot,
  context,
  surface,
  recorded,
}) {
  const current = buildIdentityValuesFamilyArtifact({ repositoryRoot, context, surface });
  assert.equal(
    canonicalJson(recorded),
    canonicalJson(current),
    "Recorded identity/value certificate differs from current independent equations."
  );
  return current;
}

/** Generic hub adapter name for the one family-level builder. */
export const buildFamilyArtifact = buildIdentityValuesFamilyArtifact;

/** Generic hub adapter identity list; callers still derive signatures from the supplied surface. */
export const supportedSurfaceKeys = ASSIGNED_SURFACE_KEYS;
