import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { canonicalJson, sha256, spanOf, ts } from "../surface-bindings/lib/compiler-surface.mjs";
import { normalizeCallable, findClassMethod, findFunction, expectedMethodTerm, expectedSupportingTerm } from "../authority-r5/catalog-published-source-equations.mjs";
import { CATALOG_PUBLISHED_SOURCE_CONTRACTS, CATALOG_PUBLISHED_SUPPORTING_CONTRACTS } from "../authority-r5/catalog-published-source-contracts.mjs";

/** Complete equation family; no native graph, sample, or unchecked delegation supplies credit. */
export const catalogProofKind = "independent-catalog-snapshot-closed-equations-v1";
/** Snapshot methods whose entire helper closure is independently specified below. */
const snapshotMembers = new Set(["container", "containers", "lot", "lots", "compositionRevisionsForItem", "event", "count"]);
/** Reviewed old 33-candidate family, admitting only members with a closed helper dependency graph. */
export const catalogContracts = CATALOG_PUBLISHED_SOURCE_CONTRACTS.filter((contract) =>
  contract.className === "InventoryCatalog" ||
  (contract.className === "InventoryOnceReadSnapshotImplementation" && snapshotMembers.has(contract.methodName)));
/** Whole-source inputs bind symbol resolution, class fields, inherited contracts, and native library assumptions. */
const sourceFiles = ["src/catalog.ts", "src/facade.ts", "src/model.ts", "src/ordering.ts", "src/sparse-record.ts"];
/** Every non-member source function reachable from the admitted read bodies has its own complete equation. */
const helperContracts = [
  ["src/ordering.ts", "compareInventoryIdentityText", "function expected(p0,p1) { return p0 < p1 ? -1 : p0 > p1 ? 1 : 0; }"],
  ["src/catalog.ts", "compareTransformationRevision", `function expected(p0,p1) {
    const order = compareInventoryIdentityText(p0.transformationId,p1.transformationId);
    return order === 0 ? compareInventoryIdentityText(p0.revisionId,p1.revisionId) : order;
  }`],
  ["src/model.ts", "assertInventoryIdentity", `function expected(p0,p1) {
    const trimmed = p0.trim();
    if (trimmed.length === 0) throw new Error(\`\${p1} must not be empty.\`);
    if (trimmed !== p0) { throw new Error(\`\${p1} must not contain surrounding whitespace.\`); }
  }`],
  ["src/model.ts", "inventoryContainerIdentity", `function expected(p0) { assertInventoryIdentity(p0,"containerId"); return JSON.stringify([p0]); }`],
  ["src/model.ts", "inventoryLotIdentity", `function expected(p0,p1) { assertInventoryIdentity(p0,"lot itemId"); assertInventoryIdentity(p1,"lotId"); return JSON.stringify([p0,p1]); }`],
  ["src/facade.ts", "compareInventoryCompositionRevision", `function expected(p0,p1) { return compareInventoryIdentityText(p0.revisionId,p1.revisionId); }`],
  ["src/facade.ts", "compareProjectedContainerDefinition", `function expected(p0,p1) { return compareInventoryIdentityText(inventoryContainerIdentity(p0.definition.containerId),inventoryContainerIdentity(p1.definition.containerId)); }`],
  ["src/facade.ts", "compareProjectedLotDefinition", `function expected(p0,p1) { return compareInventoryIdentityText(inventoryLotIdentity(p0.definition.itemId,p0.definition.lotId),inventoryLotIdentity(p1.definition.itemId,p1.definition.lotId)); }`],
  ["src/sparse-record.ts", "inventorySparseRecordHas", `function expected(p0,p1) { return Object.prototype.hasOwnProperty.call(p0,p1); }`],
  ["src/sparse-record.ts", "inventorySparseRecordValue", `function expected(p0,p1) { return inventorySparseRecordHas(p0,p1) ? p0[p1] : undefined; }`],
];
/** Exact verifier/specification input set is independently checked at each admission. */
const producerFiles = [
  "experiments/tla-conformance/value-contracts/catalog-family.mjs",
  "experiments/tla-conformance/value-contracts/surface-binding.mjs",
  "experiments/tla-conformance/authority-r5/catalog-published-source-contracts.mjs",
  "experiments/tla-conformance/authority-r5/catalog-published-source-equations.mjs",
  "experiments/tla-conformance/surface-bindings/lib/compiler-surface.mjs",
  "node_modules/typescript/package.json",
];
/** Cache only within one immutable compiler pass and only while every producer/source byte remains identical. */
const passCache = new WeakMap();

/** Parse expected equations independently, without invoking production or seeding runtime states. */
function parseSource(file, text) { return ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS); }
/** Identify one concrete member or helper without source names supplied by an artifact. */
function declarationKey(root, declaration) {
  const file = path.relative(root, declaration.getSourceFile().fileName).replaceAll("\\", "/");
  const owner = ts.isMethodDeclaration(declaration) ? `${declaration.parent.name.text}.` : "";
  return `${file}#${owner}${declaration.name.text}`;
}
/** Reject generators, accessors, decorators, and unproved parameter behavior rather than erase their effects. */
function validateCallableSyntax(declaration) {
  assert.equal(declaration.asteriskToken, undefined, "Generator methods are outside the read equation domain.");
  assert(!ts.canHaveDecorators(declaration) || (ts.getDecorators(declaration)?.length ?? 0) === 0, "Decorated method is not a plain read.");
  for (const parameter of declaration.parameters) {
    assert.equal(parameter.dotDotDotToken, undefined, "Rest parameters require a separate equation.");
    assert(ts.isIdentifier(parameter.name));
  }
}
/** Verify a class method has the exact public interface declaration discovered by the independent compiler. */
function requirePublicRelation(context, callable, declaration, contract) {
  if (contract.className === "InventoryCatalog") {
    assert.deepEqual(callable.declaration, spanOf(context, declaration));
    return { kind: "EXACT_CLASS_METHOD", implementation: spanOf(context, declaration) };
  }
  const source = declaration.getSourceFile();
  const publicOwner = source.statements.find((node) => ts.isInterfaceDeclaration(node) && node.name.text === "InventoryOnceReadSnapshotApi");
  assert(publicOwner !== undefined);
  const publicMembers = publicOwner.members.filter((node) => node.name?.getText(source) === contract.methodName);
  assert.equal(publicMembers.length, 1);
  assert.deepEqual(callable.declaration, spanOf(context, publicMembers[0]));
  const implemented = declaration.parent.heritageClauses?.filter((clause) => clause.token === ts.SyntaxKind.ImplementsKeyword).flatMap((clause) => clause.types) ?? [];
  const expectedSymbol = context.checker.getSymbolAtLocation(publicOwner.name);
  assert(implemented.some((type) => context.checker.getSymbolAtLocation(type.expression) === expectedSymbol), "Snapshot class no longer implements its exact public interface.");
  const actualType = context.checker.getTypeAtLocation(declaration);
  const publicType = context.checker.getTypeAtLocation(publicMembers[0]);
  assert(context.checker.isTypeAssignableTo(actualType, publicType), "Implementation is not assignable to the public method.");
  return { kind: "COMPILER_RESOLVED_IMPLEMENTS", interface: spanOf(context, publicMembers[0]), implementation: spanOf(context, declaration) };
}
/** Build every admitted equation once, checking the entire reachable helper graph and exact compiler association. */
export function buildCatalogFamilyArtifact({ repositoryRoot, context, surface, sourceOverrides = new Map() }) {
  assert.equal(catalogContracts.length, 24);
  const inputFiles = [...sourceFiles, ...producerFiles];
  const inputs = inputFiles.map((file) => ({ file, sha256: sha256(sourceOverrides.get(file) ?? fs.readFileSync(path.resolve(repositoryRoot, file))) }));
  const cacheKey = sha256(canonicalJson({ surface: surface.digest, inputs }));
  const old = sourceOverrides.size === 0 ? passCache.get(context) : undefined;
  if (old?.key === cacheKey) return old.value;
  const sources = new Map(sourceFiles.map((file) => [file, sourceOverrides.has(file)
    ? parseSource(path.resolve(repositoryRoot, file), sourceOverrides.get(file))
    : context.program.getSourceFile(path.resolve(repositoryRoot, file))]));
  for (const [file, source] of sources) assert(source !== undefined, `Missing compiler source ${file}.`);
  const certified = new Map();
  const proofs = [];
  const callableByKey = new Map(surface.callables.map((callable) => [callable.key, callable]));
  for (const contract of catalogContracts) {
    const declaration = findClassMethod(sources.get(contract.sourceFile), contract.className, contract.methodName);
    validateCallableSyntax(declaration);
    const term = normalizeCallable(declaration);
    assert.deepEqual(term, expectedMethodTerm(contract), `Read equation changed: ${contract.surfaceKey}`);
    const callable = callableByKey.get(contract.surfaceKey);
    assert(callable !== undefined, `Compiler omitted ${contract.surfaceKey}.`);
    const relation = sourceOverrides.size === 0 ? requirePublicRelation(context, callable, declaration, contract) : { kind: "MUTATION_CONTROL_ONLY" };
    const key = declarationKey(repositoryRoot, declaration);
    certified.set(key, { declaration, term });
    proofs.push({ surfaceKey: contract.surfaceKey, signatureHash: callable.signatureHash, declaration: callable.declaration,
      implementation: spanOf(context, declaration), relation, equation: contract.equation, term, dependencies: [] });
  }
  for (const [file, name, expected] of helperContracts) {
    const declaration = findFunction(sources.get(file), name);
    validateCallableSyntax(declaration);
    const term = normalizeCallable(declaration);
    assert.deepEqual(term, normalizeCallable(findFunction(parseSource("expected.ts", expected), "expected")), `Helper equation changed: ${name}`);
    certified.set(declarationKey(repositoryRoot, declaration), { declaration, term });
  }
  const lots = CATALOG_PUBLISHED_SUPPORTING_CONTRACTS.find((contract) => contract.functionName === "inventoryProjectedLots");
  assert(lots !== undefined);
  const lotDeclaration = findFunction(sources.get(lots.sourceFile), lots.functionName);
  const lotTerm = normalizeCallable(lotDeclaration);
  assert.deepEqual(lotTerm, expectedSupportingTerm(lots), "Lot index equation changed.");
  certified.set(declarationKey(repositoryRoot, lotDeclaration), { declaration: lotDeclaration, term: lotTerm });

  // Every source callable referenced by any admitted body must itself have an independent equation.
  // Standard Array/Map/Object/JSON/String/Error operations use the immutable ECMAScript built-in domain.
  if (sourceOverrides.size === 0) {
    const helpers = new Map();
    for (const [key, row] of certified) {
      const dependencies = new Set();
      const declaration = row.declaration;
      function inspect(node) {
        let symbol = (ts.isIdentifier(node) || ts.isPropertyAccessExpression(node))
          ? context.checker.getSymbolAtLocation(ts.isPropertyAccessExpression(node) ? node.name : node) : undefined;
        if (symbol !== undefined && (symbol.flags & ts.SymbolFlags.Alias) !== 0) symbol = context.checker.getAliasedSymbol(symbol);
        for (const dependency of symbol?.declarations ?? []) {
          assert(!ts.isGetAccessorDeclaration(dependency) && !ts.isSetAccessorDeclaration(dependency), "Accessor-backed reads are not ordinary immutable data.");
          if ((ts.isFunctionDeclaration(dependency) || ts.isMethodDeclaration(dependency)) && dependency.body !== undefined) {
            const dependencyKey = declarationKey(repositoryRoot, dependency);
            assert(certified.has(dependencyKey), `Unproved helper dependency: ${dependencyKey}`);
            if (dependencyKey !== key) dependencies.add(dependencyKey);
          }
        }
        if (ts.isCallExpression(node) || ts.isNewExpression(node)) {
          const target = context.checker.getResolvedSignature(node)?.declaration;
          assert(target !== undefined, `Unresolved call: ${node.getText()}`);
          if (target.getSourceFile().isDeclarationFile) {
            assert(/[/\\]typescript[/\\]lib[/\\]lib\.[^/\\]+\.d\.ts$/u.test(target.getSourceFile().fileName), "Only exact standard-library calls may be assumed.");
          } else if (ts.isFunctionDeclaration(target) || ts.isMethodDeclaration(target)) {
            assert(certified.has(declarationKey(repositoryRoot, target)), "Unproved resolved source call.");
          } else { assert(ts.isArrowFunction(target), "Unproved dynamic callback."); }
        }
        ts.forEachChild(node, inspect);
      }
      inspect(declaration.body);
      helpers.set(key, [...dependencies].sort());
    }
    for (const proof of proofs) proof.dependencies = helpers.get(`${proof.implementation.file}#${catalogContracts.find((contract) => contract.surfaceKey === proof.surfaceKey).className}.${catalogContracts.find((contract) => contract.surfaceKey === proof.surfaceKey).methodName}`);
  }
  const result = { schemaVersion: 1, mode: "V", proofKind: catalogProofKind, surfaceDigest: surface.digest,
    domain: "Exact unmodified validated InventoryCatalog receivers and already-frozen native snapshot receivers; immutable plain data and standard unmodified ECMAScript built-ins.",
    excluded: "Storage acquisition, catalog construction/publication, unproved delegated summaries/allocation/packaging and mutable/proxied/custom receivers are not certified by these equations.",
    allAdmittedInputs: true, sampledInputs: 0, inputs,
    helperEquations: [...certified.entries()].filter(([key]) => !key.includes("#Inventory")).map(([key, row]) => ({ key, declaration: spanOf(context, row.declaration), term: row.term })),
    proofs };
  if (sourceOverrides.size === 0) passCache.set(context, { key: cacheKey, value: result });
  return result;
}
