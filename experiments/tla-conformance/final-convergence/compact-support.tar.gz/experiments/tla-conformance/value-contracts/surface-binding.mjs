import { readAssuranceFile, assuranceFileSha256 } from "../../../scripts/assurance-files.mjs";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { canonicalJson, compareCodeUnits, nodeAtExactSpan, sha256, ts } from "../surface-bindings/lib/compiler-surface.mjs";
import { verifyValueSemantics } from "./verify.mjs";
import { buildCatalogFamilyArtifact, catalogProofKind } from "./catalog-family.mjs";
import { verifyRegisteredValueBinding } from "../throughput-r7/registered-value-family.mjs";
import { registeredValueFamilies } from "../throughput-r7/registered-families.mjs";

/** Exact reviewed specification consumed by the current semantic value checker. */
const contractsPath = fileURLToPath(new URL("./contracts.json", import.meta.url));
/** Inputs whose drift invalidates previously generated value receipts. */
const producerFiles = [
  "experiments/tla-conformance/value-contracts/contracts.json",
  "experiments/tla-conformance/value-contracts/verify.mjs",
  "experiments/tla-conformance/value-contracts/surface-binding.mjs",
  "experiments/tla-conformance/surface-bindings/lib/compiler-surface.mjs",
  "node_modules/typescript/package.json",
];

/** Reject a non-package evidence path, including a symlink escape. */
function evidencePath(repositoryRoot, relativePath) {
  if (typeof relativePath !== "string" || relativePath.length === 0 || path.isAbsolute(relativePath)) throw new Error("Value evidence requires a relative path.");
  const root = fs.realpathSync(repositoryRoot);
  const resolved = fs.realpathSync(path.resolve(root, relativePath));
  if (!resolved.startsWith(`${root}${path.sep}`)) throw new Error("Value evidence escapes the repository.");
  return resolved;
}

/** Bind each independently reviewed equation to its exact compiler-discovered public source declaration. */
export function buildValueContractArtifact({ repositoryRoot, context, surface }) {
  const specification = JSON.parse(fs.readFileSync(contractsPath, "utf8"));
  const keys = specification.contracts.flatMap((contract) => contract.surfaceKeys).sort(compareCodeUnits);
  if (keys.length !== new Set(keys).size) throw new Error("Independent value contracts repeat a surface key.");
  const proofs = [];
  for (const surfaceKey of keys) {
    const candidates = surface.callables.filter((callable) => callable.key === surfaceKey);
    if (candidates.length !== 1) throw new Error(`Value callable '${surfaceKey}' is missing or ambiguous.`);
    const callable = candidates[0];
    const declaration = callable.declaration;
    const source = context.program.getSourceFile(path.resolve(repositoryRoot, declaration.file));
    if (source === undefined || source.isDeclarationFile || !declaration.file.startsWith("src/")) throw new Error(`Value callable '${surfaceKey}' has no package implementation.`);
    const implementation = nodeAtExactSpan(source, declaration.start.offset, declaration.end.offset);
    if (implementation === undefined || !ts.isFunctionDeclaration(implementation) || implementation.body === undefined) throw new Error(`Value callable '${surfaceKey}' is not an exact source function.`);
    const verified = verifyValueSemantics(context, surfaceKey, implementation);
    if (verified.status !== "PROVED") throw new Error(`Value equation failed for '${surfaceKey}': ${JSON.stringify(verified.diagnostics)}`);
    proofs.push({ surfaceKey, signatureHash: callable.signatureHash, declaration, semantics: verified.proof });
  }
  return {
    schemaVersion: 1,
    mode: "V",
    proofKind: "independent-closed-return-equations-v1",
    surfaceDigest: surface.digest,
    producers: producerFiles.map((file) => ({ file, sha256: sha256(fs.readFileSync(path.resolve(repositoryRoot, file))) })),
    proofs,
  };
}

/** Admit a V binding only after current source equations and all exact producer/source identities are re-derived. */
const dispatchPasses = new WeakMap();

export function verifyValueContractBinding({ repositoryRoot, context, surface, binding }) {
  try {
    const reference = binding.evidence;
    if (binding.mode !== "V" || reference === undefined || !/^[0-9a-f]{64}$/u.test(reference.sha256 ?? "")) throw new Error("Value evidence reference is incomplete.");
    const digest = assuranceFileSha256(repositoryRoot, reference.file);
    if (digest !== reference.sha256) throw new Error("Value evidence hash drifted.");
    let pass = dispatchPasses.get(context);
    if (pass === undefined) { pass = new Map(); dispatchPasses.set(context, pass); }
    const key = `${reference.file}:${digest}`;
    let recorded = pass.get(key);
    if (recorded === undefined) { recorded = JSON.parse(readAssuranceFile(repositoryRoot, reference.file)); pass.set(key, recorded); }
    if (registeredValueFamilies.some((family) => family.proofKind === recorded.proofKind)) {
      return verifyRegisteredValueBinding({ repositoryRoot, context, surface, binding, registrations: registeredValueFamilies });
    }
    const current = recorded.proofKind === catalogProofKind
      ? buildCatalogFamilyArtifact({ repositoryRoot, context, surface })
      : buildValueContractArtifact({ repositoryRoot, context, surface });
    if (canonicalJson(recorded) !== canonicalJson(current)) throw new Error("Recorded value proof differs from current independent source equations.");
    if (!current.proofs.some((proof) => proof.surfaceKey === binding.surfaceKey)) throw new Error("No independent value equation for this callable.");
    return [];
  } catch (error) {
    return [{ code: "VALUE_SEMANTIC_PROOF_REJECTED", detail: error instanceof Error ? error.message : String(error) }];
  }
}
