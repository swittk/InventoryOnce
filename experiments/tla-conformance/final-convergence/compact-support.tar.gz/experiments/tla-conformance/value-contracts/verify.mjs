import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { canonicalJson, compareCodeUnits, sha256, spanOf, ts } from "../surface-bindings/lib/compiler-surface.mjs";

/** Reviewed independent return-value specifications, not regenerated from implementation. */
const contractPath = fileURLToPath(new URL("./contracts.json", import.meta.url));
/** This checker is itself bound into each semantic proof receipt. */
const verifierPath = fileURLToPath(import.meta.url);

/** Reject syntax outside the deliberately small semantics-preserving return grammar. */
function fail(code, detail) {
  const error = new Error(detail);
  error.code = code;
  throw error;
}

/** Resolve an identifier call to one real source body, never an ambient declaration. */
function dependencyBody(context, call) {
  if (!ts.isIdentifier(call.expression) || call.questionDotToken !== undefined) {
    fail("VALUE_SEMANTIC_UNBOUND_CALL", "Only direct source-identifier calls are admitted.");
  }
  const signature = context.checker.getResolvedSignature(call);
  const body = signature?.declaration;
  if (body === undefined || !ts.isFunctionDeclaration(body) || body.body === undefined || body.getSourceFile().isDeclarationFile) {
    fail("VALUE_SEMANTIC_UNBOUND_CALL", "Called value helper has no unique resolved source body.");
  }
  const relative = path.relative(context.repositoryRoot, body.getSourceFile().fileName).replaceAll("\\", "/");
  if (!relative.startsWith("src/")) fail("VALUE_SEMANTIC_UNBOUND_CALL", "Dependency is not package source.");
  return body;
}

/** Derive an executable pure return term with positional parameter identities and explicit dependency expansion. */
export function deriveValueReturnTerm(context, implementation) {
  const dependencies = new Map();
  const standardDependencies = new Map();
  const active = new Set();

  /** Expand a source body without executing it or accepting expected-state input. */
  function expand(body, arguments_) {
    if (active.has(body)) fail("VALUE_SEMANTIC_RECURSION", "Recursive value helper is not a closed term.");
    if (!ts.isFunctionDeclaration(body) || body.body === undefined || body.asteriskToken !== undefined ||
        (ts.getCombinedModifierFlags(body) & ts.ModifierFlags.Async) !== 0) {
      fail("VALUE_SEMANTIC_BODY", "Value contract requires a synchronous ordinary source function.");
    }
    if (body.parameters.length !== arguments_.length) fail("VALUE_SEMANTIC_ARITY", "Value function arity differs from its call.");
    const environment = new Map();
    for (let index = 0; index < body.parameters.length; index += 1) {
      const parameter = body.parameters[index];
      if (!ts.isIdentifier(parameter.name) || parameter.initializer !== undefined || parameter.dotDotDotToken !== undefined) {
        fail("VALUE_SEMANTIC_PARAMETER", "Parameters must be simple, non-defaulted identifiers.");
      }
      const symbol = context.checker.getSymbolAtLocation(parameter.name);
      if (symbol === undefined) fail("VALUE_SEMANTIC_PARAMETER", "Parameter has no compiler identity.");
      environment.set(symbol, arguments_[index]);
    }
    if (body.body.statements.length !== 1 || !ts.isReturnStatement(body.body.statements[0]) ||
        body.body.statements[0].expression === undefined) {
      fail("VALUE_SEMANTIC_BODY", "One explicit return expression is required; no hidden statements are allowed.");
    }
    active.add(body);
    const source = spanOf(context, body);
    dependencies.set(`${source.file}:${source.start.offset}:${source.end.offset}`, source);

    /** Admit the one reviewed prototype-free sparse-record constructor without admitting arbitrary ambient calls or casts. */
    function sparseEmptyRecordTerm(dependency, call) {
      const relative = path.relative(context.repositoryRoot, dependency.getSourceFile().fileName).replaceAll("\\", "/");
      if (relative !== "src/sparse-record.ts" || dependency.name?.text !== "createInventorySparseRecord") return undefined;
      if (call.arguments.length !== 0 || dependency.parameters.length !== 0 || dependency.body === undefined || dependency.body.statements.length !== 1 ||
          !ts.isReturnStatement(dependency.body.statements[0]) || dependency.body.statements[0].expression === undefined) {
        fail("VALUE_SEMANTIC_SPARSE_RECORD", "Sparse-record construction must remain one zero-argument return expression.");
      }
      let runtimeExpression = dependency.body.statements[0].expression;
      while (ts.isParenthesizedExpression(runtimeExpression) || ts.isAsExpression(runtimeExpression) || ts.isTypeAssertionExpression(runtimeExpression) || ts.isSatisfiesExpression(runtimeExpression)) {
        runtimeExpression = runtimeExpression.expression;
      }
      if (!ts.isCallExpression(runtimeExpression) || runtimeExpression.arguments.length !== 1 ||
          runtimeExpression.arguments[0].kind !== ts.SyntaxKind.NullKeyword || runtimeExpression.questionDotToken !== undefined ||
          !ts.isPropertyAccessExpression(runtimeExpression.expression) || runtimeExpression.expression.questionDotToken !== undefined ||
          !ts.isIdentifier(runtimeExpression.expression.expression) || runtimeExpression.expression.expression.text !== "Object" ||
          runtimeExpression.expression.name.text !== "create") {
        fail("VALUE_SEMANTIC_SPARSE_RECORD", "Sparse-record construction must be exact global Object.create(null).");
      }
      const objectSymbol = context.checker.getSymbolAtLocation(runtimeExpression.expression.expression);
      const objectDeclarations = objectSymbol?.declarations ?? [];
      if (objectSymbol?.getName() !== "Object" || (objectSymbol.flags & ts.SymbolFlags.Alias) !== 0 || objectDeclarations.length === 0 ||
          objectDeclarations.some((candidate) => !candidate.getSourceFile().isDeclarationFile) ||
          !objectDeclarations.some((candidate) => ts.isVariableDeclaration(candidate) && candidate.name.getText(candidate.getSourceFile()) === "Object")) {
        fail("VALUE_SEMANTIC_SPARSE_RECORD", "Sparse-record construction must use the standard global Object intrinsic.");
      }
      const signature = context.checker.getResolvedSignature(runtimeExpression);
      const declaration = signature?.declaration;
      if (declaration === undefined || !declaration.getSourceFile().isDeclarationFile ||
          declaration.getText(declaration.getSourceFile()) !== "create(o: object | null): any;") {
        fail("VALUE_SEMANTIC_SPARSE_RECORD", "Object.create must resolve to the reviewed standard declaration.");
      }
      const source = spanOf(context, dependency);
      dependencies.set(`${source.file}:${source.start.offset}:${source.end.offset}`, source);
      const standard = spanOf(context, declaration);
      standardDependencies.set("Object.create", {
        operation: "Object.create",
        file: "typescript/lib/lib.es5.d.ts",
        start: standard.start,
        end: standard.end,
        sourceHash: standard.sourceHash,
        astHash: standard.astHash,
      });
      return ["sparse-record", []];
    }

    /** Translate only total own-field reads, fresh ordinary/sparse records, literals and number subtraction. */
    function term(node) {
      if (ts.isParenthesizedExpression(node)) return term(node.expression);
      if (ts.isIdentifier(node)) {
        const symbol = context.checker.getSymbolAtLocation(node);
        if (!environment.has(symbol)) fail("VALUE_SEMANTIC_NONLOCAL", `Non-parameter value '${node.text}'.`);
        return environment.get(symbol);
      }
      if (ts.isNumericLiteral(node)) return ["number", String(Number(node.text))];
      if (ts.isStringLiteral(node)) return ["string", node.text];
      if (node.kind === ts.SyntaxKind.TrueKeyword) return ["boolean", true];
      if (node.kind === ts.SyntaxKind.FalseKeyword) return ["boolean", false];
      if (node.kind === ts.SyntaxKind.NullKeyword) return ["null"];
      if (ts.isPropertyAccessExpression(node)) {
        if (node.questionDotToken !== undefined) fail("VALUE_SEMANTIC_FIELD", "Optional field reads are not admitted.");
        const symbol = context.checker.getSymbolAtLocation(node.name);
        if (symbol === undefined || (symbol.flags & ts.SymbolFlags.Optional) !== 0 ||
            (symbol.declarations ?? []).some((declaration) => ts.isGetAccessorDeclaration(declaration) || ts.isSetAccessorDeclaration(declaration))) {
          fail("VALUE_SEMANTIC_FIELD", "Only required declared data fields may be projected.");
        }
        return ["get", term(node.expression), node.name.text];
      }
      if (ts.isObjectLiteralExpression(node)) {
        const fields = new Map();
        for (const property of node.properties) {
          if (!ts.isPropertyAssignment(property) ||
              !(ts.isIdentifier(property.name) || ts.isStringLiteral(property.name))) {
            fail("VALUE_SEMANTIC_RECORD", "Record fields must be explicit data properties, without spreads or methods.");
          }
          const name = property.name.text;
          if (name === "__proto__" || fields.has(name)) fail("VALUE_SEMANTIC_RECORD", "Prototype-changing or duplicate fields are not admitted.");
          fields.set(name, term(property.initializer));
        }
        return ["record", [...fields].sort(([left], [right]) => compareCodeUnits(left, right))];
      }
      if (ts.isBinaryExpression(node) && node.operatorToken.kind === ts.SyntaxKind.MinusToken) {
        for (const operand of [node.left, node.right]) {
          if ((context.checker.getTypeAtLocation(operand).flags & ts.TypeFlags.NumberLike) === 0) {
            fail("VALUE_SEMANTIC_NUMBER", "Subtraction requires declared number operands, not object coercion or bigint.");
          }
        }
        return ["subtract", term(node.left), term(node.right)];
      }
      if (ts.isCallExpression(node)) {
        const dependency = dependencyBody(context, node);
        const sparse = sparseEmptyRecordTerm(dependency, node);
        if (sparse !== undefined) return sparse;
        return expand(dependency, node.arguments.map(term));
      }
      fail("VALUE_SEMANTIC_SYNTAX", `Unproved expression kind '${ts.SyntaxKind[node.kind]}'.`);
    }
    try {
      return term(body.body.statements[0].expression);
    } finally {
      active.delete(body);
    }
  }
  const result = expand(implementation, implementation.parameters.map((_, index) => ["parameter", index]));
  return {
    term: result,
    dependencies: [...dependencies.values()].sort((left, right) => compareCodeUnits(`${left.file}:${left.start.offset}`, `${right.file}:${right.start.offset}`)),
    standardDependencies: [...standardDependencies.values()].sort((left, right) => compareCodeUnits(left.operation, right.operation)),
  };
}

/** Prove exact identity with an independently declared value equation for every admitted input, not sampled examples. */
export function verifyValueSemantics(context, surfaceKey, implementation) {
  try {
    const bytes = fs.readFileSync(contractPath);
    const document = JSON.parse(bytes);
    if (document.schemaVersion !== 2 || document.domain !== "DECLARED_IMMUTABLE_DATA_VALUES_V2" || !Array.isArray(document.contracts)) {
      fail("VALUE_SEMANTIC_CONTRACT_SCHEMA", "Independent value specification schema is invalid.");
    }
    const matches = document.contracts.filter((contract) => contract.surfaceKeys.includes(surfaceKey));
    if (matches.length !== 1) fail("VALUE_SEMANTIC_CONTRACT_MISSING", `Exactly one reviewed value contract is required for '${surfaceKey}'.`);
    const contract = matches[0];
    if (implementation.parameters.length !== contract.arity) fail("VALUE_SEMANTIC_ARITY", "Source arity differs from the independent value specification.");
    const derived = deriveValueReturnTerm(context, implementation);
    if (canonicalJson(derived.term) !== canonicalJson(contract.term)) {
      fail("VALUE_SEMANTIC_RESULT_MISMATCH", `Returned value does not implement independent contract '${contract.id}'.`);
    }
    return {
      status: "PROVED",
      proof: {
        contractId: contract.id,
        domain: document.domain,
        engine: "closed-return-term-identity-v2",
        allAdmittedInputs: true,
        sampledInputs: 0,
        independentContract: true,
        contractFile: path.relative(context.repositoryRoot, contractPath).replaceAll("\\", "/"),
        contractSha256: sha256(bytes),
        verifierFile: path.relative(context.repositoryRoot, verifierPath).replaceAll("\\", "/"),
        verifierSha256: sha256(fs.readFileSync(verifierPath)),
        equationSha256: sha256(canonicalJson(contract.term)),
        dependencies: derived.dependencies,
        standardDependencies: derived.standardDependencies,
      },
    };
  } catch (error) {
    return { status: "REJECTED", diagnostics: [{ code: error.code ?? "VALUE_SEMANTIC_VERIFICATION_FAILED", detail: error.message }] };
  }
}
