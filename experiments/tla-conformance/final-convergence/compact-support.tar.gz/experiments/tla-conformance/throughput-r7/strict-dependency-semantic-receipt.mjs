import { strictDependencyReceipt as verifyCurrentStrictDependencies } from "./strict-dependency-receipt.mjs";

/** Verify dependencies against the live strict registry while returning only stable dependency-local semantics. */
export function strictDependencySemanticReceipt(input) {
  const receipt = verifyCurrentStrictDependencies(input);
  return { kind: "COMPOSED_CURRENT_STRICT_DEPENDENCIES", dependencies: receipt.dependencies };
}
