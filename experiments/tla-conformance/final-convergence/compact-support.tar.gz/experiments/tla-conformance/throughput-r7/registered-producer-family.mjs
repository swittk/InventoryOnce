import { assuranceRepositoryPath, readAssuranceFile, assuranceFileSha256, assuranceCompilerSourceSha256 } from "../../../scripts/assurance-files.mjs";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { canonicalJson, sha256 } from "../surface-bindings/lib/compiler-surface.mjs";

/** Reuse one independently rederived producer family inside a single compiler pass only. */
const passes = new WeakMap();
/** Reuse parsed evidence bytes inside a compiler pass without trusting their labels. */
const recordedPasses = new WeakMap();

/** Resolve one ordinary repository-owned file without permitting path or symlink escape. */
function ownedFile(root, file) {
  return assuranceRepositoryPath(root, file);
}

/** Require every recorded semantic and route input to remain byte-identical to the current compiler tree. */
function verifyInputs(root, context, inputs) {
  assert(Array.isArray(inputs) && inputs.length > 0, "Registered producer needs its complete semantic input set.");
  const seen = new Set();
  for (const input of inputs) {
    assert.equal(typeof input.file, "string");
    assert(!seen.has(input.file), "Registered producer input is duplicated.");
    seen.add(input.file);
    assert.match(input.sha256, /^[0-9a-f]{64}$/u);
    const absolute = ownedFile(root, input.file);
    assert.equal(assuranceFileSha256(root, input.file), input.sha256, `Registered producer input changed: ${input.file}`);
    if (input.file.startsWith("src/") && input.file.endsWith(".ts")) {
      const source = context.program.getSourceFile(path.resolve(root, input.file));
      assert(source !== undefined, `Compiler omitted registered producer source: ${input.file}`);
      assert.equal(assuranceCompilerSourceSha256(root, input.file, source.text), input.sha256, `Compiler snapshot is stale: ${input.file}`);
    }
  }
}

/** Verify one A/B claim through exactly one trusted whole-producer registration, never as a fallback. */
export function verifyRegisteredProducerBinding({ repositoryRoot, context, surface, binding, registrations }) {
  try {
    assert(binding.mode === "A" || binding.mode === "B", "Registered producer binding must remain A or B.");
    const file = ownedFile(repositoryRoot, binding.evidence.file);
    const digest = assuranceFileSha256(repositoryRoot, binding.evidence.file);
    assert.equal(digest, binding.evidence.sha256, "Registered producer evidence changed.");

    let recordedPass = recordedPasses.get(context);
    if (recordedPass === undefined) {
      recordedPass = new Map();
      recordedPasses.set(context, recordedPass);
    }
    const recordedKey = `${file}:${digest}`;
    let recorded = recordedPass.get(recordedKey);
    if (recorded === undefined) {
      const document = JSON.parse(readAssuranceFile(repositoryRoot, binding.evidence.file).toString("utf8"));
      recorded = { document, canonical: canonicalJson(document) };
      recordedPass.set(recordedKey, recorded);
    }

    const matching = registrations.filter(
      (registration) => registration.proofKind === recorded.document.proofKind
    );
    assert.equal(matching.length, 1, "Exactly one trusted producer registration must own this proof kind.");
    const registration = matching[0];
    assert.equal(typeof registration.buildFamilyArtifact, "function");
    assert(Array.isArray(registration.supportedSurfaceRows));
    assert.equal(
      new Set(registration.supportedSurfaceRows.map((row) => `${row.surfaceKey}\n${row.mode}`)).size,
      registration.supportedSurfaceRows.length,
      "Trusted producer registration repeats a surface/mode pair."
    );
    assert(
      registration.supportedSurfaceRows.some(
        (row) => row.surfaceKey === binding.surfaceKey && row.mode === binding.mode
      ),
      "Binding is outside the trusted producer registration."
    );

    let compilerPass = passes.get(context);
    if (compilerPass === undefined) {
      compilerPass = new Map();
      passes.set(context, compilerPass);
    }
    const registrationIdentity = canonicalJson(registration.supportedSurfaceRows);
    let cached = compilerPass.get(registration);
    if (
      cached !== undefined &&
      cached.surfaceDigest === surface.digest &&
      cached.members === registrationIdentity &&
      cached.builder === registration.buildFamilyArtifact
    ) {
      verifyInputs(repositoryRoot, context, cached.artifact.inputs);
    } else {
      const artifact = registration.buildFamilyArtifact({ repositoryRoot, context, surface });
      assert.equal(artifact.schemaVersion, 1);
      assert.equal(artifact.proofKind, registration.proofKind);
      assert.equal(artifact.route, "REGISTERED_CERTIFIED_PRODUCER");
      assert.equal(artifact.sampledInputs, 0, "Registered producer cannot be sample-backed.");
      assert.equal(artifact.allAdmittedInputs, true);
      assert(
        (typeof artifact.domain === "string" && artifact.domain.length > 0) ||
          (artifact.domain !== null &&
            typeof artifact.domain === "object" &&
            !Array.isArray(artifact.domain) &&
            Object.keys(artifact.domain).length > 0),
        "Registered producer needs an explicit complete domain."
      );
      const artifactSurface = artifact.surfaceDigest ?? artifact.sourceHub?.surfaceDigest;
      assert.equal(artifactSurface, surface.digest, "Registered producer surface identity changed.");
      assert(Array.isArray(artifact.proofs) && artifact.proofs.length > 0);
      verifyInputs(repositoryRoot, context, artifact.inputs);
      const proofPairs = artifact.proofs.map((proof) => `${proof.surfaceKey}\n${proof.mode}`);
      assert.equal(new Set(proofPairs).size, proofPairs.length, "Registered producer repeats a proof pair.");
      assert.deepEqual(
        [...proofPairs].sort(),
        registration.supportedSurfaceRows.map((row) => `${row.surfaceKey}\n${row.mode}`).sort(),
        "Current producer membership differs from its trusted registration."
      );
      const live = new Map(surface.callables.map((callable) => [callable.key, callable]));
      for (const proof of artifact.proofs) {
        assert(proof.mode === "A" || proof.mode === "B", "Registered producer emitted a non-A/B proof.");
        const callable = live.get(proof.surfaceKey);
        assert(callable !== undefined, "Registered producer claims a non-public callable.");
        assert.equal(proof.signatureHash, callable.signatureHash);
        assert.deepEqual(proof.declaration, callable.declaration);
      }
      cached = {
        surfaceDigest: surface.digest,
        members: registrationIdentity,
        builder: registration.buildFamilyArtifact,
        artifact,
        canonical: canonicalJson(artifact),
      };
      compilerPass.set(registration, cached);
    }

    assert.equal(
      recorded.canonical,
      cached.canonical,
      "Recorded producer family differs from independently rederived current producer truth."
    );
    assert(
      cached.artifact.proofs.some(
        (proof) => proof.surfaceKey === binding.surfaceKey && proof.mode === binding.mode
      ),
      "No exact producer proof exists for this surface/mode pair."
    );
    return [];
  } catch (error) {
    return [{
      code: "REGISTERED_PRODUCER_PROOF_REJECTED",
      detail: error instanceof Error ? error.message : String(error),
    }];
  }
}
