import { buildFinalValueArtifact, supportedValueKeys as finalValueKeys, valueProofKind as finalValueProofKind } from "../final-convergence/final-families.mjs";
import { buildFamilyArtifact as buildReservationFeasibilityV1, supportedSurfaceKeys as reservationFeasibilityV1Keys, proofKind as reservationFeasibilityV1ProofKind } from "../boundary-adjudication-r18/family.mjs";
import { buildFamilyArtifact as buildCompositionOpenV1, supportedSurfaceKeys as compositionOpenV1Keys, proofKind as compositionOpenV1ProofKind } from "../surface-residual-r8/pure-residual5-r10/composition-open-family.mjs";
import { buildFamilyArtifact as buildResidualCoreV4, supportedSurfaceKeys as residualCoreV4Keys, proofKind as residualCoreV4ProofKind } from "../residual-core-v4-r10/family.mjs";
import { buildFamilyArtifact as buildCatalogPublicationCoreV1, supportedSurfaceKeys as catalogPublicationCoreV1Keys, proofKind as catalogPublicationCoreV1ProofKind } from "../catalog-public-lifecycle7-r9/publication-core-r10/value-family.mjs";
import { buildFamilyArtifact as buildSurfaceQueueDirectV7, supportedSurfaceKeys as surfaceQueueDirectV7Keys, proofKind as surfaceQueueDirectV7ProofKind } from "../surface-residual-r8/direct-pure-v7/family.mjs";
import { buildFamilyArtifact as buildSurfaceQueueFinalV2, supportedSurfaceKeys as surfaceQueueFinalV2Keys, proofKind as surfaceQueueFinalV2ProofKind } from "../surface-residual-r8/final-unique8-r9/value-v2/family.mjs";
import { buildFamilyArtifact as buildMigrationQueueMaterializeV1, supportedSurfaceKeys as migrationQueueMaterializeV1Keys, proofKind as migrationQueueMaterializeV1ProofKind } from "../materialize1-r8/family.mjs";
import { buildFamilyArtifact as buildTraceabilityQueueApplyV1, supportedSurfaceKeys as traceabilityQueueApplyV1Keys, proofKind as traceabilityQueueApplyV1ProofKind } from "../traceability-apply1-r8/family.mjs";
import { buildFamilyArtifact as buildR43CurrentValues, supportedSurfaceKeys as r43CurrentValueKeys, proofKind as r43CurrentValueProofKind } from "../new-source-honest486-r43/value-currentizer.mjs";
import { buildFamilyArtifact as buildAuthorityResultV3, supportedSurfaceKeys as authorityResultV3Keys, proofKind as authorityResultV3ProofKind } from "../authority-values-r40/family.mjs";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { sha256 } from "../surface-bindings/lib/compiler-surface.mjs";
import { buildFamilyArtifact as buildQuantity, supportedSurfaceKeys as quantityKeys } from "../quantity-values-r7/certificate.mjs";
import { QUANTITY_VALUES_PROOF_KIND } from "../quantity-values-r7/contracts.mjs";
import { buildFamilyArtifact as buildIdentity, supportedSurfaceKeys as identityKeys, identityValuesProofKind } from "../identity-values-r7/family.mjs";
import { buildFamilyArtifact as buildMigrationHelpers, supportedSurfaceKeys as migrationHelperKeys, proofKind as migrationHelperProofKind } from "../migration-helper-causal-r7/registered-value-family.mjs";
import { buildFamilyArtifact as buildMigrationHelperFrontier, supportedSurfaceKeys as migrationHelperFrontierKeys, proofKind as migrationHelperFrontierProofKind } from "../migration-helper-causal-r7/registered-frontier-v2-family.mjs";
import { buildFamilyArtifact as buildCatalogFoundation, supportedSurfaceKeys as catalogFoundationKeys, proofKind as catalogFoundationProofKind } from "../catalog-foundation-r7/family.mjs";
import { buildFamilyArtifact as buildEventValues, supportedSurfaceKeys as eventValueKeys, proofKind as eventValueProofKind } from "../quantity-values-r7/event-values/registered-family-adapter.mjs";
import { buildFamilyArtifact as buildTransferCorrectionValues, supportedSurfaceKeys as transferCorrectionValueKeys } from "../transfer-surface-r6/source-equations-r7/family.mjs";
import { TRANSFER_CORRECTION_VALUE_PROOF_KIND as transferCorrectionValueProofKind } from "../transfer-surface-r6/source-equations-r7/contracts.mjs";
import { buildFamilyArtifact as buildCatalogReadValues, supportedSurfaceKeys as catalogReadValueKeys, proofKind as catalogReadValueProofKind } from "../authority-r5/catalog-read-dependency-closure-certificate.mjs";
import { buildFamilyArtifact as buildAuthorityControlValues, supportedSurfaceKeys as authorityControlValueKeys, proofKind as authorityControlValueProofKind } from "../astra-authority-control-r8/family.mjs";
import { buildFamilyArtifact as buildTraceabilityValues, supportedSurfaceKeys as traceabilityValueKeys, proofKind as traceabilityValueProofKind } from "../migration-r5/traceability-value-family.mjs";
import { buildFamilyArtifact as buildFungibilityValues5, supportedSurfaceKeys as fungibilityValue5Keys, proofKind as fungibilityValue5ProofKind } from "../fungibility-values5-r8/family.mjs";
import { buildFamilyArtifact as buildStorageValues, supportedSurfaceKeys as storageValueKeys, proofKind as storageValueProofKind } from "../storage-protocol-r7/value-family.mjs";
import { buildFamilyArtifact as buildFungibilitySummary, supportedSurfaceKeys as fungibilitySummaryKeys, proofKind as fungibilitySummaryProofKind } from "../fungibility-read-r9/summary-family.mjs";
import { buildFamilyArtifact as buildFungibilityPlanValues, supportedSurfaceKeys as fungibilityPlanValueKeys, proofKind as fungibilityPlanValueProofKind } from "../fungibility-plan-r9/value-family.mjs";

/** Registrations are reviewed executable source; a certificate can never choose a module to run. */
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../..");
/** Exact source bytes loaded for the current admission route. */
const routeInputs = [
  "experiments/tla-conformance/throughput-r7/registered-value-family.mjs",
  "experiments/tla-conformance/value-contracts/surface-binding.mjs",
].map((file) => ({file,sha256:sha256(fs.readFileSync(path.resolve(root,file)))}));

/** Derive the actual semantic family and attach the current trusted route without altering its equations. */
function registeredBuilder(builder) {
  let cached;
  return function buildRegisteredArtifact(input) {
    assert.equal(path.resolve(input.repositoryRoot),root);
    for (const identity of routeInputs) assert.equal(sha256(fs.readFileSync(path.resolve(root,identity.file))),identity.sha256,`Loaded route changed: ${identity.file}`);
    if (cached !== undefined && cached.surfaceDigest === input.surface.digest) {
      for (const identity of cached.artifact.inputs) {
        assert.equal(sha256(fs.readFileSync(path.resolve(root,identity.file))),identity.sha256,`Cached family input changed: ${identity.file}`);
      }
      return cached.artifact;
    }
    const artifact = builder(input);
    const identities = new Map(artifact.inputs.map((identity)=>[identity.file,identity]));
    for (const identity of routeInputs) {
      const previous=identities.get(identity.file);
      assert(previous===undefined || previous.sha256===identity.sha256,`Conflicting route input: ${identity.file}`);
      identities.set(identity.file,identity);
    }
    const registered={...artifact,inputs:[...identities.values()].sort((a,b)=>a.file<b.file?-1:a.file>b.file?1:0)};
    cached={surfaceDigest:input.surface.digest,artifact:registered};
    return registered;
  };
}

/** Whole independent source-equation families; the original A/B checker is unchanged. */
export const registeredValueFamilies = Object.freeze([
  Object.freeze({proofKind:finalValueProofKind,buildFamilyArtifact:buildFinalValueArtifact,supportedSurfaceKeys:finalValueKeys,artifactFile:"experiments/tla-conformance/final-convergence/final-v309.json",reviewedCommit:"FINAL_CONVERGENCE_e1759f7"}),
  Object.freeze({proofKind:r43CurrentValueProofKind,buildFamilyArtifact:buildR43CurrentValues,supportedSurfaceKeys:r43CurrentValueKeys,artifactFile:"experiments/tla-conformance/new-source-honest486-r43/value-currentizer-evidence.json",reviewedCommit:"R46_521d2d4"}),
  Object.freeze({proofKind:authorityResultV3ProofKind,buildFamilyArtifact:buildAuthorityResultV3,supportedSurfaceKeys:authorityResultV3Keys,artifactFile:"experiments/tla-conformance/authority-values-r40/evidence.json",reviewedCommit:"R40_CURRENT_SOURCE"}),
  Object.freeze({proofKind:reservationFeasibilityV1ProofKind,buildFamilyArtifact:registeredBuilder(buildReservationFeasibilityV1),supportedSurfaceKeys:reservationFeasibilityV1Keys,artifactFile:"experiments/tla-conformance/throughput-r7/evidence/queue-reservation-feasibility-v1-values.json",reviewedCommit:"2bdeaf4"}),
  Object.freeze({proofKind:compositionOpenV1ProofKind,buildFamilyArtifact:registeredBuilder(buildCompositionOpenV1),supportedSurfaceKeys:compositionOpenV1Keys,artifactFile:"experiments/tla-conformance/throughput-r7/evidence/queue-composition-open-v1-values.json",reviewedCommit:"118d7c939ad5220ffaa99149e6b93b5fcce80a64"}),
  Object.freeze({proofKind:residualCoreV4ProofKind,buildFamilyArtifact:registeredBuilder(buildResidualCoreV4),supportedSurfaceKeys:residualCoreV4Keys,artifactFile:"experiments/tla-conformance/throughput-r7/evidence/residual-core-v4-values.json",reviewedCommit:"HUB_OWNER_CURRENT_460"}),
  Object.freeze({proofKind:catalogPublicationCoreV1ProofKind,buildFamilyArtifact:registeredBuilder(buildCatalogPublicationCoreV1),supportedSurfaceKeys:catalogPublicationCoreV1Keys,artifactFile:"experiments/tla-conformance/throughput-r7/evidence/queue-catalog-publication-event-v1-values.json",reviewedCommit:"89e60cdbb26fd2333cb9df7427ab52ee39f74af4"}),
  Object.freeze({proofKind:surfaceQueueDirectV7ProofKind,buildFamilyArtifact:registeredBuilder(buildSurfaceQueueDirectV7),supportedSurfaceKeys:surfaceQueueDirectV7Keys,artifactFile:"experiments/tla-conformance/throughput-r7/evidence/queue-surface-direct-v7-values.json",reviewedCommit:"fcf4871d4f8df4abfe212de2f65216ee0032b18d"}),
  Object.freeze({proofKind:surfaceQueueFinalV2ProofKind,buildFamilyArtifact:registeredBuilder(buildSurfaceQueueFinalV2),supportedSurfaceKeys:surfaceQueueFinalV2Keys,artifactFile:"experiments/tla-conformance/throughput-r7/evidence/queue-surface-final-v2-values.json",reviewedCommit:"fcf4871d4f8df4abfe212de2f65216ee0032b18d"}),
  Object.freeze({proofKind:migrationQueueMaterializeV1ProofKind,buildFamilyArtifact:registeredBuilder(buildMigrationQueueMaterializeV1),supportedSurfaceKeys:migrationQueueMaterializeV1Keys,artifactFile:"experiments/tla-conformance/throughput-r7/evidence/queue-migration-materialize-v1-values.json",reviewedCommit:"ed7fd4788d31eb184ab45c99d3d1d47a0c44681c"}),
  Object.freeze({proofKind:traceabilityQueueApplyV1ProofKind,buildFamilyArtifact:registeredBuilder(buildTraceabilityQueueApplyV1),supportedSurfaceKeys:traceabilityQueueApplyV1Keys,artifactFile:"experiments/tla-conformance/throughput-r7/evidence/queue-traceability-apply-v1-values.json",reviewedCommit:"9245decd4de5ab38e292624863f11e378c7283af"}),
  Object.freeze({proofKind:fungibilityPlanValueProofKind,buildFamilyArtifact:registeredBuilder(buildFungibilityPlanValues),supportedSurfaceKeys:fungibilityPlanValueKeys,
    artifactFile:"experiments/tla-conformance/throughput-r7/evidence/fungibility-plan-values.json",reviewedCommit:"08cdfe12cda290174301195c16a35cc9df16b521"}),
  Object.freeze({proofKind:fungibilitySummaryProofKind,buildFamilyArtifact:registeredBuilder(buildFungibilitySummary),supportedSurfaceKeys:fungibilitySummaryKeys,
    artifactFile:"experiments/tla-conformance/throughput-r7/evidence/fungibility-summary-values.json",reviewedCommit:"20de604f6cdfd47958f393c539b12cacc085b434"}),
  Object.freeze({proofKind:storageValueProofKind,buildFamilyArtifact:registeredBuilder(buildStorageValues),supportedSurfaceKeys:storageValueKeys,
    artifactFile:"experiments/tla-conformance/throughput-r7/evidence/storage-protocol-values.json",reviewedCommit:"4e10792d919d97b8925ae173adfa3343b49ffe99"}),
  Object.freeze({proofKind:fungibilityValue5ProofKind,buildFamilyArtifact:registeredBuilder(buildFungibilityValues5),supportedSurfaceKeys:fungibilityValue5Keys,
    artifactFile:"experiments/tla-conformance/throughput-r7/evidence/fungibility-values5.json",reviewedCommit:"ffb5da9680af34ff741920b72c0835c4f0a01c8c"}),
  Object.freeze({proofKind:traceabilityValueProofKind,buildFamilyArtifact:registeredBuilder(buildTraceabilityValues),supportedSurfaceKeys:traceabilityValueKeys,
    artifactFile:"experiments/tla-conformance/throughput-r7/evidence/migration-traceability-values.json",reviewedCommit:"751c990243c676d60aa85e00d329d444aa6997ad"}),
  Object.freeze({proofKind:authorityControlValueProofKind,buildFamilyArtifact:registeredBuilder(buildAuthorityControlValues),supportedSurfaceKeys:authorityControlValueKeys,
    artifactFile:"experiments/tla-conformance/throughput-r7/evidence/astra-authority-control-values.json",reviewedCommit:"e25fc9e8a4680e932a4e5ef492bb586f20478bcb"}),
  Object.freeze({proofKind:catalogReadValueProofKind,buildFamilyArtifact:registeredBuilder(buildCatalogReadValues),supportedSurfaceKeys:catalogReadValueKeys,
    artifactFile:"experiments/tla-conformance/throughput-r7/evidence/catalog-read-values.json",reviewedCommit:null,
    reviewedSource:{kind:"HUB_REVIEWED_CONTENT_SNAPSHOT",receipt:"experiments/tla-conformance/authority-r5/catalog-read-hub-integration-receipt.json"}}),
  Object.freeze({proofKind:transferCorrectionValueProofKind,buildFamilyArtifact:registeredBuilder(buildTransferCorrectionValues),supportedSurfaceKeys:transferCorrectionValueKeys,
    artifactFile:"experiments/tla-conformance/throughput-r7/evidence/transfer-correction-values.json",reviewedCommit:null,
    reviewedSource:{kind:"HUB_REVIEWED_CONTENT_SNAPSHOT",receipt:"experiments/tla-conformance/transfer-surface-r6/source-equations-r7/hub-integration-receipt.json"}}),
  Object.freeze({proofKind:catalogFoundationProofKind,buildFamilyArtifact:registeredBuilder(buildCatalogFoundation),supportedSurfaceKeys:catalogFoundationKeys,
    artifactFile:"experiments/tla-conformance/throughput-r7/evidence/catalog-foundation-values.json",reviewedCommit:null,
    reviewedSource:{kind:"REVIEWED_CONTENT_SNAPSHOT",receipt:"experiments/tla-conformance/catalog-foundation-r7/import-source-receipt.json"}}),
  Object.freeze({proofKind:eventValueProofKind,buildFamilyArtifact:registeredBuilder(buildEventValues),supportedSurfaceKeys:eventValueKeys,
    artifactFile:"experiments/tla-conformance/throughput-r7/evidence/event-values.json",reviewedCommit:null,
    reviewedSource:{kind:"HUB_REVIEWED_CONTENT_SNAPSHOT",receipt:"experiments/tla-conformance/quantity-values-r7/event-values/hub-integration-receipt.json"}}),
  Object.freeze({proofKind:migrationHelperProofKind,buildFamilyArtifact:registeredBuilder(buildMigrationHelpers),supportedSurfaceKeys:migrationHelperKeys,
    artifactFile:"experiments/tla-conformance/throughput-r7/evidence/migration-helper-values.json",reviewedCommit:null,
    reviewedSource:{kind:"REVIEWED_CONTENT_SNAPSHOT",receipt:"experiments/tla-conformance/migration-helper-causal-r7/import-source-receipt.json"}}),
  Object.freeze({proofKind:migrationHelperFrontierProofKind,buildFamilyArtifact:registeredBuilder(buildMigrationHelperFrontier),supportedSurfaceKeys:migrationHelperFrontierKeys,
    artifactFile:"experiments/tla-conformance/throughput-r7/evidence/migration-helper-frontier-values.json",reviewedCommit:"79f7e7575303a0b1c04b1634f717dda915b911a5"}),
  Object.freeze({proofKind:QUANTITY_VALUES_PROOF_KIND,buildFamilyArtifact:registeredBuilder(buildQuantity),supportedSurfaceKeys:quantityKeys,
    artifactFile:"experiments/tla-conformance/throughput-r7/evidence/quantity-values.json", reviewedCommit:"5d13503b7baceff5515e8d82b390f0949080440a"}),
  Object.freeze({proofKind:identityValuesProofKind,buildFamilyArtifact:registeredBuilder(buildIdentity),supportedSurfaceKeys:identityKeys,
    artifactFile:"experiments/tla-conformance/throughput-r7/evidence/identity-values.json",reviewedCommit:"02cf9387d669fd8655a71933849862cac8693cd9"}),
]);
