import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { canonicalJson, sha256 } from "../surface-bindings/lib/compiler-surface.mjs";

/** Cache only inside one compiler pass; every source byte is checked again before reuse. */
const passes = new WeakMap();
/** Parsed artifacts are content-addressed within a compiler pass; bytes and source inputs are still rechecked on every binding. */
const recordedPasses = new WeakMap();

/** Resolve one ordinary repository-owned file; artifacts cannot escape via paths or links. */
function ownedFile(root, file) {
  assert.equal(typeof file, "string");
  assert(file.length > 0 && !path.isAbsolute(file));
  const resolved = fs.realpathSync(path.resolve(root, file));
  assert(resolved.startsWith(`${fs.realpathSync(root)}${path.sep}`), "Family input leaves its repository.");
  return resolved;
}

/** Require every recorded semantic input to be current; hashes are provenance, not the proof itself. */
function verifyInputs(root, context, inputs) {
  assert(Array.isArray(inputs) && inputs.length > 0, "A family needs its complete semantic input set.");
  const seen = new Set();
  for (const input of inputs) {
    assert.equal(typeof input.file, "string");
    assert(!seen.has(input.file), "A family input is duplicated."); seen.add(input.file);
    assert.match(input.sha256, /^[0-9a-f]{64}$/u);
    const absolute = ownedFile(root, input.file);
    const bytes = fs.readFileSync(absolute);
    assert.equal(sha256(bytes), input.sha256, `Family input changed: ${input.file}`);
    if (input.file.startsWith("src/") && input.file.endsWith(".ts")) {
      const source = context.program.getSourceFile(path.resolve(root, input.file));
      assert(source !== undefined, `Compiler omitted source input: ${input.file}`);
      assert.equal(sha256(source.text), input.sha256, `Compiler snapshot is stale: ${input.file}`);
    }
  }
}

/** Review boundaries come from trusted source-code registrations, never certificate-provided executable paths. */
export function verifyRegisteredValueBinding({ repositoryRoot, context, surface, binding, registrations }) {
  try {
    assert.equal(binding.mode, "V");
    const file = ownedFile(repositoryRoot, binding.evidence.file);
    const bytes = fs.readFileSync(file);
    const digest = sha256(bytes);
    assert.equal(digest, binding.evidence.sha256, "Family evidence changed.");
    let recordedPass = recordedPasses.get(context);
    if (recordedPass === undefined) { recordedPass = new Map(); recordedPasses.set(context, recordedPass); }
    const recordedKey = `${file}:${digest}`;
    let parsed = recordedPass.get(recordedKey);
    if (parsed === undefined) {
      const document = JSON.parse(bytes.toString("utf8"));
      parsed = { document, canonical: canonicalJson(document) };
      recordedPass.set(recordedKey, parsed);
    }
    const recorded = parsed.document;
    const matching = registrations.filter((registration) => registration.proofKind === recorded.proofKind);
    assert.equal(matching.length, 1, "Exactly one reviewed family verifier must handle this proof kind.");
    const registration = matching[0];
    assert.equal(typeof registration.buildFamilyArtifact, "function");
    assert(Array.isArray(registration.supportedSurfaceKeys));
    assert.equal(new Set(registration.supportedSurfaceKeys).size, registration.supportedSurfaceKeys.length);
    assert(registration.supportedSurfaceKeys.includes(binding.surfaceKey), "Binding is outside the reviewed family.");
    let compilerPass = passes.get(context);
    if (compilerPass === undefined) { compilerPass = new Map(); passes.set(context, compilerPass); }
    let cached = compilerPass.get(registration);
    if (cached !== undefined && cached.surfaceDigest === surface.digest && cached.builder === registration.buildFamilyArtifact && cached.members === canonicalJson(registration.supportedSurfaceKeys)) {
      verifyInputs(repositoryRoot, context, cached.artifact.inputs);
    } else {
      const artifact = registration.buildFamilyArtifact({ repositoryRoot, context, surface });
      assert.equal(artifact.schemaVersion, 1);
      assert.equal(artifact.proofKind, registration.proofKind);
      assert.equal(artifact.sampledInputs, 0, "Sampled examples are not a complete source equation.");
      assert.equal(artifact.allAdmittedInputs, true);
      assert((typeof artifact.domain === "string" && artifact.domain.length > 0) ||
        (artifact.domain !== null && typeof artifact.domain === "object" && !Array.isArray(artifact.domain) && Object.keys(artifact.domain).length > 0), "A complete explicit domain is required.");
      assert.equal(artifact.surfaceDigest, surface.digest);
      assert(Array.isArray(artifact.proofs) && artifact.proofs.length > 0);
      verifyInputs(repositoryRoot, context, artifact.inputs);
      const proofKeys = artifact.proofs.map((proof) => proof.surfaceKey);
      assert.equal(new Set(proofKeys).size, proofKeys.length, "Family repeats a proof key.");
      assert(proofKeys.every((key) => registration.supportedSurfaceKeys.includes(key)));
      const live = new Map(surface.callables.map((callable) => [callable.key, callable]));
      for (const proof of artifact.proofs) {
        const callable = live.get(proof.surfaceKey);
        assert(callable !== undefined, "Family claims a non-public callable.");
        assert.equal(proof.signatureHash, callable.signatureHash);
        assert.deepEqual(proof.declaration, callable.declaration);
      }
      cached = { surfaceDigest: surface.digest, builder: registration.buildFamilyArtifact, members: canonicalJson(registration.supportedSurfaceKeys), artifact, canonical: canonicalJson(artifact) };
      compilerPass.set(registration, cached);
    }
    assert.equal(parsed.canonical, cached.canonical, "Recorded family differs from independently rederived current semantics.");
    assert(cached.artifact.proofs.some((proof) => proof.surfaceKey === binding.surfaceKey), "No complete source proof for this member.");
    return [];
  } catch (error) {
    return [{ code: "VALUE_FAMILY_PROOF_REJECTED", detail: error instanceof Error ? error.message : String(error) }];
  }
}
