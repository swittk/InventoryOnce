import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { sha256 } from "../surface-bindings/lib/compiler-surface.mjs";

const registryFile = "experiments/tla-conformance/throughput-r7/evidence/surface-bindings.json";
const reportFile = "experiments/tla-conformance/throughput-r7/evidence/admission-report.json";
const expectedCheckerSha256 = "4dd6bbf135ebb5a5da86b714e0d9b9d3550547a7df7b39aec1a471bf1ef3f88e";
let cache;

/** Compose already-admitted helper semantics without recursively replaying their proof families. */
export function strictDependencyReceipt({ repositoryRoot, surface, requirements, label = "strict dependency" }) {
  assert(Array.isArray(requirements) && requirements.length > 0);
  const registryBytes = fs.readFileSync(path.resolve(repositoryRoot, registryFile));
  const reportBytes = fs.readFileSync(path.resolve(repositoryRoot, reportFile));
  const identity = `${sha256(registryBytes)}:${sha256(reportBytes)}:${surface.digest}`;
  if (cache?.identity !== identity) {
    const registry = JSON.parse(registryBytes.toString("utf8"));
    const report = JSON.parse(reportBytes.toString("utf8"));
    assert.equal(registry.schemaVersion, 1);
    assert(Array.isArray(registry.bindings));
    assert.equal(registry.bindings.length, surface.callables.length);
    assert.equal(new Set(registry.bindings.map((row) => row.surfaceKey)).size, surface.callables.length);
    const liveKeys = new Set(surface.callables.map((row) => row.key));
    assert(registry.bindings.every((row) => liveKeys.has(row.surfaceKey)), "Strict dependency registry is not the current compiler surface.");
    const strict = registry.bindings.filter((row) => row.mode !== "HARD_RED").length;
    assert.equal(report.status, "CURRENT_STRICT_FAMILY_ADMISSION");
    assert.equal(report.strictGatePassed, true);
    assert.equal(report.claimedDiagnostics, 0);
    assert.equal(report.surfaceDigest, surface.digest);
    assert.equal(report.strictCallables, strict);
    assert.equal(report.strictCheckerSha256, expectedCheckerSha256);
    cache = { identity, byKey: new Map(registry.bindings.map((row) => [row.surfaceKey, row])), strictCallables: strict };
  }
  const seen = new Set();
  const dependencies = requirements.map((requirement) => {
    const normalized = typeof requirement === "string" ? { surfaceKey: requirement } : requirement;
    assert.equal(typeof normalized.surfaceKey, "string");
    assert(!seen.has(normalized.surfaceKey), `${label} repeats ${normalized.surfaceKey}`);
    seen.add(normalized.surfaceKey);
    const binding = cache.byKey.get(normalized.surfaceKey);
    assert(binding !== undefined, `${label} missing ${normalized.surfaceKey}`);
    assert.notEqual(binding.mode, "HARD_RED", `${label} remains red: ${normalized.surfaceKey}`);
    if (normalized.mode !== undefined) assert.equal(binding.mode, normalized.mode, `${label} mode changed: ${normalized.surfaceKey}`);
    return { surfaceKey: normalized.surfaceKey, mode: binding.mode };
  });
  return { kind: "COMPOSED_CURRENT_STRICT_REGISTRY", globalStrictCallables: cache.strictCallables, dependencies };
}
