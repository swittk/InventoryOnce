import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { canonicalJson, sha256 } from "../surface-bindings/lib/compiler-surface.mjs";
import { buildTransferCorrectionValueFamily } from "../transfer-surface-r6/source-equations-r7/family.mjs";

const DIRECTORY = "experiments/tla-conformance/traceability-apply1-r8";
const FAMILY_FILE = `${DIRECTORY}/family.mjs`;
export const proofKind = "traceability-apply-changes-complete-value-v1";
export const supportedSurfaceKeys = Object.freeze([
  "export:./kernel#applyInventoryTraceabilityChanges::call[0]",
]);
function rootDir(){ return path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../.."); }
function fileRef(root,file,sourceOverrides){ const override=sourceOverrides?.get(file); const bytes=override===undefined?fs.readFileSync(path.resolve(root,file)):Buffer.from(override); return {file,sha256:sha256(bytes)}; }
export function buildFamilyArtifact({repositoryRoot:root=rootDir(),context,surface,sourceOverrides=new Map()}={}){
  assert(context!==undefined&&surface!==undefined); assert.equal(surface.callables.length,535);
  const upstream=buildTransferCorrectionValueFamily({repositoryRoot:root,context,surface,sourceOverrides});
  assert.equal(upstream.proofKind,"inventoryonce-transfer-correction-complete-source-equations-v2"); assert.equal(upstream.allAdmittedInputs,true); assert.equal(upstream.sampledInputs,0);
  const rows=upstream.semanticCore.equations.filter(row=>row.id==="src/traceability.ts#applyInventoryTraceabilityChanges"); assert.equal(rows.length,1); const equation=rows[0];
  const callable=surface.callables.find(row=>row.key===supportedSurfaceKeys[0]); assert(callable!==undefined); assert.deepEqual(callable.declaration,equation.declaration,"Public traceability callable no longer equals the complete equation declaration.");
  const proof={surfaceKey:supportedSurfaceKeys[0],signatureHash:callable.signatureHash,declaration:callable.declaration,equationId:equation.id,lawId:equation.lawId,equationSha256:equation.equationSha256,completeSourceEquation:true};
  const inputs=[fileRef(root,FAMILY_FILE,sourceOverrides),...upstream.inputs].sort((a,b)=>a.file.localeCompare(b.file));
  return {schemaVersion:1,mode:"V",proofKind,family:"TraceabilityApplyChangesV1",surfaceDigest:surface.digest,domain:"Every typed ApplyInventoryTraceabilityChangesInput admitted by the complete deterministic source equation: add/remove/invalidate branches, relation identity, containment parent/cycle checks, genealogy cycle checks, and deterministic containment index rebuild. No finite fixture restriction.",allAdmittedInputs:true,sampledInputs:0,sourceCallableClosureComplete:true,inputs,upstream:{proofKind:upstream.proofKind,artifactSha256:sha256(canonicalJson(upstream))},proofs:[proof]};
}
