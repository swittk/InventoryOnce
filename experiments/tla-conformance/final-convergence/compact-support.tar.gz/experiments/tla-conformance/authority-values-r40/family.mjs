import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import {
  compareCodeUnits,
  nodeAtExactSpan,
  sha256,
  spanOf,
  ts,
} from "../surface-bindings/lib/compiler-surface.mjs";

export const proofKind = "authority-result-validators-r36-helper-closed-v3-v1";
export const supportedSurfaceKeys = Object.freeze([
  "export:.#inventoryAuthorityCutoverResult::call[0]",
  "export:.#inventoryAuthorityGreenfieldResult::call[0]",
  "export:.#requireInventoryAuthorityMode::call[0]",
]);
export const directory = "experiments/tla-conformance/authority-values-r40";
const expectedFile = `${directory}/equations.expected.ts.txt`;
const oldCanonicalFile = `${directory}/baseline-488/canonical-535.json`;
const oldReportFile = `${directory}/baseline-488/admission-report.json`;
const baseSurfaceDigest = "6a3bdd7dd66a3e352c1dca251d654406a5b25bef3c502c5392785384be5b93c1";
const baseStrict = 488;
const equationSpecs = Object.freeze([
  ["src/authority-cutover.ts", "inventoryAuthorityCutoverResult"],
  ["src/authority-cutover.ts", "inventoryAuthorityGreenfieldResult"],
  ["src/authority-cutover.ts", "assertAuthorityPortStateEnvelope"],
  ["src/authority-cutover.ts", "requireCanonicalCutoverTime"],
  ["src/authority-cutover.ts", "requireCutoverText"],
  ["src/authority-cutover.ts", "requireNonnegativeSafeInteger"],
  ["src/authority-cutover.ts", "requireRetainedCutoverText"],
  ["src/authority.ts", "requireInventoryAuthorityMode"],
]);
const localEdges = Object.freeze([
  "assertAuthorityPortStateEnvelope->requireNonnegativeSafeInteger",
  "assertAuthorityPortStateEnvelope->requireRetainedCutoverText",
  "inventoryAuthorityCutoverResult->assertAuthorityPortStateEnvelope",
  "inventoryAuthorityCutoverResult->requireCanonicalCutoverTime",
  "inventoryAuthorityCutoverResult->requireRetainedCutoverText",
  "inventoryAuthorityGreenfieldResult->assertAuthorityPortStateEnvelope",
  "inventoryAuthorityGreenfieldResult->requireCanonicalCutoverTime",
  "inventoryAuthorityGreenfieldResult->requireRetainedCutoverText",
  "requireCanonicalCutoverTime->requireCutoverText",
  "requireRetainedCutoverText->requireCutoverText",
].sort(compareCodeUnits));
const dependencySpecs = Object.freeze([
  Object.freeze({ surfaceKey: "export:./storage#emptyInventoryWorldState::call[0]", mode: "V" }),
  Object.freeze({ surfaceKey: "export:./storage#inventoryWorldContentRoots::call[0]", mode: "B" }),
]);
const baselineEvidenceSnapshots = Object.freeze({
  "experiments/tla-conformance/throughput-r7/evidence/residual-core-v4-values.json":
    `${directory}/baseline-488/evidence/residual-core-v4-values.json`,
  "experiments/tla-conformance/throughput-r7/evidence/physical-count-producer.json":
    `${directory}/baseline-488/evidence/physical-count-producer.json`,
});
const enumValues = Object.freeze({
  InventoryAuthorityMode: Object.freeze({ Legacy: "legacy", Shadow: "shadow", DualRun: "dual-run", Fencing: "fencing", Authoritative: "authoritative" }),
  InventoryAuthorityActivationKind: Object.freeze({ None: "none", LegacyCutover: "legacy-cutover", Greenfield: "greenfield" }),
  InventoryCompatibilityProjectionStatus: Object.freeze({ Current: "current", Lagging: "lagging", Failed: "failed" }),
});
const staticInputs = Object.freeze([
  "src/authority-cutover.ts",
  "src/authority.ts",
  "src/world.ts",
  "src/integrity.ts",
  expectedFile,
  `${directory}/family.mjs`,
  oldCanonicalFile,
  oldReportFile,
  "experiments/tla-conformance/surface-bindings/lib/compiler-surface.mjs",
  "experiments/tla-conformance/throughput-r7/registered-value-family.mjs",
  `${directory}/runtime-deps/typescript/package.json`,
  `${directory}/runtime-deps/typescript/lib/lib.es5.d.ts`,
  `${directory}/runtime-deps/typescript/lib/lib.es2015.core.d.ts`,
  "package.json",
  "tsconfig.json",
]);
const printer = ts.createPrinter({ removeComments: true, newLine: ts.NewLineKind.LineFeed });

function readText(root, file, overrides) {
  return overrides.get(file) ?? fs.readFileSync(path.resolve(root, file), "utf8");
}
function readBytes(root, file, overrides) {
  const value = overrides.get(file);
  return value === undefined ? fs.readFileSync(path.resolve(root, file)) : Buffer.from(value);
}
function parse(file, text) {
  return ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
}
function functions(source) {
  const out = new Map();
  for (const statement of source.statements) {
    if (ts.isFunctionDeclaration(statement) && statement.name && statement.body) {
      assert(!out.has(statement.name.text), `Duplicate function ${statement.name.text}`);
      out.set(statement.name.text, statement);
    }
  }
  return out;
}
function rendered(node, source) {
  return printer.printNode(ts.EmitHint.Unspecified, node, source).replaceAll(/\r\n/gu, "\n").trim();
}
function sourceFor(root, context, file, overrides) {
  if (overrides.has(file)) return parse(file, readText(root, file, overrides));
  const source = context.program.getSourceFile(path.resolve(root, file));
  assert(source && !source.isDeclarationFile, `Compiler omitted ${file}`);
  assert.equal(sha256(source.text), sha256(fs.readFileSync(path.resolve(root, file))), `Compiler snapshot stale ${file}`);
  return source;
}
function exactEquations(root, context, overrides) {
  const expected = functions(parse(expectedFile, readText(root, expectedFile, overrides)));
  const actualByFile = new Map();
  const receipts = [];
  for (const [file, name] of equationSpecs) {
    let source = actualByFile.get(file);
    if (source === undefined) { source = sourceFor(root, context, file, overrides); actualByFile.set(file, source); }
    const actual = functions(source).get(name);
    const law = expected.get(name);
    assert(actual && law, `Missing equation ${name}`);
    const current = rendered(actual, source);
    const frozen = rendered(law, law.getSourceFile());
    assert.equal(current, frozen, `Complete source equation drifted: ${name}`);
    receipts.push({ id: `${file}#${name}`, equationSha256: sha256(frozen), completeSource: frozen });
  }
  assert.equal(receipts.length, equationSpecs.length);
  return { receipts, actualByFile };
}
function helperGraph(actualByFile) {
  const selected = new Set(equationSpecs.map(([, name]) => name));
  const edges = [];
  for (const [file, name] of equationSpecs) {
    const source = actualByFile.get(file);
    const fn = functions(source).get(name);
    assert(fn?.body);
    const calls = new Set();
    function walk(node) {
      if (ts.isCallExpression(node) && ts.isIdentifier(node.expression) && selected.has(node.expression.text)) calls.add(node.expression.text);
      ts.forEachChild(node, walk);
    }
    walk(fn.body);
    for (const target of calls) edges.push(`${name}->${target}`);
  }
  edges.sort(compareCodeUnits);
  assert.deepEqual(edges, localEdges, "Authority result helper graph drifted");
  return edges;
}
function reachableHelperEdges(rootName, graph) {
  if (rootName === "requireInventoryAuthorityMode") return [];
  const outgoing = new Map();
  for (const edge of graph) {
    const [source, target] = edge.split("->");
    const rows = outgoing.get(source) ?? []; rows.push([edge, target]); outgoing.set(source, rows);
  }
  const seen = new Set([rootName]); const queue = [rootName]; const edges = new Set();
  for (let i=0;i<queue.length;i+=1) {
    for (const [edge,target] of outgoing.get(queue[i]) ?? []) {
      edges.add(edge); if (!seen.has(target)) { seen.add(target); queue.push(target); }
    }
  }
  return [...edges].sort(compareCodeUnits);
}
function enumReceipt(root, context, overrides) {
  const source = sourceFor(root, context, "src/authority.ts", overrides);
  const receipt = {};
  for (const [enumName, expectedMembers] of Object.entries(enumValues)) {
    const rows = source.statements.filter((row) => ts.isEnumDeclaration(row) && row.name.text === enumName);
    assert.equal(rows.length, 1, `Missing enum ${enumName}`);
    const declaration = rows[0];
    const values = {};
    for (const member of declaration.members) {
      assert(ts.isIdentifier(member.name) && member.initializer && ts.isStringLiteral(member.initializer), `Nonliteral ${enumName} member`);
      values[member.name.text] = member.initializer.text;
    }
    assert.deepEqual(values, expectedMembers, `Authority enum semantics drifted: ${enumName}`);
    receipt[enumName] = { values, declaration: spanOf(context, declaration) };
  }
  return receipt;
}
function dependencyCarryForward(root, surface, overrides) {
  const canonical = JSON.parse(readText(root, oldCanonicalFile, overrides));
  const report = JSON.parse(readText(root, oldReportFile, overrides));
  assert.equal(canonical.surfaceDigest, baseSurfaceDigest);
  assert.equal(report.surfaceDigest, baseSurfaceDigest);
  assert.equal(report.status, "CURRENT_STRICT_FAMILY_ADMISSION");
  assert.equal(report.strictGatePassed, true);
  assert.equal(report.claimedDiagnostics, 0);
  assert.equal(report.strictCallables, baseStrict);
  const strict = canonical.rows.filter((row) => row.binding?.mode !== "HARD_RED").length;
  assert.equal(strict, baseStrict);
  const oldByKey = new Map(canonical.rows.map((row) => [row.callable.key, row]));
  const liveByKey = new Map(surface.callables.map((row) => [row.key, row]));
  const dependencies = [];
  const evidenceFiles = [];
  for (const spec of dependencySpecs) {
    const old = oldByKey.get(spec.surfaceKey);
    const live = liveByKey.get(spec.surfaceKey);
    assert(old && live, `Dependency missing ${spec.surfaceKey}`);
    assert.equal(old.binding.mode, spec.mode, `Dependency mode drift ${spec.surfaceKey}`);
    assert.equal(live.signatureHash, old.callable.signatureHash, `Dependency signature drift ${spec.surfaceKey}`);
    assert.deepEqual(live.declaration, old.callable.declaration, `Dependency declaration drift ${spec.surfaceKey}`);
    const sourceBytes = readBytes(root, live.declaration.file, overrides);
    assert.equal(sha256(sourceBytes), live.declaration.sourceHash, `Dependency source drift ${spec.surfaceKey}`);
    assert(old.binding.evidence?.file && old.binding.evidence?.sha256, `Dependency evidence missing ${spec.surfaceKey}`);
    const snapshotFile = baselineEvidenceSnapshots[old.binding.evidence.file];
    assert(snapshotFile !== undefined, `Dependency baseline snapshot missing ${spec.surfaceKey}`);
    assert.equal(
      sha256(readBytes(root, snapshotFile, overrides)),
      old.binding.evidence.sha256,
      `Dependency baseline evidence bytes drift ${spec.surfaceKey}`
    );
    evidenceFiles.push(snapshotFile);
    dependencies.push({
      surfaceKey: spec.surfaceKey,
      mode: spec.mode,
      signatureHash: live.signatureHash,
      declaration: live.declaration,
      admittedEvidence: old.binding.evidence,
      baselineEvidenceSnapshot: { file: snapshotFile, sha256: old.binding.evidence.sha256 },
    });
  }
  return { receipt: { kind: "CURRENT488_STRICT_SOURCE_UNCHANGED_CARRY_FORWARD", baseSurfaceDigest, baseStrictCallables: baseStrict, candidateSurfaceDigest: surface.digest, dependencies }, evidenceFiles };
}
function packageDependencyCalls(context, surface) {
  const source = context.program.getSourceFile(path.resolve(context.repositoryRoot, "src/authority-cutover.ts"));
  assert(source);
  const green = functions(source).get("inventoryAuthorityGreenfieldResult");
  assert(green?.body);
  const expected = new Map(dependencySpecs.map((row) => [row.surfaceKey.split("#")[1].split("::")[0], row.surfaceKey]));
  const live = new Map(surface.callables.map((row) => [row.key, row]));
  const receipts = [];
  function walk(node) {
    if (ts.isCallExpression(node) && ts.isIdentifier(node.expression) && expected.has(node.expression.text)) {
      let symbol = context.checker.getSymbolAtLocation(node.expression);
      assert(symbol); if (symbol.flags & ts.SymbolFlags.Alias) symbol = context.checker.getAliasedSymbol(symbol);
      const declarations = symbol.declarations ?? [];
      assert.equal(declarations.length, 1, `Ambiguous dependency call ${node.expression.text}`);
      const target = live.get(expected.get(node.expression.text)); assert(target);
      assert.deepEqual(spanOf(context, declarations[0]), target.declaration, `Dependency call target drift ${node.expression.text}`);
      receipts.push({ call: node.expression.text, surfaceKey: target.key, targetDeclaration: target.declaration });
    }
    ts.forEachChild(node, walk);
  }
  walk(green.body);
  receipts.sort((a,b)=>compareCodeUnits(a.surfaceKey,b.surfaceKey));
  assert.deepEqual(receipts.map((x)=>x.surfaceKey), dependencySpecs.map((x)=>x.surfaceKey).sort(compareCodeUnits));
  return receipts;
}
function inputRefs(root, files, overrides) {
  return [...new Set(files)].sort(compareCodeUnits).map((file) => ({ file, sha256: sha256(readBytes(root, file, overrides)) }));
}
function assertRuntimeTypeScript(root, overrides) {
  const pairs = [
    ["node_modules/typescript/package.json", `${directory}/runtime-deps/typescript/package.json`],
    ["node_modules/typescript/lib/lib.es5.d.ts", `${directory}/runtime-deps/typescript/lib/lib.es5.d.ts`],
    ["node_modules/typescript/lib/lib.es2015.core.d.ts", `${directory}/runtime-deps/typescript/lib/lib.es2015.core.d.ts`],
  ];
  const receipts = [];
  for (const [runtimeFile, snapshotFile] of pairs) {
    const runtime = fs.readFileSync(path.resolve(root, runtimeFile));
    const snapshot = readBytes(root, snapshotFile, overrides);
    assert.equal(sha256(runtime), sha256(snapshot), `TypeScript runtime differs from reviewed snapshot: ${runtimeFile}`);
    receipts.push({ runtimeFile, snapshotFile, sha256: sha256(snapshot) });
  }
  return receipts;
}

export function buildFamilyArtifact({ repositoryRoot, context, surface, sourceOverrides = new Map() }) {
  const root = path.resolve(repositoryRoot);
  assert.equal(path.resolve(context.repositoryRoot), root);
  const runtimeTypeScript = assertRuntimeTypeScript(root, sourceOverrides);
  const equations = exactEquations(root, context, sourceOverrides);
  const graph = helperGraph(equations.actualByFile);
  const enums = enumReceipt(root, context, sourceOverrides);
  const dependency = dependencyCarryForward(root, surface, sourceOverrides);
  const calls = packageDependencyCalls(context, surface);
  const live = new Map(surface.callables.map((row) => [row.key, row]));
  const eqByName = new Map(equations.receipts.map((row) => [row.id.split("#")[1], row]));
  const proofs = supportedSurfaceKeys.map((surfaceKey) => {
    const callable = live.get(surfaceKey); assert(callable, `Missing public Authority value ${surfaceKey}`);
    const name = surfaceKey.split("#")[1].split("::")[0];
    return {
      surfaceKey,
      signatureHash: callable.signatureHash,
      declaration: callable.declaration,
      completeEquation: eqByName.get(name),
      helperClosure: reachableHelperEdges(name, graph),
      runtimeEnums: enums,
      strictDependencies: name === "inventoryAuthorityGreenfieldResult" ? dependency.receipt.dependencies : [],
    };
  });
  const files = [...staticInputs, ...dependency.evidenceFiles];
  return {
    schemaVersion: 1,
    proofKind,
    mode: "V",
    surfaceDigest: surface.digest,
    sourceBase: "63ce2175855315782abbedb48a2b532b42b57734",
    allAdmittedInputs: true,
    sampledInputs: 0,
    domain: {
      state: "All plain immutable InventoryAuthorityState-shaped records with native string/number/array values and no proxies/accessors/concurrent mutation during one synchronous validator call.",
      native: "Native ECMAScript Date, Number.isFinite, Number.isSafeInteger, String.trim, Error and ordinary property access as pinned by the installed TypeScript standard-library declarations.",
      dependencies: "Canonical empty Inventory world construction and world-content-root projection are carried from exact current488 strict rows only because their compiler signatures/declarations/source bytes and evidence bytes are unchanged on this candidate surface.",
    },
    equations: equations.receipts,
    helperGraph: graph,
    packageDependencyCalls: calls,
    dependencyCarryForward: dependency.receipt,
    runtimeEnums: enums,
    runtimeTypeScript,
    inputs: inputRefs(root, files, sourceOverrides),
    proofs,
  };
}
