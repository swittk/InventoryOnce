/** Stable proof kind routed by the hub as one reusable value-equation family. */
export const QUANTITY_VALUES_PROOF_KIND =
  "inventoryonce-quantity-measurement-complete-source-equations-v1";

/** Exact production modules whose runtime equations belong to this family. */
export const FAMILY_SOURCE_FILES = Object.freeze([
  "src/canonical.ts",
  "src/measurements.ts",
  "src/ordering.ts",
  "src/quantity.ts",
]);

/** Exact public quantity functions supported for both package entry points. */
export const QUANTITY_MEMBER_NAMES = Object.freeze([
  "addQuantity",
  "assertSameUnit",
  "compareQuantity",
  "convertQuantityByReferenceExact",
  "convertQuantityExact",
  "integerAtDecimals",
  "leastCommonQuantityMultiple",
  "multiplyQuantityByFactor",
  "multiplyQuantityByWholeNumber",
  "negateQuantity",
  "parseQuantity",
  "positiveQuantity",
  "quantity",
  "quantityEq",
  "quantityIsWholeMultipleOf",
  "quantityRatio",
  "quantityToDecimalString",
  "quantityWholeMultipleCount",
  "safeNumber",
  "subtractQuantity",
  "unitCode",
  "zeroQuantity",
]);

/** Exact public measurement functions supported for both package entry points. */
export const MEASUREMENT_MEMBER_NAMES = Object.freeze([
  "addInventoryMeasurements",
  "assertInventoryMeasurementsFollowPrimarySign",
  "assertWholeMeasurementMultiple",
  "inventoryMeasurement",
  "inventoryMeasurementAt",
  "inventoryMeasurementVector",
  "inventoryMeasurementsAreZero",
  "inventoryMeasurementsEqual",
  "inventoryMeasurementsFingerprint",
  "multiplyInventoryMeasurementsByWholeNumber",
  "negateInventoryMeasurements",
  "nonNegativeInventoryMeasurements",
  "positiveInventoryMeasurements",
  "scalarInventoryMeasurements",
  "subtractInventoryMeasurements",
  "zeroInventoryMeasurements",
]);

/** Exact source file owning each supported public equation. */
export const MEMBER_SOURCE_BY_NAME = Object.freeze(Object.fromEntries([
  ...QUANTITY_MEMBER_NAMES.map((name) => [name, "src/quantity.ts"]),
  ...MEASUREMENT_MEMBER_NAMES.map((name) => [name, "src/measurements.ts"]),
]));

/** Every non-member source function reachable from a supported equation. */
export const HELPER_SOURCE_BY_NAME = Object.freeze({
  abs: "src/quantity.ts",
  assertDecimals: "src/quantity.ts",
  assertFiniteInventoryIntentFingerprintNumbers: "src/canonical.ts",
  assertSafeInteger: "src/quantity.ts",
  assertSamePrimaryMeasurementAxis: "src/measurements.ts",
  compareInventoryIdentityText: "src/ordering.ts",
  compareMeasurementAxis: "src/measurements.ts",
  exactFractionQuantity: "src/quantity.ts",
  gcd: "src/quantity.ts",
  inventoryIntentFingerprint: "src/canonical.ts",
  measurementFingerprint: "src/measurements.ts",
  powerOfTen: "src/quantity.ts",
});

/** Exact callable alias set assigned by the throughput manifest. */
export const ASSIGNED_SURFACE_KEYS = Object.freeze(
  [".", "./kernel"].flatMap((entryPoint) =>
    [...QUANTITY_MEMBER_NAMES, ...MEASUREMENT_MEMBER_NAMES].map(
      (name) => `export:${entryPoint}#${name}::call[0]`,
    ),
  ).sort(),
);

/** Independently stated semantics for every supported quantity operation. */
const quantityLaws = {
  addQuantity: "Require equal units, align to the larger decimal scale, add exact bigint digits, require a safe stored integer, and return that scale/unit.",
  assertSameUnit: "Return normally exactly when the two unit codes are identical; otherwise throw the fixed unit-mismatch error.",
  compareQuantity: "Require equal units, align both exact integers to max scale, then return -1, 0, or 1 by mathematical ordering.",
  convertQuantityByReferenceExact: "Require the input/source unit match and both references positive; evaluate value * targetReference / sourceReference as a reduced finite decimal in the target unit.",
  convertQuantityExact: "Revalidate and reduce the positive ratio, then evaluate amount * numerator / denominator as a reduced finite decimal in the explicit target unit.",
  integerAtDecimals: "Validate the target scale, reject digit-removing scales, and multiply exact stored digits by ten to the scale difference.",
  leastCommonQuantityMultiple: "Require same-unit positive operands, align scale, and return (left / gcd(left,right)) * right with safe exact storage.",
  multiplyQuantityByFactor: "Require a positive factor, add operand scales within the allowed bound, multiply exact bigint digits, and use the factor unit.",
  multiplyQuantityByWholeNumber: "Require a safe integer multiplier and multiply exact digits through bigint without changing unit or scale.",
  negateQuantity: "Return the validated exact additive inverse with unchanged scale and unit.",
  parseQuantity: "Trim primitive text, accept only signed plain decimal notation, enforce at most 18 fractional digits, convert concatenated digits exactly, and validate unit/storage.",
  positiveQuantity: "Return the same validated quantity identity only when stored digits are strictly positive; otherwise throw the label-specific error.",
  quantity: "Require safe integer digits, an integer decimal scale from 0 through 18, and a trimmed non-empty unit; return a fresh exact record.",
  quantityEq: "Return false for unequal units; otherwise compare exact aligned numeric values for equality.",
  quantityIsWholeMultipleOf: "Require same unit and positive divisor, align scale, and test exact bigint remainder for zero.",
  quantityRatio: "Require positive safe integer numerator/denominator, divide both by their bigint gcd, and return safe reduced integers.",
  quantityToDecimalString: "Render sign and absolute safe digits in plain decimal notation, left-padding fractional zeroes and never using exponent notation.",
  quantityWholeMultipleCount: "Require same unit, positive divisor, non-negative value, and zero exact remainder; return the safe integer quotient.",
  safeNumber: "Convert bigint to number and accept it exactly when Number.isSafeInteger; otherwise throw the label-specific storage-range error.",
  subtractQuantity: "Require equal units, align to the larger decimal scale, subtract exact bigint digits, require safe storage, and retain scale/unit.",
  unitCode: "Trim primitive unit text, reject the empty result, and return the normalized unit code.",
  zeroQuantity: "Construct exact zero in the explicit unit and requested validated decimal scale.",
};

/** Independently stated semantics for every supported measurement operation. */
const measurementLaws = {
  addInventoryMeasurements: "Require equal primary axis/unit, add primary exactly, merge independent axes by identity with exact same-unit addition, then validate and sort the resulting vector.",
  assertInventoryMeasurementsFollowPrimarySign: "Compare primary and each independent axis to exact same-scale zero; reject nonzero axes at zero primary and signs opposed to primary.",
  assertWholeMeasurementMultiple: "Require equal primary schema and a whole positive primary multiple; every axis declared by oneWhole must equal that same exact package-count multiple, with absent value axes read as zero.",
  inventoryMeasurement: "Reject an axis whose primitive text trims empty and otherwise retain the exact axis text and quantity in a fresh pair.",
  inventoryMeasurementAt: "Return a matching primary/independent quantity only in the requested unit, throw on unit mismatch, and return exact zero when an independent axis is absent.",
  inventoryMeasurementVector: "Revalidate the primary and every independent pair, reject reuse of the primary axis, sort by UTF-16 identity order, reject duplicates, and return a fresh normalized vector.",
  inventoryMeasurementsAreZero: "Return true exactly when primary and every independent quantity equal exact same-unit/same-scale zero.",
  inventoryMeasurementsEqual: "Require identical primary axis/value, equal ordered independent lengths, and identical axis/value at every normalized index.",
  inventoryMeasurementsFingerprint: "Encode primary and ordered independent axis fingerprints as one finite collision-free JSON array after recursively rejecting undefined/non-finite numbers.",
  multiplyInventoryMeasurementsByWholeNumber: "Require a strictly positive safe integer multiplier, multiply every exact axis, and normalize the returned vector.",
  negateInventoryMeasurements: "Negate every exact axis and normalize the returned vector without changing axis/unit/scale identities.",
  nonNegativeInventoryMeasurements: "Reject any negative axis and reject retained independent quantity when primary is zero; otherwise return the same vector identity.",
  positiveInventoryMeasurements: "Require strictly positive primary and every independent axis non-negative; otherwise throw the axis-specific error and return the same vector on success.",
  scalarInventoryMeasurements: "Build one validated primary measurement and normalize it with no independent axes.",
  subtractInventoryMeasurements: "Negate the right vector and add through the complete same-schema vector equation.",
  zeroInventoryMeasurements: "Construct exact zero for every axis using each input axis unit and decimal scale, then normalize the returned vector.",
};

/** Human-readable independent law attached to every supported public member. */
export const MEMBER_LAW_BY_NAME = Object.freeze({
  ...quantityLaws,
  ...measurementLaws,
});

/** Independently stated semantics for every transitive source helper. */
export const HELPER_LAW_BY_NAME = Object.freeze({
  abs: "Return bigint magnitude by negating exactly when the input is negative.",
  assertDecimals: "Accept exactly safe integer scales from 0 through the fixed maximum 18 and reject every other number.",
  assertFiniteInventoryIntentFingerprintNumbers: "Depth-first validate every finite acyclic array element, rejecting undefined and non-finite numbers before JSON encoding.",
  assertSafeInteger: "Accept exactly Number.isSafeInteger inputs and otherwise throw the supplied label error.",
  assertSamePrimaryMeasurementAxis: "Accept exactly matching primary axis identities and units; reject the first mismatch with its declared error.",
  compareInventoryIdentityText: "Return -1, 0, or 1 by locale-independent primitive UTF-16 relational order.",
  compareMeasurementAxis: "Order measurements by their axis identities using the certified UTF-16 comparator.",
  exactFractionQuantity: "Require a positive denominator, reduce by gcd, remove factors two and five, reject any residual denominator, scale to a finite decimal no longer than 18 places, and validate exact storage/unit.",
  gcd: "Run Euclid over bigint magnitudes and return one for the zero/zero case used by exact rational normalization.",
  inventoryIntentFingerprint: "Recursively reject undefined/non-finite numeric values and return JSON.stringify of the finite acyclic typed array.",
  measurementFingerprint: "Fingerprint the exact ordered tuple axisId, amountMinor, decimals, unit.",
  powerOfTen: "Validate the non-negative scale through 18 and return exact bigint ten to that power.",
});

/** Exact source imports whose compiler resolution is part of measurement semantics. */
export const EXPECTED_RUNTIME_IMPORTS = Object.freeze({
  "src/canonical.ts": Object.freeze([
    Object.freeze({ module: "./model.js", imported: "InventoryMetadata", local: "InventoryMetadata", typeOnly: true }),
    Object.freeze({ module: "./model.js", imported: "InventoryMetadataValue", local: "InventoryMetadataValue", typeOnly: true }),
  ]),
  "src/measurements.ts": Object.freeze([
    Object.freeze({ module: "./canonical.js", imported: "inventoryIntentFingerprint", local: "inventoryIntentFingerprint", typeOnly: false }),
    Object.freeze({ module: "./ordering.js", imported: "compareInventoryIdentityText", local: "compareInventoryIdentityText", typeOnly: false }),
    ...Object.freeze([
      "addQuantity",
      "compareQuantity",
      "integerAtDecimals",
      "multiplyQuantityByWholeNumber",
      "negateQuantity",
      "positiveQuantity",
      "quantity",
      "quantityEq",
      "quantityIsWholeMultipleOf",
      "safeNumber",
      "subtractQuantity",
      "zeroQuantity",
    ]).map((name) => Object.freeze({ module: "./quantity.js", imported: name, local: name, typeOnly: false })),
    Object.freeze({ module: "./quantity.js", imported: "Quantity", local: "Quantity", typeOnly: true }),
    Object.freeze({ module: "./quantity.js", imported: "UnitCode", local: "UnitCode", typeOnly: true }),
  ]),
  "src/ordering.ts": Object.freeze([]),
  "src/quantity.ts": Object.freeze([]),
});

/** Only this independently specified top-level runtime value may exist in family sources. */
export const EXPECTED_TOP_LEVEL_RUNTIME_VALUES = Object.freeze({
  "src/canonical.ts": Object.freeze([]),
  "src/measurements.ts": Object.freeze([]),
  "src/ordering.ts": Object.freeze([]),
  "src/quantity.ts": Object.freeze(["MAXIMUM_QUANTITY_DECIMALS"]),
});

/** Exact standard global roots permitted by the independent equations. */
export const ALLOWED_STANDARD_RUNTIME_GLOBALS = Object.freeze(new Set([
  "Array",
  "BigInt",
  "Error",
  "JSON",
  "Map",
  "Math",
  "Number",
  "String",
  "undefined",
]));

/** Built-ins admitted only with these exact TypeScript standard-library declarations. */
export const ALLOWED_BUILTIN_DECLARATIONS = Object.freeze(new Set([
  "lib.es2015.collection.d.ts#get#MethodSignature",
  "lib.es2015.collection.d.ts#set#MethodSignature",
  "lib.es2015.core.d.ts#isFinite#MethodSignature",
  "lib.es2015.core.d.ts#isSafeInteger#MethodSignature",
  "lib.es2015.iterable.d.ts#<anonymous>#ConstructSignature",
  "lib.es2017.string.d.ts#padStart#MethodSignature",
  "lib.es2020.bigint.d.ts#<anonymous>#CallSignature",
  "lib.es2022.error.d.ts#<anonymous>#ConstructSignature",
  "lib.es5.d.ts#<anonymous>#CallSignature",
  "lib.es5.d.ts#abs#MethodSignature",
  "lib.es5.d.ts#exec#MethodSignature",
  "lib.es5.d.ts#isArray#MethodSignature",
  "lib.es5.d.ts#map#MethodSignature",
  "lib.es5.d.ts#max#MethodSignature",
  "lib.es5.d.ts#push#MethodSignature",
  "lib.es5.d.ts#slice#MethodSignature",
  "lib.es5.d.ts#sort#MethodSignature",
  "lib.es5.d.ts#stringify#MethodSignature",
  "lib.es5.d.ts#trim#MethodSignature",
]));

/** Explicit all-input domain; the certificate never generalizes from fixtures. */
export const FAMILY_DOMAIN = Object.freeze({
  id: "ALL_DECLARED_EXACT_QUANTITY_AND_NORMALIZED_MEASUREMENT_VALUES_V1",
  quantityConstructors: "All primitive string/number/bigint inputs described by UnitCode, QuantityInput, ratio, decimal parsing, scaling, and safe-number signatures, including every invalid-input rejection branch.",
  quantityAlgebra: "All values returned by the certified quantity constructors and all QuantityRatio values returned by quantityRatio; exact operations include negative/zero/positive values wherever their declarations allow them.",
  measurementConstructors: "All primitive axis strings, certified Quantity values, finite plain readonly arrays, and InventoryIndependentMeasurementInput records described by the declarations, including every duplicate/axis/unit/sign rejection branch.",
  measurementAlgebra: "All normalized InventoryMeasurementVector values returned by inventoryMeasurementVector/scalarInventoryMeasurements and finite schemas described by their declarations.",
  builtIns: "Unmodified ECMAScript String, RegExp, Array, Map, Object-free record construction, JSON, Math, Number, BigInt, and Error behavior at the exact compiler-resolved TypeScript library declarations recorded by the certificate.",
  immutability: "Inputs are finite acyclic plain immutable records/arrays containing primitive fields and certified quantity/vector values; fresh local arrays/maps may be mutated only while constructing results.",
  excluded: "Proxies, accessors, subclass instances, cyclic arrays, monkey-patched built-ins, coercive custom objects, ambient replacements, and externally mutable inputs are not admitted. Storage, clocks, I/O, randomness, and application callbacks are absent from this family.",
});
