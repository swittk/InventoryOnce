import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  canonicalJson,
  compareCodeUnits,
  sha256,
  spanOf,
  ts,
} from "../surface-bindings/lib/compiler-surface.mjs";
import {
  ALLOWED_BUILTIN_DECLARATIONS,
  ALLOWED_STANDARD_RUNTIME_GLOBALS,
  ASSIGNED_SURFACE_KEYS,
  EXPECTED_RUNTIME_IMPORTS,
  EXPECTED_TOP_LEVEL_RUNTIME_VALUES,
  FAMILY_SOURCE_FILES,
  FAMILY_DOMAIN,
  HELPER_LAW_BY_NAME,
  HELPER_SOURCE_BY_NAME,
  MEASUREMENT_MEMBER_NAMES,
  MEMBER_LAW_BY_NAME,
  MEMBER_SOURCE_BY_NAME,
  QUANTITY_MEMBER_NAMES,
  QUANTITY_VALUES_PROOF_KIND,
} from "./contracts.mjs";

/** Independently authored source equations parsed without production symbol resolution. */
const expectedEquationPath = fileURLToPath(
  new URL("./equations.expected.ts.txt", import.meta.url),
);

/** Source/specification/checker inputs that define this semantic producer. */
const producerFiles = Object.freeze([
  "experiments/tla-conformance/quantity-values-r7/certificate.mjs",
  "experiments/tla-conformance/quantity-values-r7/contracts.mjs",
  "experiments/tla-conformance/quantity-values-r7/equations.expected.ts.txt",
  "experiments/tla-conformance/surface-bindings/lib/compiler-surface.mjs",
  "node_modules/typescript/package.json",
]);

/** One complete family derivation may be reused inside one immutable compiler pass. */
const familyPassCache = new WeakMap();

/** Convert one path to the repository-relative code-unit identity used by artifacts. */
function relativePath(repositoryRoot, fileName) {
  return path.relative(repositoryRoot, fileName).replaceAll("\\", "/");
}

/** Parse specification or mutation text as a complete TypeScript source file. */
function parseSource(fileName, sourceText) {
  return ts.createSourceFile(
    fileName,
    sourceText,
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TS,
  );
}

/** Return one concrete ordinary function by exact source name. */
function findFunction(source, functionName) {
  const matches = source.statements.filter(
    (statement) =>
      ts.isFunctionDeclaration(statement) &&
      statement.name?.text === functionName &&
      statement.body !== undefined,
  );
  assert.equal(matches.length, 1, `Expected one concrete function '${functionName}'.`);
  return matches[0];
}

/** Return one exact top-level variable declaration by source name. */
function findVariable(source, variableName) {
  const matches = [];
  for (const statement of source.statements) {
    if (!ts.isVariableStatement(statement)) continue;
    for (const declaration of statement.declarationList.declarations) {
      if (ts.isIdentifier(declaration.name) && declaration.name.text === variableName) {
        matches.push({ statement, declaration });
      }
    }
  }
  assert.equal(matches.length, 1, `Expected one variable '${variableName}'.`);
  return matches[0];
}

/** Remove formatting while retaining every declared static type identity. */
function normalizedType(typeNode) {
  return typeNode === undefined ? null : typeNode.getText().replaceAll(/\s+/gu, "");
}

/** Return the stable spelling of one TypeScript operator token. */
function operatorText(kind) {
  return ts.tokenToString(kind) ?? ts.SyntaxKind[kind];
}

/** Normalize a complete callable into a name-insensitive, branch-complete source equation. */
export function normalizeQuantityValueCallable(declaration) {
  assert(declaration.body !== undefined, "A source equation requires one concrete body.");
  assert.equal(declaration.asteriskToken, undefined, "Generator equations are outside this family.");
  assert.equal(
    declaration.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword) ?? false,
    false,
    "Async equations are outside this family.",
  );
  assert(
    !ts.canHaveDecorators(declaration) || (ts.getDecorators(declaration)?.length ?? 0) === 0,
    "Decorated equations are outside this family.",
  );
  const counters = { local: 0, lambda: 0 };
  const environment = new Map();

  /** Allocate one deterministic identity for a source binding pattern. */
  function bindPattern(pattern, scopedEnvironment, prefix) {
    if (ts.isIdentifier(pattern)) {
      const identity = `${prefix}:${counters.local}`;
      counters.local += 1;
      scopedEnvironment.set(pattern.text, identity);
      return ["binding", identity];
    }
    if (ts.isArrayBindingPattern(pattern)) {
      return [
        "array-binding",
        pattern.elements.map((element) => {
          if (ts.isOmittedExpression(element)) return ["omitted"];
          assert(ts.isBindingElement(element), "Unexpected array binding element.");
          assert.equal(element.dotDotDotToken, undefined, "Rest bindings require another equation family.");
          assert.equal(element.propertyName, undefined, "Renamed array bindings are not admitted.");
          assert.equal(element.initializer, undefined, "Defaulted array bindings are not admitted.");
          return bindPattern(element.name, scopedEnvironment, prefix);
        }),
      ];
    }
    throw new Error(`Unsupported binding pattern '${pattern.getText()}'.`);
  }

  for (const [index, parameter] of declaration.parameters.entries()) {
    assert(ts.isIdentifier(parameter.name), "Parameters must use simple identifiers.");
    environment.set(parameter.name.text, `parameter:${index}`);
  }

  /** Normalize an explicit object-literal property name. */
  function propertyName(name) {
    if (ts.isIdentifier(name) || ts.isStringLiteral(name) || ts.isNumericLiteral(name)) {
      return name.text;
    }
    throw new Error(`Computed property '${name.getText()}' is outside this family.`);
  }

  /** Normalize every expression kind admitted by the independent equations. */
  function expression(node, scopedEnvironment = environment) {
    if (ts.isParenthesizedExpression(node)) return expression(node.expression, scopedEnvironment);
    if (ts.isAsExpression(node) || ts.isTypeAssertionExpression(node)) {
      return ["typed-cast", normalizedType(node.type), expression(node.expression, scopedEnvironment)];
    }
    if (ts.isNonNullExpression(node)) {
      return ["non-null", expression(node.expression, scopedEnvironment)];
    }
    if (ts.isIdentifier(node)) {
      return ["reference", scopedEnvironment.get(node.text) ?? `source:${node.text}`];
    }
    if (ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) {
      return ["string", node.text];
    }
    if (ts.isNumericLiteral(node)) return ["number", node.text];
    if (ts.isBigIntLiteral(node)) return ["bigint", node.text];
    if (ts.isRegularExpressionLiteral(node)) return ["regexp", node.text];
    if (node.kind === ts.SyntaxKind.TrueKeyword) return ["boolean", true];
    if (node.kind === ts.SyntaxKind.FalseKeyword) return ["boolean", false];
    if (node.kind === ts.SyntaxKind.NullKeyword) return ["null"];
    if (ts.isPropertyAccessExpression(node)) {
      return [
        "property",
        expression(node.expression, scopedEnvironment),
        node.name.text,
        node.questionDotToken === undefined ? "required" : "optional",
      ];
    }
    if (ts.isElementAccessExpression(node)) {
      assert(node.argumentExpression !== undefined, "Element access requires an index.");
      return [
        "element",
        expression(node.expression, scopedEnvironment),
        expression(node.argumentExpression, scopedEnvironment),
        node.questionDotToken === undefined ? "required" : "optional",
      ];
    }
    if (ts.isCallExpression(node)) {
      return [
        "call",
        expression(node.expression, scopedEnvironment),
        node.typeArguments?.map(normalizedType) ?? [],
        node.arguments.map((argument) => expression(argument, scopedEnvironment)),
        node.questionDotToken === undefined ? "required" : "optional",
      ];
    }
    if (ts.isNewExpression(node)) {
      return [
        "new",
        expression(node.expression, scopedEnvironment),
        node.typeArguments?.map(normalizedType) ?? [],
        (node.arguments ?? []).map((argument) => expression(argument, scopedEnvironment)),
      ];
    }
    if (ts.isBinaryExpression(node)) {
      return [
        "binary",
        operatorText(node.operatorToken.kind),
        expression(node.left, scopedEnvironment),
        expression(node.right, scopedEnvironment),
      ];
    }
    if (ts.isConditionalExpression(node)) {
      return [
        "conditional",
        expression(node.condition, scopedEnvironment),
        expression(node.whenTrue, scopedEnvironment),
        expression(node.whenFalse, scopedEnvironment),
      ];
    }
    if (ts.isPrefixUnaryExpression(node)) {
      return ["prefix", operatorText(node.operator), expression(node.operand, scopedEnvironment)];
    }
    if (ts.isPostfixUnaryExpression(node)) {
      return ["postfix", operatorText(node.operator), expression(node.operand, scopedEnvironment)];
    }
    if (ts.isTypeOfExpression(node)) {
      return ["typeof", expression(node.expression, scopedEnvironment)];
    }
    if (ts.isArrayLiteralExpression(node)) {
      return [
        "array",
        node.elements.map((element) =>
          ts.isOmittedExpression(element)
            ? ["omitted"]
            : expression(element, scopedEnvironment)),
      ];
    }
    if (ts.isObjectLiteralExpression(node)) {
      return [
        "record",
        node.properties.map((property) => {
          if (ts.isPropertyAssignment(property)) {
            return ["field", propertyName(property.name), expression(property.initializer, scopedEnvironment)];
          }
          if (ts.isShorthandPropertyAssignment(property)) {
            return ["field", property.name.text, expression(property.name, scopedEnvironment)];
          }
          if (ts.isSpreadAssignment(property)) {
            return ["spread", expression(property.expression, scopedEnvironment)];
          }
          throw new Error(`Object member '${property.getText()}' is outside this family.`);
        }),
      ];
    }
    if (ts.isTemplateExpression(node)) {
      return [
        "template",
        node.head.text,
        node.templateSpans.map((span) => [
          expression(span.expression, scopedEnvironment),
          span.literal.text,
        ]),
      ];
    }
    if (ts.isArrowFunction(node)) {
      assert.equal(node.asteriskToken, undefined, "Generator callbacks are not admitted.");
      assert.equal(
        node.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword) ?? false,
        false,
        "Async callbacks require a separate semantic equation.",
      );
      const childEnvironment = new Map(scopedEnvironment);
      const lambdaId = counters.lambda;
      counters.lambda += 1;
      for (const [index, parameter] of node.parameters.entries()) {
        assert(ts.isIdentifier(parameter.name), "Callback parameters must use simple identifiers.");
        assert.equal(parameter.dotDotDotToken, undefined, "Rest callbacks require a separate semantic equation.");
        assert.equal(parameter.initializer, undefined, "Defaulted callbacks require a separate semantic equation.");
        childEnvironment.set(parameter.name.text, `lambda:${lambdaId}:${index}`);
      }
      return [
        "lambda",
        { async: false, closure: "lexical", parameters: node.parameters.map((parameter, index) => ({
          identity: `lambda:${lambdaId}:${index}`,
          type: normalizedType(parameter.type),
          optional: parameter.questionToken !== undefined,
          rest: false,
          default: null,
        })) },
        ts.isBlock(node.body)
          ? statement(node.body, childEnvironment)
          : expression(node.body, childEnvironment),
      ];
    }
    throw new Error(
      `Unproved expression '${ts.SyntaxKind[node.kind]}': ${node.getText()}`,
    );
  }

  /** Normalize one declaration list, preserving mutability, types, defaults, and order. */
  function declarationList(list, scopedEnvironment) {
    const declarationKind = (list.flags & ts.NodeFlags.Const) !== 0
      ? "const"
      : (list.flags & ts.NodeFlags.Let) !== 0
        ? "let"
        : "var";
    const declarations = [];
    for (const declaration of list.declarations) {
      const initializer = declaration.initializer === undefined
        ? ["undefined"]
        : expression(declaration.initializer, scopedEnvironment);
      const pattern = bindPattern(declaration.name, scopedEnvironment, "local");
      declarations.push([pattern, normalizedType(declaration.type), initializer]);
    }
    return ["declarations", declarationKind, declarations];
  }

  /** Normalize a branch while treating one-statement braces as semantically explicit sequences. */
  function branch(node, scopedEnvironment) {
    return ts.isBlock(node)
      ? ["sequence", statements(node.statements, new Map(scopedEnvironment))]
      : statement(node, new Map(scopedEnvironment));
  }

  /** Normalize a complete ordered statement sequence. */
  function statements(sourceStatements, scopedEnvironment) {
    return sourceStatements.map((sourceStatement) => statement(sourceStatement, scopedEnvironment));
  }

  /** Normalize every statement/control-flow form admitted by the equations. */
  function statement(node, scopedEnvironment = environment) {
    if (ts.isBlock(node)) {
      return ["sequence", statements(node.statements, new Map(scopedEnvironment))];
    }
    if (ts.isVariableStatement(node)) {
      return declarationList(node.declarationList, scopedEnvironment);
    }
    if (ts.isIfStatement(node)) {
      return [
        "if",
        expression(node.expression, scopedEnvironment),
        branch(node.thenStatement, scopedEnvironment),
        node.elseStatement === undefined
          ? ["no-else"]
          : branch(node.elseStatement, scopedEnvironment),
      ];
    }
    if (ts.isReturnStatement(node)) {
      return ["return", node.expression === undefined ? ["undefined"] : expression(node.expression, scopedEnvironment)];
    }
    if (ts.isThrowStatement(node)) return ["throw", expression(node.expression, scopedEnvironment)];
    if (ts.isExpressionStatement(node)) return ["expression", expression(node.expression, scopedEnvironment)];
    if (ts.isForOfStatement(node)) {
      assert(ts.isVariableDeclarationList(node.initializer), "For-of requires a declared iterator.");
      const iterable = expression(node.expression, scopedEnvironment);
      const childEnvironment = new Map(scopedEnvironment);
      const binding = declarationList(node.initializer, childEnvironment);
      return ["for-of", binding, iterable, branch(node.statement, childEnvironment)];
    }
    if (ts.isForStatement(node)) {
      const childEnvironment = new Map(scopedEnvironment);
      const initializer = node.initializer === undefined
        ? ["none"]
        : ts.isVariableDeclarationList(node.initializer)
          ? declarationList(node.initializer, childEnvironment)
          : expression(node.initializer, childEnvironment);
      return [
        "for",
        initializer,
        node.condition === undefined ? ["none"] : expression(node.condition, childEnvironment),
        node.incrementor === undefined ? ["none"] : expression(node.incrementor, childEnvironment),
        branch(node.statement, childEnvironment),
      ];
    }
    if (ts.isWhileStatement(node)) {
      return ["while", expression(node.expression, scopedEnvironment), branch(node.statement, scopedEnvironment)];
    }
    if (ts.isContinueStatement(node)) {
      assert.equal(node.label, undefined, "Labeled continue is outside this family.");
      return ["continue"];
    }
    throw new Error(
      `Unproved statement '${ts.SyntaxKind[node.kind]}': ${node.getText()}`,
    );
  }

  return {
    parameters: declaration.parameters.map((parameter, index) => ({
      identity: `parameter:${index}`,
      type: normalizedType(parameter.type),
      optional: parameter.questionToken !== undefined,
      rest: parameter.dotDotDotToken !== undefined,
      default: parameter.initializer === undefined
        ? null
        : expression(parameter.initializer, environment),
    })),
    returnType: normalizedType(declaration.type),
    body: ["sequence", statements(declaration.body.statements, environment)],
  };
}

/** Normalize all named imports so changed module resolution cannot hide behind unchanged helper names. */
function normalizedRuntimeImports(source) {
  const imports = [];
  for (const statement of source.statements) {
    if (!ts.isImportDeclaration(statement) || !ts.isStringLiteral(statement.moduleSpecifier)) continue;
    const clause = statement.importClause;
    if (clause === undefined) continue;
    assert.equal(clause.name, undefined, "Default imports are outside this family.");
    assert(clause.namedBindings === undefined || ts.isNamedImports(clause.namedBindings), "Namespace imports are outside this family.");
    for (const specifier of clause.namedBindings?.elements ?? []) {
      imports.push({
        module: statement.moduleSpecifier.text,
        imported: specifier.propertyName?.text ?? specifier.name.text,
        local: specifier.name.text,
        typeOnly: clause.isTypeOnly || specifier.isTypeOnly,
      });
    }
  }
  return imports.sort((left, right) =>
    compareCodeUnits(canonicalJson(left), canonicalJson(right)));
}

/** Return the exact repository source identity for one concrete source function. */
function declarationKey(repositoryRoot, declaration) {
  assert(declaration.name !== undefined, "Certified functions require names.");
  return `${relativePath(repositoryRoot, declaration.getSourceFile().fileName)}#${declaration.name.text}`;
}

/** Return one exact TypeScript library identity for a resolved built-in declaration. */
function builtinDeclarationKey(declaration) {
  const file = path.basename(declaration.getSourceFile().fileName);
  const name = declaration.name?.getText(declaration.getSourceFile()) ?? "<anonymous>";
  return `${file}#${name}#${ts.SyntaxKind[declaration.kind]}`;
}

/** Return whether one declaration is lexically contained by the certified callable. */
function declarationIsInsideCallable(sourceDeclaration, callable) {
  let current = sourceDeclaration;
  while (current !== undefined) {
    if (current === callable) return true;
    current = current.parent;
  }
  return false;
}

/** Return a bounded source location for diagnostics without formatting compiler node graphs. */
function boundedDeclarationLocation(repositoryRoot, declaration) {
  const source = declaration.getSourceFile();
  const start = source.getLineAndCharacterOfPosition(declaration.getStart(source));
  return `${relativePath(repositoryRoot, source.fileName)}:${start.line + 1}:${start.character + 1}`;
}

/** Verify exact helper/free-variable resolution and collect every standard built-in call identity. */
function verifyDependencyClosure({ repositoryRoot, context, certified, quantityMaximum, declarations }) {
  const builtins = new Map();
  const runtimeGlobals = new Map();
  const dependencyNamesByKey = new Map();
  const trustedLibraryRoot = fs.realpathSync(
    path.dirname(ts.getDefaultLibFilePath(context.program.getCompilerOptions())),
  );

  /** Require one declaration to come from the active compiler's actual standard-library root. */
  function trustedLibraryFile(declaration) {
    assert.equal(declaration.getSourceFile().isDeclarationFile, true, "Runtime library declaration must be ambient.");
    const targetLibraryFile = fs.realpathSync(declaration.getSourceFile().fileName);
    assert(
      targetLibraryFile.startsWith(`${trustedLibraryRoot}${path.sep}`),
      `Runtime declaration is outside trusted TypeScript library: ${targetLibraryFile}`,
    );
    return targetLibraryFile;
  }

  for (const [key, declaration] of declarations) {
    const dependencyNames = new Set();

    /** Resolve aliases before judging whether a name still means the certified helper. */
    function resolvedSymbol(node) {
      let symbol = context.checker.getSymbolAtLocation(node);
      if (symbol !== undefined && (symbol.flags & ts.SymbolFlags.Alias) !== 0) {
        symbol = context.checker.getAliasedSymbol(symbol);
      }
      return symbol;
    }

    /** Record one built-in call only when it resolves to the explicit standard-library allowlist. */
    function inspectCall(node) {
      const target = context.checker.getResolvedSignature(node)?.declaration;
      assert(target !== undefined, `Unresolved call '${node.getText()}'.`);
      if (target.getSourceFile().isDeclarationFile) {
        trustedLibraryFile(target);
        const builtinKey = builtinDeclarationKey(target);
        assert(ALLOWED_BUILTIN_DECLARATIONS.has(builtinKey), `Unproved built-in '${builtinKey}'.`);
        const declarationSpan = spanOf(context, target);
        // Different standard constructors/overloads may share an anonymous signature name.
        const evidenceKey = `${builtinKey}:${declarationSpan.start.offset}:${declarationSpan.end.offset}`;
        const old = builtins.get(evidenceKey) ?? { key: evidenceKey, operationKey: builtinKey, declaration: declarationSpan, callSites: [] };
        assert.deepEqual(old.declaration, declarationSpan, `Built-in overload '${evidenceKey}' changed within one pass.`);
        old.callSites.push(spanOf(context, node));
        builtins.set(evidenceKey, old);
        return;
      }
      assert(
        ts.isFunctionDeclaration(target) && target.body !== undefined,
        `Resolved source call '${node.getText()}' is not an ordinary function.`,
      );
      const targetKey = declarationKey(repositoryRoot, target);
      assert(certified.has(targetKey), `Unproved source call '${targetKey}'.`);
      if (targetKey !== key) dependencyNames.add(targetKey);
    }

    /** Inspect calls and non-call helper references such as sort/map callbacks. */
    function visit(node) {
      if (ts.isCallExpression(node) || ts.isNewExpression(node)) inspectCall(node);
      if (ts.isIdentifier(node)) {
        const symbol = resolvedSymbol(node);
        for (const sourceDeclaration of symbol?.declarations ?? []) {
          if (ts.isFunctionDeclaration(sourceDeclaration) && sourceDeclaration.body !== undefined) {
            const targetKey = declarationKey(repositoryRoot, sourceDeclaration);
            assert(certified.has(targetKey), `Unproved source function reference '${targetKey}'.`);
            if (targetKey !== key) dependencyNames.add(targetKey);
          }
          if (ts.isVariableDeclaration(sourceDeclaration)) {
            if (declarationIsInsideCallable(sourceDeclaration, declaration)) continue;
            if (sourceDeclaration.getSourceFile().isDeclarationFile) {
              trustedLibraryFile(sourceDeclaration);
              assert(
                ALLOWED_STANDARD_RUNTIME_GLOBALS.has(node.text),
                `Unproved standard runtime global '${node.text}'.`,
              );
              const declarationSpan = spanOf(context, sourceDeclaration);
              const globalKey = `${node.text}:${declarationSpan.file}:${declarationSpan.start.offset}:${declarationSpan.end.offset}`;
              runtimeGlobals.set(globalKey, {
                key: globalKey,
                name: node.text,
                declaration: declarationSpan,
              });
              continue;
            }
            const location = boundedDeclarationLocation(repositoryRoot, sourceDeclaration);
            // Compare identities as a Boolean: formatting a cyclic compiler node can exhaust host memory.
            assert(
              sourceDeclaration === quantityMaximum.declaration,
              `Unknown nonlocal runtime variable '${node.text}' at ${location}.`,
            );
          }
          if (
            (ts.isEnumDeclaration(sourceDeclaration) || ts.isEnumMember(sourceDeclaration)) &&
            !sourceDeclaration.getSourceFile().isDeclarationFile
          ) {
            assert.fail(
              `Unknown nonlocal runtime enum '${node.text}' at ${boundedDeclarationLocation(repositoryRoot, sourceDeclaration)}.`,
            );
          }
        }
      }
      ts.forEachChild(node, visit);
    }

    visit(declaration.body);
    dependencyNamesByKey.set(key, [...dependencyNames].sort(compareCodeUnits));
  }

  return {
    builtins: [...builtins.values()]
      .map((row) => ({ ...row, callSites: row.callSites.sort((left, right) => compareCodeUnits(canonicalJson(left), canonicalJson(right))) }))
      .sort((left, right) => compareCodeUnits(left.key, right.key)),
    runtimeGlobals: [...runtimeGlobals.values()]
      .sort((left, right) => compareCodeUnits(left.key, right.key)),
    dependencyNamesByKey,
  };
}

/** Return exact top-level runtime variables/enums without trusting compiler resolution. */
function normalizedTopLevelRuntimeValues(source) {
  const names = [];
  for (const statement of source.statements) {
    assert.equal(ts.isEnumDeclaration(statement), false, "Runtime enums are outside this source-equation family.");
    if (!ts.isVariableStatement(statement) || (statement.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.DeclareKeyword) ?? false)) continue;
    for (const declaration of statement.declarationList.declarations) {
      assert(ts.isIdentifier(declaration.name), "Top-level destructured runtime values are outside this family.");
      names.push(declaration.name.text);
    }
  }
  return names.sort(compareCodeUnits);
}

/** Read one source through an optional in-memory mutation without modifying product files. */
function sourceText(repositoryRoot, sourceOverrides, file) {
  return sourceOverrides.get(file) ?? fs.readFileSync(path.resolve(repositoryRoot, file), "utf8");
}

/** Build the complete semantic certificate and all 76 alias candidates in one compiler pass. */
export function buildQuantityValuesFamilyCertificate({
  repositoryRoot,
  context,
  surface,
  sourceOverrides = new Map(),
}) {
  assert.equal(ASSIGNED_SURFACE_KEYS.length, 76, "Assigned alias cardinality changed.");
  assert.equal(new Set(ASSIGNED_SURFACE_KEYS).size, 76, "Assigned aliases must be unique.");
  const expectedSource = parseSource(expectedEquationPath, fs.readFileSync(expectedEquationPath, "utf8"));
  const sources = new Map(
    FAMILY_SOURCE_FILES.map((file) => {
      const absolute = path.resolve(repositoryRoot, file);
      const source = sourceOverrides.has(file)
        ? parseSource(absolute, sourceText(repositoryRoot, sourceOverrides, file))
        : context.program.getSourceFile(absolute);
      assert(source !== undefined, `Missing compiler source '${file}'.`);
      return [file, source];
    }),
  );

  const runtimeImports = [];
  for (const file of FAMILY_SOURCE_FILES) {
    const actualImports = normalizedRuntimeImports(sources.get(file));
    const expectedImports = [...EXPECTED_RUNTIME_IMPORTS[file]]
      .sort((left, right) => compareCodeUnits(canonicalJson(left), canonicalJson(right)));
    assert.deepEqual(actualImports, expectedImports, `Import/free-variable bindings changed in '${file}'.`);
    runtimeImports.push(...actualImports.map((row) => ({ file, ...row })));
    assert.deepEqual(
      normalizedTopLevelRuntimeValues(sources.get(file)),
      [...EXPECTED_TOP_LEVEL_RUNTIME_VALUES[file]],
      `Unknown top-level runtime value in '${file}'.`,
    );
  }

  const actualMaximum = findVariable(sources.get("src/quantity.ts"), "MAXIMUM_QUANTITY_DECIMALS");
  const expectedMaximum = findVariable(expectedSource, "MAXIMUM_QUANTITY_DECIMALS");
  assert.equal(actualMaximum.declaration.initializer?.getText(), expectedMaximum.declaration.initializer?.getText(), "Maximum decimal equation changed.");
  assert.equal(
    (actualMaximum.statement.declarationList.flags & ts.NodeFlags.Const) !== 0,
    true,
    "Maximum decimal limit must stay constant.",
  );

  const allMemberNames = [...QUANTITY_MEMBER_NAMES, ...MEASUREMENT_MEMBER_NAMES];
  const allHelperNames = Object.keys(HELPER_SOURCE_BY_NAME).sort(compareCodeUnits);
  const actualDeclarations = new Map();
  const expectedTerms = new Map();
  for (const name of [...allMemberNames, ...allHelperNames]) {
    const sourceFile = MEMBER_SOURCE_BY_NAME[name] ?? HELPER_SOURCE_BY_NAME[name];
    const actual = findFunction(sources.get(sourceFile), name);
    const expected = findFunction(expectedSource, name);
    const actualTerm = normalizeQuantityValueCallable(actual);
    const expectedTerm = normalizeQuantityValueCallable(expected);
    assert.deepEqual(actualTerm, expectedTerm, `Independent source equation changed for '${name}'.`);
    actualDeclarations.set(`${sourceFile}#${name}`, actual);
    expectedTerms.set(name, expectedTerm);
  }
  assert.equal(actualDeclarations.size, 50, "Complete callable/helper equation closure changed.");

  let closure = { builtins: [], runtimeGlobals: [], dependencyNamesByKey: new Map() };
  if (sourceOverrides.size === 0) {
    closure = verifyDependencyClosure({
      repositoryRoot,
      context,
      certified: new Set(actualDeclarations.keys()),
      quantityMaximum: actualMaximum,
      declarations: actualDeclarations,
    });
  }

  const semanticInputs = [
    ...FAMILY_SOURCE_FILES,
    ...producerFiles,
    ...closure.builtins.map((builtin) => builtin.declaration.file),
    ...closure.runtimeGlobals.map((global) => global.declaration.file),
  ];
  const uniqueInputFiles = [...new Set(semanticInputs)].sort(compareCodeUnits);
  const inputs = uniqueInputFiles.map((file) => ({
    file,
    sha256: sha256(sourceOverrides.get(file) ?? fs.readFileSync(path.resolve(repositoryRoot, file))),
  }));

  const memberEquations = allMemberNames
    .map((name) => {
      const sourceFile = MEMBER_SOURCE_BY_NAME[name];
      const key = `${sourceFile}#${name}`;
      const declaration = actualDeclarations.get(key);
      const term = expectedTerms.get(name);
      return {
        id: key,
        name,
        sourceFile,
        implementation: spanOf(context, declaration),
        law: MEMBER_LAW_BY_NAME[name],
        equationSha256: sha256(canonicalJson(term)),
        term,
        dependencies: closure.dependencyNamesByKey.get(key) ?? [],
      };
    })
    .sort((left, right) => compareCodeUnits(left.id, right.id));

  const helperEquations = allHelperNames
    .map((name) => {
      const sourceFile = HELPER_SOURCE_BY_NAME[name];
      const key = `${sourceFile}#${name}`;
      const declaration = actualDeclarations.get(key);
      const term = expectedTerms.get(name);
      return {
        id: key,
        name,
        sourceFile,
        implementation: spanOf(context, declaration),
        law: HELPER_LAW_BY_NAME[name],
        equationSha256: sha256(canonicalJson(term)),
        term,
        dependencies: closure.dependencyNamesByKey.get(key) ?? [],
      };
    })
    .sort((left, right) => compareCodeUnits(left.id, right.id));

  const semanticCore = {
    proofKind: QUANTITY_VALUES_PROOF_KIND,
    domain: FAMILY_DOMAIN,
    inputs,
    maximumQuantityDecimals: {
      value: 18,
      declaration: spanOf(context, actualMaximum.statement),
    },
    runtimeImports,
    runtimeGlobals: closure.runtimeGlobals,
    builtins: closure.builtins,
    memberEquations,
    helperEquations,
  };
  const certificateId = `VALUE_CERTIFICATE_FAMILY:sha256:${sha256(canonicalJson(semanticCore))}`;

  const callableByKey = new Map(surface.callables.map((callable) => [callable.key, callable]));
  const proofs = [];
  for (const surfaceKey of ASSIGNED_SURFACE_KEYS) {
    const match = /^export:(\.|\.\/kernel)#([^:]+)::call\[0\]$/u.exec(surfaceKey);
    assert(match !== null, `Invalid assigned surface key '${surfaceKey}'.`);
    const [, entryPoint, name] = match;
    const sourceFile = MEMBER_SOURCE_BY_NAME[name];
    assert(sourceFile !== undefined, `Assigned alias '${surfaceKey}' has no member equation.`);
    const implementation = actualDeclarations.get(`${sourceFile}#${name}`);
    const callable = callableByKey.get(surfaceKey);
    assert(callable !== undefined, `Compiler omitted assigned alias '${surfaceKey}'.`);
    if (sourceOverrides.size === 0) {
      assert.deepEqual(callable.declaration, spanOf(context, implementation), `Alias declaration drifted for '${surfaceKey}'.`);
      assert(callable.reachabilityPaths.includes(`export:${entryPoint}#${name}`), `Alias reachability drifted for '${surfaceKey}'.`);
    }
    proofs.push({
      surfaceKey,
      mode: "V",
      signature: callable.signature,
      signatureHash: callable.signatureHash,
      declaration: callable.declaration,
      implementation: spanOf(context, implementation),
      relation: sourceOverrides.size === 0 ? "COMPILER_RESOLVED_EXACT_EXPORT_ALIAS" : "MUTATION_CONTROL_ONLY",
      memberEquationId: `${sourceFile}#${name}`,
      memberEquationSha256: memberEquations.find((row) => row.id === `${sourceFile}#${name}`).equationSha256,
    });
  }

  return {
    schemaVersion: 1,
    mode: "V",
    proofKind: QUANTITY_VALUES_PROOF_KIND,
    certificateId,
    surfaceDigest: surface.digest,
    allAdmittedInputs: true,
    sampledInputs: 0,
    inputs,
    domain: FAMILY_DOMAIN,
    semanticCore,
    proofs,
  };
}

/** Canonical 76-key alias list used by the hub family handler. */
export const supportedSurfaceKeys = ASSIGNED_SURFACE_KEYS;

/** Hub-compatible family builder alias retaining the more descriptive public function above. */
export const buildFamilyArtifact = buildQuantityValuesFamilyCertificate;

/** Resolve an evidence file while rejecting absolute paths and repository escapes. */
function checkedEvidencePath(repositoryRoot, evidenceFile) {
  assert(typeof evidenceFile === "string" && evidenceFile.length > 0, "Evidence path is required.");
  assert.equal(path.isAbsolute(evidenceFile), false, "Evidence path must be repository-relative.");
  const root = fs.realpathSync(repositoryRoot);
  const resolved = fs.realpathSync(path.resolve(root, evidenceFile));
  assert(resolved.startsWith(`${root}${path.sep}`), "Evidence path escapes the repository.");
  return resolved;
}

/** Return whether every exact semantic input still matches a cached family derivation. */
function cachedInputsAreFresh(repositoryRoot, inputs) {
  return inputs.every((input) =>
    sha256(fs.readFileSync(path.resolve(repositoryRoot, input.file))) === input.sha256);
}

/** Derive the complete family at most once per unchanged compiler pass and semantic input set. */
function familyArtifactForCompilerPass({ repositoryRoot, context, surface }) {
  const cached = familyPassCache.get(context);
  if (
    cached !== undefined &&
    cached.surfaceDigest === surface.digest &&
    cachedInputsAreFresh(repositoryRoot, cached.artifact.inputs)
  ) {
    return cached.artifact;
  }
  const artifact = buildQuantityValuesFamilyCertificate({ repositoryRoot, context, surface });
  familyPassCache.set(context, { surfaceDigest: surface.digest, artifact });
  return artifact;
}

/** Re-derive a recorded family against current compiler context/surface before one alias may receive V credit. */
export function verifyQuantityValuesFamilyBinding({ repositoryRoot, context, surface, binding }) {
  try {
    assert.equal(binding.mode, "V", "Quantity family bindings require V mode.");
    assert(binding.evidence !== undefined, "Quantity family binding lacks evidence.");
    assert(/^[0-9a-f]{64}$/u.test(binding.evidence.sha256 ?? ""), "Quantity family evidence digest is invalid.");
    const evidenceFile = checkedEvidencePath(repositoryRoot, binding.evidence.file);
    const bytes = fs.readFileSync(evidenceFile);
    assert.equal(sha256(bytes), binding.evidence.sha256, "Quantity family evidence bytes changed.");
    const recorded = JSON.parse(bytes.toString("utf8"));
    assert.equal(recorded.proofKind, QUANTITY_VALUES_PROOF_KIND, "Wrong quantity family proof kind.");
    const current = familyArtifactForCompilerPass({ repositoryRoot, context, surface });
    assert.equal(canonicalJson(recorded), canonicalJson(current), "Recorded quantity family differs from current source equations.");
    assert(current.proofs.some((proof) => proof.surfaceKey === binding.surfaceKey), "Binding key is not proved by this family.");
    return [];
  } catch (error) {
    return [{
      code: "VALUE_SEMANTIC_PROOF_REJECTED",
      detail: error instanceof Error ? error.message : String(error),
    }];
  }
}
