/** Registered-family discriminator for pure event and replacement-plan equations. */
export const EVENT_VALUES_PROOF_KIND =
  "inventoryonce-event-replacement-complete-source-equations-v1";

/** Exact production source revision whose implementation bodies are certified. */
export const EVENT_VALUES_SOURCE_BASE =
  "428f50a0abdf1dec0d96d36419d51df106247044";

/** Exact current compiler surface consumed without running another census. */
export const EVENT_VALUES_SURFACE_DIGEST =
  "ec078013972d9ee2b4ba84d28cfa7449a18dc29679d81766e314db6a6139b81e";

/** The complete fixed 45-key follow-on assignment, in code-unit order. */
export const ASSIGNED_SURFACE_KEYS = Object.freeze([
  "export:./kernel#assertCanonicalInventoryTime::call[0]",
  "export:./kernel#commitInventoryEvent::call[0]",
  "export:./kernel#createInventoryContainerMetadataEvent::call[0]",
  "export:./kernel#createInventoryIssueEvent::call[0]",
  "export:./kernel#createInventoryIssueManyEvent::call[0]",
  "export:./kernel#createInventoryLotMetadataEvent::call[0]",
  "export:./kernel#createInventoryOpeningEvent::call[0]",
  "export:./kernel#createInventoryPackEvent::call[0]",
  "export:./kernel#createInventoryReceiptEvent::call[0]",
  "export:./kernel#createInventoryReceiptManyEvent::call[0]",
  "export:./kernel#createInventoryScrapEvent::call[0]",
  "export:./kernel#createInventoryScrapManyEvent::call[0]",
  "export:./kernel#createInventoryTraceabilityEvent::call[0]",
  "export:./kernel#createInventoryTransformationEvent::call[0]",
  "export:./kernel#createInventoryUnpackEvent::call[0]",
  "export:./kernel#defineInventoryEvent::call[0]",
  "export:./kernel#inventoryEventIdForOperation::call[0]",
  "export:./kernel#inventoryEventIntentFingerprint::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.aggregate::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.associate::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.changeCustodian::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.changeDispositionAuthority::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.changeOwner::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.changeQualifiedDimension::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.changeStatus::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.clearCustodian::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.clearDispositionAuthority::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.clearOwner::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.clearQualifiedDimension::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.clearStatus::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.containerMetadata::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.countAdjustment::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.disaggregate::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.disassociate::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.issue::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.lotMetadata::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.omit::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.opening::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.pack::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.placeInContainer::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.receive::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.removeFromContainer::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.scrap::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.transform::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.unpack::call[0]",
]);

/** Members whose complete local transitive closure does not enter catalog foundation. */
export const LOCALLY_CLOSED_SURFACE_KEYS = Object.freeze([
  "export:./kernel#assertCanonicalInventoryTime::call[0]",
  "export:./kernel#commitInventoryEvent::call[0]",
  "export:./kernel#inventoryEventIdForOperation::call[0]",
  "export:./kernel#inventoryEventIntentFingerprint::call[0]",
  "type:src/facade.ts#InventoryOnceReplacementPlans.omit::call[0]",
]);

/** Public function implementation file selected by each kernel export. */
export const EXPORTED_FUNCTION_SOURCE = Object.freeze({
  assertCanonicalInventoryTime: "src/events.ts",
  commitInventoryEvent: "src/events.ts",
  createInventoryContainerMetadataEvent: "src/commands.ts",
  createInventoryIssueEvent: "src/commands.ts",
  createInventoryIssueManyEvent: "src/commands.ts",
  createInventoryLotMetadataEvent: "src/commands.ts",
  createInventoryOpeningEvent: "src/commands.ts",
  createInventoryPackEvent: "src/commands.ts",
  createInventoryReceiptEvent: "src/commands.ts",
  createInventoryReceiptManyEvent: "src/commands.ts",
  createInventoryScrapEvent: "src/commands.ts",
  createInventoryScrapManyEvent: "src/commands.ts",
  createInventoryTraceabilityEvent: "src/commands.ts",
  createInventoryTransformationEvent: "src/commands.ts",
  createInventoryUnpackEvent: "src/commands.ts",
  defineInventoryEvent: "src/events.ts",
  inventoryEventIdForOperation: "src/commands.ts",
  inventoryEventIntentFingerprint: "src/events.ts",
});

/** Non-transfer replacement methods whose actual class bodies implement the public interface. */
export const REPLACEMENT_METHOD_NAMES = Object.freeze([
  "aggregate",
  "associate",
  "changeCustodian",
  "changeDispositionAuthority",
  "changeOwner",
  "changeQualifiedDimension",
  "changeStatus",
  "clearCustodian",
  "clearDispositionAuthority",
  "clearOwner",
  "clearQualifiedDimension",
  "clearStatus",
  "containerMetadata",
  "countAdjustment",
  "disaggregate",
  "disassociate",
  "issue",
  "lotMetadata",
  "omit",
  "opening",
  "pack",
  "placeInContainer",
  "receive",
  "removeFromContainer",
  "scrap",
  "transform",
  "unpack",
]);

/** Source files that contain every newly proved implementation and private helper. */
export const LOCAL_SOURCE_FILES = Object.freeze([
  "src/commands.ts",
  "src/events.ts",
  "src/facade.ts",
]);

/** Trusted current source identities bind the independent laws to exact implementation bytes. */
export const EXPECTED_SOURCE_SHA256 = Object.freeze({
  "src/amounts.ts": "98ddc0fa8d80b2ca244a207f4eb8b55d86131c2ccfd77620da5c85248d03ef57",
  "src/canonical.ts": "eb2981c629182525c6742d2a67f513f0daec88507e5861f475d5de04984a2d56",
  "src/catalog.ts": "00b2e80984f1fa48dfdba87e4b810f2fe80a03d339399f2d7dff12190e611f56",
  "src/commands.ts": "c40c66fc3e5d3e60022534a561d44280cda205f3cc10be759f8efdc97038a98b",
  "src/events.ts": "8d076ee8f426c011d7df3f205dd014f0e835f71798b3684ca56844b691ba2370",
  "src/facade.ts": "a89805b56aa4b238b54168403b016c7e264ab664f405805fbf1de877cb026e5d",
  "src/measurements.ts": "3d627e4ff13b55e84c09dbd5bb4f624d1bac0acbdc1fabd28bbd92fa0228f7e5",
  "src/model.ts": "df2f15e918a5f349ade6fcfc33393a520f2b74c7221a2e0eca83f7647341d122",
  "src/ordering.ts": "e72ac94e99b1b4914f3f6dec55583e401484a41ecadd051be788724c88f24cb9",
  "src/quantity.ts": "8c0be7d29d08fef1daa83fd987896c1c1a015c4f70cd329261987fcc907382a6",
});

/** Already-admitted dependency families referenced rather than copied or rerun. */
export const REUSED_DEPENDENCY_FAMILIES = Object.freeze([
  Object.freeze({
    proofKind: "inventoryonce-quantity-measurement-complete-source-equations-v1",
    certificateId:
      "VALUE_CERTIFICATE_FAMILY:sha256:22f777b6f641ae5af58c1236b6e6e2e9f2257d95551ed957bd59447662d4c310",
    reviewedCommit: "5d13503b7baceff5515e8d82b390f0949080440a",
    admittedAliases: 76,
  }),
  Object.freeze({
    proofKind: "independent-identity-values-closed-equations-v1",
    familyId: "inventoryonce.identity-values.closed-source-equations.v1",
    reviewedCommit: "02cf9387d669fd8655a71933849862cac8693cd9",
    admittedAliases: 40,
  }),
  Object.freeze({
    proofKind: "independent-catalog-snapshot-closed-equations-v1",
    canonicalArtifactSha256:
      "6331d60cf48d83da632f73ad232b2990ca2dbf5c4185c5c87aaa089f0f51626f",
    admittedAliases: 24,
  }),
]);

/** Exact already-certified source equations directly used by this family. */
export const REUSED_EQUATION_IDS = Object.freeze(new Set([
  "src/catalog.ts#InventoryCatalog.activeItem",
  "src/amounts.ts#InventoryAmountKind",
  "src/amounts.ts#createMeasuredVector",
  "src/amounts.ts#packageAmount",
  "src/amounts.ts#resolveInventoryAmount",
  "src/amounts.ts#validateIndependentAmountInputs",
  "src/canonical.ts#assertFiniteInventoryIntentFingerprintNumbers",
  "src/canonical.ts#inventoryIntentFingerprint",
  "src/canonical.ts#inventoryMetadataFingerprint",
  "src/canonical.ts#inventoryMetadataValueFingerprint",
  "src/canonical.ts#isInventoryMetadataArray",
  "src/catalog.ts#InventoryCatalog.itemRevision",
  "src/catalog.ts#InventoryCatalog.packagingRevision",
  "src/catalog.ts#assertMeasurementsMatchItem",
  "src/measurements.ts#addInventoryMeasurements",
  "src/measurements.ts#assertSamePrimaryMeasurementAxis",
  "src/measurements.ts#assertWholeMeasurementMultiple",
  "src/measurements.ts#compareMeasurementAxis",
  "src/measurements.ts#inventoryMeasurement",
  "src/measurements.ts#inventoryMeasurementAt",
  "src/measurements.ts#inventoryMeasurementVector",
  "src/measurements.ts#inventoryMeasurementsAreZero",
  "src/measurements.ts#inventoryMeasurementsEqual",
  "src/measurements.ts#inventoryMeasurementsFingerprint",
  "src/measurements.ts#measurementFingerprint",
  "src/measurements.ts#multiplyInventoryMeasurementsByWholeNumber",
  "src/measurements.ts#negateInventoryMeasurements",
  "src/measurements.ts#positiveInventoryMeasurements",
  "src/measurements.ts#subtractInventoryMeasurements",
  "src/model.ts#assertInventoryIdentity",
  "src/model.ts#InventoryTraceabilityNodeKind",
  "src/model.ts#compareQualifiedDimension",
  "src/model.ts#inventoryContainerIdentity",
  "src/model.ts#inventoryLotIdentity",
  "src/model.ts#inventoryStockPositionIdentity",
  "src/model.ts#inventoryTraceabilityNodeIdentity",
  "src/model.ts#normalizeInventoryStockPositionKey",
  "src/model.ts#qualifiedDimensionIdentityTuple",
  "src/ordering.ts#compareInventoryIdentityText",
  "src/quantity.ts#addQuantity",
  "src/quantity.ts#assertDecimals",
  "src/quantity.ts#assertSafeInteger",
  "src/quantity.ts#assertSameUnit",
  "src/quantity.ts#compareQuantity",
  "src/quantity.ts#integerAtDecimals",
  "src/quantity.ts#multiplyQuantityByWholeNumber",
  "src/quantity.ts#negateQuantity",
  "src/quantity.ts#parseQuantity",
  "src/quantity.ts#positiveQuantity",
  "src/quantity.ts#powerOfTen",
  "src/quantity.ts#quantity",
  "src/quantity.ts#quantityEq",
  "src/quantity.ts#quantityIsWholeMultipleOf",
  "src/quantity.ts#safeNumber",
  "src/quantity.ts#unitCode",
  "src/quantity.ts#zeroQuantity",
]));

/** Catalog-foundation equations required by defineInventoryEvent's declared domain. */
export const CATALOG_FOUNDATION_DEPENDENCY_EQUATION_IDS = Object.freeze(new Set([
  "src/catalog.ts#assertInventoryCatalogRetainsSnapshot",
  "src/catalog.ts#assertPositionMatchesItem",
  "src/catalog.ts#inventoryCatalogFromSnapshot",
]));

/** Runtime enums/constants whose exact declarations are part of this family's equations. */
export const LOCAL_RUNTIME_VALUE_IDS = Object.freeze([
  "src/events.ts#InventoryEventKind",
  "src/events.ts#InventoryTraceabilityRelationAction",
  "src/events.ts#InventoryTraceabilityRelationKind",
  "src/events.ts#InventoryTransferLifecycleAction",
  "src/facade.ts#replacementEventDrafts",
]);

/** Exact semantic domain of the construction equations. */
export const FAMILY_DOMAIN = Object.freeze({
  inputs:
    "All values admitted by the declared TypeScript inputs after the referenced quantity, identity, amount and catalogue equations: finite acyclic immutable plain records/arrays, exact safe-integer quantities and package counts, canonical identities/times, and catalogue receivers created by the certified catalogue family.",
  eventKinds:
    "defineInventoryEvent covers every declared InventoryEventKind branch, including catalogue publication, correction and transfer-lifecycle validation; constructors in this certificate expose only the fixed non-transfer key set.",
  planners:
    "Replacement methods execute only on the library-created InventoryOnceReplacementPlansImplementation receiver with its frozen catalogue and synthetic correction operation id. They allocate an opaque plan, set its public kind and retain the draft in the module-private WeakMap; they do not publish or commit durable state.",
  builtins:
    "Unmodified ECMAScript Array, Date, Error, JSON, Map, Number, Object, Set, String, WeakMap and encodeURIComponent semantics from the active trusted TypeScript library root.",
  rejected:
    "Mutable/proxied/custom-prototype inputs, accessors, custom coercion/iterators, rebound globals, monkey-patched built-ins, cyclic data, forged planner receivers/plans, async/generator/default/rest substitutions, and unknown nonlocal runtime values are outside the certificate and fail closed.",
});

/** Independently stated complete laws used to review every equation group. */
export const FAMILY_LAWS = Object.freeze([
  Object.freeze({
    id: "event-definition-normalization-v1",
    statement:
      "Validate eventId/operationId/canonical occurredAt; enforce catalogue snapshot/digest iff CatalogPublication; correction pointer iff Correction with non-self ids and nonblank reason; normalize and sort stock effects, provenance transfers/overrides, lot/container definitions, traceability changes and transfer lifecycle; reject mismatched transfer ids and empty non-correction/non-publication facts; apply the complete kind-specific sign, conservation, metadata, graph and lifecycle guards; return every original event field overridden only by the normalized arrays and optional normalized transferLifecycle.",
  }),
  Object.freeze({
    id: "event-commit-v1",
    statement:
      "Require canonical recordedAt, occurredAt <= recordedAt, every present provenance startedAt <= recordedAt, and positive safe-integer recordSequence; return the entire draft plus recordedAt and recordSequence without durable publication.",
  }),
  Object.freeze({
    id: "event-intent-fingerprint-v1",
    statement:
      "Hash the exact ordered tuple event id, operation id, kind, occurrence time, optional parties/reference/reason, catalogue digest/snapshot digest, correction tuple, metadata fingerprint, lifecycle fingerprint, ordered lot/container/provenance arrays, ordered stock effect identity/measurement/evidence/metadata tuples, and ordered traceability identities.",
  }),
  Object.freeze({
    id: "canonical-time-v1",
    statement:
      "Parse with the unmodified Date parser and accept exactly finite epochs whose new Date(epoch).toISOString() equals the supplied text; otherwise reject with the supplied label.",
  }),
  Object.freeze({
    id: "movement-command-v1",
    statement:
      "Resolve the item by package revision, explicit revision or active item; resolve exact amount measurements; reject transfer-bound ordinary positions and package mismatches; construct normalized signed effects and evidence; attach exact optional lot/container facts; derive event id from nonblank encoded operation id; invoke the complete event-definition law with all header fields preserved only when present.",
  }),
  Object.freeze({
    id: "many-movement-command-v1",
    statement:
      "Reject empty line arrays. Issue and scrap preserve input order and one negative effect per line; scrap also requires a nonblank reason. Receipt groups exact destination identities, requires equal metadata/package identity for collisions, adds exact measurements and positive safe package counts, then emits effects and deduplicated lot/container definitions in code-unit identity order.",
  }),
  Object.freeze({
    id: "pack-unpack-command-v1",
    statement:
      "Pack rejects transfer-bound/already-packaged sources, resolves the exact matching package item and whole count, moves equal measurements from loose to that exact package revision and transfers positive-layer provenance. Unpack requires/matches the source package, removes only packagingRevisionId, optionally replaces containerId, attaches destination container metadata, and moves the same measurements/provenance.",
  }),
  Object.freeze({
    id: "transformation-command-v1",
    statement:
      "Require nonempty consume and produce arrays; resolve every line to an exact revision-qualified position; emit negative consumes then positive produces in input order; deduplicate compatible lot/container facts by identity and sort them; derive complete Cartesian genealogy only when every line has one unambiguous or explicitly matching node, otherwise use no genealogy or reject partial/ambiguous lineage.",
  }),
  Object.freeze({
    id: "metadata-traceability-command-v1",
    statement:
      "Lot metadata first requires an active item and emits exactly its itemId/lotId plus supplied lot fields; container metadata emits exactly containerId plus supplied container fields; traceability emits exactly the supplied relation changes. Each uses empty stock arrays and the shared movement/event-definition law.",
  }),
  Object.freeze({
    id: "replacement-plan-construction-v1",
    statement:
      "Each direct planner inserts only the frozen catalogue and synthetic replacement operation id into its corresponding certified command, then allocates an opaque plan whose kind is draft.kind and whose private WeakMap entry is that draft. omit allocates kind 'omit' with a null private entry. No planner commits, stores or publishes an event.",
  }),
  Object.freeze({
    id: "replacement-property-change-v1",
    statement:
      "Change verbs require a trimmed nonempty new identity different from the prior value and replace only the named status/owner/custodian/disposition-authority/container field. Clear verbs require the named field and remove only it. Qualified change validates configured dimension identity/value, replaces exactly one matching value or appends, normalizes position order; qualified clear removes exactly the named present dimension and omits the array when empty. All then use the single reclassification constructor.",
  }),
  Object.freeze({
    id: "replacement-count-adjustment-v1",
    statement:
      "For every input line in order compute observed minus expectedAtObservation using certified exact measurement subtraction, omit zero deltas, and emit one remaining effect with item revision, position, exact delta and fingerprints of expected/observed. Define a CountAdjustment event with derived event id, synthetic operation id, occurrence time, empty traceability and every optional header field conditionally preserved.",
  }),
  Object.freeze({
    id: "replacement-relation-v1",
    statement:
      "Aggregate/disaggregate select add/remove containment; associate/disassociate select add/remove association. The private relation equation builds exactly one change from input.from to input.to, adds only frozen catalogue and synthetic operation id, then delegates to the certified traceability constructor and opaque-plan constructor.",
  }),
]);

/** Map one public implementation to the independently stated law that governs it. */
export function lawIdForPublicImplementation(name) {
  if (name === "assertCanonicalInventoryTime") return "canonical-time-v1";
  if (name === "commitInventoryEvent") return "event-commit-v1";
  if (name === "defineInventoryEvent") return "event-definition-normalization-v1";
  if (name === "inventoryEventIntentFingerprint") return "event-intent-fingerprint-v1";
  if (name === "inventoryEventIdForOperation") return "movement-command-v1";
  if (["createInventoryIssueManyEvent", "createInventoryReceiptManyEvent", "createInventoryScrapManyEvent"].includes(name)) return "many-movement-command-v1";
  if (["createInventoryPackEvent", "createInventoryUnpackEvent"].includes(name)) return "pack-unpack-command-v1";
  if (name === "createInventoryTransformationEvent") return "transformation-command-v1";
  if (["createInventoryContainerMetadataEvent", "createInventoryLotMetadataEvent", "createInventoryTraceabilityEvent"].includes(name)) return "metadata-traceability-command-v1";
  if (name.startsWith("createInventory")) return "movement-command-v1";
  if (name === "countAdjustment") return "replacement-count-adjustment-v1";
  if (["aggregate", "associate", "disaggregate", "disassociate"].includes(name)) return "replacement-relation-v1";
  if (name === "omit" || ["containerMetadata", "issue", "lotMetadata", "opening", "pack", "receive", "scrap", "transform", "unpack"].includes(name)) return "replacement-plan-construction-v1";
  return "replacement-property-change-v1";
}
