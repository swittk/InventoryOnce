import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  canonicalJson,
  compareCodeUnits,
  sha256,
  spanOf,
  ts,
} from "../../surface-bindings/lib/compiler-surface.mjs";
import {
  buildFamilyArtifact as buildCatalogFoundationFamilyArtifact,
  proofKind as catalogFoundationProofKind,
} from "../../catalog-foundation-r7/family.mjs";
import { SOURCE_FILES as catalogFoundationSourceFiles } from "../../catalog-foundation-r7/contracts.mjs";
import { buildFamilyArtifact as buildCurrentQuantityFamilyArtifact } from "../certificate.mjs";
import { buildFamilyArtifact as buildCurrentIdentityFamilyArtifact } from "../../identity-values-r7/family.mjs";
import { buildCatalogFamilyArtifact as buildCurrentCatalogSnapshotFamilyArtifact } from "../../value-contracts/catalog-family.mjs";
import {
  ASSIGNED_SURFACE_KEYS,
  CATALOG_FOUNDATION_DEPENDENCY_EQUATION_IDS,
  EVENT_VALUES_PROOF_KIND,
  EVENT_VALUES_SOURCE_BASE,
  EVENT_VALUES_SURFACE_DIGEST,
  EXPECTED_SOURCE_SHA256,
  EXPORTED_FUNCTION_SOURCE,
  FAMILY_DOMAIN,
  FAMILY_LAWS,
  LOCALLY_CLOSED_SURFACE_KEYS,
  LOCAL_RUNTIME_VALUE_IDS,
  LOCAL_SOURCE_FILES,
  REPLACEMENT_METHOD_NAMES,
  REUSED_DEPENDENCY_FAMILIES,
  REUSED_EQUATION_IDS,
  lawIdForPublicImplementation,
} from "./contracts.mjs";

/** Source/specification/checker inputs that define this follow-on producer. */
const producerFiles = Object.freeze([
  "experiments/tla-conformance/quantity-values-r7/event-values/certificate.mjs",
  "experiments/tla-conformance/quantity-values-r7/event-values/contracts.mjs",
  "experiments/tla-conformance/quantity-values-r7/event-values/catalog-foundation-dependency-reference.json",
  "experiments/tla-conformance/quantity-values-r7/event-values/equations.expected.ts.txt",
  "experiments/tla-conformance/quantity-values-r7/event-values/registered-family-adapter.mjs",
  "experiments/tla-conformance/quantity-values-r7/quantity-values-certificate.json",
  "experiments/tla-conformance/surface-bindings/lib/compiler-surface.mjs",
  "node_modules/typescript/package.json",
  "package.json",
  "tsconfig.json",
]);

/** Independent equation program parsed without importing production symbols. */
const equationProgramPath = fileURLToPath(
  new URL("./equations.expected.ts.txt", import.meta.url),
);

/** Fail-closed handoff for the catalog-foundation helper equations. */
const catalogFoundationDependencyPath = fileURLToPath(
  new URL("./catalog-foundation-dependency-reference.json", import.meta.url),
);

/** Reuse one complete derivation only inside one unchanged compiler context. */
const familyPassCache = new WeakMap();

/** Convert one absolute compiler path to the artifact's repository-relative identity. */
function relativePath(repositoryRoot, fileName) {
  return path.relative(repositoryRoot, fileName).replaceAll("\\", "/");
}

/** Read source through an in-memory mutation without writing production files. */
function readSource(repositoryRoot, sourceOverrides, file) {
  return sourceOverrides.get(file) ?? fs.readFileSync(path.resolve(repositoryRoot, file), "utf8");
}

/** Parse a mutation as TypeScript only after its target construction succeeded. */
function parseSource(fileName, sourceText) {
  return ts.createSourceFile(
    fileName,
    sourceText,
    ts.ScriptTarget.Latest,
    true,
    ts.ScriptKind.TS,
  );
}

/** Build a real compiler context whose deliberate source mutations retain symbol resolution. */
function loadOverriddenContext(repositoryRoot, sourceOverrides) {
  const root = path.resolve(repositoryRoot);
  for (const file of sourceOverrides.keys()) {
    assert(Object.hasOwn(EXPECTED_SOURCE_SHA256, file), `Source override left the closed family: ${file}`);
  }
  const configPath = path.join(root, "tsconfig.json");
  const config = ts.readConfigFile(configPath, ts.sys.readFile);
  assert.equal(config.error, undefined, "Cannot read TypeScript configuration for mutation control.");
  const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root, undefined, configPath);
  assert.equal(parsed.errors.length, 0, "TypeScript configuration diagnostics changed.");
  const overridesByAbsolutePath = new Map(
    [...sourceOverrides].map(([file, text]) => [path.resolve(root, file), text]),
  );
  const host = ts.createCompilerHost(parsed.options, true);
  const originalGetSourceFile = host.getSourceFile.bind(host);
  host.getSourceFile = (fileName, languageVersion, onError, shouldCreateNewSourceFile) => {
    const override = overridesByAbsolutePath.get(path.resolve(fileName));
    return override === undefined
      ? originalGetSourceFile(fileName, languageVersion, onError, shouldCreateNewSourceFile)
      : ts.createSourceFile(fileName, override, languageVersion, true, ts.ScriptKind.TS);
  };
  host.readFile = (fileName) =>
    overridesByAbsolutePath.get(path.resolve(fileName)) ?? ts.sys.readFile(fileName);
  const program = ts.createProgram({ rootNames: parsed.fileNames, options: parsed.options, host });
  const diagnostics = ts.getPreEmitDiagnostics(program);
  assert.equal(diagnostics.length, 0, `Mutated compiler program has ${diagnostics.length} diagnostic(s).`);
  return { repositoryRoot: root, program, checker: program.getTypeChecker() };
}

/** Return one concrete top-level function by exact name. */
function findFunction(source, name) {
  const declarations = source.statements.filter(
    (statement) =>
      ts.isFunctionDeclaration(statement) &&
      statement.name?.text === name &&
      statement.body !== undefined,
  );
  assert.equal(declarations.length, 1, `Expected one concrete function '${name}'.`);
  return declarations[0];
}

/** Return one exact named class declaration. */
function findClass(source, name) {
  const declarations = source.statements.filter(
    (statement) => ts.isClassDeclaration(statement) && statement.name?.text === name,
  );
  assert.equal(declarations.length, 1, `Expected one class '${name}'.`);
  return declarations[0];
}

/** Return one concrete method from one exact class. */
function findClassMethod(source, className, methodName) {
  const owner = findClass(source, className);
  const methods = owner.members.filter(
    (member) =>
      ts.isMethodDeclaration(member) &&
      ts.isIdentifier(member.name) &&
      member.name.text === methodName &&
      member.body !== undefined,
  );
  assert.equal(methods.length, 1, `Expected one concrete method '${className}.${methodName}'.`);
  return methods[0];
}

/** Return one concrete constructor from one exact class. */
function findClassConstructor(source, className) {
  const constructors = findClass(source, className).members.filter(
    (member) => ts.isConstructorDeclaration(member) && member.body !== undefined,
  );
  assert.equal(constructors.length, 1, `Expected one concrete constructor '${className}'.`);
  return constructors[0];
}

/** Resolve the independent expected callable corresponding to one production equation id. */
function findExpectedCallable(source, id) {
  const local = id.slice(id.indexOf("#") + 1);
  const separator = local.indexOf(".");
  if (separator < 0) return findFunction(source, local);
  const className = local.slice(0, separator);
  const memberName = local.slice(separator + 1);
  return memberName === "<constructor>"
    ? findClassConstructor(source, className)
    : findClassMethod(source, className, memberName);
}

/** Count every concrete top-level/class callable in the independent equation program. */
function expectedCallableCount(source) {
  let count = 0;
  for (const statement of source.statements) {
    if (ts.isFunctionDeclaration(statement) && statement.body !== undefined) count += 1;
    if (!ts.isClassDeclaration(statement)) continue;
    for (const member of statement.members) {
      if (
        (ts.isMethodDeclaration(member) || ts.isConstructorDeclaration(member)) &&
        member.body !== undefined
      ) count += 1;
    }
  }
  return count;
}

/** Reject any catalog-foundation status label that was not established by trusted code. */
export function validateCatalogFoundationDependencyReference(reference) {
  assert.equal(reference.schemaVersion, 1);
  assert.equal(reference.owner, "catalog-foundation-r7");
  assert.equal(reference.sourceBase, EVENT_VALUES_SOURCE_BASE);
  assert.equal(reference.surfaceDigest, EVENT_VALUES_SURFACE_DIGEST);
  assert.deepEqual(reference.equationIds, [...CATALOG_FOUNDATION_DEPENDENCY_EQUATION_IDS].sort());
  assert.equal(
    reference.status,
    "PENDING_REGISTERED_FAMILY",
    "A status label cannot replace invocation of the trusted catalog-foundation verifier.",
  );
  assert.equal(reference.proofKind, null);
  assert.equal(reference.certificateId, null);
  assert.equal(reference.artifactSha256, null);
  assert.equal(reference.reviewedCommit, null);
  return false;
}

/** Invoke the trusted current-source catalogue-foundation verifier; JSON labels never promote themselves. */
function loadCatalogFoundationDependencyReference({ repositoryRoot, context, surface }) {
  const pendingReference = JSON.parse(fs.readFileSync(catalogFoundationDependencyPath, "utf8"));
  validateCatalogFoundationDependencyReference(pendingReference);
  const artifact = buildCatalogFoundationFamilyArtifact({ repositoryRoot, context, surface });
  assert.equal(artifact.proofKind, catalogFoundationProofKind);
  assert.equal(artifact.surfaceDigest, surface.digest);
  assert.equal(artifact.allAdmittedInputs, true);
  assert.equal(artifact.sampledInputs, 0);
  const equations = new Map(artifact.equations.map((equation) => [equation.id, equation]));
  const verifiedEquationIds = new Set();
  const equationTerms = [];
  for (const equationId of [...CATALOG_FOUNDATION_DEPENDENCY_EQUATION_IDS].sort(compareCodeUnits)) {
    const equation = equations.get(equationId);
    assert(equation !== undefined, `Trusted catalogue foundation omitted '${equationId}'.`);
    verifiedEquationIds.add(equationId);
    equationTerms.push({ equationId, termSha256: sha256(canonicalJson(equation.term)) });
  }
  return {
    verified: true,
    verifiedEquationIds,
    artifact,
    reference: {
      ...pendingReference,
      status: "VERIFIED_BY_TRUSTED_CODE",
      proofKind: artifact.proofKind,
      certificateId: artifact.certificateId,
      artifactSha256: sha256(canonicalJson(artifact)),
      equationTerms,
    },
  };
}

/** Rebuild every reused equation from trusted current-source families before reuse. */
function buildCurrentReusedDependencyAuthority({ repositoryRoot, context, surface }) {
  const quantity = buildCurrentQuantityFamilyArtifact({ repositoryRoot, context, surface });
  const identity = buildCurrentIdentityFamilyArtifact({ repositoryRoot, context, surface });
  const catalog = buildCurrentCatalogSnapshotFamilyArtifact({ repositoryRoot, context, surface });
  for (const artifact of [quantity, identity, catalog]) {
    assert.equal(artifact.surfaceDigest, surface.digest, `Current reused family surface drifted: ${artifact.proofKind}`);
    assert.equal(artifact.allAdmittedInputs, true, `Current reused family is incomplete: ${artifact.proofKind}`);
    assert.equal(artifact.sampledInputs, 0, `Current reused family became sample-backed: ${artifact.proofKind}`);
  }

  const providers = new Map();
  function add(provider, id) {
    if (!REUSED_EQUATION_IDS.has(id)) return;
    const rows = providers.get(id) ?? [];
    if (!rows.includes(provider)) rows.push(provider);
    providers.set(id, rows.sort(compareCodeUnits));
  }
  for (const row of [
    ...(quantity.semanticCore?.memberEquations ?? []),
    ...(quantity.semanticCore?.helperEquations ?? []),
  ]) add(quantity.proofKind, row.id);
  for (const row of identity.equations ?? []) add(identity.proofKind, row.id);
  for (const row of identity.supportingValues ?? []) add(identity.proofKind, row.id);
  for (const row of catalog.proofs ?? []) add(catalog.proofKind, row.equationId);
  for (const row of catalog.helperEquations ?? []) add(catalog.proofKind, row.key);

  const catalogSource = context.program.getSourceFile(path.resolve(repositoryRoot, "src/catalog.ts"));
  assert(catalogSource !== undefined, "Current compiler omitted src/catalog.ts.");
  const activeItem = findClassMethod(catalogSource, "InventoryCatalog", "activeItem");
  const expectedActiveItemSource = parseSource(
    "event-current-active-item.expected.ts",
    `class InventoryCatalog {
      activeItem(itemId) {
        const item = this.activeItemById.get(itemId);
        if (item === undefined) throw new Error(\`Unknown active inventory item '\${itemId}'.\`);
        return item;
      }
    }`,
  );
  const expectedActiveItem = findClassMethod(expectedActiveItemSource, "InventoryCatalog", "activeItem");
  assert(activeItem.body !== undefined && expectedActiveItem.body !== undefined);
  const activeItemTerm = normalizeEventValueSyntax(activeItem.body);
  assert.deepEqual(
    activeItemTerm,
    normalizeEventValueSyntax(expectedActiveItem.body),
    "Current InventoryCatalog.activeItem equation changed.",
  );
  add("R131_CURRENT_ACTIVE_ITEM_EXPECTED_TERM", "src/catalog.ts#InventoryCatalog.activeItem");

  assert.deepEqual(
    [...providers.keys()].sort(compareCodeUnits),
    [...REUSED_EQUATION_IDS].sort(compareCodeUnits),
    "Current reused dependency coverage is incomplete.",
  );
  const inputsByFile = new Map();
  for (const artifact of [quantity, identity, catalog]) {
    for (const input of artifact.inputs) {
      const prior = inputsByFile.get(input.file);
      assert(prior === undefined || prior.sha256 === input.sha256, `Current reused input conflict: ${input.file}`);
      inputsByFile.set(input.file, input);
    }
  }
  return {
    verifiedEquationIds: [...providers.keys()].sort(compareCodeUnits),
    providers: [...providers]
      .sort(([left], [right]) => compareCodeUnits(left, right))
      .map(([equationId, proofKinds]) => ({ equationId, proofKinds })),
    families: [quantity, identity, catalog].map((artifact) => ({
      proofKind: artifact.proofKind,
      surfaceDigest: artifact.surfaceDigest,
      artifactSha256: sha256(canonicalJson(artifact)),
      proofCount: artifact.proofs.length,
    })),
    activeItem: {
      equationId: "src/catalog.ts#InventoryCatalog.activeItem",
      declaration: spanOf(context, activeItem),
      equationSha256: sha256(canonicalJson(activeItemTerm)),
    },
    inputs: [...inputsByFile.values()].sort((left, right) => compareCodeUnits(left.file, right.file)),
  };
}

/** Return one exact public interface method declaration. */
function findInterfaceMethod(source, interfaceName, methodName) {
  const owners = source.statements.filter(
    (statement) => ts.isInterfaceDeclaration(statement) && statement.name.text === interfaceName,
  );
  assert.equal(owners.length, 1, `Expected one interface '${interfaceName}'.`);
  const methods = owners[0].members.filter(
    (member) =>
      ts.isMethodSignature(member) &&
      ts.isIdentifier(member.name) &&
      member.name.text === methodName,
  );
  assert.equal(methods.length, 1, `Expected one interface method '${interfaceName}.${methodName}'.`);
  return methods[0];
}

/** Return one top-level enum declaration by exact name. */
function findEnum(source, name) {
  const declarations = source.statements.filter(
    (statement) => ts.isEnumDeclaration(statement) && statement.name.text === name,
  );
  assert.equal(declarations.length, 1, `Expected one enum '${name}'.`);
  return declarations[0];
}

/** Return one exact top-level variable statement/declaration pair. */
function findTopLevelVariable(source, name) {
  const declarations = [];
  for (const statement of source.statements) {
    if (!ts.isVariableStatement(statement)) continue;
    for (const declaration of statement.declarationList.declarations) {
      if (ts.isIdentifier(declaration.name) && declaration.name.text === name) {
        declarations.push({ statement, declaration });
      }
    }
  }
  assert.equal(declarations.length, 1, `Expected one top-level variable '${name}'.`);
  return declarations[0];
}

/** Return a stable identity for any source callable admitted to the closure. */
function declarationId(repositoryRoot, declaration) {
  const file = relativePath(repositoryRoot, declaration.getSourceFile().fileName);
  if (ts.isFunctionDeclaration(declaration)) {
    assert(declaration.name !== undefined);
    return `${file}#${declaration.name.text}`;
  }
  if (ts.isMethodDeclaration(declaration) || ts.isConstructorDeclaration(declaration)) {
    const owner = declaration.parent;
    assert(ts.isClassDeclaration(owner) && owner.name !== undefined, "Callable method needs a named class.");
    const member = ts.isConstructorDeclaration(declaration)
      ? "<constructor>"
      : declaration.name.getText(declaration.getSourceFile());
    return `${file}#${owner.name.text}.${member}`;
  }
  throw new Error(`Unsupported callable declaration '${ts.SyntaxKind[declaration.kind]}'.`);
}

/** Return one bounded source location without asking Node to print a cyclic compiler object. */
function declarationLocation(repositoryRoot, declaration) {
  const source = declaration.getSourceFile();
  const point = source.getLineAndCharacterOfPosition(declaration.getStart(source));
  return `${relativePath(repositoryRoot, source.fileName)}:${point.line + 1}:${point.character + 1}`;
}

/** Normalize a complete runtime AST without source text matching or code execution. */
export function normalizeEventValueSyntax(node) {
  if (ts.isParenthesizedExpression(node)) return normalizeEventValueSyntax(node.expression);
  if (
    ts.isAsExpression(node) ||
    ts.isTypeAssertionExpression(node) ||
    ts.isNonNullExpression(node) ||
    ts.isSatisfiesExpression(node)
  ) {
    return ["runtime-type-erasure", normalizeEventValueSyntax(node.expression)];
  }
  if (ts.isIdentifier(node)) return ["identifier", node.text];
  if (
    ts.isStringLiteral(node) ||
    ts.isNoSubstitutionTemplateLiteral(node) ||
    ts.isNumericLiteral(node) ||
    ts.isBigIntLiteral(node) ||
    ts.isRegularExpressionLiteral(node)
  ) {
    return [ts.SyntaxKind[node.kind], node.text];
  }
  if (node.kind === ts.SyntaxKind.TrueKeyword) return ["boolean", true];
  if (node.kind === ts.SyntaxKind.FalseKeyword) return ["boolean", false];
  if (node.kind === ts.SyntaxKind.NullKeyword) return ["null"];
  if (node.kind === ts.SyntaxKind.ThisKeyword) return ["this"];
  const children = node.getChildren(node.getSourceFile()).filter((child) => !ts.isJSDoc(child));
  if (children.length === 0) return [ts.SyntaxKind[node.kind], node.getText(node.getSourceFile())];
  return [ts.SyntaxKind[node.kind], children.map(normalizeEventValueSyntax)];
}

/** Reject callable behaviors that are not part of the synchronous construction domain. */
function validateCallableSyntax(declaration) {
  assert(declaration.body !== undefined, "Source equation needs a concrete body.");
  assert.equal(declaration.asteriskToken, undefined, "Generator equations are outside this family.");
  assert.equal(
    declaration.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword) ?? false,
    false,
    "Async equations are outside this family.",
  );
  assert(
    !ts.canHaveDecorators(declaration) || (ts.getDecorators(declaration)?.length ?? 0) === 0,
    "Decorated equations are outside this family.",
  );
  for (const parameter of declaration.parameters) {
    assert.equal(parameter.dotDotDotToken, undefined, "Rest parameters require another equation.");
    // Defaults are retained by normalizeEventValueSyntax and therefore cannot be erased.
  }
  function inspect(node) {
    if (ts.isArrowFunction(node) || ts.isFunctionExpression(node)) {
      assert.equal(node.asteriskToken, undefined, "Generator callbacks are outside this family.");
      assert.equal(
        node.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.AsyncKeyword) ?? false,
        false,
        "Async callbacks are outside this family.",
      );
      for (const parameter of node.parameters) {
        assert.equal(parameter.dotDotDotToken, undefined, "Rest callbacks require another equation.");
        // Callback defaults remain explicit AST children and are never erased.
      }
    }
    assert(!ts.isGetAccessorDeclaration(node) && !ts.isSetAccessorDeclaration(node), "Accessor execution is outside immutable value equations.");
    ts.forEachChild(node, inspect);
  }
  inspect(declaration.body);
}

/** Return whether one declaration is lexically contained by a certified callable. */
function declarationIsInsideCallable(candidate, callable) {
  let current = candidate;
  while (current !== undefined) {
    if (current === callable) return true;
    current = current.parent;
  }
  return false;
}

/** Return an enum declaration identity for an enum or enum-member declaration. */
function enumDeclarationId(repositoryRoot, declaration) {
  const owner = ts.isEnumDeclaration(declaration) ? declaration : declaration.parent;
  assert(ts.isEnumDeclaration(owner));
  return `${relativePath(repositoryRoot, owner.getSourceFile().fileName)}#${owner.name.text}`;
}

/** Require a resolved standard declaration to live under the active TypeScript library root. */
function trustedLibraryFile(trustedLibraryRoot, declaration) {
  assert.equal(declaration.getSourceFile().isDeclarationFile, true, "Runtime library declaration must be ambient.");
  const file = fs.realpathSync(declaration.getSourceFile().fileName);
  assert(file.startsWith(`${trustedLibraryRoot}${path.sep}`), `Runtime declaration left the trusted TypeScript library: ${file}`);
  return file;
}

/** Return one stable standard-operation identity including overload span. */
function standardOperationKey(repositoryRoot, declaration) {
  const source = declaration.getSourceFile();
  const name = declaration.name?.getText(source) ?? "<anonymous>";
  return `${relativePath(repositoryRoot, source.fileName)}#${name}#${ts.SyntaxKind[declaration.kind]}@${declaration.getStart(source)}:${declaration.getEnd()}`;
}

/** Resolve an imported alias to the compiler symbol that supplies its runtime value. */
function resolvedCompilerSymbol(context, node) {
  let symbol = context.checker.getSymbolAtLocation(node);
  if (symbol !== undefined && (symbol.flags & ts.SymbolFlags.Alias) !== 0) {
    symbol = context.checker.getAliasedSymbol(symbol);
  }
  return symbol;
}

/** Verify every source call/free value and recursively collect the exact local helper closure. */
function verifyDependencyClosure({ repositoryRoot, context, roots }) {
  const localFiles = new Set(LOCAL_SOURCE_FILES);
  const trustedLibraryRoot = fs.realpathSync(
    path.dirname(ts.getDefaultLibFilePath(context.program.getCompilerOptions())),
  );
  const declarations = new Map();
  const pending = [...roots];
  const dependenciesById = new Map();
  const standardOperations = new Map();
  const runtimeGlobals = new Map();
  const reusedDependencies = new Set();
  const catalogFoundationDependencies = new Set();
  const runtimeValues = new Set();

  /** Resolve aliases so imports cannot disguise a changed implementation. */
  function resolvedSymbol(node) {
    return resolvedCompilerSymbol(context, node);
  }

  /** Classify one resolved source callable or fail closed. */
  function classifySourceCallable(declaration, dependencies) {
    const id = declarationId(repositoryRoot, declaration);
    const file = relativePath(repositoryRoot, declaration.getSourceFile().fileName);
    if (localFiles.has(file)) {
      dependencies.add(id);
      pending.push(declaration);
      return;
    }
    if (REUSED_EQUATION_IDS.has(id)) {
      dependencies.add(id);
      reusedDependencies.add(id);
      return;
    }
    if (CATALOG_FOUNDATION_DEPENDENCY_EQUATION_IDS.has(id)) {
      dependencies.add(id);
      catalogFoundationDependencies.add(id);
      return;
    }
    throw new Error(`Unproved transitive source callable '${id}'.`);
  }

  while (pending.length > 0) {
    const declaration = pending.shift();
    const id = declarationId(repositoryRoot, declaration);
    if (declarations.has(id)) continue;
    validateCallableSyntax(declaration);
    declarations.set(id, declaration);
    const dependencies = new Set();

    function inspect(node) {
      if (ts.isCallExpression(node) || ts.isNewExpression(node)) {
        const target = context.checker.getResolvedSignature(node)?.declaration;
        assert(target !== undefined, `Unresolved call '${node.getText()}'.`);
        if (target.getSourceFile().isDeclarationFile) {
          trustedLibraryFile(trustedLibraryRoot, target);
          const key = standardOperationKey(repositoryRoot, target);
          const prior = standardOperations.get(key) ?? {
            key,
            declaration: spanOf(context, target),
            callSites: [],
          };
          prior.callSites.push(spanOf(context, node));
          standardOperations.set(key, prior);
        } else if (
          (ts.isFunctionDeclaration(target) ||
            ts.isMethodDeclaration(target) ||
            ts.isConstructorDeclaration(target)) &&
          target.body !== undefined
        ) {
          classifySourceCallable(target, dependencies);
        } else if (
          (ts.isArrowFunction(target) || ts.isFunctionExpression(target)) &&
          declarationIsInsideCallable(target, declaration)
        ) {
          // The full lexical callback is already retained inside this declaration term.
        } else {
          throw new Error(`Unproved call target '${ts.SyntaxKind[target.kind]}' at ${declarationLocation(repositoryRoot, target)}.`);
        }
      }

      if (ts.isIdentifier(node)) {
        const symbol = resolvedSymbol(node);
        for (const candidate of symbol?.declarations ?? []) {
          if (
            (ts.isFunctionDeclaration(candidate) ||
              ts.isMethodDeclaration(candidate) ||
              ts.isConstructorDeclaration(candidate)) &&
            candidate.body !== undefined &&
            !declarationIsInsideCallable(candidate, declaration)
          ) {
            classifySourceCallable(candidate, dependencies);
          }
          if (ts.isEnumDeclaration(candidate) || ts.isEnumMember(candidate)) {
            if (candidate.getSourceFile().isDeclarationFile) continue;
            const valueId = enumDeclarationId(repositoryRoot, candidate);
            assert(
              LOCAL_RUNTIME_VALUE_IDS.includes(valueId) || REUSED_EQUATION_IDS.has(valueId),
              `Unproved runtime enum '${valueId}'.`,
            );
            runtimeValues.add(valueId);
          }
          if (ts.isVariableDeclaration(candidate)) {
            if (declarationIsInsideCallable(candidate, declaration)) continue;
            if (candidate.getSourceFile().isDeclarationFile) {
              trustedLibraryFile(trustedLibraryRoot, candidate);
              const declarationSpan = spanOf(context, candidate);
              const globalKey = `${node.text}:${declarationSpan.file}:${declarationSpan.start.offset}:${declarationSpan.end.offset}`;
              runtimeGlobals.set(globalKey, {
                key: globalKey,
                name: node.text,
                declaration: declarationSpan,
              });
              continue;
            }
            const valueId = `${relativePath(repositoryRoot, candidate.getSourceFile().fileName)}#${candidate.name.getText(candidate.getSourceFile())}`;
            assert(LOCAL_RUNTIME_VALUE_IDS.includes(valueId), `Unknown nonlocal runtime variable '${valueId}' at ${declarationLocation(repositoryRoot, candidate)}.`);
            runtimeValues.add(valueId);
          }
        }
      }
      ts.forEachChild(node, inspect);
    }

    inspect(declaration.body);
    dependencies.delete(id);
    dependenciesById.set(id, [...dependencies].sort(compareCodeUnits));
  }

  const sortedStandard = [...standardOperations.values()]
    .map((operation) => ({
      ...operation,
      callSites: operation.callSites.sort((left, right) =>
        compareCodeUnits(canonicalJson(left), canonicalJson(right))),
    }))
    .sort((left, right) => compareCodeUnits(left.key, right.key));
  return {
    declarations,
    dependenciesById,
    standardOperations: sortedStandard,
    runtimeGlobals: [...runtimeGlobals.values()].sort((left, right) => compareCodeUnits(left.key, right.key)),
    runtimeValues: [...runtimeValues].sort(compareCodeUnits),
    reusedDependencies: [...reusedDependencies].sort(compareCodeUnits),
    catalogFoundationDependencies: [...catalogFoundationDependencies].sort(compareCodeUnits),
  };
}

/** Derive one member's exact reachable equation set and shortest catalog-foundation paths. */
function dependencyClosureForMember(rootEquationId, dependenciesById, verifiedCatalogFoundationEquationIds) {
  const reachableEquationIds = new Set();
  const catalogFoundationPathById = new Map();
  const pendingPathById = new Map();
  const queue = [[rootEquationId]];
  while (queue.length > 0) {
    const pathToEquation = queue.shift();
    const equationId = pathToEquation.at(-1);
    if (reachableEquationIds.has(equationId)) continue;
    reachableEquationIds.add(equationId);
    if (CATALOG_FOUNDATION_DEPENDENCY_EQUATION_IDS.has(equationId)) {
      catalogFoundationPathById.set(equationId, pathToEquation);
      if (!verifiedCatalogFoundationEquationIds.has(equationId)) pendingPathById.set(equationId, pathToEquation);
      continue;
    }
    const dependencies = dependenciesById.get(equationId);
    if (dependencies === undefined) {
      assert(REUSED_EQUATION_IDS.has(equationId), `Member closure reached an unclassified equation '${equationId}'.`);
      continue;
    }
    for (const dependencyId of dependencies) {
      queue.push([...pathToEquation, dependencyId]);
    }
  }
  return {
    rootEquationId,
    reachableEquationIds: [...reachableEquationIds].sort(compareCodeUnits),
    catalogFoundationDependencyPaths: [...catalogFoundationPathById]
      .sort(([left], [right]) => compareCodeUnits(left, right))
      .map(([equationId, path_]) => ({ equationId, path: path_ })),
    pendingDependencyPaths: [...pendingPathById]
      .sort(([left], [right]) => compareCodeUnits(left, right))
      .map(([equationId, path_]) => ({ equationId, path: path_ })),
    pathSelection: "Breadth-first over code-unit-sorted direct dependencies; one exact shortest path per pending equation.",
  };
}

/** Return the independent law record for one public or private equation. */
function lawForEquation(id, publicName) {
  let lawId;
  if (publicName !== undefined) {
    lawId = lawIdForPublicImplementation(publicName);
  } else if (id.startsWith("src/events.ts#")) {
    lawId = id.endsWith("assertCanonicalInventoryTime")
      ? "canonical-time-v1"
      : id.includes("Fingerprint") || id.includes("fingerprint") || id.endsWith("traceabilityChangeIdentity")
        ? "event-intent-fingerprint-v1"
        : "event-definition-normalization-v1";
  } else if (id.includes("InventoryOnceReplacementPlan") || id.startsWith("src/facade.ts#")) {
    lawId = id.endsWith("countAdjustment")
      ? "replacement-count-adjustment-v1"
      : id.endsWith("relation")
        ? "replacement-relation-v1"
        : id.includes("QualifiedDimension") || id.includes("requireChangedIdentity") || id.includes("requirePresentIdentity") || id.endsWith("reclassification")
          ? "replacement-property-change-v1"
          : "replacement-plan-construction-v1";
  } else if (id.includes("Transformation") || id.includes("Genealogy")) {
    lawId = "transformation-command-v1";
  } else if (id.includes("Receipt") || id.includes("MovementLines") || id.includes("sorted") || id.includes("collect")) {
    lawId = "many-movement-command-v1";
  } else if (id.includes("Pack") || id.includes("packaging") || id.includes("Packaging")) {
    lawId = "pack-unpack-command-v1";
  } else {
    lawId = "movement-command-v1";
  }
  const law = FAMILY_LAWS.find((candidate) => candidate.id === lawId);
  assert(law !== undefined, `Missing independent law '${lawId}'.`);
  return law;
}

/** Verify the implementation class is the exact runtime object behind the public planner interface. */
function replacementInterfaceRelation({ context, source, callable, implementation, methodName }) {
  const publicMethod = findInterfaceMethod(source, "InventoryOnceReplacementPlans", methodName);
  assert.deepEqual(callable.declaration, spanOf(context, publicMethod), `Public replacement declaration drifted for '${methodName}'.`);
  const owner = implementation.parent;
  assert(ts.isClassDeclaration(owner));
  const implementedTypes = owner.heritageClauses
    ?.filter((clause) => clause.token === ts.SyntaxKind.ImplementsKeyword)
    .flatMap((clause) => clause.types) ?? [];
  const publicOwner = publicMethod.parent;
  assert(ts.isInterfaceDeclaration(publicOwner));
  const publicSymbol = context.checker.getSymbolAtLocation(publicOwner.name);
  assert(
    implementedTypes.some((type) => context.checker.getSymbolAtLocation(type.expression) === publicSymbol),
    "Replacement implementation no longer implements the exact public interface.",
  );
  assert(
    context.checker.isTypeAssignableTo(
      context.checker.getTypeAtLocation(implementation),
      context.checker.getTypeAtLocation(publicMethod),
    ),
    `Replacement implementation '${methodName}' is not assignable to its public declaration.`,
  );
  return {
    kind: "COMPILER_RESOLVED_INTERFACE_IMPLEMENTATION",
    interface: spanOf(context, publicMethod),
    implementation: spanOf(context, implementation),
  };
}

/** Prove the correction callback receives this exact implementation and synthetic operation id. */
function replacementConstructionBridge({ context, source }) {
  const correct = findClassMethod(source, "InventoryOnceStockImplementation", "correct");
  const implementationClass = findClass(source, "InventoryOnceReplacementPlansImplementation");
  const implementationSymbol = context.checker.getSymbolAtLocation(implementationClass.name);
  let construction;
  let callback;

  function visit(node) {
    if (
      ts.isVariableDeclaration(node) &&
      ts.isIdentifier(node.name) &&
      node.name.text === "replacementPlans" &&
      ts.isNewExpression(node.initializer)
    ) {
      assert.equal(construction, undefined, "Replacement implementation is constructed more than once.");
      const symbol = context.checker.getSymbolAtLocation(node.initializer.expression);
      assert(symbol === implementationSymbol, "Correction callback constructs a different planner class.");
      assert.equal(node.initializer.arguments?.length, 2);
      const [catalogArgument, operationArgument] = node.initializer.arguments;
      assert(ts.isPropertyAccessExpression(catalogArgument));
      assert.equal(catalogArgument.expression.getText(source), "internals");
      assert.equal(catalogArgument.name.text, "catalog");
      assert(ts.isTemplateExpression(operationArgument));
      assert.equal(operationArgument.head.text, "");
      assert.equal(operationArgument.templateSpans.length, 1);
      assert.equal(operationArgument.templateSpans[0].expression.getText(source), "input.operationId");
      assert.equal(operationArgument.templateSpans[0].literal.text, ":replacement");
      construction = spanOf(context, node.initializer);
    }
    if (
      ts.isVariableDeclaration(node) &&
      ts.isIdentifier(node.name) &&
      node.name.text === "opaqueReplacement" &&
      ts.isCallExpression(node.initializer) &&
      ts.isPropertyAccessExpression(node.initializer.expression) &&
      node.initializer.expression.name.text === "replaceWith"
    ) {
      assert.equal(callback, undefined, "Replacement callback is invoked more than once.");
      assert.equal(node.initializer.expression.expression.getText(source), "input");
      assert.equal(node.initializer.arguments.length, 1);
      assert.equal(node.initializer.arguments[0].getText(source), "replacementPlans");
      callback = spanOf(context, node.initializer);
    }
    ts.forEachChild(node, visit);
  }
  visit(correct.body);
  assert(construction !== undefined, "Correction no longer constructs the certified replacement planner.");
  assert(callback !== undefined, "Correction no longer passes the certified planner to replaceWith.");
  return {
    kind: "COMPILER_RESOLVED_CORRECTION_CALLBACK_BRIDGE",
    correctMethod: spanOf(context, correct),
    construction,
    callback,
    durableBoundary:
      "The bridge ends at opaque plan construction; commitInventoryOperation and durable publication are not claimed by this value family.",
  };
}

/** Return exact normalized enum/WeakMap declarations used by every source equation. */
function runtimeValueEquations({ repositoryRoot, context, sources, expectedSource }) {
  const values = [];
  const trustedLibraryRoot = fs.realpathSync(
    path.dirname(ts.getDefaultLibFilePath(context.program.getCompilerOptions())),
  );
  for (const id of LOCAL_RUNTIME_VALUE_IDS) {
    const separator = id.indexOf("#");
    const file = id.slice(0, separator);
    const name = id.slice(separator + 1);
    const source = sources.get(file);
    assert(source !== undefined);
    if (name === "replacementEventDrafts") {
      const found = findTopLevelVariable(source, name);
      assert((found.statement.declarationList.flags & ts.NodeFlags.Const) !== 0, "Replacement plan table must remain const-bound.");
      assert(ts.isNewExpression(found.declaration.initializer));
      assert.equal(found.declaration.initializer.expression.getText(source), "WeakMap");
      const runtimeSymbol = resolvedCompilerSymbol(context, found.declaration.initializer.expression);
      assert(runtimeSymbol !== undefined, "WeakMap runtime value must resolve to one compiler symbol.");
      const runtimeDeclarations = runtimeSymbol.declarations ?? [];
      assert(runtimeDeclarations.length > 0, "WeakMap runtime value must have a declaration.");
      for (const runtimeDeclaration of runtimeDeclarations) {
        if (!runtimeDeclaration.getSourceFile().isDeclarationFile) {
          throw new Error(
            `Unknown nonlocal runtime variable '${relativePath(repositoryRoot, runtimeDeclaration.getSourceFile().fileName)}#${runtimeDeclaration.getText(runtimeDeclaration.getSourceFile())}'.`,
          );
        }
        trustedLibraryFile(trustedLibraryRoot, runtimeDeclaration);
      }
      const constructorDeclaration = context.checker
        .getResolvedSignature(found.declaration.initializer)?.declaration;
      assert(constructorDeclaration !== undefined, "WeakMap constructor signature must resolve.");
      trustedLibraryFile(trustedLibraryRoot, constructorDeclaration);
      const expected = findTopLevelVariable(expectedSource, name);
      const term = normalizeEventValueSyntax(found.statement);
      assert.deepEqual(term, normalizeEventValueSyntax(expected.statement), `Independent value equation changed: ${id}`);
      values.push({
        id,
        declaration: spanOf(context, found.statement),
        term,
        runtimeGlobalDeclarations: runtimeDeclarations
          .map((runtimeDeclaration) => spanOf(context, runtimeDeclaration))
          .sort((left, right) => compareCodeUnits(canonicalJson(left), canonicalJson(right))),
        constructorDeclaration: spanOf(context, constructorDeclaration),
        law: "One module-private WeakMap maps only library-created opaque plans to their exact event draft or null omit marker.",
      });
      continue;
    }
    const declaration = findEnum(source, name);
    const expected = findEnum(expectedSource, name);
    const term = normalizeEventValueSyntax(declaration);
    assert.deepEqual(term, normalizeEventValueSyntax(expected), `Independent value equation changed: ${id}`);
    values.push({
      id,
      declaration: spanOf(context, declaration),
      term,
      law: "Every enum member and literal value is retained exactly; changed kind/action identities reject the family.",
    });
  }
  return values.sort((left, right) => compareCodeUnits(left.id, right.id));
}

/** Build one complete 45-key certificate using one supplied compiler context and surface. */
export function buildEventValuesFamilyArtifact({
  repositoryRoot,
  context,
  surface,
  sourceOverrides = new Map(),
}) {
  assert.equal(ASSIGNED_SURFACE_KEYS.length, 45, "Follow-on surface cardinality changed.");
  assert.equal(new Set(ASSIGNED_SURFACE_KEYS).size, 45, "Follow-on surface keys must be unique.");
  assert.equal(surface.digest, EVENT_VALUES_SURFACE_DIGEST, "Event family requires the exact current 535 surface.");

  const expectedSource = parseSource(
    equationProgramPath,
    fs.readFileSync(equationProgramPath, "utf8"),
  );
  assert.equal(expectedSource.parseDiagnostics.length, 0, "Independent equation program has syntax errors.");
  const activeContext = sourceOverrides.size === 0
    ? context
    : loadOverriddenContext(repositoryRoot, sourceOverrides);
  const foundationContext = [...sourceOverrides.keys()].some((file) => catalogFoundationSourceFiles.includes(file))
    ? activeContext
    : context;
  const catalogFoundationReference = loadCatalogFoundationDependencyReference({
    repositoryRoot,
    context: foundationContext,
    surface,
  });
  const currentReusedDependencyAuthority = buildCurrentReusedDependencyAuthority({
    repositoryRoot,
    context: activeContext,
    surface,
  });
  const allSourceFiles = Object.keys(EXPECTED_SOURCE_SHA256).sort(compareCodeUnits);
  const sources = new Map();
  for (const file of allSourceFiles) {
    const text = readSource(repositoryRoot, sourceOverrides, file);
    if (!sourceOverrides.has(file)) {
      assert.equal(sha256(text), EXPECTED_SOURCE_SHA256[file], `Independent equation source changed: ${file}`);
    }
    const source = activeContext.program.getSourceFile(path.resolve(repositoryRoot, file));
    assert(source !== undefined, `Compiler omitted source '${file}'.`);
    sources.set(file, source);
  }

  const localRoots = [];
  const publicImplementations = new Map();
  for (const [name, file] of Object.entries(EXPORTED_FUNCTION_SOURCE)) {
    const declaration = findFunction(sources.get(file), name);
    localRoots.push(declaration);
    publicImplementations.set(name, declaration);
  }
  for (const name of REPLACEMENT_METHOD_NAMES) {
    const declaration = findClassMethod(
      sources.get("src/facade.ts"),
      "InventoryOnceReplacementPlansImplementation",
      name,
    );
    localRoots.push(declaration);
    publicImplementations.set(name, declaration);
  }
  localRoots.push(findClassConstructor(
    sources.get("src/facade.ts"),
    "InventoryOnceReplacementPlanImplementation",
  ));

  const closure = verifyDependencyClosure({ repositoryRoot, context: activeContext, roots: localRoots });
  for (const required of CATALOG_FOUNDATION_DEPENDENCY_EQUATION_IDS) {
    assert(
      closure.catalogFoundationDependencies.includes(required),
      `Declared-domain catalog-foundation dependency disappeared: ${required}`,
    );
  }
  assert.equal(expectedCallableCount(expectedSource), closure.declarations.size, "Independent equation program/local helper closure cardinality changed.");
  const expectedTermsById = new Map();
  for (const [id, declaration] of closure.declarations) {
    const expectedDeclaration = findExpectedCallable(expectedSource, id);
    validateCallableSyntax(expectedDeclaration);
    const actualTerm = normalizeEventValueSyntax(declaration);
    const expectedTerm = normalizeEventValueSyntax(expectedDeclaration);
    assert.deepEqual(actualTerm, expectedTerm, `Independent source equation changed: ${id}`);
    expectedTermsById.set(id, expectedTerm);
  }

  const lawById = new Map(FAMILY_LAWS.map((law) => [law.id, law]));
  const memberEquations = [];
  for (const [name, declaration] of publicImplementations) {
    const id = declarationId(repositoryRoot, declaration);
    const law = lawForEquation(id, name);
    assert.equal(lawById.get(law.id), law);
    const term = expectedTermsById.get(id);
    assert(term !== undefined);
    memberEquations.push({
      id,
      publicName: name,
      declaration: spanOf(activeContext, declaration),
      law,
      term,
      equationSha256: sha256(canonicalJson(term)),
      dependencies: closure.dependenciesById.get(id) ?? [],
    });
  }
  memberEquations.sort((left, right) => compareCodeUnits(left.id, right.id));

  const memberIds = new Set(memberEquations.map((equation) => equation.id));
  const helperEquations = [...closure.declarations]
    .filter(([id]) => !memberIds.has(id))
    .map(([id, declaration]) => {
      const law = lawForEquation(id);
      const term = expectedTermsById.get(id);
      assert(term !== undefined);
      return {
        id,
        declaration: spanOf(activeContext, declaration),
        law,
        term,
        equationSha256: sha256(canonicalJson(term)),
        dependencies: closure.dependenciesById.get(id) ?? [],
      };
    })
    .sort((left, right) => compareCodeUnits(left.id, right.id));
  const dependenciesByEquationId = new Map(
    [...memberEquations, ...helperEquations]
      .map((equation) => [equation.id, equation.dependencies]),
  );

  const publicSurface = new Map(surface.callables.map((callable) => [callable.key, callable]));
  const facadeSource = sources.get("src/facade.ts");
  const plannerBridge = sourceOverrides.size === 0
    ? replacementConstructionBridge({ context: activeContext, source: facadeSource })
    : { kind: "MUTATION_CONTROL_ONLY" };
  const proofs = [];
  for (const surfaceKey of ASSIGNED_SURFACE_KEYS) {
    const callable = publicSurface.get(surfaceKey);
    assert(callable !== undefined, `Compiler omitted assigned callable '${surfaceKey}'.`);
    let name;
    let implementation;
    let relation;
    const exported = /^export:\.\/kernel#([^:]+)::call\[0\]$/u.exec(surfaceKey);
    if (exported !== null) {
      name = exported[1];
      implementation = publicImplementations.get(name);
      assert(implementation !== undefined);
      if (sourceOverrides.size === 0) {
        assert.deepEqual(callable.declaration, spanOf(activeContext, implementation), `Export declaration drifted for '${surfaceKey}'.`);
        assert(callable.reachabilityPaths.includes(`export:./kernel#${name}`));
      }
      relation = sourceOverrides.size === 0
        ? { kind: "COMPILER_RESOLVED_EXACT_EXPORT", implementation: spanOf(activeContext, implementation) }
        : { kind: "MUTATION_CONTROL_ONLY" };
    } else {
      const planner = /^type:src\/facade\.ts#InventoryOnceReplacementPlans\.([^:]+)::call\[0\]$/u.exec(surfaceKey);
      assert(planner !== null, `Unexpected assigned key '${surfaceKey}'.`);
      name = planner[1];
      implementation = publicImplementations.get(name);
      assert(implementation !== undefined);
      relation = sourceOverrides.size === 0
        ? {
            ...replacementInterfaceRelation({
              context: activeContext,
              source: facadeSource,
              callable,
              implementation,
              methodName: name,
            }),
            bridge: plannerBridge,
          }
        : { kind: "MUTATION_CONTROL_ONLY" };
    }
    const equationId = declarationId(repositoryRoot, implementation);
    const equation = memberEquations.find((candidate) => candidate.id === equationId);
    assert(equation !== undefined);
    const dependencyClosure = dependencyClosureForMember(
      equationId,
      dependenciesByEquationId,
      catalogFoundationReference.verifiedEquationIds,
    );
    const allAdmittedInputs = dependencyClosure.pendingDependencyPaths.length === 0;
    proofs.push({
      surfaceKey,
      mode: "V",
      signature: callable.signature,
      signatureHash: callable.signatureHash,
      declaration: callable.declaration,
      implementation: spanOf(activeContext, implementation),
      relation,
      equationId,
      equationSha256: equation.equationSha256,
      lawId: equation.law.id,
      dependencyClosure,
      allAdmittedInputs,
      creditDisposition: !allAdmittedInputs
        ? "PENDING_CATALOG_FOUNDATION_DEPENDENCIES"
        : surfaceKey === "export:./kernel#commitInventoryEvent::call[0]"
          ? "NO_DOUBLE_CREDIT_IF_CONCURRENT_PHYSICALCOUNT_A_EXISTS"
          : "NEW_VALUE_CANDIDATE",
    });
  }

  const locallyClosedSurfaceKeys = proofs
    .filter((proof) => proof.dependencyClosure.catalogFoundationDependencyPaths.length === 0)
    .map((proof) => proof.surfaceKey);
  assert.deepEqual(
    locallyClosedSurfaceKeys,
    LOCALLY_CLOSED_SURFACE_KEYS,
    "Member-specific catalog dependency closure changed.",
  );
  const admittedSurfaceKeys = proofs
    .filter((proof) => proof.allAdmittedInputs)
    .map((proof) => proof.surfaceKey);
  const pendingSurfaceKeys = proofs
    .filter((proof) => !proof.allAdmittedInputs)
    .map((proof) => proof.surfaceKey);
  const catalogFoundationAffectedSurfaceKeys = proofs
    .filter((proof) => proof.dependencyClosure.catalogFoundationDependencyPaths.length > 0)
    .map((proof) => proof.surfaceKey);
  const fullFamilyAllAdmittedInputs = pendingSurfaceKeys.length === 0;

  const runtimeValues = runtimeValueEquations({
    repositoryRoot,
    context: activeContext,
    sources,
    expectedSource,
  });
  const semanticInputFiles = [
    ...allSourceFiles,
    ...producerFiles,
    ...catalogFoundationReference.artifact.inputs.map((input) => input.file),
    ...currentReusedDependencyAuthority.inputs.map((input) => input.file),
    ...closure.standardOperations.map((operation) => operation.declaration.file),
    ...closure.runtimeGlobals.map((global) => global.declaration.file),
    ...runtimeValues.flatMap((value) => [
      ...(value.runtimeGlobalDeclarations ?? []).map((declaration) => declaration.file),
      ...(value.constructorDeclaration === undefined ? [] : [value.constructorDeclaration.file]),
    ]),
  ];
  const inputs = [...new Set(semanticInputFiles)]
    .sort(compareCodeUnits)
    .map((file) => ({
      file,
      sha256: sha256(sourceOverrides.get(file) ?? fs.readFileSync(path.resolve(repositoryRoot, file))),
    }));

  const semanticCore = {
    proofKind: EVENT_VALUES_PROOF_KIND,
    sourceBase: EVENT_VALUES_SOURCE_BASE,
    domain: FAMILY_DOMAIN,
    laws: FAMILY_LAWS,
    reusedDependencyFamilies: REUSED_DEPENDENCY_FAMILIES,
    currentReusedDependencyAuthority: {
      verifiedEquationIds: currentReusedDependencyAuthority.verifiedEquationIds,
      providers: currentReusedDependencyAuthority.providers,
      families: currentReusedDependencyAuthority.families,
      activeItem: currentReusedDependencyAuthority.activeItem,
    },
    catalogFoundationDependency: {
      ...catalogFoundationReference.reference,
      equationIds: closure.catalogFoundationDependencies,
      affectedSurfaceKeys: catalogFoundationAffectedSurfaceKeys,
      relation: catalogFoundationReference.verified
        ? "VERIFIED_REGISTERED_SOURCE_EQUATION_REFERENCE"
        : "PENDING_REGISTERED_SOURCE_EQUATION_REFERENCE",
    },
    reusedEquationIds: closure.reusedDependencies,
    inputs,
    runtimeValues,
    runtimeGlobals: closure.runtimeGlobals,
    standardOperations: closure.standardOperations,
    memberEquations,
    helperEquations,
    memberDependencyClosures: proofs.map((proof) => ({
      surfaceKey: proof.surfaceKey,
      allAdmittedInputs: proof.allAdmittedInputs,
      ...proof.dependencyClosure,
    })),
    admissionPartition: {
      assignedSurfaceKeys: ASSIGNED_SURFACE_KEYS,
      locallyClosedSurfaceKeys,
      admittedSurfaceKeys,
      pendingSurfaceKeys,
    },
    replacementConstructionBridge: plannerBridge,
    durablePublicationClaimed: false,
    overlapPolicy: {
      surfaceKey: "export:./kernel#commitInventoryEvent::call[0]",
      rule: "A concurrent/existing PhysicalCount A admission wins; this V equation may strengthen provenance but is never counted as a second callable.",
    },
  };
  const certificateId = `VALUE_CERTIFICATE_FAMILY:sha256:${sha256(canonicalJson(semanticCore))}`;
  return {
    schemaVersion: 1,
    mode: "V",
    proofKind: EVENT_VALUES_PROOF_KIND,
    certificateId,
    surfaceDigest: surface.digest,
    allAdmittedInputs: fullFamilyAllAdmittedInputs,
    sampledInputs: 0,
    inputs,
    domain: FAMILY_DOMAIN,
    semanticCore,
    proofs,
  };
}

/** Project the complete derivation to only members whose own inputs are admitted. */
function registeredArtifactFromCompleteFamily(completeArtifact) {
  if (completeArtifact.allAdmittedInputs) return completeArtifact;
  const proofs = completeArtifact.proofs.filter((proof) => proof.allAdmittedInputs);
  assert(proofs.length > 0, "No independently closed event-family member is available.");
  const registeredSurfaceKeys = proofs.map((proof) => proof.surfaceKey);
  assert.deepEqual(registeredSurfaceKeys, LOCALLY_CLOSED_SURFACE_KEYS);
  const semanticCore = {
    ...completeArtifact.semanticCore,
    registrationScope: {
      kind: "MEMBER_SPECIFIC_TRANSITIVE_CLOSURE_SUBSET",
      completeFamilyCertificateId: completeArtifact.certificateId,
      registeredSurfaceKeys,
      pendingSurfaceKeys: completeArtifact.proofs
        .filter((proof) => !proof.allAdmittedInputs)
        .map((proof) => proof.surfaceKey),
      allRegisteredMemberInputsAdmitted: true,
    },
  };
  return {
    ...completeArtifact,
    certificateId: `VALUE_CERTIFICATE_FAMILY:sha256:${sha256(canonicalJson(semanticCore))}`,
    allAdmittedInputs: true,
    semanticCore,
    proofs,
  };
}

/** Hub-compatible builder derives the complete family once and returns its closed registration. */
export function buildFamilyArtifact(arguments_) {
  return registeredArtifactFromCompleteFamily(familyArtifactForCompilerPass(arguments_));
}

/** Trusted catalogue-foundation verification closes the complete exact 45-member assignment. */
export const supportedSurfaceKeys = ASSIGNED_SURFACE_KEYS;

/** Return whether every cached semantic input still has its exact recorded bytes. */
function cachedInputsAreFresh(repositoryRoot, inputs) {
  return inputs.every((input) =>
    sha256(fs.readFileSync(path.resolve(repositoryRoot, input.file))) === input.sha256);
}

/** Rebuild one family once per compiler pass and never once per alias. */
export function familyArtifactForCompilerPass({ repositoryRoot, context, surface }) {
  const cached = familyPassCache.get(context);
  if (
    cached !== undefined &&
    cached.surfaceDigest === surface.digest &&
    cachedInputsAreFresh(repositoryRoot, cached.artifact.inputs)
  ) {
    return cached.artifact;
  }
  const artifact = buildEventValuesFamilyArtifact({ repositoryRoot, context, surface });
  familyPassCache.set(context, { surfaceDigest: surface.digest, artifact });
  return artifact;
}
