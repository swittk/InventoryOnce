import {
  buildFamilyArtifact,
  supportedSurfaceKeys,
} from "./certificate.mjs";
import { EVENT_VALUES_PROOF_KIND } from "./contracts.mjs";

/** Trusted code registration consumed by throughput-r7's whole-family V verifier. */
export const eventValuesRegistration = Object.freeze({
  proofKind: EVENT_VALUES_PROOF_KIND,
  buildFamilyArtifact,
  supportedSurfaceKeys,
});

/** Named exports let the hub register this family without an evidence-selected code path. */
export { buildFamilyArtifact, supportedSurfaceKeys };

/** Named proof kind prevents evidence bytes from choosing their own verifier. */
export { EVENT_VALUES_PROOF_KIND as proofKind };
