import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { discoverCompilerSurface, sha256 } from "../surface-bindings/lib/compiler-surface.mjs";
import { loadEvidenceCompilerContext } from "../surface-bindings/lib/binding-checker.mjs";
import { verifyRegisteredValueBinding } from "../throughput-r7/registered-value-family.mjs";
import { verifyRegisteredProducerBinding } from "../throughput-r7/registered-producer-family.mjs";
import {
  buildFinalValueArtifact,
  buildFinalProducerArtifact,
  valueProofKind,
  producerProofKind,
  supportedValueKeys,
  supportedProducerRows,
} from "./final-families.mjs";
import { finalConvergenceRepositoryPath, finalConvergenceRepositoryRoot } from "./repository-root.mjs";

export function runFinalAdversarialChecks(ROOT, context) {
const VALUE_FILE = "experiments/tla-conformance/final-convergence/final-v309.json";
const PRODUCER_FILE = "experiments/tla-conformance/final-convergence/final-a121-b58.json";
const surface = context.surface;
const valueRegistration = Object.freeze({ proofKind: valueProofKind, buildFamilyArtifact: buildFinalValueArtifact, supportedSurfaceKeys: supportedValueKeys });
const producerRegistration = Object.freeze({ proofKind: producerProofKind, buildFamilyArtifact: buildFinalProducerArtifact, supportedSurfaceRows: supportedProducerRows });
function evidence(file) { return { file, sha256: sha256(fs.readFileSync(path.resolve(ROOT, file))) }; }
function writeTemp(name, document) { const file = `experiments/tla-conformance/final-convergence/${name}`; fs.writeFileSync(finalConvergenceRepositoryPath(ROOT, file), `${JSON.stringify(document, null, 2)}\n`); return file; }
const valueEvidence = evidence(VALUE_FILE);
const producerEvidence = evidence(PRODUCER_FILE);
const valueKey = supportedValueKeys[0];
const producerA = supportedProducerRows.find((row) => row.mode === "A");
const producerB = supportedProducerRows.find((row) => row.mode === "B");
assert(producerA !== undefined && producerB !== undefined);

assert.deepEqual(verifyRegisteredValueBinding({ repositoryRoot: ROOT, context, surface, binding: { surfaceKey: valueKey, mode: "V", evidence: valueEvidence }, registrations: [valueRegistration] }), []);
assert.equal(verifyRegisteredValueBinding({ repositoryRoot: ROOT, context, surface, binding: { surfaceKey: valueKey, mode: "A", evidence: valueEvidence }, registrations: [valueRegistration] })[0]?.code, "VALUE_FAMILY_PROOF_REJECTED");
const tamperedValue = JSON.parse(fs.readFileSync(finalConvergenceRepositoryPath(ROOT, VALUE_FILE), "utf8"));
tamperedValue.proofs[0].semantics = { ...tamperedValue.proofs[0].semantics, finalConvergenceTamper: true };
const tamperedValueFile = writeTemp(".tampered-v309.json", tamperedValue);
try {
  assert.equal(verifyRegisteredValueBinding({ repositoryRoot: ROOT, context, surface, binding: { surfaceKey: tamperedValue.proofs[0].surfaceKey, mode: "V", evidence: evidence(tamperedValueFile) }, registrations: [valueRegistration] })[0]?.code, "VALUE_FAMILY_PROOF_REJECTED");
} finally { fs.rmSync(finalConvergenceRepositoryPath(ROOT, tamperedValueFile), { force: true }); }

for (const row of [producerA, producerB]) {
  assert.deepEqual(verifyRegisteredProducerBinding({ repositoryRoot: ROOT, context, surface, binding: { surfaceKey: row.surfaceKey, mode: row.mode, evidence: producerEvidence }, registrations: [producerRegistration] }), []);
}
assert.equal(verifyRegisteredProducerBinding({ repositoryRoot: ROOT, context, surface, binding: { surfaceKey: producerA.surfaceKey, mode: producerA.mode === "A" ? "B" : "A", evidence: producerEvidence }, registrations: [producerRegistration] })[0]?.code, "REGISTERED_PRODUCER_PROOF_REJECTED");
const tamperedProducer = JSON.parse(fs.readFileSync(finalConvergenceRepositoryPath(ROOT, PRODUCER_FILE), "utf8"));
tamperedProducer.proofs[0].semantics = { ...tamperedProducer.proofs[0].semantics, finalConvergenceTamper: true };
const tamperedProducerFile = writeTemp(".tampered-a121-b58.json", tamperedProducer);
try {
  const row = tamperedProducer.proofs[0];
  assert.equal(verifyRegisteredProducerBinding({ repositoryRoot: ROOT, context, surface, binding: { surfaceKey: row.surfaceKey, mode: row.mode, evidence: evidence(tamperedProducerFile) }, registrations: [producerRegistration] })[0]?.code, "REGISTERED_PRODUCER_PROOF_REJECTED");
} finally { fs.rmSync(finalConvergenceRepositoryPath(ROOT, tamperedProducerFile), { force: true }); }

/** Every frozen authority/cohort file must be independently pinned even if the caller can re-sign proposed final evidence. */
for (const [file, buildArtifact] of [
  ["authority-producer17.json", buildFinalProducerArtifact],
  ["authority-value3.json", buildFinalValueArtifact],
  ["r137-v15.json", buildFinalValueArtifact],
  ["readworld-producer24.json", buildFinalProducerArtifact],
  ["wrapper-producer11.json", buildFinalProducerArtifact],
  ["r170-pristine-repro-transport.json", buildFinalProducerArtifact],
]) {
  const target = finalConvergenceRepositoryPath(ROOT, `experiments/tla-conformance/final-convergence/${file}`);
  const original = fs.readFileSync(target), times = fs.statSync(target);
  try {
    const forged = JSON.parse(original.toString("utf8"));
    if (Array.isArray(forged.proofs)) forged.proofs[0].semantics = { ...forged.proofs[0].semantics, systemicUnprovedAuthority: true };
    else { forged.affectedStrictRows = []; const {contentSha256, ...core} = forged; forged.contentSha256 = sha256(JSON.stringify(core)); }
    fs.writeFileSync(target, `${JSON.stringify(forged, null, 2)}\n`);
    fs.utimesSync(target, times.atime, times.mtime);
    assert.throws(() => buildArtifact({ repositoryRoot: ROOT, context, surface }), /Frozen assurance evidence differs from immutable proof input/u, `Re-signed ${file} must not acquire proof credit.`);
  } finally { fs.writeFileSync(target, original); fs.utimesSync(target, times.atime, times.mtime); }
}

return { status: "FINAL_CONVERGENCE_ADVERSARIAL_PASS", surfaceDigest: surface.digest, valueRows: supportedValueKeys.length, producerRows: supportedProducerRows.length, controls: { honestValueAccepted: true, wrongValueModeRejected: true, resignedValueTamperRejected: true, honestAandBAccepted: true, wrongProducerModeRejected: true, resignedProducerTamperRejected: true, immutableHistoricalAuthorityTamperRejected: true, sameMtimeEvidenceDriftRejected: true } };
}
