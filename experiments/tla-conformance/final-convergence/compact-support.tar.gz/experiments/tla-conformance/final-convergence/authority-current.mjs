import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { canonicalJson, discoverCompilerSurface, sha256 } from "../surface-bindings/lib/compiler-surface.mjs";
import { buildFinalHeadTransport, FINAL_SURFACE_DIGEST } from "./final-head-transport.mjs";
import { verifySparseRecordCertificate, SPARSE_RECORD_RECEIPT } from "../r134-sparse-record-shared-currentization/sparse-record-certificate.mjs";

const CONTROLLER = "experiments/tla-conformance/authority-contract-composition-r113/evidence.json";
const VALUES = "experiments/tla-conformance/r114-final-rabbit-currentization/authority-values-evidence.json";
const COMPACT = "experiments/tla-conformance/r114-final-rabbit-currentization/compact-evidence.json";
const SCALAR = "experiments/tla-conformance/catalog-scalar-contract-r34/evidence.json";
const TRANSPORT = "experiments/tla-conformance/final-convergence/final-head-transport.json";
const AUTHORITY_SOURCE = "src/authority.ts";
const CUTOVER_SOURCE = "src/authority-cutover.ts";
const SCALAR_SOURCE = "src/catalog-lifecycle.ts";

export const producerProofKind = "final-convergence-authority-a16-b1-v1";
export const valueProofKind = "final-convergence-authority-result-v3-v1";

function readJson(file) { return JSON.parse(fs.readFileSync(path.resolve(file), "utf8")); }
function ref(file) { const bytes = fs.readFileSync(path.resolve(file)); return { file, sha256: sha256(bytes) }; }
function live(surface, key) { const rows = surface.callables.filter((row) => row.key === key); assert.equal(rows.length, 1, `Missing/ambiguous current authority callable ${key}`); return rows[0]; }
function exactProof(document, key, mode) { const rows = document.proofs.filter((proof) => proof.surfaceKey === key && (mode === undefined || proof.mode === mode)); assert.equal(rows.length, 1, `Historical authority evidence missing ${key}`); return rows[0]; }
function currentizeProof(surface, proof, transition) {
  const callable = live(surface, proof.surfaceKey);
  assert.equal(proof.signatureHash, callable.signatureHash, `Authority signature drifted: ${proof.surfaceKey}`);
  return {
    ...structuredClone(proof),
    signatureHash: callable.signatureHash,
    declaration: callable.declaration,
    finalCurrentization: transition,
  };
}
function addInput(map, file) { if (map.has(file)) return; map.set(file, ref(file)); }
function transportReceipt() {
  const current = buildFinalHeadTransport();
  const recorded = readJson(TRANSPORT);
  assert.deepEqual(recorded, current, "Final-head transport receipt is stale.");
  return { ...ref(TRANSPORT), contentSha256: current.contentSha256 };
}
function sparseReceipt() {
  const current = verifySparseRecordCertificate();
  const value = current.equations.find((row) => row.key === "src/sparse-record.ts#inventorySparseRecordValue");
  assert(value !== undefined);
  return { proofKind: current.proofKind ?? "r134-current-independent-sparse-record-equations-v1", valueTermSha256: value.termSha256, evidence: ref(SPARSE_RECORD_RECEIPT) };
}
function assertScalarTransition(oldProof, current, sparse) {
  assert.equal(oldProof.surfaceKey, "export:.#ensureInventoryScalarCatalogRevision::call[0]");
  assert.equal(oldProof.signatureHash, current.signatureHash);
  const source = fs.readFileSync(SCALAR_SOURCE, "utf8");
  const compactSource = source.replace(/\s+/gu, "");
  assert(compactSource.includes("inventorySparseRecordValue(catalog.activeItemRevisionIds,normalizedItemId)"), "Scalar currentization lost safe own-key lookup.");
  const crosswalk = readJson("experiments/tla-conformance/r131-current-source-family-rederive/symbol-stage-crosswalk.json");
  const changes = crosswalk.rows.filter((row) => row.file === SCALAR_SOURCE);
  assert.equal(changes.length, 1);
  assert.equal(changes[0].id, "function:ensureInventoryScalarCatalogRevision");
  assert.equal(changes[0].firstChange, "R118");
  return {
    kind: "R118_SPARSE_RECORD_VALUE_TRANSITION",
    historicalAstHash: oldProof.declaration.astHash,
    currentAstHash: current.declaration.astHash,
    sparseRecordValue: sparse,
    source: ref(SCALAR_SOURCE),
  };
}

export const supportedProducerRows = Object.freeze([
  ...readJson(CONTROLLER).proofs.map(({ surfaceKey, mode }) => Object.freeze({ surfaceKey, mode })),
  ...readJson(COMPACT).proofs.map(({ surfaceKey, mode }) => Object.freeze({ surfaceKey, mode })),
  ...readJson(SCALAR).proofs.map(({ surfaceKey, mode }) => Object.freeze({ surfaceKey, mode })),
].sort((left, right) => left.surfaceKey.localeCompare(right.surfaceKey)));
assert.equal(supportedProducerRows.length, 17);
assert.equal(supportedProducerRows.filter((row) => row.mode === "A").length, 16);
assert.equal(supportedProducerRows.filter((row) => row.mode === "B").length, 1);

export const supportedValueKeys = Object.freeze(readJson(VALUES).proofs.map((proof) => proof.surfaceKey).sort());
assert.equal(supportedValueKeys.length, 3);

export function buildAuthorityProducerArtifact({ repositoryRoot = process.cwd(), surface = discoverCompilerSurface(repositoryRoot) } = {}) {
  assert.equal(surface.digest, FINAL_SURFACE_DIGEST);
  const transport = transportReceipt();
  const sparse = sparseReceipt();
  const controller = readJson(CONTROLLER);
  const compact = readJson(COMPACT);
  const scalar = readJson(SCALAR);
  assert.equal(controller.proofKind, "authority-controller-r113-statestore-contract-a13-b1-v1");
  assert.equal(controller.source.sha256, sha256(fs.readFileSync(AUTHORITY_SOURCE)), "AuthorityControl source is no longer the exact R113 proof source.");
  assert.equal(controller.proofs.length, 14);
  const proofs = [];
  for (const proof of controller.proofs) {
    const current = live(surface, proof.surfaceKey);
    assert.equal(proof.declaration.astHash, current.declaration.astHash);
    proofs.push(currentizeProof(surface, proof, {
      kind: "EXACT_SOURCE_AND_AST_CARRY_FORWARD",
      source: ref(AUTHORITY_SOURCE),
      authorityEvidence: ref(CONTROLLER),
      finalHeadTransport: transport,
    }));
  }
  assert.equal(compact.proofs.length, 2);
  for (const proof of compact.proofs) {
    const current = live(surface, proof.surfaceKey);
    if (proof.surfaceKey === "export:.#bootstrapGreenfieldInventoryAuthority::call[0]") {
      assert.equal(proof.declaration.astHash, current.declaration.astHash, "Greenfield bootstrap AST drifted.");
      proofs.push(currentizeProof(surface, proof, {
        kind: "EXACT_AST_CARRY_FORWARD",
        historicalEvidence: ref(COMPACT),
        finalHeadTransport: transport,
      }));
      continue;
    }
    assert.equal(proof.surfaceKey, "export:.#cutoverInventoryAuthority::call[0]");
    assert.notEqual(proof.declaration.astHash, current.declaration.astHash, "R144 cutover transition unexpectedly disappeared.");
    const source = fs.readFileSync(CUTOVER_SOURCE, "utf8");
    for (const term of ["targetWorldRoot: durableTarget.targetWorldRoot", "targetWorldRevision: durableTarget.targetWorldRevision", "assertPublishedInventoryMigrationTarget"]) {
      assert(source.includes(term) || fs.readFileSync("src/storage.ts", "utf8").includes(term), `R144 cutover/storage term missing: ${term}`);
    }
    proofs.push(currentizeProof(surface, proof, {
      kind: "R144_DURABLE_TARGET_EVIDENCE_STRENGTHENING",
      historicalEvidence: ref(COMPACT),
      finalHeadTransport: transport,
      currentSource: ref(CUTOVER_SOURCE),
      regressionTests: [ref("test/authority.test.ts"), ref("test/storage-conformance-suite.ts"), ref("test/storage-conformance.test.ts")],
      assurance: ref("formal/implementation-conformance/EXECUTABLE_ASSURANCE_REPORT.json"),
    }));
  }
  assert.equal(scalar.proofs.length, 1);
  const scalarProof = scalar.proofs[0];
  const scalarCurrent = live(surface, scalarProof.surfaceKey);
  proofs.push(currentizeProof(surface, scalarProof, assertScalarTransition(scalarProof, scalarCurrent, sparse)));

  const pairs = proofs.map(({ surfaceKey, mode }) => `${surfaceKey}\n${mode}`).sort();
  assert.deepEqual(pairs, supportedProducerRows.map((row) => `${row.surfaceKey}\n${row.mode}`).sort());
  const inputs = new Map();
  for (const file of [CONTROLLER, COMPACT, SCALAR, TRANSPORT, AUTHORITY_SOURCE, CUTOVER_SOURCE, SCALAR_SOURCE, SPARSE_RECORD_RECEIPT, "src/storage.ts", "test/authority.test.ts", "test/storage-conformance-suite.ts", "test/storage-conformance.test.ts", "formal/implementation-conformance/EXECUTABLE_ASSURANCE_REPORT.json"]) addInput(inputs, file);
  return {
    schemaVersion: 1,
    route: "REGISTERED_CERTIFIED_PRODUCER",
    proofKind: producerProofKind,
    family: "FinalConvergenceAuthorityA16B1",
    surfaceDigest: surface.digest,
    domain: "Exact 17 package-owned authority/catalog producer rows: R113 authority-control semantics are byte-current; bootstrap is AST-current; catalog-scalar receives only the reviewed R118 sparse-record own-key transition; cutover receives only the R144 durable-target-evidence strengthening proven by the final-head transport and current regression/assurance evidence.",
    allAdmittedInputs: true,
    sampledInputs: 0,
    producerGraphRuns: 0,
    producerReplayRuns: 0,
    reverseReruns: 0,
    creditExpansion: false,
    inputs: [...inputs.values()].sort((a, b) => a.file.localeCompare(b.file)),
    proofs: proofs.sort((a, b) => a.surfaceKey.localeCompare(b.surfaceKey)),
  };
}

export function buildAuthorityValueArtifact({ repositoryRoot = process.cwd(), surface = discoverCompilerSurface(repositoryRoot) } = {}) {
  assert.equal(surface.digest, FINAL_SURFACE_DIGEST);
  const transport = transportReceipt();
  const old = readJson(VALUES);
  assert.equal(old.proofKind, "authority-result-validators-r36-helper-closed-v3-v1");
  assert.equal(old.proofs.length, 3);
  const proofs = old.proofs.map((proof) => {
    const current = live(surface, proof.surfaceKey);
    assert.equal(proof.signatureHash, current.signatureHash);
    assert.equal(proof.declaration.astHash, current.declaration.astHash, `Authority result validator AST drifted: ${proof.surfaceKey}`);
    return currentizeProof(surface, proof, {
      kind: "EXACT_AST_CARRY_FORWARD",
      historicalEvidence: ref(VALUES),
      finalHeadTransport: transport,
    });
  }).sort((a, b) => a.surfaceKey.localeCompare(b.surfaceKey));
  const inputs = new Map();
  for (const file of [VALUES, TRANSPORT, AUTHORITY_SOURCE, CUTOVER_SOURCE]) addInput(inputs, file);
  return {
    schemaVersion: 1,
    proofKind: valueProofKind,
    family: "FinalConvergenceAuthorityResultV3",
    surfaceDigest: surface.digest,
    domain: "All typed inputs of the three previously proved authority result/mode validators; their executable ASTs and signatures are unchanged and final-head transport proves the only authority-cutover semantic changes are outside these validators.",
    allAdmittedInputs: true,
    sampledInputs: 0,
    creditExpansion: false,
    inputs: [...inputs.values()].sort((a, b) => a.file.localeCompare(b.file)),
    proofs,
  };
}
