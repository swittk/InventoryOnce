import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { discoverCompilerSurface, sha256 } from "../surface-bindings/lib/compiler-surface.mjs";
import { buildFinalHeadTransport, FINAL_SURFACE_DIGEST } from "./final-head-transport.mjs";

export const proofKind = "final-convergence-wrapper-a11-v1";
const FILES = Object.freeze([
  "experiments/tla-conformance/throughput-r7/evidence/queue-reservation-replacement-a2-producer.json",
  "experiments/tla-conformance/throughput-r7/evidence/queue-direct-transfer-a2-producer.json",
  "experiments/tla-conformance/throughput-r7/evidence/queue-correction-composed-a2-producer.json",
  "experiments/tla-conformance/throughput-r7/evidence/queue-surface-count-abandon-a1-producer.json",
  "experiments/tla-conformance/throughput-r7/evidence/queue-trace-removal-a2-producer.json",
  "experiments/tla-conformance/throughput-r7/evidence/queue-transfer-adapter-a2-producer.json",
]);
const EXPECTED = Object.freeze(new Map([
  ["reservation-allocation-replacement-refine-a2-v1", 2],
  ["stateful-facade-direct-transfer-residual-a2-v1", 2],
  ["stateful-facade-metadata-correction-composed-a2-v2", 2],
  ["surface-residual-final-count-abandon-a1-v1", 1],
  ["traceability-public-removal-direct-producer-a2-v1", 2],
  ["transfer-wrapper-direct-producer-a2-v1", 2],
]));
const BASE_INDEX="experiments/tla-conformance/final-convergence/base-authority-index.json";
const OFFICIAL="experiments/tla-conformance/r105-layered-6dfc-currentization/surface-bindings-6dfc.json";
const R137="experiments/tla-conformance/final-convergence/r137-v15.json";
const R163_WHOLE="experiments/tla-conformance/r163-r147-whole-trace-peer/WholeContainerA4.current.json";
const R163_RECEIPT="experiments/tla-conformance/r163-r147-whole-trace-peer/receipt.json";
const TRANSPORT="experiments/tla-conformance/final-convergence/final-head-transport.json";
const TRACE_MODEL="formal/TraceabilityGraph.tla";
const PACKAGING_MODEL="formal/PackagingIdentity.tla";
const RECLASS_MODEL="formal/ReclassificationConservation.tla";
const HISTORICAL_PACKAGING_SHA="3320a170b3584a2811e6a48b09d52d3cc43b4585c3129a65c49cd9086eb4b9e2";
function readJson(file){return JSON.parse(fs.readFileSync(path.resolve(file),"utf8"));}
function ref(file){const bytes=fs.readFileSync(path.resolve(file));return{file,sha256:sha256(bytes)};}
function canonical(value){if(Array.isArray(value))return`[${value.map(canonical).join(",")}]`;if(value!==null&&typeof value==="object")return`{${Object.keys(value).sort().map(k=>`${JSON.stringify(k)}:${canonical(value[k])}`).join(",")}}`;return JSON.stringify(value);}
function live(surface,key){const rows=surface.callables.filter(r=>r.key===key);assert.equal(rows.length,1,`Missing current wrapper callable ${key}`);return rows[0];}
const docs=FILES.map(readJson);
export const supportedSurfaceRows=Object.freeze(docs.flatMap(a=>a.proofs.map(({surfaceKey,mode})=>Object.freeze({surfaceKey,mode}))).sort((a,b)=>a.surfaceKey.localeCompare(b.surfaceKey)));
assert.equal(supportedSurfaceRows.length,11);assert(supportedSurfaceRows.every(r=>r.mode==="A"));
const own=new Set(supportedSurfaceRows.map(r=>r.surfaceKey));
function transportReceipt(){const b=buildFinalHeadTransport(),r=readJson(TRANSPORT);assert.deepEqual(r,b);return{...ref(TRANSPORT),contentSha256:b.contentSha256};}
function dependencyKeys(proof,official){const found=new Set();function walk(v){if(Array.isArray(v)){v.forEach(walk);return}if(!v||typeof v!=="object")return;if(typeof v.surfaceKey==="string"&&official.has(v.surfaceKey))found.add(v.surfaceKey);Object.values(v).forEach(walk)}walk(proof.semantics??proof);return[...found].sort();}
function resolveBase(key,mode,index,surface,inputs,transport){const row=index.get(key);assert(row!==undefined,`Wrapper dependency lacks base authority: ${key}`);assert.equal(row.mode,mode);const a=row.authority,bytes=fs.readFileSync(path.resolve(a.evidence.file));assert.equal(sha256(bytes),a.evidence.sha256);inputs.set(a.evidence.file,a.evidence);const d=JSON.parse(bytes.toString("utf8"));let recorded;if(a.kind==="PROOF_ARTIFACT"){recorded=d.proofs?.[a.proofIndex];assert.equal(recorded?.surfaceKey,key);assert.equal(sha256(Buffer.from(canonical(recorded.semantics??recorded.semantic??recorded))),a.proofSemanticSha256);}else if(a.kind==="BINDING_REGISTRY"){recorded=d.bindings?.[a.bindingIndex];assert.equal(recorded?.surfaceKey,key);}else{recorded=d.rows?.[a.rowIndex]?.binding;assert.equal(recorded?.surfaceKey,key);}const c=live(surface,key);if(recorded?.signatureHash!==undefined)assert.equal(recorded.signatureHash,c.signatureHash);return{surfaceKey:key,mode,authority:a,finalSignatureHash:c.signatureHash,finalHeadTransport:transport};}
function resolveR137(key,mode,surface,inputs,transport){const a=readJson(R137);assert.equal(a.proofKind,"final-convergence-r137-transfer-correction-v15-v1");const p=a.proofs.find(x=>x.surfaceKey===key);assert(p!==undefined,`R137 current authority missing ${key}`);assert.equal(mode,"V");const c=live(surface,key);assert.equal(p.signatureHash,c.signatureHash);inputs.set(R137,ref(R137));return{surfaceKey:key,mode,proofKind:a.proofKind,evidence:ref(R137),semanticIdentity:sha256(Buffer.from(canonical(p.semantics))),finalHeadTransport:transport};}
function currentizeHistoricalSemantics(old){
  const semantics=structuredClone(old.semantics??old);
  if(old.surfaceKey!=="type:src/facade.ts#InventoryOnceStockApi.reclassifyMany::call[0]")return semantics;
  const direct=semantics.directProducer;
  assert.equal(direct?.producer,"ReclassificationConservation.reclassifyMany");
  assert.equal(direct?.formalRegistryBridge?.preservedModel,"ReclassificationConservation");
  const inputs=direct.currentInputs;
  assert(Array.isArray(inputs));
  const row=inputs.find(input=>input.file===PACKAGING_MODEL);
  assert(row!==undefined,"Historical reclassify producer lacks PackagingIdentity snapshot input.");
  assert.equal(row.sha256,HISTORICAL_PACKAGING_SHA,"Historical PackagingIdentity snapshot hash changed unexpectedly.");
  const currentPackaging=ref(PACKAGING_MODEL);
  row.sha256=currentPackaging.sha256;
  const drifts=direct.sourceContract?.exactDrifts;
  assert(Array.isArray(drifts));
  assert(!drifts.some(d=>d.file===PACKAGING_MODEL),"PackagingIdentity transport already present in historical drift list.");
  drifts.push({file:PACKAGING_MODEL,proofSha256:HISTORICAL_PACKAGING_SHA,currentSha256:currentPackaging.sha256,scopeDecision:"EXCLUDED_PACKAGING_IDENTITY_STRENGTHENING_NOT_IN_RECLASSIFY_MANY_RUNTIME_OR_RECLASSIFICATION_CONSERVATION_MODEL_PATH"});
  drifts.sort((a,b)=>a.file.localeCompare(b.file));
  semantics.currentAssuranceTransport={changedInput:currentPackaging,actualProducer:"ReclassificationConservation.reclassifyMany",actualFormalModel:ref(RECLASS_MODEL),classification:"NON_SEMANTIC_GLOBAL_SOURCE_SNAPSHOT_DRIFT",packagingModelTlcRequired:true};
  return semantics;
}
function special(proofKindValue){if(proofKindValue==="stateful-facade-direct-transfer-residual-a2-v1"){const whole=readJson(R163_WHOLE),receipt=readJson(R163_RECEIPT);assert.equal(whole.proofs.length,4);assert.equal(receipt.status,"R163_R147_WHOLE4_TRACEOPEN2_PEER_CURRENT");return{wholeContainerCurrent:{evidence:ref(R163_WHOLE),receipt:ref(R163_RECEIPT)}};}if(proofKindValue==="traceability-public-removal-direct-producer-a2-v1"){const text=fs.readFileSync(TRACE_MODEL,"utf8");assert(text.includes("productionCount"));assert(text.includes("ProducedIdentityWasCreatedOnce"));return{traceabilityGraphStrengthening:{model:ref(TRACE_MODEL),kind:"GHOST_PRODUCTION_COUNT_STRENGTHENING_NO_BEHAVIOR_REMOVAL"}};}return{};}
export function buildFamilyArtifact({repositoryRoot=process.cwd(),surface=discoverCompilerSurface(repositoryRoot)}={}){assert.equal(surface.digest,FINAL_SURFACE_DIGEST);const transport=transportReceipt(),officialDoc=readJson(OFFICIAL),official=new Map(officialDoc.bindings.map(r=>[r.surfaceKey,r.mode])),base=readJson(BASE_INDEX);assert.equal(base.selectedRows,418);const index=new Map(base.selected.map(r=>[r.surfaceKey,r]));const inputs=new Map();for(const f of [...FILES,BASE_INDEX,OFFICIAL,TRANSPORT,R163_WHOLE,R163_RECEIPT,TRACE_MODEL,"src/facade.ts","src/reservations.ts"])inputs.set(f,ref(f));const proofs=[];for(const d of docs){assert.equal(d.proofs.length,EXPECTED.get(d.proofKind));for(const old of d.proofs){const c=live(surface,old.surfaceKey);assert.equal(old.signatureHash,c.signatureHash);assert.equal(old.declaration.astHash,c.declaration.astHash,`Wrapper public AST drifted: ${old.surfaceKey}`);const deps=[];for(const key of dependencyKeys(old,official)){if(own.has(key)){deps.push({surfaceKey:key,mode:official.get(key),kind:"SAME_CURRENT_FAMILY"});continue;}const mode=official.get(key);assert.notEqual(mode,"HARD_RED");if(["export:./kernel#createInventoryCorrectionEvent::call[0]","export:./kernel#createInventoryTransferManyEvent::call[0]"].includes(key))deps.push(resolveR137(key,mode,surface,inputs,transport));else deps.push(resolveBase(key,mode,index,surface,inputs,transport));}proofs.push({surfaceKey:old.surfaceKey,mode:"A",signatureHash:c.signatureHash,declaration:c.declaration,semantics:{historicalProofKind:d.proofKind,historicalEvidence:ref(FILES[docs.indexOf(d)]),historicalSemantics:currentizeHistoricalSemantics(old),currentDependencyClosure:deps,finalHeadTransport:transport,...special(d.proofKind)}});}}proofs.sort((a,b)=>a.surfaceKey.localeCompare(b.surfaceKey));assert.deepEqual(proofs.map(({surfaceKey,mode})=>({surfaceKey,mode})),supportedSurfaceRows);return{schemaVersion:1,route:"REGISTERED_CERTIFIED_PRODUCER",proofKind,family:"FinalConvergenceWrapperA11",surfaceDigest:surface.digest,domain:"Exact eleven package-owned facade/kernel wrappers. Every public wrapper AST/signature is unchanged from its reviewed producer family; stale dependency receipts are rebound to consolidated current authorities. Metadata/transfer dependencies consume current R137 V15, container transfer consumes peer-green WholeContainer4, count abandon consumes current Direct7 through the base authority, and traceability removal composes the strengthened current TraceabilityGraph ghost invariant.",allAdmittedInputs:true,sampledInputs:0,producerGraphRuns:0,producerReplayRuns:0,reverseReruns:0,creditExpansion:false,inputs:[...inputs.values()].sort((a,b)=>a.file.localeCompare(b.file)),proofs};}
