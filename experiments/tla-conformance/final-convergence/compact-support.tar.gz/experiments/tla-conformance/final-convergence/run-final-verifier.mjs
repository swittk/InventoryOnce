import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";

import { discoverCompilerSurface } from "../surface-bindings/lib/compiler-surface.mjs";
import { loadEvidenceCompilerContext } from "../surface-bindings/lib/binding-checker.mjs";
import { verifyRegisteredValueBinding } from "../throughput-r7/registered-value-family.mjs";
import { verifyRegisteredProducerBinding } from "../throughput-r7/registered-producer-family.mjs";
import {
  buildFinalValueArtifact,
  buildFinalProducerArtifact,
  valueProofKind,
  producerProofKind,
  supportedValueKeys,
  supportedProducerRows,
  verifyCurrentHeadAssuranceTransports,
} from "./final-families.mjs";
import { finalConvergenceRepositoryRoot } from "./repository-root.mjs";

const ROOT = finalConvergenceRepositoryRoot(import.meta.url);
const FINAL_REGISTRY = "experiments/tla-conformance/final-convergence/final-surface-bindings.json";
const HONEST_488 = "experiments/tla-conformance/r105-layered-6dfc-currentization/surface-bindings-6dfc.json";

function read(file) {
  return JSON.parse(fs.readFileSync(path.resolve(ROOT, file), "utf8"));
}

verifyCurrentHeadAssuranceTransports({ repositoryRoot: ROOT });
const surface = discoverCompilerSurface(ROOT);
const context = loadEvidenceCompilerContext(ROOT, []);
const valueRegistration = Object.freeze({
  proofKind: valueProofKind,
  buildFamilyArtifact: buildFinalValueArtifact,
  supportedSurfaceKeys: supportedValueKeys,
});
const producerRegistration = Object.freeze({
  proofKind: producerProofKind,
  buildFamilyArtifact: buildFinalProducerArtifact,
  supportedSurfaceRows: supportedProducerRows,
});
const registry = read(FINAL_REGISTRY);
const honest = read(HONEST_488);
const valueEvidence = registry.bindings.find((row) => row.mode === "V")?.evidence;
const producerEvidence = registry.bindings.find((row) => row.mode === "A")?.evidence;
assert(valueEvidence !== undefined && producerEvidence !== undefined);

let valueAccepted = 0;
for (const surfaceKey of supportedValueKeys) {
  assert.deepEqual(
    verifyRegisteredValueBinding({
      repositoryRoot: ROOT,
      context,
      surface,
      binding: { surfaceKey, mode: "V", evidence: valueEvidence },
      registrations: [valueRegistration],
    }),
    [],
    `Final V309 rejected ${surfaceKey}`,
  );
  valueAccepted += 1;
}

let producerAccepted = 0;
for (const { surfaceKey, mode } of supportedProducerRows) {
  assert.deepEqual(
    verifyRegisteredProducerBinding({
      repositoryRoot: ROOT,
      context,
      surface,
      binding: { surfaceKey, mode, evidence: producerEvidence },
      registrations: [producerRegistration],
    }),
    [],
    `Final A/B rejected ${surfaceKey}`,
  );
  producerAccepted += 1;
}

const counts = registry.bindings.reduce((result, row) => {
  result[row.mode] = (result[row.mode] ?? 0) + 1;
  return result;
}, {});
assert.deepEqual(counts, { A: 121, B: 58, V: 309, HARD_RED: 47 });
assert.deepEqual(
  registry.bindings.filter((row) => row.mode === "HARD_RED"),
  honest.bindings.filter((row) => row.mode === "HARD_RED"),
  "Final convergence changed genuine external HARD_RED membership/reasons.",
);
assert.equal(valueAccepted, 309);
assert.equal(producerAccepted, 179);

console.log(JSON.stringify({
  status: "FINAL_REGISTERED_VERIFIER_GREEN",
  surfaceDigest: surface.digest,
  valueAccepted,
  producerAccepted,
  strictAccepted: valueAccepted + producerAccepted,
  hardRed: counts.HARD_RED,
  unexpected: 0,
}, null, 2));
