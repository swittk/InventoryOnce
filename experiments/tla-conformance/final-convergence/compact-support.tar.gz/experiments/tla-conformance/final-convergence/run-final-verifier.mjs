import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import ts from "typescript";
import { readAssuranceFile } from "../../../scripts/assurance-files.mjs";
import { loadCompilerContext, discoverCompilerSurface } from "../surface-bindings/lib/compiler-surface.mjs";
import { checkBindings } from "../surface-bindings/lib/binding-checker.mjs";
import { verifyCurrentReviewAssurance } from "./current-review-assurance.mjs";
import { buildFinalHeadTransport } from "./final-head-transport.mjs";
import { buildFinalValueArtifact, buildFinalProducerArtifact, producerProofKind, supportedProducerRows, supportedValueKeys, epochRegistryRows } from "./final-families.mjs";
import { buildFinalRegistry } from "./build-final-registry.mjs";
import { runFinalAdversarialChecks } from "./final-selftest.mjs";

const DIRECTORY = "experiments/tla-conformance/final-convergence/";

/** Compile source/tests once; both public censuses, every producer, and the central binder use this Program. */
export function createFinalCompilerContext(root) {
  const configPath = path.join(root, "tsconfig.test.json");
  const config = ts.readConfigFile(configPath, ts.sys.readFile);
  if (config.error !== undefined) throw new Error(ts.flattenDiagnosticMessageText(config.error.messageText, "\n"));
  const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root, undefined, configPath);
  if (parsed.errors.length !== 0) throw new Error("Invalid shared assurance compiler configuration.");
  const program = ts.createProgram({ rootNames: parsed.fileNames, options: parsed.options });
  const context = loadCompilerContext(root, program);
  context.surface = discoverCompilerSurface(root, context);
  return context;
}

/** Full-run provenance is checked once beside, not embedded redundantly inside, every semantic proof. */
export function verifyFinalCurrentReview(root, context) {
  return verifyCurrentReviewAssurance(root, context);
}

export function buildFinalTransport(root, context) { return buildFinalHeadTransport({ repositoryRoot: root, context, surface: context.surface }); }
export function buildFinalValues(root, context) { return buildFinalValueArtifact({ repositoryRoot: root, context, surface: context.surface }); }
export function buildFinalProducers(root, context) { return buildFinalProducerArtifact({ repositoryRoot: root, context, surface: context.surface }); }
export function buildFinalRegistryArtifact(root) { return buildFinalRegistry(root); }

/** The unchanged central binding rules themselves admit all 488 rows; no second independent compiler/verification loop is needed. */
export function verifyFinalBindings(root, context) {
  const registry = JSON.parse(readAssuranceFile(root, DIRECTORY + "final-surface-bindings.json"));
  const counts = {};
  for(const row of registry.bindings) counts[row.mode] = (counts[row.mode] ?? 0) + 1;
  assert.deepEqual(counts, { A: 121, V: 309, B: 58, HARD_RED: 47 });
  assert.deepEqual(registry.bindings.filter(row => row.mode === "HARD_RED"), epochRegistryRows.filter(row => row.mode === "HARD_RED"));
  assert.deepEqual(registry.bindings.filter(row => row.mode === "V").map(row => row.surfaceKey).sort(), [...supportedValueKeys].sort());
  assert.deepEqual(registry.bindings.filter(row => row.mode === "A" || row.mode === "B").map(row => ({ surfaceKey: row.surfaceKey, mode: row.mode })).sort((a,b)=>a.surfaceKey<b.surfaceKey?-1:a.surfaceKey>b.surfaceKey?1:0), supportedProducerRows);
  const diagnostics = checkBindings({ repositoryRoot: root, surface: context.surface, registries: [registry], compilerContext: context, registeredProducerFamilies: [{ proofKind: producerProofKind, buildFamilyArtifact: buildFinalProducerArtifact, supportedSurfaceRows: supportedProducerRows }] });
  const unexpectedRows = diagnostics.filter(row => row.code !== "EXPLICIT_HARD_RED");
  assert.deepEqual(unexpectedRows, [], "Central binder rejected a current strict row.");
  assert.equal(diagnostics.length, 47);
  return { status: "FINAL_BINDER_GREEN", surfaceDigest: context.surface.digest, callables: context.surface.callables.length, diagnostics: 47,
    byCode: { EXPLICIT_HARD_RED: 47 }, hardRed: 47, unexpected: 0, unexpectedRows: [], valueAccepted: 309, producerAccepted: 179, strictAccepted: 488 };
}

export function verifyFinalRegistry(root) {
  const current = JSON.parse(readAssuranceFile(root, DIRECTORY + "final-surface-bindings.json"));
  assert.deepEqual(buildFinalRegistry(root), current, "Exact final registry is stale.");
  return { status: "FINAL_535_REGISTRY_BUILT", counts: { A: 121, B: 58, V: 309, HARD_RED: 47 } };
}

export function verifyFinalAdversarial(root, context) { return runFinalAdversarialChecks(root, context); }
