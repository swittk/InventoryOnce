import assert from "node:assert/strict";
import { readAssuranceFile, assuranceFileSha256 } from "../../../scripts/assurance-files.mjs";
import { createImmutableAssuranceReader } from "../../../scripts/immutable-assurance-inputs.mjs";
import { readReview517722PriorFile, REVIEW_517722_RUNTIME_PRIOR_HEAD } from "../../../scripts/inventory-epoch-contract.mjs";
import { sha256 } from "../surface-bindings/lib/compiler-surface.mjs";
import { buildFinalHeadTransport } from "./final-head-transport.mjs";
import { finalConvergenceRepositoryRoot, assertFinalConvergenceRepositoryRoot } from "./repository-root.mjs";

const ROOT = finalConvergenceRepositoryRoot(import.meta.url);
const DIRECTORY = "experiments/tla-conformance/final-convergence/";
const TRANSPORT = DIRECTORY + "final-head-transport.json";
/** Previously established immutable authority is a precondition, never self-authentication by proposed evidence. */
const frozen = createImmutableAssuranceReader(ROOT);
const protectedInputs = ["authority-producer17.json", "authority-value3.json", "r137-v15.json", "readworld-producer24.json", "wrapper-producer11.json", "r170-pristine-repro-transport.json"];
export const producerProofKind = "final-convergence-producer-a121-b58-v1";
export const valueProofKind = "final-convergence-value-v309-v1";

/** Authenticate the immediately previous complete compact artifact against its immutable certified PR head. */
export function reviewPriorArtifact(root, kind) {
  assert(["value", "producer", "registry"].includes(kind), "Unknown prior proof domain.");
  const file = DIRECTORY + `review-517722-prior-${kind}.json`;
  const original = DIRECTORY + (kind === "value" ? "final-v309.json" : kind === "producer" ? "final-a121-b58.json" : "final-surface-bindings.json");
  const bytes = readAssuranceFile(root, file);
  assert.equal(sha256(bytes), sha256(readReview517722PriorFile(root, original)), "Review 517722 prior authority differs from the independently compact-certified predecessor.");
  return { artifact: JSON.parse(bytes), reference: { file, sha256: sha256(bytes), priorHead: REVIEW_517722_RUNTIME_PRIOR_HEAD } };
}

const priorRegistry = reviewPriorArtifact(ROOT, "registry").artifact;
export const epochRegistryRows = Object.freeze(priorRegistry.bindings.map(row => Object.freeze({ ...row })));
export const supportedValueKeys = Object.freeze(epochRegistryRows.filter(row => row.mode === "V").map(row => row.surfaceKey).sort());
export const supportedProducerRows = Object.freeze(epochRegistryRows.filter(row => row.mode === "A" || row.mode === "B").map(row => Object.freeze({ surfaceKey: row.surfaceKey, mode: row.mode })).sort((a,b) => a.surfaceKey < b.surfaceKey ? -1 : a.surfaceKey > b.surfaceKey ? 1 : 0));
assert.equal(epochRegistryRows.length, 535); assert.equal(new Set(epochRegistryRows.map(row => row.surfaceKey)).size, 535);
assert.equal(supportedValueKeys.length, 309); assert.equal(supportedProducerRows.length, 179);

/** Rebind only through the checked whole-module primitive isomorphism, retaining the prior proof and exact ownership. */
function build(kind, { repositoryRoot = ROOT, context, surface } = {}) {
  const root = assertFinalConvergenceRepositoryRoot(repositoryRoot, import.meta.url);
  assert(context !== undefined && surface !== undefined, "Final proof construction requires the shared compiler pass.");
  for (const input of protectedInputs) frozen.read(DIRECTORY + input);
  const prior = reviewPriorArtifact(root, kind);
  const currentTransport = buildFinalHeadTransport({ repositoryRoot: root, context, surface });
  assert.deepEqual(JSON.parse(readAssuranceFile(root, TRANSPORT)), currentTransport, "Current semantic transport is stale.");
  const transport = { file: TRANSPORT, sha256: assuranceFileSha256(root, TRANSPORT) };
  const callableByKey = new Map(surface.callables.map(callable => [callable.key, callable]));
  const proofs = prior.artifact.proofs.map(proof => {
    const surfaceKey = proof.surfaceKey, current = callableByKey.get(surfaceKey);
    assert(current !== undefined, `Prior strict callable disappeared: ${proof.surfaceKey}`);
    return { ...proof, surfaceKey, signatureHash: current.signatureHash, declaration: current.declaration,
      semantics: { kind: "EXACT_REVIEW_517722_RUNTIME_TRANSITION", priorProof: proof.semantics, priorSignatureHash: proof.signatureHash, priorAuthority: prior.reference, runtimeTransport: transport, creditExpansion: false } };
  });
  const expected = kind === "value" ? supportedValueKeys : supportedProducerRows.map(row => row.surfaceKey);
  assert.deepEqual(proofs.map(row => row.surfaceKey).sort(), [...expected].sort());
  return {
    schemaVersion: 1,
    ...(kind === "producer" ? { route: "REGISTERED_CERTIFIED_PRODUCER" } : {}),
    proofKind: kind === "value" ? valueProofKind : producerProofKind,
    family: kind === "value" ? "FinalConvergenceValueV309" : "FinalConvergenceProducerA121B58",
    surfaceDigest: surface.digest,
    domain: "The complete previously compact-certified 535-row ownership partition, with all 488 strict package-owned rows transported through the exact Review 517722 seven-file runtime transition. Invalid runtime discriminators/cuts are narrowed fail-closed; retained traceability values are copied without identity change; fungibility member ordering is a deterministic permutation; the correction replay patch is the exact independently full-assurance-certified source transition. External ownership remains excluded.",
    allAdmittedInputs: true, sampledInputs: 0, creditExpansion: false,
    ...(kind === "producer" ? { producerGraphRuns: 0, producerReplayRuns: 0, reverseReruns: 0, externalSurfaceCreditGranted: false } : {}),
    inputs: [prior.reference, transport, ...currentTransport.inputs], proofs,
  };
}
export function buildFinalValueArtifact(input) { return build("value", input); }
export function buildFinalProducerArtifact(input) { return build("producer", input); }

/** Keep the semantic transport independent of bookkeeping HEAD and full-run receipt churn. */
export function verifyCurrentHeadAssuranceTransports(input) {
  const current = buildFinalHeadTransport(input);
  assert.deepEqual(JSON.parse(readAssuranceFile(input.repositoryRoot, TRANSPORT)), current, "Current semantic transport is stale.");
  return current;
}
