import assert from "node:assert/strict";
import { readAssuranceFile, assuranceFileSha256 } from "../../../scripts/assurance-files.mjs";
import { createImmutableAssuranceReader } from "../../../scripts/immutable-assurance-inputs.mjs";
import { readEpochPriorFile, epochSurfaceKey } from "../../../scripts/inventory-epoch-contract.mjs";
import { sha256 } from "../surface-bindings/lib/compiler-surface.mjs";
import { buildFinalHeadTransport } from "./final-head-transport.mjs";
import { finalConvergenceRepositoryRoot, assertFinalConvergenceRepositoryRoot } from "./repository-root.mjs";

const ROOT = finalConvergenceRepositoryRoot(import.meta.url);
const DIRECTORY = "experiments/tla-conformance/final-convergence/";
const TRANSPORT = DIRECTORY + "final-head-transport.json";
/** Previously established immutable authority is a precondition, never self-authentication by proposed evidence. */
const frozen = createImmutableAssuranceReader(ROOT);
const protectedInputs = ["authority-producer17.json", "authority-value3.json", "r137-v15.json", "readworld-producer24.json", "wrapper-producer11.json", "r170-pristine-repro-transport.json"];
export const producerProofKind = "final-convergence-producer-a121-b58-v1";
export const valueProofKind = "final-convergence-value-v309-v1";

/** Authenticate a prior complete artifact against the independently fixed predecessor commit. */
export function epochPriorArtifact(root, kind) {
  assert(["value", "producer", "registry"].includes(kind), "Unknown prior proof domain.");
  const file = DIRECTORY + `epoch-prior-${kind}.json`;
  const original = DIRECTORY + (kind === "value" ? "final-v309.json" : kind === "producer" ? "final-a121-b58.json" : "final-surface-bindings.json");
  const bytes = readAssuranceFile(root, file);
  assert.equal(sha256(bytes), sha256(readEpochPriorFile(root, original)), "Prior epoch authority differs from its immutable proof commit.");
  return { artifact: JSON.parse(bytes), reference: { file, sha256: sha256(bytes) } };
}

const priorRegistry = epochPriorArtifact(ROOT, "registry").artifact;
export const epochRegistryRows = Object.freeze(priorRegistry.bindings.map(row => Object.freeze({ ...row, surfaceKey: epochSurfaceKey(row.surfaceKey) })));
export const supportedValueKeys = Object.freeze(epochRegistryRows.filter(row => row.mode === "V").map(row => row.surfaceKey).sort());
export const supportedProducerRows = Object.freeze(epochRegistryRows.filter(row => row.mode === "A" || row.mode === "B").map(row => Object.freeze({ surfaceKey: row.surfaceKey, mode: row.mode })).sort((a,b) => a.surfaceKey < b.surfaceKey ? -1 : a.surfaceKey > b.surfaceKey ? 1 : 0));
assert.equal(epochRegistryRows.length, 535); assert.equal(new Set(epochRegistryRows.map(row => row.surfaceKey)).size, 535);
assert.equal(supportedValueKeys.length, 309); assert.equal(supportedProducerRows.length, 179);

/** Rebind only through the checked whole-module primitive isomorphism, retaining the prior proof and exact ownership. */
function build(kind, { repositoryRoot = ROOT, context, surface } = {}) {
  const root = assertFinalConvergenceRepositoryRoot(repositoryRoot, import.meta.url);
  assert(context !== undefined && surface !== undefined, "Final proof construction requires the shared compiler pass.");
  for (const input of protectedInputs) frozen.read(DIRECTORY + input);
  const prior = epochPriorArtifact(root, kind);
  const currentTransport = buildFinalHeadTransport({ repositoryRoot: root, context, surface });
  assert.deepEqual(JSON.parse(readAssuranceFile(root, TRANSPORT)), currentTransport, "Current semantic transport is stale.");
  const transport = { file: TRANSPORT, sha256: assuranceFileSha256(root, TRANSPORT) };
  const callableByKey = new Map(surface.callables.map(callable => [callable.key, callable]));
  const proofs = prior.artifact.proofs.map(proof => {
    const surfaceKey = epochSurfaceKey(proof.surfaceKey), current = callableByKey.get(surfaceKey);
    assert(current !== undefined, `Prior strict callable disappeared: ${proof.surfaceKey}`);
    return { ...proof, surfaceKey, signatureHash: current.signatureHash, declaration: current.declaration,
      semantics: { kind: "EXACT_EPOCH_MILLISECONDS_PRIMITIVE_TRANSPORT", priorProof: proof.semantics, priorSignatureHash: proof.signatureHash, priorAuthority: prior.reference, primitiveTransport: transport, creditExpansion: false } };
  });
  const expected = kind === "value" ? supportedValueKeys : supportedProducerRows.map(row => row.surfaceKey);
  assert.deepEqual(proofs.map(row => row.surfaceKey).sort(), [...expected].sort());
  return {
    schemaVersion: 1,
    ...(kind === "producer" ? { route: "REGISTERED_CERTIFIED_PRODUCER" } : {}),
    proofKind: kind === "value" ? valueProofKind : producerProofKind,
    family: kind === "value" ? "FinalConvergenceValueV309" : "FinalConvergenceProducerA121B58",
    surfaceDigest: surface.digest,
    domain: "Every admitted exact safe-integer epoch millisecond input, including signed instants and zero. The complete prior strict callable set is transported through the independently checked full TypeScript and emitted-syntax transformation; external ownership remains excluded.",
    allAdmittedInputs: true, sampledInputs: 0, creditExpansion: false,
    ...(kind === "producer" ? { producerGraphRuns: 0, producerReplayRuns: 0, reverseReruns: 0, externalSurfaceCreditGranted: false } : {}),
    inputs: [prior.reference, transport, ...currentTransport.inputs], proofs,
  };
}
export function buildFinalValueArtifact(input) { return build("value", input); }
export function buildFinalProducerArtifact(input) { return build("producer", input); }

/** Keep the semantic transport independent of bookkeeping HEAD and full-run receipt churn. */
export function verifyCurrentHeadAssuranceTransports(input) {
  const current = buildFinalHeadTransport(input);
  assert.deepEqual(JSON.parse(readAssuranceFile(input.repositoryRoot, TRANSPORT)), current, "Current semantic transport is stale.");
  return current;
}
