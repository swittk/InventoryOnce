import assert from "node:assert/strict";
import { createImmutableAssuranceReader, FROZEN_FINAL_EVIDENCE_HEAD } from "../../../scripts/immutable-assurance-inputs.mjs";
import { readAssuranceFile } from "../../../scripts/assurance-files.mjs";
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { discoverCompilerSurface, sha256 } from "../surface-bindings/lib/compiler-surface.mjs";
import { buildFinalHeadTransport, FINAL_SURFACE_DIGEST } from "./final-head-transport.mjs";
import { assertFinalConvergenceRepositoryRoot, finalConvergenceRepositoryRoot } from "./repository-root.mjs";

const ROOT = finalConvergenceRepositoryRoot(import.meta.url);
/** One independently pinned input reader; it hashes live bytes even when parsed evidence is cached. */
const frozenInputs = createImmutableAssuranceReader(ROOT);

export const producerProofKind = "final-convergence-producer-a121-b58-v1";
export const valueProofKind = "final-convergence-value-v309-v1";
const PREVIOUS_FINAL_SURFACE_DIGEST = "ec078013972d9ee2b4ba84d28cfa7449a18dc29679d81766e314db6a6139b81e";
const BASE_INDEX = "experiments/tla-conformance/final-convergence/base-authority-index.json";
const OFFICIAL = "experiments/tla-conformance/r105-layered-6dfc-currentization/surface-bindings-6dfc.json";
const TRANSPORT = "experiments/tla-conformance/final-convergence/final-head-transport.json";
const R165_TRANSPORT = "experiments/tla-conformance/final-convergence/r165-assurance-transport.json";
const R168_TRANSPORT = "experiments/tla-conformance/final-convergence/r168-assurance-transport.json";
const R169_TRANSPORT = "experiments/tla-conformance/final-convergence/r169-assurance-transport.json";
const R170_TRANSPORT = "experiments/tla-conformance/final-convergence/r170-assurance-transport.json";
const R170_PRISTINE_TRANSPORT = "experiments/tla-conformance/final-convergence/r170-pristine-repro-transport.json";
const DIRECT35_TRANSPORT = "experiments/tla-conformance/r158-direct35-clean-handoff/direct35-current-source-transport.json";
const FINAL_TRANSPORTED_BASE_AST_KEYS = new Set([
  "export:.#cutoverInventoryAuthority::call[0]",
  "export:.#parseQuantity::call[0]",
  "export:.#resolveInventoryAmount::call[0]",
  "export:./kernel#assertCanonicalInventoryTime::call[0]",
  "export:./kernel#inventoryIntentFingerprint::call[0]",
  "export:./kernel#normalizeInventoryStockPositionKey::call[0]",
  "export:./kernel#parseQuantity::call[0]",
  "export:./kernel#resolveInventoryAmount::call[0]",
  "export:./migrations#dryRunInventoryMigration::call[0]",
  "export:./storage#inventoryCountBookDigest::call[0]",
  "export:./storage#inventoryDurableMigrationPlanDigest::call[0]",
  "export:./storage#inventoryDurablePlanDigest::call[0]",
  "export:./storage#inventoryProjectionDigest::call[0]",
  "export:./storage#inventoryReservationBookDigest::call[0]",
  "export:./storage#inventoryWorldContentRoots::call[0]",
]);
const RECORDED = Object.freeze({
  authorityProducer: "experiments/tla-conformance/final-convergence/authority-producer17.json",
  authorityValue: "experiments/tla-conformance/final-convergence/authority-value3.json",
  r137Value: "experiments/tla-conformance/final-convergence/r137-v15.json",
  readWorldProducer: "experiments/tla-conformance/final-convergence/readworld-producer24.json",
  wrapperProducer: "experiments/tla-conformance/final-convergence/wrapper-producer11.json",
});
function readJson(file){return file === TRANSPORT ? JSON.parse(readAssuranceFile(ROOT,file).toString("utf8")) : frozenInputs.json(file);}
function ref(file){const bytes=file === TRANSPORT || file === "scripts/formal-models.mjs" ? readAssuranceFile(ROOT,file) : frozenInputs.read(file);return{file,sha256:sha256(bytes)};}
function canonical(value){if(Array.isArray(value))return`[${value.map(canonical).join(",")}]`;if(value!==null&&typeof value==="object")return`{${Object.keys(value).sort().map(k=>`${JSON.stringify(k)}:${canonical(value[k])}`).join(",")}}`;return JSON.stringify(value);}
function live(surface,key){const rows=surface.callables.filter(r=>r.key===key);assert.equal(rows.length,1,`Missing final callable ${key}`);return rows[0];}
function assertHistoricalAncestor(head) {
  execFileSync("git", ["merge-base", "--is-ancestor", head, "HEAD"], { cwd: ROOT, stdio: "ignore" });
}
function historicalTransportReceipt(file, status, currentHead) {
  const recorded = frozenInputs.transport(file, status, currentHead, FROZEN_FINAL_EVIDENCE_HEAD);
  const { contentSha256, ...core } = recorded;
  assert.equal(contentSha256, sha256(Buffer.from(canonical(core))), `Historical transport content hash is stale: ${file}`);
  return { ...ref(file), contentSha256, affectedStrictRows: recorded.affectedStrictRows, affectedValueRows: recorded.affectedValueRows };
}
function transportReceipt(context,surface){const built=buildFinalHeadTransport({repositoryRoot:ROOT,context,surface}),recorded=readJson(TRANSPORT);assert.deepEqual(recorded,built);return{...ref(TRANSPORT),contentSha256:built.contentSha256};}
function r165TransportReceipt(){const receipt=historicalTransportReceipt(R165_TRANSPORT,"R165_PLUS_R167_ASSURANCE_TRANSPORT_PROVED","0c94ee9925a0785a883241b2e6ed843e50aeb5ac");const recorded=readJson(R165_TRANSPORT);assert.equal(recorded.postR165ReviewedDelta.head,"d947e47af2502f2ed2f8ae6971ee639a91ff0867");return receipt;}
function r168TransportReceipt(){return historicalTransportReceipt(R168_TRANSPORT,"R168_ASSURANCE_MAINTENANCE_TRANSPORT_PROVED","e1759f756a9e7de5d67e7c03d563f6f574892e26");}
function r169TransportReceipt(){return historicalTransportReceipt(R169_TRANSPORT,"R169_CURRENT_HEAD_ASSURANCE_TRANSPORT_PROVED","5584d6e84fd5737a3a24f73daa57115602c3460d");}
function r170TransportReceipt(){return historicalTransportReceipt(R170_TRANSPORT,"R170_CURRENT_HEAD_ASSURANCE_TRANSPORT_PROVED","f430b5141b0afc0b2796e38bc90ef45df4c0dcd9");}
function r170PristineTransportReceipt(){return historicalTransportReceipt(R170_PRISTINE_TRANSPORT,"R170_PRISTINE_REPRO_ASSURANCE_TRANSPORT_PROVED","7046246c88b32487def30e96fffa4b2a740e0005");}
function verifySelectedAuthority(row,surface,inputs,transport){const a=row.authority,bytes=frozenInputs.read(a.evidence.file);assert.equal(sha256(bytes),a.evidence.sha256,`Selected base authority changed: ${row.surfaceKey}`);inputs.set(a.evidence.file,a.evidence);const d=JSON.parse(bytes.toString("utf8"));let recorded,baseSemantics;if(a.kind==="PROOF_ARTIFACT"){recorded=d.proofs?.[a.proofIndex];assert.equal(recorded?.surfaceKey,row.surfaceKey);assert.equal(sha256(Buffer.from(canonical(recorded.semantics??recorded.semantic??recorded))),a.proofSemanticSha256);baseSemantics=structuredClone(recorded.semantics??recorded.semantic??recorded);}else if(a.kind==="BINDING_REGISTRY"){recorded=d.bindings?.[a.bindingIndex];assert.equal(recorded?.surfaceKey,row.surfaceKey);assert.equal(recorded?.mode,row.mode);baseSemantics={binding:structuredClone(recorded),direct35CurrentSourceTransport:ref(DIRECT35_TRANSPORT)};inputs.set(DIRECT35_TRANSPORT,ref(DIRECT35_TRANSPORT));}else{recorded=d.rows?.[a.rowIndex]?.binding;assert.equal(recorded?.surfaceKey,row.surfaceKey);assert.equal(recorded?.mode,row.mode);baseSemantics={binding:structuredClone(recorded),direct35CurrentSourceTransport:ref(DIRECT35_TRANSPORT)};inputs.set(DIRECT35_TRANSPORT,ref(DIRECT35_TRANSPORT));}
 const c=live(surface,row.surfaceKey);if(recorded?.signatureHash!==undefined)assert.equal(recorded.signatureHash,c.signatureHash);if(recorded?.declaration?.astHash!==undefined&&!FINAL_TRANSPORTED_BASE_AST_KEYS.has(row.surfaceKey))assert.equal(recorded.declaration.astHash,c.declaration.astHash,`Selected base public AST drifted: ${row.surfaceKey}`);if(FINAL_TRANSPORTED_BASE_AST_KEYS.has(row.surfaceKey))assert.equal(transport.file,TRANSPORT,`Transported base AST row lost final-head transport: ${row.surfaceKey}`);assert(["cc97e53a60ad9a4a700ee0c21f926e05b3a09dbd1ee739d94354a228fc47877a",PREVIOUS_FINAL_SURFACE_DIGEST,FINAL_SURFACE_DIGEST,null].includes(a.surfaceDigest??null),`Unexpected selected authority surface for ${row.surfaceKey}`);return{surfaceKey:row.surfaceKey,mode:row.mode,signatureHash:c.signatureHash,declaration:c.declaration,semantics:{kind:"FINAL_CONSOLIDATED_BASE_AUTHORITY",baseAuthority:a,baseSemantics,finalHeadTransport:transport,creditExpansion:false}};}
function residuals(){return{
 authorityProducer:readJson(RECORDED.authorityProducer),
 authorityValue:readJson(RECORDED.authorityValue),
 r137Value:readJson(RECORDED.r137Value),
 readWorldProducer:readJson(RECORDED.readWorldProducer),
 wrapperProducer:readJson(RECORDED.wrapperProducer),
};}
function rebindFrozenResidual(proof,surface,transport){const current=live(surface,proof.surfaceKey);assert.equal(proof.signatureHash,current.signatureHash,`Frozen residual signature drifted: ${proof.surfaceKey}`);return{...structuredClone(proof),signatureHash:current.signatureHash,declaration:current.declaration,semantics:{...structuredClone(proof.semantics),finalHeadTransport:transport,creditExpansion:false}};}
function build(kind,{repositoryRoot=ROOT,surface,context}={}){for(const file of [OFFICIAL,BASE_INDEX,...Object.values(RECORDED),R165_TRANSPORT,R168_TRANSPORT,R169_TRANSPORT,R170_TRANSPORT,R170_PRISTINE_TRANSPORT])frozenInputs.read(file);repositoryRoot=assertFinalConvergenceRepositoryRoot(repositoryRoot,import.meta.url);surface??=discoverCompilerSurface(repositoryRoot);assert.equal(surface.digest,FINAL_SURFACE_DIGEST);const transport=transportReceipt(context,surface),official=readJson(OFFICIAL),modes=new Map(official.bindings.map(r=>[r.surfaceKey,r.mode])),base=readJson(BASE_INDEX);assert.equal(base.selectedRows,418);assert.equal(base.missingRows,70);const baseRows=base.selected.filter(r=>kind==="value"?r.mode==="V":r.mode==="A"||r.mode==="B");const expectedBase=kind==="value"?291:127;assert.equal(baseRows.length,expectedBase);const inputs=new Map([[BASE_INDEX,ref(BASE_INDEX)],[OFFICIAL,ref(OFFICIAL)],[TRANSPORT,ref(TRANSPORT)]]);const proofs=baseRows.map(row=>verifySelectedAuthority(row,surface,inputs,transport));const r=residuals();const extra=(kind==="value"?[...r.authorityValue.proofs,...r.r137Value.proofs]:[...r.authorityProducer.proofs,...r.readWorldProducer.proofs,...r.wrapperProducer.proofs]).map((proof)=>rebindFrozenResidual(proof,surface,transport));for(const file of Object.values(RECORDED))inputs.set(file,ref(file));proofs.push(...extra);if(kind==="producer"){const r165=r165TransportReceipt();inputs.set(R165_TRANSPORT,ref(R165_TRANSPORT));for(const row of r165.affectedStrictRows){const affected=proofs.filter(p=>p.surfaceKey===row.surfaceKey&&p.mode===row.mode);assert.equal(affected.length,1,`Assurance transport affected row missing: ${row.surfaceKey}`);affected[0].semantics={...affected[0].semantics,currentHeadAssuranceTransport:r165};}assert.deepEqual(r165.affectedStrictRows,[{surfaceKey:"export:.#cutoverInventoryAuthority::call[0]",mode:"A"},{surfaceKey:"type:src/facade.ts#InventoryOnceStockApi.reclassifyMany::call[0]",mode:"A"}]);assert.deepEqual(r165.affectedValueRows,[]);const r168=r168TransportReceipt();inputs.set(R168_TRANSPORT,ref(R168_TRANSPORT));for(const row of r168.affectedStrictRows){const affected=proofs.filter(p=>p.surfaceKey===row.surfaceKey&&p.mode===row.mode);assert.equal(affected.length,1,`R168 assurance transport affected row missing: ${row.surfaceKey}`);affected[0].semantics={...affected[0].semantics,currentHeadReviewAssuranceTransport:r168};}assert.deepEqual(r168.affectedStrictRows,[{surfaceKey:"export:.#cutoverInventoryAuthority::call[0]",mode:"A"},{surfaceKey:"type:src/authority.ts#InventoryAuthorityControl.read::call[0]",mode:"B"}]);assert.deepEqual(r168.affectedValueRows,[]);const r169=r169TransportReceipt();inputs.set(R169_TRANSPORT,ref(R169_TRANSPORT));for(const row of r169.affectedStrictRows){const affected=proofs.filter(p=>p.surfaceKey===row.surfaceKey&&p.mode===row.mode);assert.equal(affected.length,1,`R169 assurance transport affected row missing: ${row.surfaceKey}`);affected[0].semantics={...affected[0].semantics,currentHeadReview169AssuranceTransport:r169};}assert.deepEqual(r169.affectedStrictRows,[{surfaceKey:"export:.#cutoverInventoryAuthority::call[0]",mode:"A"},{surfaceKey:"type:src/facade.ts#InventoryOnceStockApi.reclassifyMany::call[0]",mode:"A"}]);assert.deepEqual(r169.affectedValueRows,[]);const r170=r170TransportReceipt();inputs.set(R170_TRANSPORT,ref(R170_TRANSPORT));for(const row of r170.affectedStrictRows){const affected=proofs.filter(p=>p.surfaceKey===row.surfaceKey&&p.mode===row.mode);assert.equal(affected.length,1,`R170 assurance transport affected row missing: ${row.surfaceKey}`);affected[0].semantics={...affected[0].semantics,currentHeadReview170AssuranceTransport:r170};}assert.deepEqual(r170.affectedStrictRows,[{surfaceKey:"export:.#cutoverInventoryAuthority::call[0]",mode:"A"},{surfaceKey:"type:src/facade.ts#InventoryOnceTraceabilityApi.disaggregate::call[0]",mode:"A"},{surfaceKey:"type:src/facade.ts#InventoryOnceTraceabilityApi.disassociate::call[0]",mode:"A"}]);assert.deepEqual(r170.affectedValueRows,[]);const r170Pristine=r170PristineTransportReceipt();inputs.set(R170_PRISTINE_TRANSPORT,ref(R170_PRISTINE_TRANSPORT));for(const row of r170Pristine.affectedStrictRows){const affected=proofs.filter(p=>p.surfaceKey===row.surfaceKey&&p.mode===row.mode);assert.equal(affected.length,1,`R170 pristine-repro transport affected row missing: ${row.surfaceKey}`);affected[0].semantics={...affected[0].semantics,currentHeadReview170PristineReproTransport:r170Pristine};}assert.deepEqual(r170Pristine.affectedStrictRows,[{surfaceKey:"export:.#cutoverInventoryAuthority::call[0]",mode:"A"}]);assert.deepEqual(r170Pristine.affectedValueRows,[]);}proofs.sort((a,b)=>a.surfaceKey.localeCompare(b.surfaceKey));const expected=official.bindings.filter(r=>kind==="value"?r.mode==="V":r.mode==="A"||r.mode==="B").sort((a,b)=>a.surfaceKey.localeCompare(b.surfaceKey));assert.equal(proofs.length,kind==="value"?309:179);assert.equal(new Set(proofs.map(p=>p.surfaceKey)).size,proofs.length);assert.deepEqual(proofs.map(p=>({surfaceKey:p.surfaceKey,mode:kind==="value"?"V":p.mode})),expected.map(r=>({surfaceKey:r.surfaceKey,mode:r.mode})),`Final ${kind} membership differs from honest488.`);for(const p of proofs){const c=live(surface,p.surfaceKey);assert.equal(p.signatureHash,c.signatureHash);assert.deepEqual(p.declaration,c.declaration);assert.equal(modes.get(p.surfaceKey),kind==="value"?"V":p.mode);}return{schemaVersion:1,...(kind==="producer"?{route:"REGISTERED_CERTIFIED_PRODUCER"}:{}),proofKind:kind==="value"?valueProofKind:producerProofKind,family:kind==="value"?"FinalConvergenceValueV309":"FinalConvergenceProducerA121B58",surfaceDigest:surface.digest,domain:kind==="value"?"Exact honest-488 V309 membership. Every member is independently selected from a frozen current authority or one of the final residual currentizers, rebound to the exact current compiler declaration, and transported across the only later source delta by the single final-head theorem.":"Exact honest-488 A121/B58 membership. Every package-owned action/read is independently selected from a frozen current authority or one of the final residual currentizers; the 47 true external callable identities are excluded and remain HARD_RED.",allAdmittedInputs:true,sampledInputs:0,creditExpansion:false,...(kind==="producer"?{producerGraphRuns:0,producerReplayRuns:0,reverseReruns:0,externalSurfaceCreditGranted:false}:{}),inputs:[...inputs.values()].sort((a,b)=>a.file.localeCompare(b.file)),proofs};}

/** Verify immutable historical assurance receipts plus the single current-head assurance boundary. */
export function verifyCurrentHeadAssuranceTransports({ repositoryRoot = ROOT, context, surface } = {}) {
  repositoryRoot = assertFinalConvergenceRepositoryRoot(repositoryRoot, import.meta.url);
  const current = buildFinalHeadTransport({ repositoryRoot, context, surface });
  const r169 = r169TransportReceipt();
  const r170 = r170TransportReceipt();
  return {
    current: { file: TRANSPORT, contentSha256: current.contentSha256, currentReviewAssurance: current.currentReviewAssurance },
    r169: { file: R169_TRANSPORT, contentSha256: r169.contentSha256 },
    r170: { file: R170_TRANSPORT, contentSha256: r170.contentSha256 },
  };
}
export function buildFinalValueArtifact(input){return build("value",input);}
export function buildFinalProducerArtifact(input){return build("producer",input);}
export const supportedValueKeys=Object.freeze(readJson(OFFICIAL).bindings.filter(r=>r.mode==="V").map(r=>r.surfaceKey).sort());
export const supportedProducerRows=Object.freeze(readJson(OFFICIAL).bindings.filter(r=>r.mode==="A"||r.mode==="B").map(r=>Object.freeze({surfaceKey:r.surfaceKey,mode:r.mode})).sort((a,b)=>a.surfaceKey.localeCompare(b.surfaceKey)));
assert.equal(supportedValueKeys.length,309);assert.equal(supportedProducerRows.length,179);
