import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import ts from "typescript";
import { canonicalJson, discoverCompilerSurface, sha256 } from "../surface-bindings/lib/compiler-surface.mjs";

export const OLD_SOURCE_HEAD = "6cafd49ff4b3729f80ae35d9fc0220f7a8a4b55a";
export const FINAL_SOURCE_HEAD = "e1759f756a9e7de5d67e7c03d563f6f574892e26";
export const OLD_SURFACE_DIGEST = "cc97e53a60ad9a4a700ee0c21f926e05b3a09dbd1ee739d94354a228fc47877a";
export const FINAL_SURFACE_DIGEST = "ec078013972d9ee2b4ba84d28cfa7449a18dc29679d81766e314db6a6139b81e";
const OLD_SURFACE_FILE = "experiments/tla-conformance/final-convergence/old-surface-cc97e.json";
const R169_TRANSPORT = "experiments/tla-conformance/final-convergence/r169-assurance-transport.json";
const R169_LATER_TRACKED = Object.freeze([
  "formal/PackagingIdentity.tla",
  "formal/README.md",
  "formal/RecordedDeficit.tla",
  "formal/implementation-conformance/API_ASSURANCE.json",
  "formal/implementation-conformance/CALL_CHAIN_ASSURANCE.json",
  "formal/implementation-conformance/EXECUTABLE_ASSURANCE_REPORT.json",
  "formal/implementation-conformance/FIELD_CLASSIFICATION.json",
  "formal/implementation-conformance/IMPLEMENTATION_CONFORMANCE.md",
  "scripts/audit-formal-implementation-conformance.mjs",
  "scripts/executable-assurance-coherence.mjs",
  "scripts/executable-assurance-coherence.selftest.mjs",
  "scripts/formal-implementation-surface.cjs",
  "test/formal-implementation-conformance.test.ts",
  "test/r47-concurrent-completion-peer.test.ts",
]);
const CHANGED_SOURCE_FILES = Object.freeze([
  "src/authority-cutover.ts",
  "src/deficits.ts",
  "src/projection.ts",
  "src/storage.ts",
  "src/traceability-replay.ts",
  "src/transfers.ts",
]);
const AUTHORITY_CHANGED_RUNTIME = Object.freeze([
  "fn:assertCompletedInventoryCutoverManifest",
  "fn:completedInventoryCutoverResult",
  "fn:cutoverInventoryAuthority",
]);
const STORAGE_CHANGED_RUNTIME = Object.freeze([
  "fn:assertPublishedInventoryMigrationTarget",
  "method:InMemoryInventoryDurableStorage.completeMigrationManifestUnlocked",
]);
const DEFICIT_CHANGED_RUNTIME = Object.freeze([
  "fn:applyInventoryRecordedDeficitBurden",
  "fn:recordedDeficitByLocation",
]);

function git(args, encoding = "utf8") {
  return execFileSync("git", args, { cwd: process.cwd(), encoding, maxBuffer: 64 * 1024 * 1024 });
}
function oldText(file) { return git(["show", `${OLD_SOURCE_HEAD}:${file}`]); }
function currentText(file) { return fs.readFileSync(file, "utf8"); }
function sourceFile(file, text) { return ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS); }
function emitted(node) {
  let text = node.getText(node.getSourceFile());
  if (ts.isFunctionDeclaration(node) && node.name !== undefined) {
    const name = node.name.text;
    text = text.replace(/^export\s+/u, "");
    text = text.replace(new RegExp(`^(?:async\\s+)?function\\s+${name}\\b`, "u"), (match) => match.replace(name, "__proof"));
  } else if (ts.isMethodDeclaration(node) || ts.isConstructorDeclaration(node)) {
    text = `class __Host { ${text} }`;
  }
  return ts.transpileModule(text, {
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None, removeComments: true, useDefineForClassFields: false },
  }).outputText.trim();
}
function runtimeRows(file, text) {
  const source = sourceFile(file, text);
  const rows = new Map();
  for (const statement of source.statements) {
    if (ts.isFunctionDeclaration(statement) && statement.name !== undefined && statement.body !== undefined) {
      rows.set(`fn:${statement.name.text}`, sha256(emitted(statement)));
    }
    if (ts.isClassDeclaration(statement) && statement.name !== undefined) {
      for (const member of statement.members) {
        if (ts.isMethodDeclaration(member) && member.body !== undefined) rows.set(`method:${statement.name.text}.${member.name.getText(source)}`, sha256(emitted(member)));
        if (ts.isConstructorDeclaration(member) && member.body !== undefined) rows.set(`ctor:${statement.name.text}`, sha256(emitted(member)));
      }
    }
  }
  return rows;
}
function changedRuntime(file) {
  const before = runtimeRows(file, oldText(file));
  const after = runtimeRows(file, currentText(file));
  const names = [...new Set([...before.keys(), ...after.keys()])].sort();
  return names.filter((name) => before.get(name) !== after.get(name));
}
function transpiledFile(text) {
  return ts.transpileModule(text, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ES2022, removeComments: true, useDefineForClassFields: false } }).outputText.trim();
}
function assertProjectionAlphaRename() {
  const before = transpiledFile(oldText("src/projection.ts"));
  const candidate = currentText("src/projection.ts").replaceAll("existingEventWithSameId", "sameEventId");
  assert.equal(transpiledFile(candidate), before, "Projection delta exceeded the reviewed local-variable alpha rename.");
}
function assertTraceabilityAlphaRename() {
  const before = oldText("src/traceability-replay.ts");
  const current = currentText("src/traceability-replay.ts");
  const start = current.indexOf("function validateAndIndexAddition(");
  const end = current.indexOf("function removeIndexedRelation(", start);
  assert(start >= 0 && end > start, "Traceability helper boundaries changed.");
  let helper = current.slice(start, end);
  helper = helper.replace(
    '  relation: Pick<InventoryTraceabilityRelationChange, "kind" | "from" | "to">,',
    '  change: Pick<InventoryTraceabilityRelationChange, "kind" | "from" | "to">,',
  );
  helper = helper.replaceAll("relation.from", "change.from").replaceAll("relation.to", "change.to").replaceAll("relation.kind", "change.kind");
  const candidate = `${current.slice(0, start)}${helper}${current.slice(end)}`;
  assert.equal(transpiledFile(candidate), transpiledFile(before), "Traceability replay delta exceeded the reviewed parameter alpha rename/comments.");
}
function assertTransfersDocumentationOnly() {
  assert.equal(transpiledFile(currentText("src/transfers.ts")), transpiledFile(oldText("src/transfers.ts")), "Transfer runtime emit changed.");
}
function exactChangedSourceFiles() {
  return git(["diff", "--name-only", OLD_SOURCE_HEAD, FINAL_SOURCE_HEAD, "--", "src"]).trim().split(/\r?\n/u).filter(Boolean).sort();
}
function currentHead() { return git(["rev-parse", "HEAD"]).trim(); }
function assertCurrentProductTreeIsFinalSource() {
  const head = currentHead();
  const laterTracked = git([
    "diff",
    "--name-only",
    FINAL_SOURCE_HEAD,
    head,
    "--",
    "src",
    "formal",
    "scripts",
    "test",
    "package.json",
    "tsconfig.json",
    "tsconfig.test.json",
  ]).split(/\r?\n/u).filter(Boolean);
  assert.deepEqual(laterTracked, [...R169_LATER_TRACKED].sort(), "Integrated proof tree differs from the exact R169-reviewed product/assurance tree.");
}

export function buildFinalHeadTransport({ repositoryRoot = process.cwd() } = {}) {
  assert.equal(path.resolve(repositoryRoot), path.resolve(process.cwd()));
  assertCurrentProductTreeIsFinalSource();
  assert.deepEqual(exactChangedSourceFiles(), CHANGED_SOURCE_FILES, "Final product source delta widened.");

  const oldSurfaceBytes = fs.readFileSync(OLD_SURFACE_FILE);
  const oldSurface = JSON.parse(oldSurfaceBytes.toString("utf8"));
  assert.equal(oldSurface.digest, OLD_SURFACE_DIGEST);
  assert.equal(oldSurface.callables.length, 535);
  const currentSurface = discoverCompilerSurface(repositoryRoot);
  assert.equal(currentSurface.digest, FINAL_SURFACE_DIGEST);
  assert.equal(currentSurface.callables.length, 535);
  const oldByKey = new Map(oldSurface.callables.map((row) => [row.key, row]));
  const signatureChanges = [];
  const astChanges = [];
  for (const current of currentSurface.callables) {
    const previous = oldByKey.get(current.key);
    assert(previous !== undefined, `Final surface added callable ${current.key}`);
    if (previous.signatureHash !== current.signatureHash) signatureChanges.push(current.key);
    if (previous.declaration.astHash !== current.declaration.astHash) astChanges.push(current.key);
  }
  assert.deepEqual(signatureChanges, [], "A public signature changed after the cc97e assurance freeze.");
  assert.deepEqual(astChanges, ["export:.#cutoverInventoryAuthority::call[0]"], "Unexpected public callable AST changed after cc97e.");

  assertProjectionAlphaRename();
  assertTraceabilityAlphaRename();
  assertTransfersDocumentationOnly();
  assert.deepEqual(changedRuntime("src/authority-cutover.ts"), AUTHORITY_CHANGED_RUNTIME);
  assert.deepEqual(changedRuntime("src/storage.ts"), STORAGE_CHANGED_RUNTIME);
  assert.deepEqual(changedRuntime("src/deficits.ts"), DEFICIT_CHANGED_RUNTIME);

  const deficitTest = currentText("test/review-hardening.test.ts");
  assert(deficitTest.includes("treats an empty recorded-deficit location selection as all locations"));
  assert(deficitTest.includes("locationIds: []"));
  assert(deficitTest.includes("unselected location"));
  const authorityTest = currentText("test/authority.test.ts");
  assert(authorityTest.includes("completedReplay.targetWorldRoot"));
  assert(authorityTest.includes("completedManifest?.targetWorldRevision"));
  const storageTest = currentText("test/storage-conformance-suite.ts");
  assert(storageTest.includes("completedManifest?.targetWorldRoot"));
  assert(storageTest.includes("completedManifest?.targetWorldRevision"));
  const storageSource = currentText("src/storage.ts");
  for (const term of ["targetWorldRoot", "targetWorldRevision", "assertPublishedInventoryMigrationTarget"]) assert(storageSource.includes(term));

  const core = {
    schemaVersion: 1,
    status: "FINAL_HEAD_TRANSPORT_PROVED",
    oldSourceHead: OLD_SOURCE_HEAD,
    finalSourceHead: FINAL_SOURCE_HEAD,
    oldSurfaceDigest: OLD_SURFACE_DIGEST,
    finalSurfaceDigest: FINAL_SURFACE_DIGEST,
    callables: 535,
    publicSignatureChanges: 0,
    publicAstChanges: astChanges,
    exactSourceDelta: CHANGED_SOURCE_FILES,
    semantics: {
      projection: "ALPHA_RENAME_ONLY",
      traceabilityReplay: "ALPHA_RENAME_ONLY_PLUS_COMMENTS",
      transfers: "COMMENT_ONLY_RUNTIME_EMIT_IDENTICAL",
      authorityCutover: { changedRuntime: AUTHORITY_CHANGED_RUNTIME, rule: "R144 durable target evidence strengthens completed-cutover replay and fixes stale dry-run target identity." },
      storage: { changedRuntime: STORAGE_CHANGED_RUNTIME, rule: "R144 records and validates exact published migration target root/revision; other storage runtime declarations are unchanged." },
      recordedDeficit: { changedRuntime: DEFICIT_CHANGED_RUNTIME, rule: "R167 makes empty locationIds select every location for recorded-deficit burdening while preserving strict non-empty filtering and independent per-location deficit accounting." },
    },
    evidence: {
      oldSurface: { file: OLD_SURFACE_FILE, sha256: sha256(oldSurfaceBytes) },
      currentProductFiles: CHANGED_SOURCE_FILES.map((file) => ({ file, sha256: sha256(fs.readFileSync(file)) })),
      currentRegressionTests: ["test/authority.test.ts", "test/storage-conformance-suite.ts", "test/storage-conformance.test.ts", "test/review-hardening.test.ts"].map((file) => ({ file, sha256: sha256(fs.readFileSync(file)) })),
    },
    currentReviewAssuranceTransport: (() => { const recorded=JSON.parse(fs.readFileSync(R169_TRANSPORT,"utf8")); assert.equal(recorded.status,"R169_CURRENT_HEAD_ASSURANCE_TRANSPORT_PROVED"); assert.equal(recorded.currentHead,"5584d6e84fd5737a3a24f73daa57115602c3460d"); return { file:R169_TRANSPORT, sha256:sha256(fs.readFileSync(R169_TRANSPORT)), contentSha256:recorded.contentSha256, affectedStrictRows:recorded.affectedStrictRows, affectedValueRows:recorded.affectedValueRows }; })(),
    creditExpansion: false,
  };
  return { ...core, contentSha256: sha256(canonicalJson(core)) };
}

if (process.argv[1] !== undefined && path.resolve(process.argv[1]) === path.resolve("experiments/tla-conformance/final-convergence/final-head-transport.mjs")) {
  const artifact = buildFinalHeadTransport();
  const target = "experiments/tla-conformance/final-convergence/final-head-transport.json";
  const text = `${JSON.stringify(artifact, null, 2)}\n`;
  if (process.argv.includes("--check")) assert.equal(fs.readFileSync(target, "utf8"), text, "Final-head transport artifact is stale.");
  else fs.writeFileSync(target, text);
  console.log(JSON.stringify({ status: artifact.status, contentSha256: artifact.contentSha256, finalSurfaceDigest: artifact.finalSurfaceDigest }, null, 2));
}
