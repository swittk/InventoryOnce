import assert from "node:assert/strict";
import { readAssuranceFile } from "../../../scripts/assurance-files.mjs";
import { verifyEpochRuntimeTransport, EPOCH_PRIOR_PROOF_HEAD, epochSurfaceKey, readEpochPriorFile } from "../../../scripts/inventory-epoch-contract.mjs";
import { canonicalJson, sha256 } from "../surface-bindings/lib/compiler-surface.mjs";
import { assertFinalConvergenceRepositoryRoot, finalConvergenceRepositoryRoot } from "./repository-root.mjs";

const ROOT = finalConvergenceRepositoryRoot(import.meta.url);
/** One immutable compiler pass owns one semantic theorem construction. No HEAD or mtime keys confer proof credit. */
const passes = new WeakMap();

export function buildFinalHeadTransport({ repositoryRoot = ROOT, context, surface } = {}) {
  const root = assertFinalConvergenceRepositoryRoot(repositoryRoot, import.meta.url);
  assert(context !== undefined && surface !== undefined && context.repositoryRoot === root, "Semantic transport requires the current shared compiler snapshot.");
  if (passes.has(context)) return structuredClone(passes.get(context));
  const transition = verifyEpochRuntimeTransport(root);
  const oldRegistry = JSON.parse(readEpochPriorFile(root, "experiments/tla-conformance/final-convergence/final-surface-bindings.json"));
  const mapped = oldRegistry.bindings.map(row => epochSurfaceKey(row.surfaceKey));
  assert.equal(surface.callables.length, 535);
  assert.equal(new Set(mapped).size, 535, "Temporal vocabulary mapping is not bijective.");
  assert.deepEqual([...mapped].sort(), surface.callables.map(row => row.key).sort(), "Temporal migration changed the public ownership domain.");
  const inputs = [...transition.inputs];
  for (const file of ["scripts/inventory-epoch-contract.mjs", "formal/UseByReservation.tla", "formal/UseByReservation.cfg", "formal/UseByReservationEpochZeroMutation.cfg"]) {
    inputs.push({ file, sha256: sha256(readAssuranceFile(root, file)) });
  }
  const core = { schemaVersion: 2, status: "FINAL_HEAD_TRANSPORT_PROVED", priorProofHead: EPOCH_PRIOR_PROOF_HEAD,
    finalSurfaceDigest: surface.digest, callables: 535, exactPrimitiveTransport: transition,
    publicKeyTransport: oldRegistry.bindings.filter(row => epochSurfaceKey(row.surfaceKey) !== row.surfaceKey).map(row => ({ before: row.surfaceKey, after: epochSurfaceKey(row.surfaceKey), mode: row.mode })),
    inputs, creditExpansion: false };
  const artifact = { ...core, contentSha256: sha256(canonicalJson(core)) };
  passes.set(context, artifact);
  return structuredClone(artifact);
}
