import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import ts from "typescript";
import { canonicalJson, discoverCompilerSurface, sha256 } from "../surface-bindings/lib/compiler-surface.mjs";
import { verifyCurrentReviewAssurance } from "./current-review-assurance.mjs";
import {
  assertFinalConvergenceRepositoryRoot,
  finalConvergenceRepositoryPath,
  finalConvergenceRepositoryRoot,
  isDirectFinalConvergenceInvocation,
} from "./repository-root.mjs";

const ROOT = finalConvergenceRepositoryRoot(import.meta.url);

export const OLD_SOURCE_HEAD = "6cafd49ff4b3729f80ae35d9fc0220f7a8a4b55a";
export const FINAL_SOURCE_HEAD = "0e9214af91ecf326e94ec77b1e9727087be78eb9";
export const OLD_SURFACE_DIGEST = "cc97e53a60ad9a4a700ee0c21f926e05b3a09dbd1ee739d94354a228fc47877a";
export const FINAL_SURFACE_DIGEST = "9cdd7329e0fcd9b0683315c8813c82e41f5ba3373dca8ef0f6e6b6c2a286cdcb";
const OLD_SURFACE_FILE = "experiments/tla-conformance/final-convergence/old-surface-cc97e.json";
const R170_TRANSPORT = "experiments/tla-conformance/final-convergence/r170-assurance-transport.json";
const R170_PRISTINE_TRANSPORT = "experiments/tla-conformance/final-convergence/r170-pristine-repro-transport.json";
const POST_CERTIFICATE_AUTHORITATIVE_FILES = Object.freeze([
  "formal/ImplementationConformance.cfg",
  "formal/ImplementationConformance.tla",
  "formal/ImplementationConformanceReplaceDeltaMutation.cfg",
  "formal/implementation-conformance/EXECUTABLE_ASSURANCE_REPORT.json",
  "scripts/formal-models.mjs",
]);
const CHANGED_SOURCE_FILES = Object.freeze([
  "src/authority-cutover.ts",
  "src/coordinator.ts",
  "src/deficits.ts",
  "src/fungibility.ts",
  "src/integrity.ts",
  "src/migrations.ts",
  "src/projection.ts",
  "src/quantity.ts",
  "src/storage.ts",
  "src/traceability-replay.ts",
  "src/transfers.ts",
]);
const AUTHORITY_CHANGED_RUNTIME = Object.freeze([
  "fn:assertCompletedInventoryCutoverManifest",
  "fn:completedInventoryCutoverResult",
  "fn:cutoverInventoryAuthority",
]);
const STORAGE_CHANGED_RUNTIME = Object.freeze([
  "fn:assertPublishedInventoryMigrationTarget",
  "method:InMemoryInventoryDurableStorage.completeMigrationManifestUnlocked",
]);
const DEFICIT_CHANGED_RUNTIME = Object.freeze([
  "fn:applyInventoryRecordedDeficitBurden",
  "fn:recordedDeficitByLocation",
]);
const MIGRATION_CHANGED_RUNTIME = Object.freeze([
  "fn:createDurableInventoryMigrationPlan",
  "fn:dryRunInventoryMigration",
]);
const FUNGIBILITY_CHANGED_RUNTIME = Object.freeze([
  "fn:fungibilityAllocationIncrement",
  "fn:positionHasIndependentMeasuredContents",
  "fn:positionHasUnfixedIndependentMeasuredContents",
]);
const COORDINATOR_CHANGED_RUNTIME = Object.freeze([
  "fn:assertReservationConsumptionMatchesIssue",
  "fn:reservationLifecycleEvidenceFingerprint",
]);
const INTEGRITY_CHANGED_RUNTIME = Object.freeze([
  "fn:assertAllowedCountTransition",
  "fn:normalizedJsonObjectKeys",
  "fn:sameJson",
  "fn:sameNormalizedJsonValue",
]);
const QUANTITY_CHANGED_RUNTIME = Object.freeze([
  "fn:parseQuantity",
]);

function git(args, encoding = "utf8") {
  return execFileSync("git", args, { cwd: ROOT, encoding, maxBuffer: 64 * 1024 * 1024 });
}
function oldText(file) { return git(["show", `${OLD_SOURCE_HEAD}:${file}`]); }
function currentText(file) { return fs.readFileSync(finalConvergenceRepositoryPath(ROOT, file), "utf8"); }
function sourceFile(file, text) { return ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS); }
function emitted(node) {
  let text = node.getText(node.getSourceFile());
  if (ts.isFunctionDeclaration(node) && node.name !== undefined) {
    const name = node.name.text;
    text = text.replace(/^export\s+/u, "");
    text = text.replace(new RegExp(`^(?:async\\s+)?function\\s+${name}\\b`, "u"), (match) => match.replace(name, "__proof"));
  } else if (ts.isMethodDeclaration(node) || ts.isConstructorDeclaration(node)) {
    text = `class __Host { ${text} }`;
  }
  return ts.transpileModule(text, {
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None, removeComments: true, useDefineForClassFields: false },
  }).outputText.trim();
}
function runtimeRows(file, text) {
  const source = sourceFile(file, text);
  const rows = new Map();
  for (const statement of source.statements) {
    if (ts.isFunctionDeclaration(statement) && statement.name !== undefined && statement.body !== undefined) {
      rows.set(`fn:${statement.name.text}`, sha256(emitted(statement)));
    }
    if (ts.isClassDeclaration(statement) && statement.name !== undefined) {
      for (const member of statement.members) {
        if (ts.isMethodDeclaration(member) && member.body !== undefined) rows.set(`method:${statement.name.text}.${member.name.getText(source)}`, sha256(emitted(member)));
        if (ts.isConstructorDeclaration(member) && member.body !== undefined) rows.set(`ctor:${statement.name.text}`, sha256(emitted(member)));
      }
    }
  }
  return rows;
}
function changedRuntime(file) {
  const before = runtimeRows(file, oldText(file));
  const after = runtimeRows(file, currentText(file));
  const names = [...new Set([...before.keys(), ...after.keys()])].sort();
  return names.filter((name) => before.get(name) !== after.get(name));
}
function transpiledFile(text) {
  return ts.transpileModule(text, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ES2022, removeComments: true, useDefineForClassFields: false } }).outputText.trim();
}
function assertProjectionAlphaRename() {
  const before = transpiledFile(oldText("src/projection.ts"));
  const candidate = currentText("src/projection.ts").replaceAll("existingEventWithSameId", "sameEventId");
  assert.equal(transpiledFile(candidate), before, "Projection delta exceeded the reviewed local-variable alpha rename.");
}
function assertTraceabilityAlphaRename() {
  const before = oldText("src/traceability-replay.ts");
  const current = currentText("src/traceability-replay.ts");
  const start = current.indexOf("function validateAndIndexAddition(");
  const end = current.indexOf("function removeIndexedRelation(", start);
  assert(start >= 0 && end > start, "Traceability helper boundaries changed.");
  let helper = current.slice(start, end);
  helper = helper.replace(
    '  relation: Pick<InventoryTraceabilityRelationChange, "kind" | "from" | "to">,',
    '  change: Pick<InventoryTraceabilityRelationChange, "kind" | "from" | "to">,',
  );
  helper = helper.replaceAll("relation.from", "change.from").replaceAll("relation.to", "change.to").replaceAll("relation.kind", "change.kind");
  const candidate = `${current.slice(0, start)}${helper}${current.slice(end)}`;
  assert.equal(transpiledFile(candidate), transpiledFile(before), "Traceability replay delta exceeded the reviewed parameter alpha rename/comments.");
}
function assertTransfersDocumentationOnly() {
  assert.equal(transpiledFile(currentText("src/transfers.ts")), transpiledFile(oldText("src/transfers.ts")), "Transfer runtime emit changed.");
}
function exactChangedSourceFiles() {
  return git(["diff", "--name-only", OLD_SOURCE_HEAD, FINAL_SOURCE_HEAD, "--", "src"]).trim().split(/\r?\n/u).filter(Boolean).sort();
}
function currentHead() { return git(["rev-parse", "HEAD"]).trim(); }
let currentReviewAssuranceCache;
function currentReviewAssuranceReference(repositoryRoot) {
  const receiptFile = "experiments/tla-conformance/final-convergence/current-pr-review-assurance-receipt.json";
  const receiptSha256 = sha256(fs.readFileSync(finalConvergenceRepositoryPath(repositoryRoot, receiptFile)));
  const authoritativeStatus = git([
    "status", "--porcelain=v1", "--untracked-files=all", "--",
    "src", "formal", "scripts", "test", "package.json", "tsconfig.json", "tsconfig.test.json",
  ]);
  const key = `${currentHead()}:${receiptSha256}:${sha256(Buffer.from(authoritativeStatus))}`;
  if (currentReviewAssuranceCache?.key === key) return structuredClone(currentReviewAssuranceCache.reference);
  const reference = verifyCurrentReviewAssurance(repositoryRoot).reference;
  currentReviewAssuranceCache = { key, reference: structuredClone(reference) };
  return reference;
}
function assertCurrentProductTreeIsFinalSource() {
  const head = currentHead();
  const laterTracked = git([
    "diff",
    "--name-only",
    FINAL_SOURCE_HEAD,
    head,
    "--",
    "src",
    "formal",
    "scripts",
    "test",
    "package.json",
    "tsconfig.json",
    "tsconfig.test.json",
  ]).split(/\r?\n/u).filter(Boolean);
  assert.deepEqual(laterTracked, [...POST_CERTIFICATE_AUTHORITATIVE_FILES].sort(), "Integrated proof tree differs from the exact current-review certified product/assurance tree.");
}

export function buildFinalHeadTransport({ repositoryRoot = ROOT } = {}) {
  const resolvedRepositoryRoot = assertFinalConvergenceRepositoryRoot(repositoryRoot, import.meta.url);
  assertCurrentProductTreeIsFinalSource();
  assert.deepEqual(exactChangedSourceFiles(), CHANGED_SOURCE_FILES, "Final product source delta widened.");

  const oldSurfaceBytes = fs.readFileSync(finalConvergenceRepositoryPath(resolvedRepositoryRoot, OLD_SURFACE_FILE));
  const oldSurface = JSON.parse(oldSurfaceBytes.toString("utf8"));
  assert.equal(oldSurface.digest, OLD_SURFACE_DIGEST);
  assert.equal(oldSurface.callables.length, 535);
  const currentSurface = discoverCompilerSurface(resolvedRepositoryRoot);
  assert.equal(currentSurface.digest, FINAL_SURFACE_DIGEST);
  assert.equal(currentSurface.callables.length, 535);
  const oldByKey = new Map(oldSurface.callables.map((row) => [row.key, row]));
  const signatureChanges = [];
  const astChanges = [];
  for (const current of currentSurface.callables) {
    const previous = oldByKey.get(current.key);
    assert(previous !== undefined, `Final surface added callable ${current.key}`);
    if (previous.signatureHash !== current.signatureHash) signatureChanges.push(current.key);
    if (previous.declaration.astHash !== current.declaration.astHash) astChanges.push(current.key);
  }
  assert.deepEqual(signatureChanges, [], "A public signature changed after the cc97e assurance freeze.");
  assert.deepEqual(astChanges, [
    "export:.#cutoverInventoryAuthority::call[0]",
    "export:.#parseQuantity::call[0]",
    "export:./kernel#parseQuantity::call[0]",
    "export:./migrations#dryRunInventoryMigration::call[0]",
  ], "Unexpected public callable AST changed after cc97e.");

  assertProjectionAlphaRename();
  assertTraceabilityAlphaRename();
  assertTransfersDocumentationOnly();
  assert.deepEqual(changedRuntime("src/authority-cutover.ts"), AUTHORITY_CHANGED_RUNTIME);
  assert.deepEqual(changedRuntime("src/storage.ts"), STORAGE_CHANGED_RUNTIME);
  assert.deepEqual(changedRuntime("src/deficits.ts"), DEFICIT_CHANGED_RUNTIME);
  assert.deepEqual(changedRuntime("src/fungibility.ts"), FUNGIBILITY_CHANGED_RUNTIME);
  assert.deepEqual(changedRuntime("src/coordinator.ts"), COORDINATOR_CHANGED_RUNTIME);
  assert.deepEqual(changedRuntime("src/integrity.ts"), INTEGRITY_CHANGED_RUNTIME);
  assert.deepEqual(changedRuntime("src/migrations.ts"), MIGRATION_CHANGED_RUNTIME);
  assert.deepEqual(changedRuntime("src/quantity.ts"), QUANTITY_CHANGED_RUNTIME);

  const deficitTest = currentText("test/review-hardening.test.ts");
  assert(deficitTest.includes("treats an empty recorded-deficit location selection as all locations"));
  assert(deficitTest.includes("locationIds: []"));
  assert(deficitTest.includes("unselected location"));
  const authorityTest = currentText("test/authority.test.ts");
  assert(authorityTest.includes("completedReplay.targetWorldRoot"));
  assert(authorityTest.includes("completedManifest?.targetWorldRevision"));
  const storageTest = currentText("test/storage-conformance-suite.ts");
  assert(storageTest.includes("completedManifest?.targetWorldRoot"));
  assert(storageTest.includes("completedManifest?.targetWorldRevision"));
  const storageSource = currentText("src/storage.ts");
  for (const term of ["targetWorldRoot", "targetWorldRevision", "assertPublishedInventoryMigrationTarget"]) assert(storageSource.includes(term));

  const core = {
    schemaVersion: 1,
    status: "FINAL_HEAD_TRANSPORT_PROVED",
    oldSourceHead: OLD_SOURCE_HEAD,
    finalSourceHead: FINAL_SOURCE_HEAD,
    oldSurfaceDigest: OLD_SURFACE_DIGEST,
    finalSurfaceDigest: FINAL_SURFACE_DIGEST,
    callables: 535,
    publicSignatureChanges: 0,
    publicAstChanges: astChanges,
    exactSourceDelta: CHANGED_SOURCE_FILES,
    semantics: {
      projection: "ALPHA_RENAME_ONLY",
      traceabilityReplay: "ALPHA_RENAME_ONLY_PLUS_COMMENTS",
      transfers: "COMMENT_ONLY_RUNTIME_EMIT_IDENTICAL",
      authorityCutover: { changedRuntime: AUTHORITY_CHANGED_RUNTIME, rule: "Completed-cutover replay retains durable target evidence and compares source dispositions through their canonical migration fingerprint, making equivalent adapter key-order round trips replay-safe." },
      storage: { changedRuntime: STORAGE_CHANGED_RUNTIME, rule: "R144 records and validates exact published migration target root/revision; other storage runtime declarations are unchanged." },
      recordedDeficit: { changedRuntime: DEFICIT_CHANGED_RUNTIME, rule: "R167 makes empty locationIds select every location for recorded-deficit burdening while preserving strict non-empty filtering and independent per-location deficit accounting." },
      fungibility: { changedRuntime: FUNGIBILITY_CHANGED_RUNTIME, rule: "Current review repair aligns fungibility allocation with ordinary picking: independent measurement axes fixed by intact packaging do not make the package unsplittable, while serial and genuinely unfixed measured contents retain whole-position allocation semantics." },
      reservationConsumption: { changedRuntime: COORDINATOR_CHANGED_RUNTIME, rule: "Consume validation compares the full normalized reservation lifecycle through a canonical field-complete fingerprint, so equivalent independently materialized object-key order is accepted while allocation order and every semantic field remain exact." },
      integrityTransitions: { changedRuntime: INTEGRITY_CHANGED_RUNTIME, rule: "Integrity comparisons are recursively order-insensitive for object keys but preserve arrays exactly, and reconciliation event identity is admitted only by count completion." },
      migrationReplay: { changedRuntime: MIGRATION_CHANGED_RUNTIME, rule: "Migration planning reuses one immutable catalog snapshot per run; the snapshot value is unchanged and existing migration replay/plan assertions remain green." },
      quantityParsing: { changedRuntime: QUANTITY_CHANGED_RUNTIME, rule: "Decimal quantity parsing rejects impossible safe-integer magnitudes before BigInt construction while preserving exact accepted values, leading zeros, decimal scale, and the existing safe-integer validation." },
    },
    evidence: {
      oldSurface: { file: OLD_SURFACE_FILE, sha256: sha256(oldSurfaceBytes) },
      currentProductFiles: CHANGED_SOURCE_FILES.map((file) => ({ file, sha256: sha256(fs.readFileSync(finalConvergenceRepositoryPath(resolvedRepositoryRoot, file))) })),
      currentRegressionTests: ["test/authority.test.ts", "test/migrations.test.ts", "test/storage-conformance-suite.ts", "test/storage-conformance.test.ts", "test/review-hardening.test.ts", "test/fungibility.test.ts", "test/reservation-consume-shortage.test.ts", "test/formal-callgraph-semantics.test.ts"].map((file) => ({ file, sha256: sha256(fs.readFileSync(finalConvergenceRepositoryPath(resolvedRepositoryRoot, file))) })),
    },
    currentReviewAssuranceTransport: (() => { const recorded=JSON.parse(fs.readFileSync(finalConvergenceRepositoryPath(resolvedRepositoryRoot, R170_TRANSPORT),"utf8")); assert.equal(recorded.status,"R170_CURRENT_HEAD_ASSURANCE_TRANSPORT_PROVED"); assert.equal(recorded.currentHead,"f430b5141b0afc0b2796e38bc90ef45df4c0dcd9"); return { file:R170_TRANSPORT, sha256:sha256(fs.readFileSync(finalConvergenceRepositoryPath(resolvedRepositoryRoot, R170_TRANSPORT))), contentSha256:recorded.contentSha256, affectedStrictRows:recorded.affectedStrictRows, affectedValueRows:recorded.affectedValueRows }; })(),
    currentReviewPristineReproTransport: (() => { const recorded=JSON.parse(fs.readFileSync(finalConvergenceRepositoryPath(resolvedRepositoryRoot, R170_PRISTINE_TRANSPORT),"utf8")); assert.equal(recorded.status,"R170_PRISTINE_REPRO_ASSURANCE_TRANSPORT_PROVED"); assert.equal(recorded.currentHead,"7046246c88b32487def30e96fffa4b2a740e0005"); return { file:R170_PRISTINE_TRANSPORT, sha256:sha256(fs.readFileSync(finalConvergenceRepositoryPath(resolvedRepositoryRoot, R170_PRISTINE_TRANSPORT))), contentSha256:recorded.contentSha256, affectedStrictRows:recorded.affectedStrictRows, affectedValueRows:recorded.affectedValueRows }; })(),
    currentReviewAssurance: currentReviewAssuranceReference(resolvedRepositoryRoot),
    creditExpansion: false,
  };
  return { ...core, contentSha256: sha256(canonicalJson(core)) };
}

if (isDirectFinalConvergenceInvocation(import.meta.url)) {
  const artifact = buildFinalHeadTransport({ repositoryRoot: ROOT });
  const target = finalConvergenceRepositoryPath(ROOT, "experiments/tla-conformance/final-convergence/final-head-transport.json");
  const text = `${JSON.stringify(artifact, null, 2)}\n`;
  if (process.argv.includes("--check")) assert.equal(fs.readFileSync(target, "utf8"), text, "Final-head transport artifact is stale.");
  else fs.writeFileSync(target, text);
  console.log(JSON.stringify({ status: artifact.status, contentSha256: artifact.contentSha256, finalSurfaceDigest: artifact.finalSurfaceDigest }, null, 2));
}
