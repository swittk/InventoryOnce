import assert from "node:assert/strict";
import { assertAssuranceCommitChain, FROZEN_FINAL_EVIDENCE_HEAD } from "../../../scripts/immutable-assurance-inputs.mjs";
import { repositoryAssuranceStateSha256 } from "../../../scripts/repository-assurance-state.mjs";
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import ts from "typescript";
import { canonicalJson, discoverCompilerSurface, sha256 } from "../surface-bindings/lib/compiler-surface.mjs";
import { verifyCurrentReviewAssurance } from "./current-review-assurance.mjs";
import {
  assertFinalConvergenceRepositoryRoot,
  finalConvergenceRepositoryPath,
  finalConvergenceRepositoryRoot,
  isDirectFinalConvergenceInvocation,
} from "./repository-root.mjs";

const ROOT = finalConvergenceRepositoryRoot(import.meta.url);

export const OLD_SOURCE_HEAD = "6cafd49ff4b3729f80ae35d9fc0220f7a8a4b55a";
export const FINAL_SOURCE_HEAD = "535b94d68e80516f7ee8dd56a569d4aaf1799ff3";
export const OLD_SURFACE_DIGEST = "cc97e53a60ad9a4a700ee0c21f926e05b3a09dbd1ee739d94354a228fc47877a";
export const FINAL_SURFACE_DIGEST = "8a6c398e2a7f94de13dfbf0a4c40815685e6591a672ef12a586c5471fd39b697";
const OLD_SURFACE_FILE = "experiments/tla-conformance/final-convergence/old-surface-cc97e.json";
const R170_TRANSPORT = "experiments/tla-conformance/final-convergence/r170-assurance-transport.json";
const R170_PRISTINE_TRANSPORT = "experiments/tla-conformance/final-convergence/r170-pristine-repro-transport.json";
const POST_CERTIFICATE_AUTHORITATIVE_FILES = Object.freeze([
  "formal/implementation-conformance/EXECUTABLE_ASSURANCE_REPORT.json",
]);
const CHANGED_SOURCE_FILES = Object.freeze([
  "src/amounts.ts",
  "src/authority-cutover.ts",
  "src/canonical.ts",
  "src/catalog.ts",
  "src/commands.ts",
  "src/coordinator.ts",
  "src/deficits.ts",
  "src/events.ts",
  "src/facade.ts",
  "src/fungibility.ts",
  "src/integrity.ts",
  "src/migrations.ts",
  "src/model.ts",
  "src/picking.ts",
  "src/projection.ts",
  "src/quantity.ts",
  "src/stock-amount-rules.ts",
  "src/storage.ts",
  "src/traceability-replay.ts",
  "src/transfers.ts",
]);
const AUTHORITY_CHANGED_RUNTIME = Object.freeze([
  "fn:assertCompletedInventoryCutoverManifest",
  "fn:completedInventoryCutoverResult",
  "fn:cutoverInventoryAuthority",
]);
const STORAGE_CHANGED_RUNTIME = Object.freeze([
  "fn:assertPublishedInventoryMigrationTarget",
  "method:InMemoryInventoryDurableStorage.completeMigrationManifestUnlocked",
]);
const DEFICIT_CHANGED_RUNTIME = Object.freeze([
  "fn:applyInventoryRecordedDeficitBurden",
  "fn:recordedDeficitByLocation",
]);
const MIGRATION_CHANGED_RUNTIME = Object.freeze([
  "fn:createDurableInventoryMigrationPlan",
  "fn:dryRunInventoryMigration",
]);
const FUNGIBILITY_CHANGED_RUNTIME = Object.freeze([
  "fn:fungibilityAllocationIncrement",
  "fn:positionHasIndependentMeasuredContents",
  "fn:positionHasUnfixedIndependentMeasuredContents",
]);
const COORDINATOR_CHANGED_RUNTIME = Object.freeze([
  "fn:assertReservationConsumptionMatchesIssue",
  "fn:reservationLifecycleEvidenceFingerprint",
]);
const INTEGRITY_CHANGED_RUNTIME = Object.freeze([
  "fn:assertAllowedCountTransition",
  "fn:assertAllowedReservationTransition",
  "fn:canonicalNormalizedJson",
  "fn:inventoryCountBookDigest",
  "fn:inventoryDurableMigrationPlanDigest",
  "fn:inventoryDurablePlanDigest",
  "fn:inventoryProjectionDigest",
  "fn:inventoryReservationBookDigest",
  "fn:inventoryWorldContentRoots",
  "fn:normalizedJsonObjectKeys",
  "fn:sameJson",
  "fn:sameNormalizedJsonValue",
  "fn:sortedRecordRows",
]);
const QUANTITY_CHANGED_RUNTIME = Object.freeze([
  "fn:parseQuantity",
]);

function git(args, encoding = "utf8") {
  return execFileSync("git", args, { cwd: ROOT, encoding, maxBuffer: 64 * 1024 * 1024 });
}
function oldText(file) { return git(["show", `${OLD_SOURCE_HEAD}:${file}`]); }
function currentText(file) { return fs.readFileSync(finalConvergenceRepositoryPath(ROOT, file), "utf8"); }
function sourceFile(file, text) { return ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS); }
function emitted(node) {
  let text = node.getText(node.getSourceFile());
  if (ts.isFunctionDeclaration(node) && node.name !== undefined) {
    const name = node.name.text;
    text = text.replace(/^export\s+/u, "");
    text = text.replace(new RegExp(`^(?:async\\s+)?function\\s+${name}\\b`, "u"), (match) => match.replace(name, "__proof"));
  } else if (ts.isMethodDeclaration(node) || ts.isConstructorDeclaration(node)) {
    text = `class __Host { ${text} }`;
  }
  return ts.transpileModule(text, {
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.None, removeComments: true, useDefineForClassFields: false },
  }).outputText.trim();
}
function normalizedEmit(node) { return emitted(node).replace(/\s+/gu, " ").trim(); }

function runtimeRows(file, text) {
  const source = sourceFile(file, text);
  const rows = new Map();
  for (const statement of source.statements) {
    if (ts.isFunctionDeclaration(statement) && statement.name !== undefined && statement.body !== undefined) {
      rows.set(`fn:${statement.name.text}`, sha256(emitted(statement)));
    }
    if (ts.isClassDeclaration(statement) && statement.name !== undefined) {
      for (const member of statement.members) {
        if (ts.isMethodDeclaration(member) && member.body !== undefined) rows.set(`method:${statement.name.text}.${member.name.getText(source)}`, sha256(emitted(member)));
        if (ts.isConstructorDeclaration(member) && member.body !== undefined) rows.set(`ctor:${statement.name.text}`, sha256(emitted(member)));
      }
    }
  }
  return rows;
}
function changedRuntime(file) {
  const before = runtimeRows(file, oldText(file));
  const after = runtimeRows(file, currentText(file));
  const names = [...new Set([...before.keys(), ...after.keys()])].sort();
  return names.filter((name) => before.get(name) !== after.get(name));
}
function transpiledFile(text) {
  return ts.transpileModule(text, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ES2022, removeComments: true, useDefineForClassFields: false } }).outputText.trim();
}
function assertProjectionAlphaRename() {
  const before = transpiledFile(oldText("src/projection.ts"));
  const candidate = currentText("src/projection.ts").replaceAll("existingEventWithSameId", "sameEventId");
  assert.equal(transpiledFile(candidate), before, "Projection delta exceeded the reviewed local-variable alpha rename.");
}
function assertTraceabilityAlphaRename() {
  const before = oldText("src/traceability-replay.ts");
  const current = currentText("src/traceability-replay.ts");
  const start = current.indexOf("function validateAndIndexAddition(");
  const end = current.indexOf("function removeIndexedRelation(", start);
  assert(start >= 0 && end > start, "Traceability helper boundaries changed.");
  let helper = current.slice(start, end);
  helper = helper.replace(
    '  relation: Pick<InventoryTraceabilityRelationChange, "kind" | "from" | "to">,',
    '  change: Pick<InventoryTraceabilityRelationChange, "kind" | "from" | "to">,',
  );
  helper = helper.replaceAll("relation.from", "change.from").replaceAll("relation.to", "change.to").replaceAll("relation.kind", "change.kind");
  const candidate = `${current.slice(0, start)}${helper}${current.slice(end)}`;
  assert.equal(transpiledFile(candidate), transpiledFile(before), "Traceability replay delta exceeded the reviewed parameter alpha rename/comments.");
}
function assertFrozenTransfersDocumentationOnly() {
  assert.equal(transpiledFile(git(["show", `${FROZEN_FINAL_EVIDENCE_HEAD}:src/transfers.ts`])), transpiledFile(oldText("src/transfers.ts")), "Pre-systemic transfer runtime emit changed.");
}
function exactChangedSourceFiles() {
  return git(["diff", "--name-only", OLD_SOURCE_HEAD, FINAL_SOURCE_HEAD, "--", "src"]).trim().split(/\r?\n/u).filter(Boolean).sort();
}
function currentHead() { return git(["rev-parse", "HEAD"]).trim(); }
let currentReviewAssuranceCache;
function currentReviewAssuranceReference(repositoryRoot) {
  const receiptFile = "experiments/tla-conformance/final-convergence/current-pr-review-assurance-receipt.json";
  const receiptSha256 = sha256(fs.readFileSync(finalConvergenceRepositoryPath(repositoryRoot, receiptFile)));
  const authoritativeStatus = git([
    "status", "--porcelain=v1", "--untracked-files=all", "--",
    "src", "formal", "scripts", "test", "package.json", "tsconfig.json", "tsconfig.test.json",
  ]);
  const key = `${currentHead()}:${receiptSha256}:${sha256(Buffer.from(authoritativeStatus))}`;

  const reference = verifyCurrentReviewAssurance(repositoryRoot).reference;
  assertAssuranceCommitChain(repositoryRoot, [FROZEN_FINAL_EVIDENCE_HEAD, reference.certifiedHead, currentHead()]);
  currentReviewAssuranceCache = { key, reference: structuredClone(reference) };
  return reference;
}
function assertCurrentProductTreeIsFinalSource() {
  const head = currentHead();
  const laterTracked = git([
    "diff",
    "--name-only",
    FINAL_SOURCE_HEAD,
    head,
    "--",
    "src",
    "formal",
    "scripts",
    "test",
    "package.json",
    "tsconfig.json",
    "tsconfig.test.json",
  ]).split(/\r?\n/u).filter(Boolean);
  assert.deepEqual(laterTracked, [...POST_CERTIFICATE_AUTHORITATIVE_FILES].sort(), "Integrated proof tree differs from the exact current-review certified product/assurance tree.");
}

const REVIEW_517437_PRIOR_SOURCE_HEAD = "02d7b37c46bfe0f3129fa3f377960d740886a083";

/** Replace one exact function declaration while preserving all unrelated module bytes. */
function replaceTransitionFunction(text, name, replacement) {
  const declaration = transitionFunction(text, name);
  return `${text.slice(0, declaration.getStart())}${replacement}${text.slice(declaration.getEnd())}`;
}

/** Prove Review 517437's product delta is exactly two guards plus amount comments. */
function verifyReview517437ProductTransition() {
  const exactFiles = git([
    "diff", "--name-only", REVIEW_517437_PRIOR_SOURCE_HEAD, FINAL_SOURCE_HEAD, "--", "src",
  ]).trim().split(/\r?\n/u).filter(Boolean).sort();
  assert.deepEqual(exactFiles, ["src/amounts.ts", "src/canonical.ts", "src/events.ts"]);

  const priorAmount = git(["show", `${REVIEW_517437_PRIOR_SOURCE_HEAD}:src/amounts.ts`]);
  assert.equal(
    transpiledFile(currentText("src/amounts.ts")),
    transpiledFile(priorAmount),
    "Review 517437 amount delta exceeded comments.",
  );

  const priorCanonical = git(["show", `${REVIEW_517437_PRIOR_SOURCE_HEAD}:src/canonical.ts`]);
  let restoredCanonical = currentText("src/canonical.ts");
  restoredCanonical = replaceTransitionFunction(
    restoredCanonical,
    "inventoryIntentFingerprint",
    transitionFunction(priorCanonical, "inventoryIntentFingerprint").getText(),
  );
  restoredCanonical = replaceTransitionFunction(
    restoredCanonical,
    "assertInventoryIntentFingerprintValues",
    transitionFunction(priorCanonical, "assertFiniteInventoryIntentFingerprintNumbers").getText(),
  );
  assert.equal(
    transpiledFile(restoredCanonical),
    transpiledFile(priorCanonical),
    "Review 517437 fingerprint delta contains an unproved extra runtime change.",
  );

  const priorEvents = git(["show", `${REVIEW_517437_PRIOR_SOURCE_HEAD}:src/events.ts`]);
  const restoredEvents = replaceTransitionFunction(
    currentText("src/events.ts"),
    "assertCanonicalInventoryTime",
    transitionFunction(priorEvents, "assertCanonicalInventoryTime").getText(),
  );
  assert.equal(
    transpiledFile(restoredEvents),
    transpiledFile(priorEvents),
    "Review 517437 canonical-time delta contains an unproved extra runtime change.",
  );

  return {
    priorCertifiedHead: REVIEW_517437_PRIOR_SOURCE_HEAD,
    certifiedHead: FINAL_SOURCE_HEAD,
    exactFiles,
    laws: [
      "Intent fingerprints reject every runtime value outside the typed primitive/array domain before JSON encoding.",
      "Canonical inventory timestamps remain fixed-width four-digit UTC text, so lexical ordering equals chronological ordering.",
      "The amount-source delta is comments only and emits identical JavaScript.",
      "Reversing the two guard changes restores the prior certified runtime emission exactly.",
    ],
    inputs: exactFiles.map((file) => ({
      file,
      sha256: sha256(fs.readFileSync(finalConvergenceRepositoryPath(ROOT, file))),
    })),
  };
}

function buildUncachedFinalHeadTransport({ repositoryRoot = ROOT, context, surface } = {}) {
  const resolvedRepositoryRoot = assertFinalConvergenceRepositoryRoot(repositoryRoot, import.meta.url);
  assertCurrentProductTreeIsFinalSource();
  assert.deepEqual(exactChangedSourceFiles(), CHANGED_SOURCE_FILES, "Final product source delta widened.");

  const oldSurfaceBytes = fs.readFileSync(finalConvergenceRepositoryPath(resolvedRepositoryRoot, OLD_SURFACE_FILE));
  const oldSurface = JSON.parse(oldSurfaceBytes.toString("utf8"));
  assert.equal(oldSurface.digest, OLD_SURFACE_DIGEST);
  assert.equal(oldSurface.callables.length, 535);
  const currentSurface = surface ?? discoverCompilerSurface(resolvedRepositoryRoot, context);
  assert.equal(currentSurface.digest, FINAL_SURFACE_DIGEST);
  assert.equal(currentSurface.callables.length, 535);
  const oldByKey = new Map(oldSurface.callables.map((row) => [row.key, row]));
  const signatureChanges = [];
  const astChanges = [];
  for (const current of currentSurface.callables) {
    const previous = oldByKey.get(current.key);
    assert(previous !== undefined, `Final surface added callable ${current.key}`);
    if (previous.signatureHash !== current.signatureHash) signatureChanges.push(current.key);
    if (previous.declaration.astHash !== current.declaration.astHash) astChanges.push(current.key);
  }
  assert.deepEqual(signatureChanges, [], "A public signature changed after the cc97e assurance freeze.");
  assert.deepEqual(astChanges, [
    "export:.#cutoverInventoryAuthority::call[0]",
    "export:.#parseQuantity::call[0]",
    "export:.#resolveInventoryAmount::call[0]",
    "export:./kernel#assertCanonicalInventoryTime::call[0]",
    "export:./kernel#inventoryIntentFingerprint::call[0]",
    "export:./kernel#normalizeInventoryStockPositionKey::call[0]",
    "export:./kernel#parseQuantity::call[0]",
    "export:./kernel#resolveInventoryAmount::call[0]",
    "export:./migrations#dryRunInventoryMigration::call[0]",
    "export:./storage#inventoryCountBookDigest::call[0]",
    "export:./storage#inventoryDurableMigrationPlanDigest::call[0]",
    "export:./storage#inventoryDurablePlanDigest::call[0]",
    "export:./storage#inventoryProjectionDigest::call[0]",
    "export:./storage#inventoryReservationBookDigest::call[0]",
    "export:./storage#inventoryWorldContentRoots::call[0]",
  ], "Unexpected public callable AST changed after cc97e.");

  assertProjectionAlphaRename();
  assertTraceabilityAlphaRename();
  assertFrozenTransfersDocumentationOnly();
  assert.deepEqual(changedRuntime("src/authority-cutover.ts"), AUTHORITY_CHANGED_RUNTIME);
  assert.deepEqual(changedRuntime("src/storage.ts"), STORAGE_CHANGED_RUNTIME);
  assert.deepEqual(changedRuntime("src/deficits.ts"), DEFICIT_CHANGED_RUNTIME);
  assert.deepEqual(changedRuntime("src/fungibility.ts"), FUNGIBILITY_CHANGED_RUNTIME);
  assert.deepEqual(changedRuntime("src/coordinator.ts"), COORDINATOR_CHANGED_RUNTIME);
  assert.deepEqual(changedRuntime("src/integrity.ts"), INTEGRITY_CHANGED_RUNTIME);
  assert.deepEqual(changedRuntime("src/migrations.ts"), MIGRATION_CHANGED_RUNTIME);
  assert.deepEqual(changedRuntime("src/quantity.ts"), QUANTITY_CHANGED_RUNTIME);
  const systemicRuntimeTransition = verifySystemicRuntimeTransition();
  const systemicIntegrityTransition = verifySystemicIntegrityTransition();
  const review517437ProductTransition = verifyReview517437ProductTransition();

  const deficitTest = currentText("test/review-hardening.test.ts");
  assert(deficitTest.includes("treats an empty recorded-deficit location selection as all locations"));
  assert(deficitTest.includes("locationIds: []"));
  assert(deficitTest.includes("unselected location"));
  const authorityTest = currentText("test/authority.test.ts");
  assert(authorityTest.includes("completedReplay.targetWorldRoot"));
  assert(authorityTest.includes("completedManifest?.targetWorldRevision"));
  const storageTest = currentText("test/storage-conformance-suite.ts");
  assert(storageTest.includes("completedManifest?.targetWorldRoot"));
  assert(storageTest.includes("completedManifest?.targetWorldRevision"));
  const storageSource = currentText("src/storage.ts");
  for (const term of ["targetWorldRoot", "targetWorldRevision", "assertPublishedInventoryMigrationTarget"]) assert(storageSource.includes(term));

  const core = {
    schemaVersion: 1,
    status: "FINAL_HEAD_TRANSPORT_PROVED",
    oldSourceHead: OLD_SOURCE_HEAD,
    finalSourceHead: FINAL_SOURCE_HEAD,
    oldSurfaceDigest: OLD_SURFACE_DIGEST,
    finalSurfaceDigest: FINAL_SURFACE_DIGEST,
    callables: 535,
    publicSignatureChanges: 0,
    publicAstChanges: astChanges,
    exactSourceDelta: CHANGED_SOURCE_FILES,
    semantics: {
      projection: "ALPHA_RENAME_ONLY",
      traceabilityReplay: "ALPHA_RENAME_ONLY_PLUS_COMMENTS",
      transfers: "COMMENT_ONLY_RUNTIME_EMIT_IDENTICAL",
      authorityCutover: { changedRuntime: AUTHORITY_CHANGED_RUNTIME, rule: "Completed-cutover replay retains durable target evidence and compares source dispositions through their canonical migration fingerprint, making equivalent adapter key-order round trips replay-safe." },
      storage: { changedRuntime: STORAGE_CHANGED_RUNTIME, rule: "R144 records and validates exact published migration target root/revision; other storage runtime declarations are unchanged." },
      recordedDeficit: { changedRuntime: DEFICIT_CHANGED_RUNTIME, rule: "R167 makes empty locationIds select every location for recorded-deficit burdening while preserving strict non-empty filtering and independent per-location deficit accounting." },
      fungibility: { changedRuntime: FUNGIBILITY_CHANGED_RUNTIME, rule: "Current review repair aligns fungibility allocation with ordinary picking: independent measurement axes fixed by intact packaging do not make the package unsplittable, while serial and genuinely unfixed measured contents retain whole-position allocation semantics." },
      reservationConsumption: { changedRuntime: COORDINATOR_CHANGED_RUNTIME, rule: "Consume validation compares the full normalized reservation lifecycle through a canonical field-complete fingerprint, so equivalent independently materialized object-key order is accepted while allocation order and every semantic field remain exact." },
      integrityTransitions: { changedRuntime: INTEGRITY_CHANGED_RUNTIME, rule: "Integrity comparisons are recursively order-insensitive for object keys but preserve arrays exactly, and reconciliation event identity is admitted only by count completion." },
      migrationReplay: { changedRuntime: MIGRATION_CHANGED_RUNTIME, rule: "Migration planning reuses one immutable catalog snapshot per run; the snapshot value is unchanged and existing migration replay/plan assertions remain green." },
      quantityParsing: { changedRuntime: QUANTITY_CHANGED_RUNTIME, rule: "Decimal quantity parsing rejects impossible safe-integer magnitudes before BigInt construction while preserving exact accepted values, leading zeros, decimal scale, and the existing safe-integer validation." },
      systemicRuntimeTransition,
      systemicIntegrityTransition,
      review517437ProductTransition,
    },
    evidence: {
      oldSurface: { file: OLD_SURFACE_FILE, sha256: sha256(oldSurfaceBytes) },
      currentProductFiles: CHANGED_SOURCE_FILES.map((file) => ({ file, sha256: sha256(fs.readFileSync(finalConvergenceRepositoryPath(resolvedRepositoryRoot, file))) })),
      currentRegressionTests: ["test/authority.test.ts", "test/migrations.test.ts", "test/storage-conformance-suite.ts", "test/storage-conformance.test.ts", "test/review-hardening.test.ts", "test/fungibility.test.ts", "test/reservation-consume-shortage.test.ts", "test/formal-callgraph-semantics.test.ts"].map((file) => ({ file, sha256: sha256(fs.readFileSync(finalConvergenceRepositoryPath(resolvedRepositoryRoot, file))) })),
    },
    currentReviewAssuranceTransport: (() => { const recorded=JSON.parse(fs.readFileSync(finalConvergenceRepositoryPath(resolvedRepositoryRoot, R170_TRANSPORT),"utf8")); assert.equal(recorded.status,"R170_CURRENT_HEAD_ASSURANCE_TRANSPORT_PROVED"); assert.equal(recorded.currentHead,"f430b5141b0afc0b2796e38bc90ef45df4c0dcd9"); return { file:R170_TRANSPORT, sha256:sha256(fs.readFileSync(finalConvergenceRepositoryPath(resolvedRepositoryRoot, R170_TRANSPORT))), contentSha256:recorded.contentSha256, affectedStrictRows:recorded.affectedStrictRows, affectedValueRows:recorded.affectedValueRows }; })(),
    currentReviewPristineReproTransport: (() => { const recorded=JSON.parse(fs.readFileSync(finalConvergenceRepositoryPath(resolvedRepositoryRoot, R170_PRISTINE_TRANSPORT),"utf8")); assert.equal(recorded.status,"R170_PRISTINE_REPRO_ASSURANCE_TRANSPORT_PROVED"); assert.equal(recorded.currentHead,"7046246c88b32487def30e96fffa4b2a740e0005"); return { file:R170_PRISTINE_TRANSPORT, sha256:sha256(fs.readFileSync(finalConvergenceRepositoryPath(resolvedRepositoryRoot, R170_PRISTINE_TRANSPORT))), contentSha256:recorded.contentSha256, affectedStrictRows:recorded.affectedStrictRows, affectedValueRows:recorded.affectedValueRows }; })(),
    currentReviewAssurance: currentReviewAssuranceReference(resolvedRepositoryRoot),
    creditExpansion: false,
  };
  return { ...core, contentSha256: sha256(canonicalJson(core)) };
}

/** Find one named body in a source module; missing/duplicate declarations cannot inherit a transition theorem. */
function transitionFunction(text, name) {
  const source = sourceFile("transition.ts", text);
  const declarations = source.statements.filter(node => ts.isFunctionDeclaration(node) && node.name?.text === name && node.body !== undefined);
  assert.equal(declarations.length, 1, `Systemic transition needs exactly one function ${name}.`);
  return declarations[0];
}

/** Verify the systemic integrity delta by reversing canonical durable hashing and the corrupt reservation guard. */
export function verifySystemicIntegrityTransition() {
  const file = "src/integrity.ts";
  const before = git(["show", `${FROZEN_FINAL_EVIDENCE_HEAD}:${file}`]);
  let restored = currentText(file);
  const source = sourceFile(file, restored);
  const canonical = source.statements.filter(node => ts.isFunctionDeclaration(node) && node.name?.text === "canonicalNormalizedJson" && node.body !== undefined);
  assert.equal(canonical.length, 1, "Systemic integrity transition needs exactly one canonical JSON helper.");
  const canonicalText = canonical[0].getText();
  assert(canonicalText.includes("keys.sort()"), "Canonical durable hashing must sort nested object keys.");
  assert(canonicalText.includes("value.map"), "Canonical durable hashing must preserve array order.");
  restored = restored.slice(0, canonical[0].getStart()) + restored.slice(canonical[0].getEnd());
  const canonicalCalls = restored.split("canonicalNormalizedJson(").length - 1;
  assert.equal(canonicalCalls, 7, "Systemic integrity transition changed the canonical-hash call set.");
  restored = restored.replaceAll("canonicalNormalizedJson(", "JSON.stringify(");

  const restoredSource = sourceFile(file, restored);
  const reservation = restoredSource.statements.filter(node => ts.isFunctionDeclaration(node) && node.name?.text === "assertAllowedReservationTransition" && node.body !== undefined);
  assert.equal(reservation.length, 1, "Systemic integrity transition needs one reservation transition validator.");
  const guard = reservation[0].body.statements.find(statement => statement.getText().includes("base.consumptionEventId !== undefined"));
  assert(guard !== undefined, "Systemic integrity transition lost the corrupt reservation-state guard.");
  assert(guard.getText().includes("Non-consumed reservation state cannot retain a consumption event."), "Reservation-state guard changed its rejected invariant.");
  restored = restored.slice(0, guard.getStart()) + restored.slice(guard.getEnd());
  assert.equal(transpiledFile(restored), transpiledFile(before), "Systemic integrity delta contains an unproved extra change.");
  return {
    priorProofHead: FROZEN_FINAL_EVIDENCE_HEAD,
    exactFile: file,
    laws: [
      "Nested object insertion order cannot change a durable content root; array order remains semantic.",
      "A non-consumed reservation cannot carry a consumption event before a lifecycle operation is applied.",
      "Reversing exactly those two repairs restores the frozen reviewed runtime byte-for-byte after TypeScript emission.",
    ],
    input: { file, sha256: sha256(currentText(file)) },
  };
}

/** Verify the complete systemic source delta by reversing only proved guard insertions and identity-set quotienting. */
export function verifySystemicRuntimeTransition() {
  const sourceFiles = ["src/amounts.ts", "src/catalog.ts", "src/commands.ts", "src/facade.ts", "src/fungibility.ts", "src/picking.ts", "src/transfers.ts"];
  const before = new Map(sourceFiles.map(file => [file, git(["show", `${FROZEN_FINAL_EVIDENCE_HEAD}:${file}`])]));
  const restored = new Map(sourceFiles.map(file => [file, currentText(file)]));
  const guardSites = [
    ["src/amounts.ts", "resolveInventoryAmount", "assertInventoryAmountKind(amount);"],
    ["src/catalog.ts", "normalizeInventoryCompositionOutput", "assertInventoryCompositionAmountKind(output.amount);"],
    ["src/commands.ts", "findCommandItem", "assertInventoryAmountKind(amount);"],
    ["src/facade.ts", "normalizeFacadeAmount", "assertInventoryAmountKind(amount);"],
    ["src/picking.ts", "resolveAllocationItemAndSelector", "assertInventoryAmountKind(amount);"],
    ["src/transfers.ts", "transferCommandItem", "assertInventoryAmountKind(amount);"],
    ["src/transfers.ts", "inventoryTransferAmountIntentValue", "assertInventoryAmountKind(amount);"],
  ];
  for (const [file, name, guard] of guardSites) {
    const text = restored.get(file), declaration = transitionFunction(text, name), first = declaration.body.statements[0];
    assert.equal(first?.getText(), guard, `Amount admission must precede all effects in ${name}.`);
    restored.set(file, text.slice(0, first.getStart()) + text.slice(first.getEnd()));
  }
  for (const file of sourceFiles) {
    let text = restored.get(file);
    const source = sourceFile(file, text), added = source.statements.filter(node => ts.isImportDeclaration(node) && node.moduleSpecifier.text === "./stock-amount-rules.js");
    assert.equal(added.length, 1, `Unexpected systemic dependency import in ${file}.`);
    text = text.slice(0, added[0].getStart()) + text.slice(added[0].getEnd());
    restored.set(file, text);
  }

  const rules = currentText("src/stock-amount-rules.ts");
  const rulesSource = sourceFile("rules.ts", rules);
  assert.equal(rulesSource.statements.every(node => ts.isImportDeclaration(node) || ts.isFunctionDeclaration(node)), true, "Shared rules gained unproved module initialization.");
  assert.deepEqual(rulesSource.statements.filter(ts.isFunctionDeclaration).map(node => node.name?.text).sort(), ["assertInventoryAmountKind", "assertInventoryCompositionAmountKind", "positionHasUnfixedIndependentMeasuredContents"].sort());
  const expectedGuards = [
    ["assertInventoryAmountKind", `function assertInventoryAmountKind(amount) {
      if (
        amount === null || typeof amount !== "object" || Array.isArray(amount) ||
        (amount.kind !== InventoryAmountKind.Measured && amount.kind !== InventoryAmountKind.Package)
      ) {
        throw new Error("Inventory amount kind is invalid.");
      }
    }`],
    ["assertInventoryCompositionAmountKind", `function assertInventoryCompositionAmountKind(amount) {
      if (
        amount === null || typeof amount !== "object" || Array.isArray(amount) ||
        (amount.kind !== InventoryCompositionOutputAmountKind.Measured && amount.kind !== InventoryCompositionOutputAmountKind.Package)
      ) {
        throw new Error("Inventory composition output amount kind is invalid.");
      }
    }`],
  ];
  for (const [name, expected] of expectedGuards) assert.equal(normalizedEmit(transitionFunction(rules, name)), normalizedEmit(transitionFunction(expected, name)), `${name} no longer implements exact closed-union admission.`);
  const predicate = transitionFunction(before.get("src/picking.ts"), "positionHasUnfixedIndependentMeasuredContents");
  assert.equal(emitted(transitionFunction(rules, "positionHasUnfixedIndependentMeasuredContents")), emitted(predicate), "Shared measurement predicate changed instead of being extracted exactly.");

  let picking = restored.get("src/picking.ts");
  const increment = transitionFunction(picking, "allocationIncrementForPosition");
  picking = picking.slice(0, increment.getStart()) + predicate.getText() + "\n" + picking.slice(increment.getStart());
  restored.set("src/picking.ts", picking);
  let fungibility = restored.get("src/fungibility.ts");
  const wrapper = transitionFunction(fungibility, "positionHasUnfixedIndependentMeasuredContents");
  const expectedWrapper = `function positionHasUnfixedIndependentMeasuredContents(catalog, position, item) {
    const packagingRevisionId = position.key.packagingRevisionId;
    const packaging = packagingRevisionId === undefined ? undefined : catalog.packagingRevision(packagingRevisionId);
    return hasUnfixedIndependentMeasuredContents(position, item, packaging);
  }`;
  assert.equal(normalizedEmit(wrapper), normalizedEmit(transitionFunction(expectedWrapper, wrapper.name.text)), "Fungibility wrapper no longer delegates the exact same physical predicate.");
  const oldWrapper = transitionFunction(before.get("src/fungibility.ts"), wrapper.name.text);
  fungibility = fungibility.slice(0, wrapper.getStart()) + oldWrapper.getText() + fungibility.slice(wrapper.getEnd());
  // Restore only the old catalog import removed because its measurement predicate moved to the shared module.
  const imports = sourceFile("fungibility.ts", fungibility).statements.filter(node => ts.isImportDeclaration(node) && node.moduleSpecifier.text === "./catalog.js");
  const oldImports = sourceFile("fungibility.ts", before.get("src/fungibility.ts")).statements.filter(node => ts.isImportDeclaration(node) && node.moduleSpecifier.text === "./catalog.js");
  assert.equal(imports.length, 1); assert.equal(oldImports.length, 1);
  const bindings = node => node.importClause.namedBindings.elements.map(element => element.getText()).sort();
  assert.deepEqual(bindings(imports[0]), bindings(oldImports[0]).filter(name => name !== "InventoryMeasurementRequirement"));
  fungibility = fungibility.slice(0, imports[0].getStart()) + oldImports[0].getText() + fungibility.slice(imports[0].getEnd());
  restored.set("src/fungibility.ts", fungibility);

  let commands = restored.get("src/commands.ts");
  const unique = transitionFunction(commands, "uniqueTransformationGenealogyNodes");
  const expectedUnique = `function uniqueTransformationGenealogyNodes(nodes) {
    const unique = new Map();
    for (const node of nodes) {
      if (node === undefined) throw new Error("Complete transformation lineage lost one node.");
      const identity = inventoryTraceabilityNodeIdentity(node);
      if (!unique.has(identity)) unique.set(identity, node);
    }
    return [...unique.values()];
  }`;
  assert.equal(normalizedEmit(unique), normalizedEmit(transitionFunction(expectedUnique, unique.name.text)), "Genealogy node quotient must retain exactly one representative per existing exact physical identity.");
  commands = commands.slice(0, unique.getStart()) + commands.slice(unique.getEnd());
  for (const [uniqueName, originalName] of [["uniqueConsumedNodes", "consumedNodes"], ["uniqueProducedNodes", "producedNodes"]]) {
    const text = `const ${uniqueName} = uniqueTransformationGenealogyNodes(${originalName});`;
    assert.equal(commands.split(text).length, 2, "Genealogy quotient must be applied once to each side before forming the product.");
    commands = commands.replace(text, "");
    assert.equal(commands.split(`of ${uniqueName}`).length, 2, "Genealogy product must consume the unique node domain exactly once.");
    commands = commands.replace(`of ${uniqueName}`, `of ${originalName}`);
  }
  restored.set("src/commands.ts", commands);
  for (const file of sourceFiles) assert.equal(transpiledFile(restored.get(file)), transpiledFile(before.get(file)), `Systemic source delta contains an unproved extra change in ${file}.`);
  return {
    priorProofHead: FROZEN_FINAL_EVIDENCE_HEAD,
    exactFiles: [...sourceFiles, "src/stock-amount-rules.ts"].sort(),
    guardSites: guardSites.map(([file, declaration]) => ({ file, declaration })),
    laws: ["Closed Measured/Package unions are unchanged for every admitted typed value; all other discriminators reject before interpretation/effects.", "Picking and fungibility execute one byte-equivalent extracted independent-measurement predicate.", "The image of the product of stock-line identities equals the Cartesian product of their unique identity images; duplicate representations neither add nor remove a genealogy relation.", "Every original stock line and all remaining runtime statements are retained exactly by the verified reverse transformation."],
    inputs: [...sourceFiles, "src/stock-amount-rules.ts"].sort().map(file => ({ file, sha256: sha256(currentText(file)) })),
  };
}

/** Reuse one verified transition only while every authoritative/evidence input remains byte-identical. */
let finalTransportCache;
export function buildFinalHeadTransport(input = {}) {
  const repositoryRoot = assertFinalConvergenceRepositoryRoot(input.repositoryRoot ?? ROOT, import.meta.url);
  const evidenceNames = [OLD_SURFACE_FILE, R170_TRANSPORT, R170_PRISTINE_TRANSPORT, "experiments/tla-conformance/final-convergence/current-pr-review-assurance-receipt.json", "experiments/tla-conformance/final-convergence/current-pr-review-full.log"];
  const key = [currentHead(), repositoryAssuranceStateSha256(repositoryRoot), ...evidenceNames.map(file => sha256(fs.readFileSync(finalConvergenceRepositoryPath(repositoryRoot, file))))].join(":");
  if (finalTransportCache?.key !== key) finalTransportCache = { key, artifact: buildUncachedFinalHeadTransport({ ...input, repositoryRoot }) };
  return structuredClone(finalTransportCache.artifact);
}

if (isDirectFinalConvergenceInvocation(import.meta.url)) {
  const artifact = buildFinalHeadTransport({ repositoryRoot: ROOT });
  const target = finalConvergenceRepositoryPath(ROOT, "experiments/tla-conformance/final-convergence/final-head-transport.json");
  const text = `${JSON.stringify(artifact, null, 2)}\n`;
  if (process.argv.includes("--check")) assert.equal(fs.readFileSync(target, "utf8"), text, "Final-head transport artifact is stale.");
  else fs.writeFileSync(target, text);
  console.log(JSON.stringify({ status: artifact.status, contentSha256: artifact.contentSha256, finalSurfaceDigest: artifact.finalSurfaceDigest }, null, 2));
}
