import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { discoverCompilerSurface, sha256 } from "../surface-bindings/lib/compiler-surface.mjs";
import { buildFinalHeadTransport, FINAL_SURFACE_DIGEST } from "./final-head-transport.mjs";

export const proofKind = "final-convergence-package-readworld-a2-b22-v1";
const HISTORICAL = "experiments/tla-conformance/external-membership-rehearsal-r35/readworld-contract-evidence.json";
const BASE_INDEX = "experiments/tla-conformance/final-convergence/base-authority-index.json";
const TRANSPORT = "experiments/tla-conformance/final-convergence/final-head-transport.json";
const OFFICIAL = "experiments/tla-conformance/r105-layered-6dfc-currentization/surface-bindings-6dfc.json";
function readJson(file) { return JSON.parse(fs.readFileSync(path.resolve(file), "utf8")); }
function ref(file) { const bytes = fs.readFileSync(path.resolve(file)); return { file, sha256: sha256(bytes) }; }
function canonical(value) { if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`; if (value !== null && typeof value === "object") return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(",")}}`; return JSON.stringify(value); }
function live(surface, key) { const rows = surface.callables.filter((row) => row.key === key); assert.equal(rows.length, 1, `Missing current readWorld callable ${key}`); return rows[0]; }
const historical = readJson(HISTORICAL);
export const supportedSurfaceRows = Object.freeze(historical.proofs.map(({ surfaceKey, mode }) => Object.freeze({ surfaceKey, mode })).sort((a,b)=>a.surfaceKey.localeCompare(b.surfaceKey)));
assert.equal(supportedSurfaceRows.length, 24);
assert.equal(supportedSurfaceRows.filter((row)=>row.mode==="A").length,2);
assert.equal(supportedSurfaceRows.filter((row)=>row.mode==="B").length,22);
const ownKeys = new Set(supportedSurfaceRows.map((row)=>row.surfaceKey));
function transportReceipt(){const built=buildFinalHeadTransport(),recorded=readJson(TRANSPORT);assert.deepEqual(recorded,built);return{...ref(TRANSPORT),contentSha256:built.contentSha256};}
function proofDependencyKeys(proof, officialModes) {
  const found = new Set();
  function walk(value) {
    if (Array.isArray(value)) { for (const item of value) walk(item); return; }
    if (value === null || typeof value !== "object") return;
    if (typeof value.surfaceKey === "string" && officialModes.has(value.surfaceKey)) found.add(value.surfaceKey);
    for (const child of Object.values(value)) walk(child);
  }
  walk(proof.semantics ?? proof);
  return [...found].sort();
}
function resolveBaseAuthority(key, mode, indexByKey, surface, inputs, transport) {
  const row = indexByKey.get(key);
  assert(row !== undefined, `ReadWorld dependency lacks consolidated current authority: ${key}`);
  assert.equal(row.mode, mode, `ReadWorld dependency mode changed: ${key}`);
  const authority = row.authority;
  const bytes = fs.readFileSync(path.resolve(authority.evidence.file));
  assert.equal(sha256(bytes), authority.evidence.sha256, `ReadWorld dependency evidence changed: ${key}`);
  inputs.set(authority.evidence.file, authority.evidence);
  const document = JSON.parse(bytes.toString("utf8"));
  let recorded;
  if (authority.kind === "PROOF_ARTIFACT") {
    recorded = document.proofs?.[authority.proofIndex];
    assert.equal(recorded?.surfaceKey, key);
    assert.equal(sha256(Buffer.from(canonical(recorded.semantics ?? recorded.semantic ?? recorded))), authority.proofSemanticSha256,
      `ReadWorld dependency semantic identity changed: ${key}`);
  } else if (authority.kind === "BINDING_REGISTRY") {
    recorded = document.bindings?.[authority.bindingIndex];
    assert.equal(recorded?.surfaceKey, key);
    assert.equal(recorded?.mode, mode);
  } else {
    recorded = document.rows?.[authority.rowIndex]?.binding;
    assert.equal(recorded?.surfaceKey, key);
    assert.equal(recorded?.mode, mode);
  }
  const callable = live(surface,key);
  if (recorded?.signatureHash !== undefined) assert.equal(recorded.signatureHash,callable.signatureHash);
  if (recorded?.declaration?.astHash !== undefined && authority.surfaceDigest === FINAL_SURFACE_DIGEST) assert.equal(recorded.declaration.astHash,callable.declaration.astHash);
  return { surfaceKey:key,mode,authority,finalSignatureHash:callable.signatureHash,finalDeclarationAstHash:callable.declaration.astHash,finalHeadTransport:transport };
}
export function buildFamilyArtifact({repositoryRoot=process.cwd(),surface=discoverCompilerSurface(repositoryRoot)}={}){
  assert.equal(surface.digest,FINAL_SURFACE_DIGEST);
  assert.equal(historical.proofKind,"package-readworld-environment-contract-a2-b22-v1");
  assert.equal(historical.allAdmittedInputs,true);assert.equal(historical.sampledInputs,0);assert.equal(historical.proofs.length,24);
  const official=readJson(OFFICIAL),officialModes=new Map(official.bindings.map((row)=>[row.surfaceKey,row.mode]));
  const base=readJson(BASE_INDEX);assert.equal(base.selectedRows,418);assert.equal(base.missingRows,70);
  const indexByKey=new Map(base.selected.map((row)=>[row.surfaceKey,row]));
  const transport=transportReceipt(),inputs=new Map();
  for(const file of [HISTORICAL,BASE_INDEX,OFFICIAL,TRANSPORT,"src/facade.ts"])inputs.set(file,ref(file));
  const proofs=[];
  for(const old of historical.proofs){
    const callable=live(surface,old.surfaceKey);assert.equal(old.signatureHash,callable.signatureHash);assert.equal(old.declaration.astHash,callable.declaration.astHash,`ReadWorld wrapper AST drifted: ${old.surfaceKey}`);
    const dependencies=[];
    for(const key of proofDependencyKeys(old,officialModes)){
      if(ownKeys.has(key)){dependencies.push({surfaceKey:key,mode:officialModes.get(key),kind:"SAME_CURRENT_FAMILY"});continue;}
      const mode=officialModes.get(key);assert.notEqual(mode,"HARD_RED",`Credited external dependency survived readWorld boundary migration: ${key}`);
      dependencies.push(resolveBaseAuthority(key,mode,indexByKey,surface,inputs,transport));
    }
    proofs.push({surfaceKey:old.surfaceKey,mode:old.mode,signatureHash:callable.signatureHash,declaration:callable.declaration,semantics:{historicalProofKind:historical.proofKind,historicalEvidence:ref(HISTORICAL),historicalSemantics:structuredClone(old.semantics??old),currentDependencyClosure:dependencies,finalHeadTransport:transport,environmentBoundaryRule:"Historical readWorld/Clock surface receipts were already replaced by explicit no-surface-credit environment contracts; no HARD_RED external callable receives strict credit."}});
  }
  proofs.sort((a,b)=>a.surfaceKey.localeCompare(b.surfaceKey));assert.deepEqual(proofs.map(({surfaceKey,mode})=>({surfaceKey,mode})),supportedSurfaceRows);
  return{schemaVersion:1,route:"REGISTERED_CERTIFIED_PRODUCER",proofKind,family:"FinalConvergencePackageReadWorldA2B22",surfaceDigest:surface.digest,domain:"Exact 24 package-owned storage-backed read/publication wrappers. Public wrapper ASTs are unchanged from the reviewed 24-row family; every credited package dependency is rebound to a current consolidated authority, while InventoryDurableStorage.readWorld / InventoryClock.now remain explicit no-surface-credit environment assumptions.",allAdmittedInputs:true,sampledInputs:0,producerGraphRuns:0,producerReplayRuns:0,reverseReruns:0,externalSurfaceCreditGranted:false,creditExpansion:false,inputs:[...inputs.values()].sort((a,b)=>a.file.localeCompare(b.file)),proofs};
}
