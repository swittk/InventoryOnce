import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { discoverCompilerSurface, sha256 } from "../surface-bindings/lib/compiler-surface.mjs";
import { buildFinalHeadTransport, FINAL_SURFACE_DIGEST } from "./final-head-transport.mjs";
import { verifySparseRecordCertificate, SPARSE_RECORD_RECEIPT } from "../r134-sparse-record-shared-currentization/sparse-record-certificate.mjs";

export const proofKind = "final-convergence-r137-transfer-correction-v15-v1";
const TRANSITION = "experiments/tla-conformance/r137-transfer-correction-r118-currentization/transition-classification.json";
const TRANSITION_CHECKER = "experiments/tla-conformance/r137-transfer-correction-r118-currentization/check-transition.mjs";
const TRANSPORT = "experiments/tla-conformance/final-convergence/final-head-transport.json";
const FAMILY_FILES = Object.freeze([
  "experiments/tla-conformance/throughput-r7/evidence/transfer-correction-values.json",
  "experiments/tla-conformance/throughput-r7/evidence/queue-surface-final-v2-values.json",
  "experiments/tla-conformance/throughput-r7/evidence/queue-migration-materialize-v1-values.json",
  "experiments/tla-conformance/throughput-r7/evidence/queue-traceability-apply-v1-values.json",
]);
const EXPECTED_COUNTS = Object.freeze(new Map([
  ["inventoryonce-transfer-correction-complete-source-equations-v2", 11],
  ["surface-residual-final-projection-values-v2-v1", 2],
  ["migration-durable-world-materialize-complete-values-v1", 1],
  ["traceability-apply-changes-complete-value-v1", 1],
]));
function readJson(file) { return JSON.parse(fs.readFileSync(path.resolve(file), "utf8")); }
function ref(file) { const bytes = fs.readFileSync(path.resolve(file)); return { file, sha256: sha256(bytes) }; }
function live(surface, key) { const rows = surface.callables.filter((row) => row.key === key); assert.equal(rows.length, 1, `Missing current R137 callable ${key}`); return rows[0]; }
function transportReceipt() { const built = buildFinalHeadTransport(); const recorded = readJson(TRANSPORT); assert.deepEqual(recorded, built); return { ...ref(TRANSPORT), contentSha256: built.contentSha256 }; }
function transitionReceipt() {
  const row = readJson(TRANSITION);
  assert.equal(row.status, "CURRENT_R118_TRANSFER_CORRECTION_TRANSITION_CLASSIFIED");
  assert.equal(row.sourceBase, "6cafd49ff4b3729f80ae35d9fc0220f7a8a4b55a");
  assert.equal(row.surfaceDigest, "cc97e53a60ad9a4a700ee0c21f926e05b3a09dbd1ee739d94354a228fc47877a");
  assert.equal(row.equations.total, 76);
  assert.equal(row.equations.unchanged, 66);
  assert.equal(row.equations.transitioned, 10);
  assert.equal(row.equations.rows.length, 10);
  const rewrites = row.equations.rows.reduce((result, item) => {
    for (const [key, value] of Object.entries(item.rewrites)) result[key] = (result[key] ?? 0) + value;
    return result;
  }, {});
  assert.deepEqual(rewrites, {
    createInventorySparseRecord: 7,
    inventorySparseRecordValue: 16,
    setInventorySparseRecordValue: 4,
    cloneInventorySparseRecord: 6,
  });
  const sparse = verifySparseRecordCertificate();
  assert.equal(sparse.status, "CURRENT_INDEPENDENT_SPARSE_RECORD_EQUATIONS");
  return {
    transition: { ...ref(TRANSITION), contentSha256: row.contentSha256, equations: row.equations },
    checker: ref(TRANSITION_CHECKER),
    sparse: { evidence: ref(SPARSE_RECORD_RECEIPT), proofKind: sparse.proofKind ?? "r134-current-independent-sparse-record-equations-v1" },
  };
}

export const supportedSurfaceKeys = Object.freeze(FAMILY_FILES.flatMap((file) => readJson(file).proofs.map((proof) => proof.surfaceKey)).sort());
assert.equal(supportedSurfaceKeys.length, 15);
assert.equal(new Set(supportedSurfaceKeys).size, 15);

export function buildFamilyArtifact({ repositoryRoot = process.cwd(), surface = discoverCompilerSurface(repositoryRoot) } = {}) {
  assert.equal(surface.digest, FINAL_SURFACE_DIGEST);
  const transport = transportReceipt();
  const transition = transitionReceipt();
  const proofs = [];
  const inputs = new Map();
  const add = (file) => { if (!inputs.has(file)) inputs.set(file, ref(file)); };
  for (const file of [...FAMILY_FILES, TRANSITION, TRANSITION_CHECKER, SPARSE_RECORD_RECEIPT, TRANSPORT, "src/corrections.ts", "src/facade.ts", "src/projection.ts", "src/transfers.ts", "src/storage.ts", "src/migrations.ts", "src/traceability.ts"]) add(file);
  let currentTransferCorrectionIdentity;
  for (const file of FAMILY_FILES) {
    const historical = readJson(file);
    const expectedCount = EXPECTED_COUNTS.get(historical.proofKind);
    assert.notEqual(expectedCount, undefined, `Unexpected R137 proof kind ${historical.proofKind}`);
    assert.equal(historical.proofs.length, expectedCount);
    for (const old of historical.proofs) {
      const callable = live(surface, old.surfaceKey);
      assert.equal(old.signatureHash, callable.signatureHash, `R137 signature drifted: ${old.surfaceKey}`);
      const semantics = {
        historicalProofKind: historical.proofKind,
        historicalEvidence: ref(file),
        historicalSemantics: structuredClone(old.semantics ?? old.semantic ?? old),
        r118Transition: transition,
        finalHeadTransport: transport,
      };
      if (historical.proofKind !== "inventoryonce-transfer-correction-complete-source-equations-v2") {
        assert.notEqual(currentTransferCorrectionIdentity, undefined, "Dependent R137 family must follow the current transfer/correction11 authority.");
        semantics.currentTransferCorrection11 = currentTransferCorrectionIdentity;
      }
      proofs.push({
        surfaceKey: old.surfaceKey,
        signatureHash: callable.signatureHash,
        declaration: callable.declaration,
        semantics,
      });
    }
    if (historical.proofKind === "inventoryonce-transfer-correction-complete-source-equations-v2") {
      currentTransferCorrectionIdentity = {
        proofKind: historical.proofKind,
        rows: 11,
        evidence: ref(file),
        transitionContentSha256: transition.transition.contentSha256,
      };
    }
  }
  proofs.sort((a, b) => a.surfaceKey.localeCompare(b.surfaceKey));
  assert.deepEqual(proofs.map((proof) => proof.surfaceKey), supportedSurfaceKeys);
  return {
    schemaVersion: 1,
    proofKind,
    family: "FinalConvergenceR137TransferCorrectionV15",
    surfaceDigest: surface.digest,
    domain: "Exact 15 public V rows: the transfer/correction11 complete source family plus projection2, migration-materialize1, and traceability-apply1. R137 proves 76 complete equations on final pre-R144 source (66 unchanged, 10 exact sparse-record transitions); dependent families consume that current11 authority. The single final-head transport proves later projection/traceability/transfers edits are alpha/comment-only and R144 storage/cutover semantics are outside these value equations.",
    allAdmittedInputs: true,
    sampledInputs: 0,
    creditExpansion: false,
    inputs: [...inputs.values()].sort((a, b) => a.file.localeCompare(b.file)),
    proofs,
  };
}
