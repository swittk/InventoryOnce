import assert from "node:assert/strict";
import { readAssuranceFile, assuranceFileSha256 } from "../../../scripts/assurance-files.mjs";
import { epochRegistryRows } from "./final-families.mjs";

const DIRECTORY = "experiments/tla-conformance/final-convergence/";
/** Derive exact strict/external membership without compiler reparsing or any caller-CWD file resolution. */
export function buildFinalRegistry(root) {
  const valueFile = DIRECTORY + "final-v309.json", producerFile = DIRECTORY + "final-a121-b58.json";
  const value = JSON.parse(readAssuranceFile(root, valueFile)), producer = JSON.parse(readAssuranceFile(root, producerFile));
  assert.equal(value.proofKind, "final-convergence-value-v309-v1");
  assert.equal(producer.proofKind, "final-convergence-producer-a121-b58-v1");
  assert.equal(value.proofs.length, 309); assert.equal(producer.proofs.length, 179);
  assert.equal(value.surfaceDigest, producer.surfaceDigest);
  const values = new Set(value.proofs.map(row => row.surfaceKey));
  const producers = new Map(producer.proofs.map(row => [row.surfaceKey, row.mode]));
  assert.equal(values.size, 309); assert.equal(producers.size, 179);
  const valueRef = { file: valueFile, sha256: assuranceFileSha256(root, valueFile) };
  const producerRef = { file: producerFile, sha256: assuranceFileSha256(root, producerFile) };
  const bindings = epochRegistryRows.map(row => {
    if (row.mode === "HARD_RED") return structuredClone(row);
    if (row.mode === "V") { assert(values.has(row.surfaceKey)); return { surfaceKey: row.surfaceKey, mode: row.mode, evidence: valueRef }; }
    assert.equal(producers.get(row.surfaceKey), row.mode);
    return { surfaceKey: row.surfaceKey, mode: row.mode, evidence: producerRef };
  });
  assert.equal(bindings.length, 535);
  return { schemaVersion: 1, owner: "InventoryOnceEpochMilliseconds", bindings };
}
